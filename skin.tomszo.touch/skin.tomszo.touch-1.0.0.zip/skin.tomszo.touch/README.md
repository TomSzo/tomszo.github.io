# TomSzo Touch (skin.tomszo.touch)

Érintésre optimalizált, könnyű Kodi skin **Kodi 22 „Piers”**-hez, elsősorban **Androidra**
(telefon, tablet, érintőképernyős TV-box). A Kodi gyári **Estuary** skinjének (4.1.0) forkja,
ezért minden ablak és funkció ugyanúgy működik, mint a gyári felszínen.

## Mi más, mint az Estuary?

| Terület | Változás |
|---------|----------|
| Érintős mód | **Alapból bekapcsolva** – képernyőn lévő *Vissza*, *Beállítások*, *Hangerő*, *Kedvencek* gombok, görgetősáv a kezdőlap-sorokon |
| Videó OSD | Nagy, középre helyezett gombok: **-10 mp · lejátszás/szünet · +30 mp** |
| Méretek | Listasorok 75 → 100 px, oldalmenü 80 → 96 px, beállítás-gombok 70 → 86 px |
| Sebesség | Dia animációk **alapból kikapcsolva** (csak áttűnés) |
| Kinézet | Új zöldeskék kiemelőszín, saját ikon és háttérkép |
| Méret | Csak angol + magyar nyelvi fájl |

## Érintés-gesztusok (Kodi alapértelmezés)

| Gesztus | Művelet |
|---------|---------|
| Koppintás | kiválasztás (lejátszás közben: OSD megnyitása) |
| Hosszú nyomás / kétujjas koppintás | helyi menü |
| Kétujjas húzás balra | vissza |
| Kétujjas húzás jobbra | oldalmenü |
| Lejátszás közben húzás balra / jobbra | kis ugrás vissza / előre |
| Lejátszás közben húzás fel / le | nagy ugrás / fejezet előre / vissza |
| Háromujjas koppintás lejátszás közben | lejátszás / szünet |

## Beállítás

- **Távirányítóval használod?** *Beállítások → Felszín → Felszín beállítása → Általános* → kapcsold ki az **Érintős mód**-ot.
- **Animációk vissza:** ugyanitt a **Dia animációk használata**.
- **Kis kijelzőn (telefon) minden túl apró?** *Beállítások → Felszín → Nagyítás* (pl. +6 … +10 %).

## Licenc

Az Estuary licence alapján: CC BY-SA 4.0 és GNU GPL 2.0.
Eredeti szerzők: phil65, Ichabod Fletchman (Team Kodi).
