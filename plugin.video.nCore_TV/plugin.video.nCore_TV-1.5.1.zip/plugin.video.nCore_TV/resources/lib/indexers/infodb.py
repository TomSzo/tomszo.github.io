# -*- coding: utf-8 -*-
"""
Lista-kiegészítő adatok IMDb-azonosító alapján (bal oldali leírás-panelhez):
  - TMDb:  magyar (ha nincs: angol) leírás, műfaj, TMDb pontszám
  - OMDb:  IMDb pontszám + szavazatszám, Rotten Tomatoes, Metacritic   (API-kulcs kell)
  - MDBList: ugyanezek OMDb-kulcs helyett                               (API-kulcs kell)
A kulcsot a saját beállításból, vagy ha üres, a TMDb Helper beállításaiból veszi.
Gyorsítótár: <profil>/infocache.json (7 nap; sikertelen lekérés: 1 nap).
"""
import json
import os
import threading
import time

import requests
import xbmc
import xbmcaddon
from xbmcvfs import translatePath

addon = xbmcaddon.Addon()

CACHE_FILE = 'infocache.json'
CACHE_MAX = 3000
TTL_OK = 7 * 86400
TTL_MISS = 86400
BUDGET = 8.0          # mp - ennyi után a még hiányzókat kihagyjuk (következő megnyitáskor pótolja)
WORKERS = 8

_lock = threading.Lock()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[nCore_TV/infodb] %s' % msg, level)


def _cache_path():
    path = translatePath(addon.getAddonInfo('profile'))
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            pass
    return os.path.join(path, CACHE_FILE)


def _load():
    try:
        with open(_cache_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save(data):
    try:
        if len(data) > CACHE_MAX:
            for k in sorted(data, key=lambda k: data[k].get('ts', 0))[:len(data) - CACHE_MAX]:
                data.pop(k, None)
        with open(_cache_path(), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception as e:
        _log('mentési hiba: %s' % e, xbmc.LOGWARNING)


def _ext_setting(addon_id, key):
    try:
        return xbmcaddon.Addon(addon_id).getSetting(key).strip()
    except Exception:
        return ''


def _keys():
    omdb = addon.getSetting('omdb_key').strip() or _ext_setting('plugin.video.themoviedb.helper', 'omdb_apikey')
    mdbl = addon.getSetting('mdblist_key').strip() or _ext_setting('plugin.video.themoviedb.helper', 'mdblist_apikey')
    return omdb, mdbl


def _num(v):
    try:
        return float(str(v).replace(',', '').replace('%', '').split('/')[0])
    except Exception:
        return None


def _tmdb(imdb, kind, tmdb_key):
    out = {}
    for lang in ('hu-HU', 'en-US'):
        r = requests.get('https://api.themoviedb.org/3/find/%s' % imdb, timeout=6,
                         params={'api_key': tmdb_key, 'external_source': 'imdb_id', 'language': lang})
        j = r.json() if r.ok else {}
        res = (j.get('movie_results') or []) + (j.get('tv_results') or [])
        if kind == 'series' and j.get('tv_results'):
            res = j['tv_results']
        if not res:
            return out
        m = res[0]
        if not out:
            out = {'tmdb': _num(m.get('vote_average')), 'tmdb_votes': m.get('vote_count') or 0,
                   'year': (m.get('release_date') or m.get('first_air_date') or '')[:4],
                   'title': m.get('title') or m.get('name') or ''}
        if (m.get('overview') or '').strip():
            out['overview'] = m['overview'].strip()
            break
    return out


def _omdb(imdb, key):
    r = requests.get('https://www.omdbapi.com/', params={'i': imdb, 'apikey': key}, timeout=6)
    j = r.json() if r.ok else {}
    if j.get('Response') != 'True':
        return {}
    out = {'imdb': _num(j.get('imdbRating')), 'imdb_votes': int(_num(j.get('imdbVotes')) or 0),
           'genre': j.get('Genre') if j.get('Genre') not in (None, 'N/A') else ''}
    for rt in j.get('Ratings') or []:
        src, val = rt.get('Source', ''), rt.get('Value', '')
        if src == 'Rotten Tomatoes':
            out['rt'] = _num(val)
        elif src == 'Metacritic':
            out['mc'] = _num(val)
    if j.get('Metascore') not in (None, 'N/A') and out.get('mc') is None:
        out['mc'] = _num(j['Metascore'])
    return out


def _mdblist(imdb, key):
    r = requests.get('https://mdblist.com/api/', params={'apikey': key, 'i': imdb}, timeout=6)
    j = r.json() if r.ok else {}
    out = {}
    for rt in j.get('ratings') or []:
        src, val = rt.get('source'), rt.get('value')
        if val is None:
            continue
        if src == 'imdb':
            out['imdb'] = _num(val)
            out['imdb_votes'] = int(rt.get('votes') or 0)
        elif src == 'tomatoes':
            out['rt'] = _num(val)
        elif src == 'tomatoesaudience':
            out['rta'] = _num(val)
        elif src == 'metacritic':
            out['mc'] = _num(val)
    return out


def _fetch(imdb, kind, tmdb_key, omdb_key, mdbl_key):
    """None = hálózati hiba (nem kerül a gyorsítótárba, legközelebb újra próbálja)."""
    info = {}
    try:
        info.update(_tmdb(imdb, kind, tmdb_key))
    except Exception as e:
        _log('TMDb %s: %s' % (imdb, e), xbmc.LOGDEBUG)
        return None
    try:
        if omdb_key:
            info.update({k: v for k, v in _omdb(imdb, omdb_key).items() if v not in (None, '')})
        if mdbl_key and (not omdb_key or info.get('rt') is None):
            info.update({k: v for k, v in _mdblist(imdb, mdbl_key).items() if v not in (None, '')})
    except Exception as e:
        _log('pontszám %s: %s' % (imdb, e), xbmc.LOGDEBUG)
    return info


def lookup(imdb_ids, kind, tmdb_key):
    """{imdb: info} - gyorsítótárból, a hiányzókat párhuzamosan lekéri (időkorláttal)."""
    ids = [i for i in dict.fromkeys(imdb_ids) if i and str(i).startswith('tt')]
    if not ids:
        return {}
    cache = _load()
    now = time.time()
    omdb_key, mdbl_key = _keys()
    has_score_key = bool(omdb_key or mdbl_key)

    def fresh(e):
        if not e:
            return False
        ttl = TTL_OK if e.get('info') else TTL_MISS
        if has_score_key and e.get('info') and not e.get('scored'):
            return False        # azóta lett kulcs -> pontszámok pótlása
        return now - e.get('ts', 0) < ttl

    todo = [i for i in ids if not fresh(cache.get(i))]
    if todo:
        results = {}

        def worker(chunk):
            for imdb in chunk:
                if time.time() - now > BUDGET:
                    return
                results[imdb] = _fetch(imdb, kind, tmdb_key, omdb_key, mdbl_key)

        n = min(WORKERS, len(todo))
        threads = [threading.Thread(target=worker, args=(todo[k::n],)) for k in range(n)]
        for t in threads:
            t.daemon = True
            t.start()
        for t in threads:
            t.join(max(0.1, BUDGET + 6 - (time.time() - now)))
        for imdb, info in list(results.items()):
            if info is not None:
                cache[imdb] = {'ts': now, 'info': info, 'scored': has_score_key}
        with _lock:
            _save(cache)
        _log('%d/%d új lekérés (%.1f mp)' % (len(results), len(todo), time.time() - now))
    return {i: (cache.get(i) or {}).get('info') or {} for i in ids}


def score_line(info, fallback_imdb=''):
    """'IMDb 7.8 (123 e) · RT 92% · MC 71 · TMDb 7.5' színezve."""
    parts = []
    imdb = info.get('imdb') or _num(fallback_imdb)
    if imdb:
        votes = info.get('imdb_votes') or 0
        if votes >= 1000000:
            vt = ('%.1f M' % (votes / 1e6)).replace('.', ',')
        elif votes >= 1000:
            vt = '%d e' % round(votes / 1000.0)
        else:
            vt = str(votes)
        v = (' [COLOR gray](%s)[/COLOR]' % vt) if votes else ''
        parts.append('[COLOR FFF5C518][B]IMDb[/B] %.1f[/COLOR]%s' % (imdb, v))
    rt = info.get('rt')
    if rt is not None:
        col = 'FFFA320A' if rt >= 60 else 'FF7CB342'
        parts.append('[COLOR %s][B]RT[/B] %d%%[/COLOR]' % (col, rt))
    if info.get('rta') is not None:
        parts.append('[COLOR FFFA320A]Közönség %d%%[/COLOR]' % info['rta'])
    mc = info.get('mc')
    if mc is not None:
        col = 'FF66CC33' if mc >= 61 else ('FFFFCC33' if mc >= 40 else 'FFFF0000')
        parts.append('[COLOR %s][B]MC[/B] %d[/COLOR]' % (col, mc))
    if info.get('tmdb'):
        parts.append('[COLOR FF01B4E4][B]TMDb[/B] %.1f[/COLOR]' % info['tmdb'])
    return '  ·  '.join(parts)
