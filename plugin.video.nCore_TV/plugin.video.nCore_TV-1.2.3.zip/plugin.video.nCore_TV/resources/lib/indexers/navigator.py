# -*- coding: utf-8 -*-

'''
    nCore TV Addon
    Copyright (C) 2025 heg
    Módosítások (fork): Copyright (C) 2026 TomSzo, módosítva: 2026-09-20 (lásd CHANGELOG.md)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os, sys, re, xbmc, xbmcgui, xbmcvfs, xbmcplugin, xbmcaddon, locale, base64, json, time
from urllib.parse import urlparse, quote, unquote, unquote_plus, quote_plus, parse_qs
from bs4 import BeautifulSoup, SoupStrainer
import requests, time, html
import urllib.parse
from datetime import datetime, timedelta
from xbmcvfs import translatePath
import xml.etree.ElementTree as ET
import pyxbmct
from pyxbmct import AddonDialogWindow, Label, List, Button, RadioButton

from .static_data import *
from resources.lib.indexers.github_sync import GitHubSyncManager
from resources.lib.indexers.extend_search import ExtendedSearchWindow
from resources.lib.indexers.pause_menu import PlaybackInterceptor, PlaybackSettingsMenu
from resources.lib.indexers.trakt_parts import TraktInterface
from resources.lib.indexers.simkl_tracks import SimklInterface
from resources.lib.indexers.plex_tracks import PlexInterface
from resources.lib.indexers.auth_error_window import AuthErrorWindow
from resources.lib.nc_http import nc_get, nc_post
from resources.lib.indexers import quality
from resources.lib.indexers.rating_manager import RatingManagerWindow

import threading

profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

local_addon_path = xbmcaddon.Addon().getAddonInfo('path')
local_modules_path = os.path.join(local_addon_path, 'resources', 'lib', 'modules')
if local_modules_path not in sys.path:
    sys.path.append(local_modules_path)
import PTN

# Widget-hívás (skin widget / háttérfrissítés): modális ablak nem jelenhet meg
IS_WIDGET = 'widget=1' in (sys.argv[2] if len(sys.argv) > 2 else '')

def _lite_on():
    """Gyors mód (alapból be): nincs borító/fanart a listákban, nyers torrentnév leírásként."""
    return addon.getSetting('lite_mode') != 'false'

_BOX_STRAINER = SoupStrainer('div', class_='box_torrent')
_ERR_MARKERS = ('id="error"', "id='error'", 'hnr_torrents', 'lista_mini_error')
_RE_NPA = re.compile(r'<a\b[^>]*\bid=["\']nPa["\'][^>]*>.*?</a>', re.I | re.S)

class _FastSoup(object):
    """
    BeautifulSoup-helyettes a találati oldalakhoz. A teljes oldal html.parser-es felépítése a lista-nyitás
    legdrágább lépése; itt csak a box_torrent blokkokat építjük fel (~2x gyorsabb). Minden más művelet
    (más tag keresése, str()) lusta módon a teljes soup-on fut, így a viselkedés azonos marad.
    """
    def __init__(self, text):
        self._text = text or ''
        self._boxes = None
        self._full = None

    def _full_soup(self):
        if self._full is None:
            self._full = BeautifulSoup(self._text, 'html.parser')
        return self._full

    def find_all(self, name=None, *args, **kwargs):
        if name == 'div' and not args and kwargs.get('class_') == 'box_torrent' and len(kwargs) == 1:
            if self._boxes is None:
                self._boxes = BeautifulSoup(self._text, 'html.parser', parse_only=_BOX_STRAINER).find_all('div', class_='box_torrent')
            return self._boxes
        return self._full_soup().find_all(name, *args, **kwargs)

    def find(self, name=None, *args, **kwargs):
        if name == 'a' and not args and kwargs.get('id') == 'nPa' and len(kwargs) == 1:
            if 'nPa' not in self._text:
                return None
            m = _RE_NPA.search(self._text)
            if m:
                return BeautifulSoup(m.group(0), 'html.parser').find('a', id='nPa')
        return self._full_soup().find(name, *args, **kwargs)

    def __str__(self):
        # known_errors() a soup-szerializációra keres; hibaoldal csak ritkán van, ott a teljes útvonal fut
        if any(m in self._text for m in _ERR_MARKERS):
            return str(self._full_soup())
        return ''

    def __getattr__(self, item):
        return getattr(self._full_soup(), item)

_STR_CACHE = {}
def _tstr(el):
    """str(tag) egyszeri szerializálása elemenként (korábban elemenként 3-4x)."""
    hit = _STR_CACHE.get(id(el))
    if hit is not None and hit[0] is el:
        return hit[1]
    if len(_STR_CACHE) > 400:
        _STR_CACHE.clear()
    out = str(el)
    _STR_CACHE[id(el)] = (el, out)
    return out

def _local_tracking_on():
    return addon.getSetting('local_tracking_enabled') != 'false'

def _season_pack_menu_on():
    return addon.getSetting('season_pack_menu_enabled') != 'false'

enable_2fa = addon.getSetting('enable_2fa') == 'true'
session_valid_2fa = addon.getSetting('session_valid_2fa') == 'true'
length_2fa = 6

custom_view_list = addon.getSetting('custom_view_list')
fixed_wide_view = 'series'
user_change_view = 'movies'

simkl_notif_icon = "special://home/addons/plugin.video.nCore_TV/resources/simkl_notif.png"
trakt_notif_icon = "special://home/addons/plugin.video.nCore_TV/resources/trakt_notif.png"
plex_notif_icon = "special://home/addons/plugin.video.nCore_TV/resources/plex_notif.png"

simkl_notif = addon.getSetting('simkl_notif_enabled') == 'true'
trakt_notif = addon.getSetting('trakt_notif_enabled') == 'true'
plex_notif = addon.getSetting('plex_notif_enabled') == 'true'

### Kodi colors:
#[COLOR ]
# red #green #blue #yellow #orange #pink #purple #cyan #gray #white #black #gold
# silver #brown #lime #magenta #lightblue #lightgreen #lightgray #lightpink #lightyellow
#[/COLOR]

def log_debug(message):
    xbmc.log(f'{base_log_info} | pass_cookie info | {message}', xbmc.LOGINFO)

def known_errors(soup_string):
    if IS_WIDGET:
        if re.search('<div id="error">|<div class="hnr_torrents"><br/>Az általad|<div class="lista_mini_error">Jelenleg nem futtat', soup_string):
            xbmc.log('[nCore_TV] widget: hibaoldal, üres lista', xbmc.LOGINFO)
            return True
        return False
    if re.search('<div id="error">', soup_string):
        message = "Az oldalon karbantartás van!"
        xbmcgui.Dialog().ok("Hiba", message)
        return True
    
    if re.search('<div class="hnr_torrents"><br/>Az általad letöltött anyagokat', soup_string):
        message = "Az általad letöltött anyagokat a szabályoknak megfelelően visszaosztottad, a listád ennek köszönhetően üres."
        xbmcgui.Dialog().ok("Nem található torrent!", message)
        return True
        
    if re.search('<div class="lista_mini_error">Jelenleg nem futtat egyetlen', soup_string):
        message = "Jelenleg nem futtat egyetlen torrentet sem."
        xbmcgui.Dialog().ok("Nem található torrent!", message)
        return True

    return False

def force_login_if_requested():
    if addon.getSetting("force_login") == "true":
        addon.setSetting("saved_pass_cookie", "")
        addon.setSetting("last_update", "")
        addon.setSetting("pass_k", "")
        addon.setSetting("session_valid_2fa", "false")
        #xbmc.log("Force login: cleared saved_pass_cookie, last_update, pass_k, and session_valid_2fa.", level=xbmc.LOGINFO)
        addon.setSetting("force_login", "false")

def validate_tokens():
    invalid_values = ["", "deleted", "true"]
    saved_pass = addon.getSetting("saved_pass_cookie")
    pass_k_val = addon.getSetting("pass_k")
    
    if saved_pass in invalid_values:
        addon.setSetting("saved_pass_cookie", "")
        addon.setSetting("session_valid_2fa", "false")
    if pass_k_val in invalid_values:
        addon.setSetting("pass_k", "")

def prompt_for_2fa_code():
    dialog = xbmcgui.Dialog()
    while True:
        two_factor_code = dialog.input(
            heading=f"Kétlépcsős azonosítási kód (pontosan {length_2fa} számjegy)",
            type=xbmcgui.INPUT_NUMERIC,
            defaultt="",
        )

        if two_factor_code is None:
            return None

        if two_factor_code.isdigit() and len(two_factor_code) == length_2fa:
            return two_factor_code
        else:
            dialog.notification(
                "Érvénytelen kód",
                f"A kódnak pontosan {length_2fa} számjegyből kell állnia.",
                time=3000
            )

def fetch_and_update_cookie(two_factor_code=None):
    try:
        data_x = {
            'set_lang': 'hu',
            'submitted': '1',
            'nev': user_name,
            'pass': pass_word,
            'ne_leptessen_ki': '1'
        }

        if enable_2fa and two_factor_code:
            data_x['2factor'] = two_factor_code
            #log_debug(f"Attempting login with 2FA code: {two_factor_code}")
        elif enable_2fa and not two_factor_code:
            xbmc.log("2FA is enabled but no code was provided for login attempt.", xbmc.LOGWARNING)


        resp = nc_post(f'{base_url}/login.php', headers=headers, data=data_x, allow_redirects=False)
        response_text_lower = resp.text.lower()

        if "sikertelen bejelentkezés" in response_text_lower or "hibás felhasználónév vagy jelszó" in response_text_lower:
            #xbmc.log("Login failed: Incorrect username/password.", xbmc.LOGINFO)
            handle_failed_attempt(reason="Hibás felhasználónév vagy jelszó.")
            return False

        if "a kétlépcsős azonosító kód helytelen" in response_text_lower:
            xbmcgui.Dialog().ok("Login Error", "A megadott kétlépcsős azonosító kód helytelen.")
            addon.setSetting("session_valid_2fa", "false")
            handle_failed_attempt(reason="Helytelen 2FA kód.")
            return False

        if resp.status_code != 302:
            xbmc.log(f'Login failed: Expected 302 redirect but got status: {resp.status_code}', xbmc.LOGINFO)
            handle_failed_attempt(reason=f"Váratlan HTTP státusz kód: {resp.status_code}")
            return False

        res_headers = resp.headers.get("Set-Cookie")
        if not res_headers:
            xbmc.log('Login failed: No Set-Cookie header found in response.', xbmc.LOGINFO)
            handle_failed_attempt(reason="Hiányzó Set-Cookie fejléc.")
            return False

        pass_cookie_matches = re.findall(r'pass=(.*?);', str(res_headers))
        if not pass_cookie_matches:
            #xbmc.log("Login failed: 'pass' cookie not found in Set-Cookie header.", xbmc.LOGINFO)
            handle_failed_attempt(reason="'pass' süti hiányzik.")
            return False
            
        pass_cookie = pass_cookie_matches[0].strip()
        if pass_cookie.lower() == "deleted":
            #xbmc.log("Login returned 'deleted' cookie value - invalid credentials or session.", xbmc.LOGINFO)
            handle_failed_attempt(reason="'pass' süti 'deleted' értékű.")
            return False

        cookies = {'nick': user_name, 'pass': pass_cookie}
        response = nc_get(base_url, cookies=cookies, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        if "a bejelentkezés" in response.text.lower() and "nem található" in response.text.lower():
             #xbmc.log("Login verification failed: Site still indicates login needed or user not found.", xbmc.LOGINFO)
             handle_failed_attempt(reason="Bejelentkezés ellenőrzése sikertelen a főoldalon.")
             return False

        pass_k_matches = re.findall(r'rss.php\?key=(.*?)\"', str(soup))
        if pass_k_matches:
            pass_k = pass_k_matches[0].strip()
            addon.setSetting("pass_k", pass_k)
        else:
            #xbmc.log('Login verification failed: Failed to retrieve pass_k from main page. This usually means the session is not truly active.', xbmc.LOGINFO)
            handle_failed_attempt(reason="Pass kulcs (pass_k) lekérése sikertelen.")
            return False

        addon.setSetting("saved_pass_cookie", pass_cookie)
        addon.setSetting("login_failed", "false")
        addon.setSetting("session_valid_2fa", "true")

        addon.setSetting("last_update", str(time.time()))
        #log_debug(f'Login successful. last_update set to: {addon.getSetting("last_update")}')

        track_event("logins", "Auth: nCore", "nCore User authenticated and session cookie updated.", icon="🔄")
        return True

    except Exception as e:
        #xbmc.log(f'Error in fetch_and_update_cookie: {e}', xbmc.LOGINFO)
        handle_failed_attempt(reason=f"Váratlan hiba: {e}")
        return False

def handle_failed_attempt(reason=""):
    dialog = xbmcgui.Dialog()
    error_message = "A bejelentkezés sikertelen. Ellenőrizd újra a bejelentkezési adataidat."
    if reason:
        error_message += f"\nOk: {reason}"
    error_message += "\nAz újbóli próbálkozás előtt minimum 6 percet várni kell. A beállításokba ezt kapcsold majd be hozzá:\nBelépés újra (csak elgépelt user/pass esetén kell)"
    
    if IS_WIDGET:
        addon.setSetting("last_update", str(time.time()))
        addon.setSetting("login_failed", "true")
        addon.setSetting("session_valid_2fa", "false")
        return
    dialog.ok("Login Error", error_message)
    addon.setSetting("last_update", str(time.time()))
    addon.setSetting("login_failed", "true")
    addon.setSetting("session_valid_2fa", "false")
    addon.openSettings()
    xbmc.log("A bejelentkezés sikertelen.", level=xbmc.LOGINFO)

def should_update_cookie():
    try:
        last_update = addon.getSetting("last_update")
        login_failed = addon.getSetting("login_failed")
        saved_pass = addon.getSetting("saved_pass_cookie")

        if not saved_pass:
            #log_debug("should_update_cookie: No saved_pass_cookie, requiring update.")
            addon.setSetting("session_valid_2fa", "false")
            return True

        if login_failed == "true":
            if last_update:
                last_update_time = datetime.fromtimestamp(float(last_update))
                if datetime.now() - last_update_time < timedelta(minutes=5):
                    next_update_time = last_update_time + timedelta(minutes=5)
                    #log_debug(f'should_update_cookie: Failure cooldown active. Next update time: {next_update_time}')
                    return False
            #log_debug("should_update_cookie: Login failed and cooldown passed or no last_update, requiring update.")
            addon.setSetting("session_valid_2fa", "false")
            return True

        if last_update:
            last_update_time = datetime.fromtimestamp(float(last_update))
            refresh_threshold_time = last_update_time + timedelta(days=28) 
            
            if datetime.now() < refresh_threshold_time:
                #log_debug(f'should_update_cookie: Fixed 28-day window still valid. Next refresh around: {refresh_threshold_time}')
                return False
            else:
                #log_debug(f'should_update_cookie: Fixed 28-day window expired. Requiring update.')
                addon.setSetting("session_valid_2fa", "false")
                return True

        #log_debug("should_update_cookie: last_update missing, but saved_pass exists. Forcing update.")
        addon.setSetting("session_valid_2fa", "false")
        return True

    except Exception as e:
        #xbmc.log(f'Error in should_update_cookie: {e}', xbmc.LOGINFO)
        addon.setSetting("session_valid_2fa", "false")
        return True

if not user_name or not pass_word:
    if IS_WIDGET: sys.exit(0)
    addon.openSettings()
else:
    force_login_if_requested()
    validate_tokens()

    needs_full_login_attempt = should_update_cookie()

    current_2fa_session_valid = addon.getSetting('session_valid_2fa') == 'true'

    two_factor_code = None
    if IS_WIDGET and enable_2fa and (not current_2fa_session_valid or needs_full_login_attempt):
        sys.exit(0)  # 2FA-kód csak interaktívan kérhető
    if enable_2fa and (not current_2fa_session_valid or needs_full_login_attempt):
        #xbmc.log("2FA enabled and session not valid or full login required. Prompting for 2FA code.", xbmc.LOGINFO)
        two_factor_code = prompt_for_2fa_code()
        if not two_factor_code:
            xbmcgui.Dialog().notification("2FA hiba", "Nincs megadva 2FA kód. Bejelentkezés törölve.", xbmcgui.NOTIFICATION_ERROR)
            #xbmc.log("2FA code was not provided by user. Aborting login.", xbmc.LOGINFO)

            addon.setSetting("login_failed", "true") 
            addon.setSetting("last_update", str(time.time()))
            addon.setSetting("session_valid_2fa", "false")
            sys.exit(0)

    if needs_full_login_attempt or (enable_2fa and two_factor_code):
        login_successful = fetch_and_update_cookie(two_factor_code)
        if not login_successful:
            #xbmc.log("Initial login attempt (possibly with 2FA) failed. Stopping addon process.", xbmc.LOGINFO)
            sys.exit(0)

    saved_pass_cookie = addon.getSetting("saved_pass_cookie")
    pass_k = addon.getSetting("pass_k")
    session_valid_2fa = addon.getSetting("session_valid_2fa") == 'true'

    if enable_2fa and not session_valid_2fa:
        #xbmc.log("2FA is enabled, but session is invalid. This indicates a critical authentication problem.", xbmc.LOGINFO)
        xbmcgui.Dialog().ok("2FA hiba", "A kétlépcsős azonosítás engedélyezve van, de a munkamenet érvénytelen. Próbáld meg újra a bejelentkezést a beállításokban.")
        addon.openSettings()
        sys.exit(0)

#########

def check_exist_elementum():
    check_dir = xbmcvfs.translatePath('special://home/addons/plugin.video.elementum')
    if not os.path.exists(check_dir):
        raise FileNotFoundError('Az Elementum nincs telepítve!')

def determineDisplayName(context, full_url):
    pattern = r'kivalasztott_tipus%5B%5D=([^&]+)&'
    raw_matches = re.findall(pattern, full_url)
    types = [unquote(m) for m in raw_matches]
    lower_types = [t.lower() for t in types]

    if "nyit_zene_resz=true" in full_url.lower():
        if any(t.endswith("_hun") for t in lower_types):
            return "[B]Kereső [COLOR lime]HU[/COLOR][/B] > Zene, Clip"
        else:
            return "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > Zene, Clip"

    if "nyit_sorozat_resz=true" in full_url.lower():
        if len(types) == 4:
            if all("_hun" in t for t in lower_types):
                return "[B]Kereső [COLOR lime]HU[/COLOR][/B] > Sorozat & Film" if context == "newsearch" else "[B]Kereső [COLOR lime]HU[/COLOR][/B] > imdb_id"
            else:
                return "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film" if context == "newsearch" else "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > imdb_id"
        elif len(types) == 2:
            if all("_hun" in t for t in lower_types):
                return "[B]Kereső [COLOR lime]HU[/COLOR][/B] > Sorozat"
            else:
                return "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat"

    if "nyit_filmek_resz=true" in full_url.lower() and "nyit_sorozat_resz=true" not in full_url.lower():
        if len(types) == 2:
            if all("_hun" in t for t in lower_types):
                return "Kereső [B][COLOR lime]HU[/COLOR][/B] > Film"
            else:
                return "Kereső [B][COLOR FFF56C00]EN[/COLOR][/B] > Film"
        elif len(types) == 4:
            if all("_hun" in t for t in lower_types):
                return "[B]Kereső [COLOR lime]HU[/COLOR][/B] > Sorozat & Film" if context == "newsearch" else "[B]Kereső [COLOR lime]HU[/COLOR][/B] > imdb_id"
            else:
                return "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film" if context == "newsearch" else "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > imdb_id"

    prefixes = []
    for t in types:
        if "_" in t:
            prefixes.append(t.split("_")[0])
    if prefixes and len(set(prefixes)) == 1:
        common_prefix = prefixes[0]
        return f"Kereső > {common_prefix.upper()}"

    if len(types) == 4:
        if all("_hun" in t for t in lower_types):
            return "Kereső [B][COLOR lime]HU[/COLOR][/B] > Sorozat & Film" if context == "newsearch" else "[B]Kereső [COLOR lime]HU[/COLOR][/B] > imdb_id"
        else:
            return "Kereső [B][COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film" if context == "newsearch" else "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > imdb_id"
    elif len(types) == 2:
        if all("_hun" in t for t in lower_types):
            return "[B]Kereső [COLOR lime]HU[/COLOR][/B] > Film"
        else:
            return "[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B] > Film"
    
    return "Keresés"

def date_picker(selected_date):
    from datetime import datetime, timedelta
    import xbmcgui

    today = (datetime.now()).strftime('%d/%m/%Y')

    dialog = xbmcgui.Dialog()
    date_input = dialog.input(
        heading="Állítsd be a dátumot\n  nap/hónap/év",
        defaultt=today,
        type=xbmcgui.INPUT_DATE
    )

    if date_input:
        date_input = date_input.replace(' ', '').strip()
        try:
            date_input_change = datetime.strptime(date_input, '%d/%m/%Y')
            selected_date = date_input_change.strftime('%Y-%m-%d')
        except ValueError as e:
            xbmcgui.Dialog().notification("Hiba", f"Érvénytelen dátumformátum: {e}", xbmcgui.NOTIFICATION_ERROR)

    return selected_date

def parse_release_robust(name):
    upper_name = name.upper()
    data = {
        "original_name": name,
        "seasons": set(),
        "episode": None,
        "is_complete": "COMPLETE" in upper_name or "SERIES" in upper_name
    }

    episode_match = re.search(r'\bS(\d{1,2})E(\d{1,2})\b', upper_name)
    if episode_match:
        data["seasons"].add(int(episode_match.group(1)))
        data["episode"] = int(episode_match.group(2))
        return data

    range_match = re.search(r'\bS(\d{1,2})[.\- ]{1,3}S?(\d{1,2})\b', upper_name)
    if range_match:
        try:
            start, end = int(range_match.group(1)), int(range_match.group(2))
            if start < end:
                data["seasons"].update(range(start, end + 1))
                return data
        except (ValueError, IndexError):
            pass

    season_matches = re.findall(r'\bS(\d{1,2})\b', upper_name)
    if season_matches:
        for s_num in season_matches:
            data["seasons"].add(int(s_num))
        return data

    return data

class navigator:
    def __init__(self):
        self.base_path = translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(self.base_path):
            try:
                os.makedirs(self.base_path)
            except: pass

        self.searchFileName = os.path.join(self.base_path, "search_history.json")
        self.local_played_torrents_file = os.path.join(self.base_path, 'played_torrents.json')
        self.merged_played_torrents_filename = os.path.join(self.base_path, 'all_merged_played_torrents.json')
        self.saved_device_names_file = os.path.join(self.base_path, "saved_device_names.json")
        self.seriesWatchFileName = os.path.join(self.base_path, "series_watch_history.json")

        self.t_path = os.path.join(self.base_path, 'trakt_status_list.json')
        self.s_path = os.path.join(self.base_path, 'simkl_status_list.json')
        self.p_path = os.path.join(self.base_path, 'plex_status_list.json')

        self.for_name = for_name
        self.for_imdb = for_imdb
        self.github_sync_manager = GitHubSyncManager()

        from resources.lib.indexers.database import DatabaseManager
        db_file = os.path.join(self.base_path, 'ncore_tv.db')
        self.db = DatabaseManager(db_file)

        is_fully_migrated = addon.getSetting('db_migration_done') == 'true'

        if not is_fully_migrated:
            xbmc.log("[nCore_TV] Első futtatás az új verzióval: Migrációs folyamat indítása...", xbmc.LOGINFO)

            self._create_legacy_backups()

            self.db.migrate_from_json(self.local_played_torrents_file)
            self.db.migrate_search_history(self.searchFileName)
            self.db.migrate_statuses(self.t_path, self.s_path, self.p_path)

            t_map = os.path.join(self.base_path, 'trakt_id_map.json')
            s_map = os.path.join(self.base_path, 'simkl_id_map.json')
            p_map = os.path.join(self.base_path, 'plex_id_map.json')
            pos_map = os.path.join(self.base_path, 'imdb_poster_map.json')
            self.db.migrate_id_maps(t_map, s_map, p_map, pos_map)

            self.db.migrate_watching_series_legacy(self.seriesWatchFileName, self.saved_device_names_file)

            old_bookmark_data = addon.getSetting('bookmark_data')

            if old_bookmark_data and len(old_bookmark_data) > 10:
                current_db_bookmarks = self.db.get_all_bookmarks()

                if not current_db_bookmarks:
                    self.db.migrate_bookmarks_from_settings(old_bookmark_data)
                    xbmc.log("[nCore_TV] Könyvjelzők migrációja SQL-be megtörtént.", xbmc.LOGINFO)

                if self.db.get_all_bookmarks():
                    addon.setSetting('bookmark_data', '')
                    xbmc.log("[nCore_TV] Régi bookmark_data kitakarítva a settings.xml-ből.", xbmc.LOGINFO)

            addon.setSetting('db_migration_done', 'true')
            xbmc.log("[nCore_TV] Minden migráció sikeresen lezajlott.", xbmc.LOGINFO)

        # Karbantartás: korábban minden plugin-hívásnál lefutott (2 JSON-fájl írása + DELETE táblátérintő subselecttel).
        # A JSON-export csak a GitHub-szinkron előtt kell (ott most kifejezetten meghívjuk),
        # az orphan-takarítás Kodi-munkamenetenként legfeljebb 6 óránként.
        try:
            _win = xbmcgui.Window(10000)
            _last = _win.getProperty('nCore_TV_maint_ts')
            if (not _last) or (time.time() - float(_last) > 21600):
                self.db.cleanup_orphans()
                _win.setProperty('nCore_TV_maint_ts', str(time.time()))
        except Exception as _e:
            xbmc.log(f"[nCore_TV] karbantartás kihagyva: {_e}", xbmc.LOGDEBUG)

    def _create_legacy_backups(self):
        import shutil
        
        files_to_protect = [
            ('played_torrents.json', 'played_torrents_original.json'),
            ('played_torrents.json.bak', 'played_torrents_original.json.bak'),
            ('search_history.json', 'search_history_original.json'),
            ('all_merged_played_torrents.json', 'all_merged_played_torrents_original.json'),
            ('all_merged_played_torrents.json.bak', 'all_merged_played_torrents_original.json.bak')
        ]
        
        for source_name, dest_name in files_to_protect:
            source_path = os.path.join(self.base_path, source_name)
            dest_path = os.path.join(self.base_path, dest_name)
            
            if os.path.exists(source_path) and not os.path.exists(dest_path):
                try:
                    shutil.copy2(source_path, dest_path)
                except Exception as e:
                    try:
                        import xbmcvfs
                        xbmcvfs.copy(source_path, dest_path)
                    except:
                        xbmc.log(f"[nCore_TV] Kritikus hiba a mentésnél: {e}", xbmc.LOGERROR)

    def _build_indicators(self, imdb_id, torrent_id, db_sync_data, db_local_played):
        import re
        indicator = ""
        plot_status_list = []
        
        if imdb_id and imdb_id in db_sync_data:
            s_data = dict(db_sync_data[imdb_id])

            if self.is_trakt_active():
                t_raw = str(s_data.get('trakt_status', "")).lower()
                if t_raw and t_raw != "none" and t_raw != "":
                    if "láttam" in t_raw or "befejezve" in t_raw:
                        indicator += "[COLOR orange][T!][/COLOR]"
                        plot_status_list.append("[COLOR orange][T] Láttam[/COLOR]")
                    elif "list" in t_raw:
                        indicator += "[COLOR yellow][T?][/COLOR]"
                        plot_status_list.append("[COLOR yellow][T] Listán[/COLOR]")
                    else:
                        match = re.search(r's\d+e\d+|(\d+%)', t_raw)
                        if match:
                            val = match.group(0).upper()
                            indicator += "[COLOR orange][T][/COLOR]"
                            plot_status_list.append(f"[COLOR orange][T] {val}[/COLOR]")

            if self.is_simkl_active():
                s_raw = str(s_data.get('simkl_status', "")).lower()
                if s_raw and s_raw != "none" and s_raw != "":
                    if any(x in s_raw for x in ["láttam", "befejezve", "completed"]):
                        indicator += "[COLOR cyan][S!][/COLOR]"
                        plot_status_list.append("[COLOR cyan][S] Láttam[/COLOR]")
                    elif "list" in s_raw:
                        indicator += "[COLOR yellow][S?][/COLOR]"
                        plot_status_list.append("[COLOR yellow][S] Listán[/COLOR]")
                    else:
                        match = re.search(r's\d+e\d+|(\d+%)', s_raw)
                        if match:
                            val = match.group(0).upper()
                            indicator += "[COLOR cyan][S][/COLOR]"
                            plot_status_list.append(f"[COLOR cyan][S] {val}[/COLOR]")

            if self.is_plex_active():
                p_raw = str(s_data.get('plex_status', "")).lower()
                if p_raw and p_raw != "none" and p_raw != "":
                    if "láttam" in p_raw or "befejezve" in p_raw:
                        indicator += "[COLOR dodgerblue][P!][/COLOR]"
                        plot_status_list.append("[COLOR dodgerblue][P] Láttam[/COLOR]")
                    elif "list" in p_raw:
                        indicator += "[COLOR yellow][P?][/COLOR]"
                        plot_status_list.append("[COLOR yellow][P] Listán[/COLOR]")
                    else:
                        match = re.search(r's\d+e\d+', p_raw)
                        if match:
                            val = match.group(0).upper()
                            indicator += "[COLOR dodgerblue][P][/COLOR]"
                            plot_status_list.append(f"[COLOR dodgerblue][P] {val}[/COLOR]")

        is_already_played = _local_tracking_on() and str(torrent_id) in db_local_played
        if is_already_played:
            indicator += "[COLOR lime][*][/COLOR]"
            plot_status_list.append("[COLOR lime][*][/COLOR]")

        if indicator:
            indicator += " - "

        plot_status_line = ""
        if plot_status_list:
            plot_status_line = " | ".join(plot_status_list) + "\n"
        
        return indicator, plot_status_line, is_already_played

    def clean_files_action(self):
        import os
        import time
        delete_type = self.params.get('type')
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        
        type_names = {
            'migrated': 'Migrált adatfájlok',
            'maps': 'ID/Poster Map fájlok',
            'backups': 'Biztonsági mentések (.bak)',
            'simkl_cache': 'Simkl JSON gyorsítótár',
            'database': 'TELJES nCore TV ADATBÁZIS'
        }

        msg = f"Biztosan törölni szeretnéd a következőt: [COLOR red]{type_names.get(delete_type)}[/COLOR]?"
        if delete_type == 'database':
            msg += "[CR][B]FIGYELEM: Minden helyi adat és beállítás elveszik![/B]"
            
        if not xbmcgui.Dialog().yesno("nCore TV - Karbantartás", msg):
            return

        deleted_count = 0
        try:
            all_files = os.listdir(profile_path)
            
            for f in all_files:
                file_path = os.path.join(profile_path, f)
                should_delete = False
                
                if delete_type == 'migrated':
                    if f.endswith('.migrated') and 'map' not in f and 'status' not in f:
                        should_delete = True
                
                elif delete_type == 'maps':
                    if '.migrated' in f and ('map' in f or 'status_list' in f or 'names' in f):
                        should_delete = True
                
                elif delete_type == 'backups':
                    if f.endswith('.bak') or '_original.json' in f:
                        should_delete = True
                
                elif delete_type == 'simkl_cache':
                    if f.startswith('simkl_') and f.endswith('.json'):
                        should_delete = True
                
                elif delete_type == 'database':
                    if f.startswith('ncore_tv.db'):
                        should_delete = True

                if should_delete and os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                        deleted_count += 1
                    except:
                        xbmc.log(f"[nCore_TV] Zárolt fájl, nem törölhető: {f}", xbmc.LOGWARNING)

            if delete_type == 'database':
                addon.setSetting('simkl_last_sync_time', 'Még nem futott')
                addon.setSetting('trakt_last_sync_time', 'Még nem futott')
                addon.setSetting('plex_last_sync_time', 'Még nem futott')
                xbmcgui.Dialog().ok("Sikeres Reset", "Az adatbázis és a szinkron idők törölve lettek.[CR]Indítsd újra az addont!")

            xbmcgui.Dialog().notification("Takarítás kész", f"{deleted_count} fájl törölve.", xbmcgui.NOTIFICATION_INFO, 3000)

        except Exception as e:
            xbmcgui.Dialog().ok("Hiba", f"Váratlan hiba a törlés során: {str(e)}")


    def IDDatabaseAudit(self):
        imdb_id = self.params.get('imdb_id')
        if not imdb_id: return

        import datetime
        audit_list = []
        audit_list.append(f"[B][COLOR gold]---== nCore TV ID-DIAGNOSZTIKA ==---[/COLOR][/B]")
        audit_list.append(f"[B]IMDb ID:[/B] {imdb_id}")
        audit_list.append("[COLOR grey]-------------------------------------------[/COLOR]")

        try:
            with self.db._get_connection() as conn:
                s_row = conn.execute("SELECT * FROM sync_status WHERE imdb_id = ?", (imdb_id,)).fetchone()
                
                if s_row:
                    audit_list.append("[B][COLOR cyan][ Helyi Szinkron Adatok ][/COLOR][/B]")
                    for key in s_row.keys():
                        if key == 'imdb_id': continue
                        val = s_row[key]
                        
                        if key == 'last_updated' and val:
                            try: val = datetime.datetime.fromtimestamp(int(val)).strftime('%Y-%m-%d %H:%M:%S')
                            except: pass
                        
                        if key == 'simkl_poster' and val:
                            audit_list.append(f"  [COLOR gold]POSTER HASH:[/COLOR] {val}")
                            audit_list.append(f"  [COLOR orange]LINK:[/COLOR] [I]https://simkl.in/posters/{val}_m.jpg[/I]")
                            continue

                        if val is None or val == "": val = "[COLOR red]HIÁNYZIK[/COLOR]"
                        audit_list.append(f"  [COLOR gold]{key.upper()}:[/COLOR] {val}")
                else:
                    audit_list.append("[B][COLOR red]HIBA: Ez az ID nem szerepel a sync_status táblában![/COLOR][/B]")

        except Exception as e:
            audit_list.append(f"[COLOR red]Audit hiba: {str(e)}[/COLOR]")

        audit_list.append("[COLOR grey]-------------------------------------------[/COLOR]")
        xbmcgui.Dialog().select(f"ID Check: {imdb_id}", audit_list)

    def getDatabaseSummary(self):
        import os
        from datetime import datetime
        stats_list = []
        stats_list.append("[B][COLOR gold]---== nCore TV RENDSZER-DIAGNOSZTIKA ==---[/COLOR][/B]")
        stats_list.append("[COLOR grey]-------------------------------------------[/COLOR]")

        db_path = self.db.db_path
        profile_path = os.path.dirname(db_path)

        if not os.path.exists(db_path):
            stats_list.append("[COLOR orange]Az adatbázis inicializálása folyamatban...[/COLOR]")
            xbmcgui.Dialog().select("Rendszer üzenet", stats_list)
            return

        try:
            files_in_profile = os.listdir(profile_path)
            migrated_files = [f for f in files_in_profile if f.endswith('.migrated')]
            original_backups = [f for f in files_in_profile if '_original' in f or f.endswith('.bak')]
            
            stats_list.append("[B][COLOR yellow][ Rendszer-migráció állapota ][/COLOR][/B]")
            if migrated_files:
                stats_list.append(f"  [COLOR gold]JSON -> SQL átállás:[/COLOR] [COLOR lime]Sikeresen lezajlott[/COLOR]")
                stats_list.append(f"  [COLOR gold]Migrált komponensek:[/COLOR] {len(migrated_files)} adategység")
                if original_backups:
                    stats_list.append(f"  [COLOR gold]Biztonsági mentések:[/COLOR] Megőrizve ({len(original_backups)} fájl)")
            else:
                stats_list.append(f"  [COLOR gold]Rendszer típusa:[/COLOR] [COLOR cyan]Tiszta SQL telepítés[/COLOR]")

            is_wal = any(f.endswith('-wal') for f in files_in_profile)
            wal_status = "[COLOR lime]Aktív[/COLOR]" if is_wal else "Normál"
            
            stats_list.append(" ")
            stats_list.append("[B][COLOR lightgreen][ Adatbázis technikai állapot ][/COLOR][/B]")
            stats_list.append(f"  [COLOR gold]Adatbázis fájl:[/COLOR] ncore_tv.db")
            stats_list.append(f"  [COLOR gold]Nagy sebességű (WAL) mód:[/COLOR] {wal_status}")
            
            size_mb = os.path.getsize(db_path) / (1024 * 1024)
            stats_list.append(f"  [COLOR gold]Fizikai méret:[/COLOR] {size_mb:.2f} MB")

            with self.db._get_connection() as conn:
                def table_exists(name):
                    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,))
                    return cur.fetchone() is not None

                stats_list.append(" ")
                stats_list.append("[B][COLOR cyan][ Adatbázis tartalom összegzése ][/COLOR][/B]")
                
                if table_exists('torrents'):
                    total = conn.execute("SELECT COUNT(*) FROM torrents").fetchone()[0]
                    played = conn.execute("SELECT COUNT(*) FROM torrents WHERE full_url IS NOT NULL AND full_url != ''").fetchone()[0]
                    if total > 0:
                        stats_list.append(f"  [COLOR gold]Helyi előzmények:[/COLOR] {total} tétel ({played} lejátszva)")
                
                if table_exists('sync_status'):
                    cloud_info = []
                    sync_times = []
                    for s_name in ['trakt', 'simkl', 'plex']:
                        col = f"{s_name}_status"
                        c = conn.execute(f"SELECT COUNT(*) FROM sync_status WHERE {col} IS NOT NULL AND {col} != ''").fetchone()[0]
                        if c > 0:
                            cloud_info.append(f"{s_name.capitalize()}: {c}")
                            ts = conn.execute(f"SELECT MAX(last_updated) FROM sync_status WHERE {col} IS NOT NULL").fetchone()[0]
                            if ts and ts > 0:
                                dt_s = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M')
                                sync_times.append(f"    [COLOR lime]•[/COLOR] {s_name.capitalize()}: {dt_s}")

                    if cloud_info:
                        stats_list.append(f"  [COLOR gold]Felhő szinkron:[/COLOR] {' | '.join(cloud_info)}")
                        if sync_times:
                            stats_list.append(f"  [COLOR gold]Utolsó frissítések:[/COLOR]")
                            stats_list.extend(sync_times)

                    poster_count = conn.execute("SELECT COUNT(*) FROM sync_status WHERE simkl_poster IS NOT NULL AND simkl_poster != ''").fetchone()[0]

                    missing_poster_count = conn.execute("SELECT COUNT(*) FROM sync_status WHERE simkl_poster IS NULL OR simkl_poster = ''").fetchone()[0]
                    
                    if poster_count > 0:
                        stats_list.append(f"  [COLOR gold]Helyi borító-tár:[/COLOR] [COLOR lime]{poster_count} db[/COLOR] (IMDb ↔ Simkl link)")
                    
                    if missing_poster_count > 0:
                        stats_list.append(f"  [COLOR gold]Hiányzó borítók:[/COLOR] [COLOR red]{missing_poster_count} db[/COLOR] (nincs még helyi kép)")

                if table_exists('watching_series'):
                    ws_count = conn.execute("SELECT COUNT(*) FROM watching_series").fetchone()[0]
                    if ws_count > 0:
                        stats_list.append(f"  [COLOR gold]SorozatFigyelő:[/COLOR] {ws_count} aktív sorozat")
                        if table_exists('device_names'):
                            dev_count = conn.execute("SELECT COUNT(*) FROM device_names").fetchone()[0]
                            if dev_count > 0:
                                stats_list.append(f"    [COLOR lime]•[/COLOR] SorozatFigyelő profilok: {dev_count} db")

                if table_exists('torrent_files'):
                    tf_count = conn.execute("SELECT COUNT(DISTINCT torrent_id) FROM torrent_files").fetchone()[0]
                    if tf_count > 0:
                        stats_list.append(f"  [COLOR gold]Binge-watch:[/COLOR] {tf_count} indexelt pakk/album")

                if table_exists('search_history'):
                    sh_count = conn.execute("SELECT COUNT(*) FROM search_history").fetchone()[0]
                    if sh_count > 0:
                        stats_list.append(f"  [COLOR gold]Keresési napló:[/COLOR] {sh_count} előzmény")

                stats_list.append(" ")
                stats_list.append("[B][COLOR orange][ Rendszer-karbantartási adatok ][/COLOR][/B]")

                if table_exists('video_positions'):
                    pos_data = conn.execute("SELECT COUNT(*), MAX(timestamp) FROM video_positions").fetchone()
                    if pos_data and pos_data[0] > 0:
                        l_act = pos_data[1].split('.')[0] if pos_data[1] else "Nincs adat"
                        stats_list.append(f"  [COLOR gold]Lejátszási pontok:[/COLOR] {pos_data[0]} mentés")
                        stats_list.append(f"    [COLOR lime]•[/COLOR] Utolsó rögzítés: {l_act}")

                    if table_exists('torrents'):
                        orphans = conn.execute("SELECT COUNT(*) FROM video_positions WHERE torrent_id NOT IN (SELECT torrent_id FROM torrents)").fetchone()[0]
                        if orphans > 0:
                            stats_list.append(f"  [COLOR red]Takarítható adatok:[/COLOR] {orphans} árva bejegyzés")

        except Exception as e:
            stats_list.append(f"[COLOR red]Hiba az elemzéskor: {str(e)}[/COLOR]")

        stats_list.append("[COLOR grey]-------------------------------------------[/COLOR]")
        stats_list.append("[I]Bezáráshoz kattints az OK gombra.[/I]")

        xbmcgui.Dialog().select("nCore TV - Rendszer Diagnosztika", stats_list)


    def TorrentDatabaseAudit(self):
        t_id = self.params.get('torrent_id')
        if not t_id:
            xbmc.log("[INFO] TorrentDatabaseAudit: Nincs torrent_id", xbmc.LOGINFO)
            return
        
        xbmc.log(f"[INFO] TorrentDatabaseAudit: Audit indítása - ID: {t_id}", xbmc.LOGINFO)
    
        audit_list = []
        audit_list.append(f"[B][COLOR gold]---== nCore TV ADATBÁZIS - ID: {t_id} ==---[/COLOR][/B]")
        audit_list.append("[COLOR grey]------------------------------------------------------------[/COLOR]")
    
        try:
            with self.db._get_connection() as conn:
                row = conn.execute("SELECT * FROM torrents WHERE torrent_id = ?", (t_id,)).fetchone()
                
                imdb_id = None
                if row:
                    imdb_id = row['imdb_id']
                    audit_list.append("[B][COLOR lightgreen][ FŐ ADATOK - torrents tábla ][/COLOR][/B]")
                    for key in row.keys():
                        val = row[key]
                        if key in ['poster_link', 'c_i']: 
                            val = self.clean_base64_data(val)
                        if val is None or val == "": 
                            val = "[COLOR red]NULL / Üres[/COLOR]"
                        audit_list.append(f"  [COLOR gold]{key.upper()}:[/COLOR] {val}")
                
                audit_list.append(" ")
    
                if imdb_id:
                    audit_list.append("[B][COLOR yellow][ FELHŐS ÁLLAPOTOK - sync_status ][/COLOR][/B]")
                    s_row = conn.execute("SELECT * FROM sync_status WHERE imdb_id = ?", (imdb_id,)).fetchone()
                    if s_row:
                        for key in s_row.keys():
                            val = s_row[key]
                            if key == 'last_updated' and val:
                                try: 
                                    val = datetime.datetime.fromtimestamp(int(val)).strftime('%Y-%m-%d %H:%M:%S')
                                except: 
                                    pass
                            if val is None or val == "": 
                                val = "---"
                            audit_list.append(f"  [COLOR gold]{key.upper()}:[/COLOR] {val}")
                
                audit_list.append(" ")

                file_rows = conn.execute("SELECT * FROM torrent_files WHERE torrent_id = ?", (t_id,)).fetchall()
                
                if file_rows:
                    def extract_season_episode(text):
                        if not text: return (None, None)
                        import re
                        patterns = [
                            r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                            r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
                            r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
                        ]
                        for series_patt in patterns:
                            match = re.search(series_patt, str(text))
                            if match: 
                                return int(match.group('season')), int(match.group('episode'))
                        return (None, None)
                    
                    file_rows = sorted(file_rows, key=lambda x: extract_season_episode(x['file_name']))
                    
                    audit_list.append(f"[B][COLOR cyan][ FÁJLLISTA - {len(file_rows)} db videó ][/COLOR][/B]")
                    for i, f in enumerate(file_rows):
                        audit_list.append(f"  [COLOR grey]{i+1:02d}.[/COLOR] {f['file_name']}")
                else:
                    audit_list.append("[B][COLOR red][-] NINCS MENTETT FÁJLLISTA[/COLOR][/B]")
                
                audit_list.append(" ")
    
                pos_rows = conn.execute("SELECT * FROM video_positions WHERE torrent_id = ? ORDER BY timestamp DESC", (t_id,)).fetchall()
                if pos_rows:
                    audit_list.append(f"[B][COLOR lightgreen][ MENTETT POZÍCIÓK - {len(pos_rows)} db ][/COLOR][/B]")
                    for i, p in enumerate(pos_rows):
                        audit_list.append(f"  [COLOR cyan]Bejegyzés #{i+1}[/COLOR]")
                        audit_list.append(f"    [COLOR gold]Dátum:[/COLOR] {p['timestamp']}")
                        audit_list.append(f"    [COLOR gold]Pont:[/COLOR] [B]{p['label']}[/B]")
                        audit_list.append(f"    [COLOR gold]Fájl:[/COLOR] [I]{p['file_name']}[/I]")
    
        except Exception as e:
            xbmc.log(f"[ERROR] TorrentDatabaseAudit: Hiba - {str(e)}", xbmc.LOGERROR)
            audit_list.append("[B][COLOR red]!!! KRITIKUS HIBA ELEMZÉS KÖZBEN !!![/COLOR][/B]")
            audit_list.append(f"[COLOR red]{e}[/COLOR]")
    
        audit_list.append("[COLOR grey]------------------------------------------------------------[/COLOR]")
        audit_list.append("[I]Jelentés vége (Kattints a bezáráshoz)[/I]")
    
        xbmcgui.Dialog().select(f"Database Audit: {t_id}", audit_list)
        xbmc.log(f"[INFO] TorrentDatabaseAudit: Audit kész - ID: {t_id}", xbmc.LOGINFO)

    def CloudAuthDiagnostic(self):
        import requests
        import xbmcgui
        stats_list = []
        stats_list.append("[B][COLOR gold]---== nCore TV FELHŐ-DIAGNOSZTIKA ==---[/COLOR][/B]")
        stats_list.append("[COLOR grey]-------------------------------------------[/COLOR]")
    
        def interpret_code(code):
            if code == 200: return "[COLOR lime]200 OK - Hitelesítve[/COLOR]"
            if code == 401: return "[COLOR red]401 - Hitelesítés lejárt[/COLOR]"
            if code == 403: return "[COLOR red]403 - Tiltott hozzáférés[/COLOR]"
            if code == 404: return "[COLOR red]404 - Nem található[/COLOR]"
            if code >= 500: return f"[COLOR orange]{code} - Szerver hiba (Várj kicsit)[/COLOR]"
            return f"[COLOR orange]{code} - Ismeretlen hiba[/COLOR]"
    
        has_any_service = False

        if self.is_trakt_active():
            has_any_service = True
            try:
                url = "https://api.trakt.tv/users/settings"
                headers = {
                    'Content-Type': 'application/json',
                    'trakt-api-version': '2',
                    'trakt-api-key': f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}",
                    'Authorization': f"Bearer {addon.getSetting('trakt_access_token')}"
                }
                r = requests.get(url, headers=headers, timeout=10)
                stats_list.append(f"[B]Trakt.tv:[/B] {interpret_code(r.status_code)}")
            except:
                stats_list.append("[B]Trakt.tv:[/B] [COLOR orange]Hálózati hiba / Időtúllépés[/COLOR]")

        if self.is_simkl_active():
            has_any_service = True
            try:
                token = addon.getSetting('simkl_access_token')
                c_id = f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
                headers = {
                    "Authorization": f"Bearer {token}", 
                    "simkl-api-client": c_id,
                    "Content-Type": "application/json"
                }
                url = f"https://api.simkl.com/users/settings?client_id={c_id}"
                r = requests.get(url, headers=headers, timeout=10)
                stats_list.append(f"[B]Simkl.com:[/B] {interpret_code(r.status_code)}")
            except:
                stats_list.append("[B]Simkl.com:[/B] [COLOR orange]Hálózati hiba / Időtúllépés[/COLOR]")

        if self.is_plex_active():
            has_any_service = True
            try:
                token = addon.getSetting('plex_token')
                url = "https://plex.tv/api/v2/user"
                headers = {
                    "X-Plex-Token": token, 
                    "Accept": "application/json"
                }
                r = requests.get(url, headers=headers, timeout=10)
                stats_list.append(f"[B]Plex:[/B] {interpret_code(r.status_code)}")
            except:
                stats_list.append("[B]Plex:[/B] [COLOR orange]Hálózati hiba / Időtúllépés[/COLOR]")

        if not has_any_service:
            stats_list.append("[I][COLOR grey]Nincs aktív felhő szolgáltatás beállítva.[/COLOR][/I]")

        stats_list.append("[COLOR grey]-------------------------------------------[/COLOR]")

        stats_list.append("[B]Magyarázat:[/B]")
        stats_list.append("[COLOR lime]• 200 OK:[/COLOR] Minden rendben, a szinkronizáció aktív.")
        stats_list.append("[COLOR red]• 401 Error:[/COLOR] A hitelesítés lejárt, újra be kell jelentkezned.")
        stats_list.append("[COLOR orange]• Hálózati hiba:[/COLOR] Nincs internet vagy a szerver nem elérhető.")
        
        stats_list.append(" ")
        stats_list.append("[COLOR grey]-------------------------------------------[/COLOR]")
        stats_list.append("[I]Bezáráshoz kattints az OK gombra.[/I]")

        xbmcgui.Dialog().select("nCore TV - Felhő Állapot Ellenőrzés", stats_list)


    def checkAuthFast(self):
        import time
        import threading
    
        last_fast_check = addon.getSetting('last_fast_auth_check_timestamp') or "0"
        
        if (time.time() - float(last_fast_check)) < 43200:
            return
    
        for t in threading.enumerate():
            if t.name == "nCoreTV_AuthCheck":
                return
    
        def verifyTask():
            auth_errors = []
            network_errors = []
            server_errors = []
            other_errors = []
    
            if self.is_trakt_active():
                try:
                    headers = {
                        'trakt-api-version': '2',
                        'trakt-api-key': f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}",
                        'Authorization': f"Bearer {addon.getSetting('trakt_access_token')}"
                    }
                    r = requests.get("https://api.trakt.tv/users/settings", headers=headers, timeout=10)
                    if r.status_code == 401:
                        auth_errors.append("Trakt.tv")
                        addon.setSetting('trakt_last_sync_time', "[COLOR red]Hitelesítés lejárt (401)[/COLOR]")
                    elif r.status_code == 403:
                        other_errors.append("Trakt.tv (403 - Tiltott)")
                        addon.setSetting('trakt_last_sync_time', "[COLOR red]Tiltott hozzáférés (403)[/COLOR]")
                    elif r.status_code >= 500:
                        server_errors.append(f"Trakt.tv ({r.status_code})")
                        addon.setSetting('trakt_last_sync_time', f"[COLOR orange]Szerver hiba ({r.status_code})[/COLOR]")
                    elif r.status_code != 200:
                        other_errors.append(f"Trakt.tv ({r.status_code})")
                        addon.setSetting('trakt_last_sync_time', f"[COLOR red]Ismeretlen hiba ({r.status_code})[/COLOR]")
                    else:
                        addon.setSetting('trakt_last_sync_time', "[COLOR lime]OK[/COLOR]")
                except Exception as e:
                    network_errors.append("Trakt.tv")
                    addon.setSetting('trakt_last_sync_time', "[COLOR orange]Hálózati hiba[/COLOR]")
    
            if self.is_simkl_active():
                try:
                    token = addon.getSetting('simkl_access_token')
                    c_id = f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
                    headers = {"Authorization": f"Bearer {token}", "simkl-api-client": c_id}
                    r = requests.get(f"https://api.simkl.com/users/settings?client_id={c_id}", headers=headers, timeout=10)
                    
                    if r.status_code == 401:
                        auth_errors.append("Simkl.com")
                        addon.setSetting('simkl_last_sync_time', "[COLOR red]Hitelesítés lejárt (401)[/COLOR]")
                    elif r.status_code == 403:
                        other_errors.append("Simkl.com (403 - Tiltott)")
                        addon.setSetting('simkl_last_sync_time', "[COLOR red]Tiltott hozzáférés (403)[/COLOR]")
                    elif r.status_code >= 500:
                        server_errors.append(f"Simkl.com ({r.status_code})")
                        addon.setSetting('simkl_last_sync_time', f"[COLOR orange]Szerver hiba ({r.status_code})[/COLOR]")
                    elif r.status_code != 200:
                        other_errors.append(f"Simkl.com ({r.status_code})")
                        addon.setSetting('simkl_last_sync_time', f"[COLOR red]Ismeretlen hiba ({r.status_code})[/COLOR]")
                    else:
                        addon.setSetting('simkl_last_sync_time', "[COLOR lime]OK[/COLOR]")
                except Exception as e:
                    network_errors.append("Simkl.com")
                    addon.setSetting('simkl_last_sync_time', "[COLOR orange]Hálózati hiba[/COLOR]")
    
            if self.is_plex_active():
                try:
                    token = addon.getSetting('plex_token')
                    headers = {"X-Plex-Token": token, "Accept": "application/json"}
                    r = requests.get("https://plex.tv/api/v2/user", headers=headers, timeout=10)
                    
                    if r.status_code == 401:
                        auth_errors.append("Plex")
                        addon.setSetting('plex_last_sync_time', "[COLOR red]Hitelesítés lejárt (401)[/COLOR]")
                    elif r.status_code == 403:
                        other_errors.append("Plex (403 - Tiltott)")
                        addon.setSetting('plex_last_sync_time', "[COLOR red]Tiltott hozzáférés (403)[/COLOR]")
                    elif r.status_code >= 500:
                        server_errors.append(f"Plex ({r.status_code})")
                        addon.setSetting('plex_last_sync_time', f"[COLOR orange]Szerver hiba ({r.status_code})[/COLOR]")
                    elif r.status_code != 200:
                        other_errors.append(f"Plex ({r.status_code})")
                        addon.setSetting('plex_last_sync_time', f"[COLOR red]Ismeretlen hiba ({r.status_code})[/COLOR]")
                    else:
                        addon.setSetting('plex_last_sync_time', "[COLOR lime]OK[/COLOR]")
                        
                except Exception as e:
                    network_errors.append("Plex")
                    addon.setSetting('plex_last_sync_time', "[COLOR orange]Hálózati hiba[/COLOR]")

            if auth_errors or network_errors or server_errors or other_errors:
                self.show_auth_error_dialog(auth_errors, network_errors, server_errors, other_errors)
    
            addon.setSetting('last_fast_auth_check_timestamp', str(time.time()))
    
        check_thread = threading.Thread(target=verifyTask, name="nCoreTV_AuthCheck")
        check_thread.daemon = True
        check_thread.start()


    def show_auth_error_dialog(self, auth_errors, network_errors, server_errors, other_errors):
        title = "[B][COLOR red]nCore TV - Felhő Szinkronizálási Hiba[/COLOR][/B]"
        
        msg = "[B][COLOR orange]A háttérben zajló szinkronizáció nem működik.[/COLOR][/B]\n\n"
        
        if auth_errors:
            msg += "[B][COLOR red]Hitelesítési hibák (401):[/COLOR][/B]\n"
            for s in auth_errors:
                msg += f"  [COLOR cyan]- {s}[/COLOR]\n"
            msg += "\n"
        
        if network_errors:
            msg += "[B][COLOR orange]Hálózati hibák (nincs internet):[/COLOR][/B]\n"
            for s in network_errors:
                msg += f"  [COLOR cyan]- {s}[/COLOR]\n"
            msg += "\n"
        
        if server_errors:
            msg += "[B][COLOR orange]Szerver hibák (500-as):[/COLOR][/B]\n"
            for s in server_errors:
                msg += f"  [COLOR cyan]- {s}[/COLOR]\n"
            msg += "\n"
        
        if other_errors:
            msg += "[B][COLOR orange]Egyéb hibák:[/COLOR][/B]\n"
            for s in other_errors:
                msg += f"  [COLOR cyan]- {s}[/COLOR]\n"
            msg += "\n"
        
        msg += "[B][COLOR white]Teendő:[/COLOR][/B]\n"
        
        if auth_errors:
            msg += "[COLOR lime]•[/COLOR] Lépj be az addon [B]Beállításaiba[/B], és végezd el újra a párosítást.\n"
            msg += "  (Trakt | Simkl | Plex menüpontokban)\n"
        
        if network_errors:
            msg += "[COLOR lime]•[/COLOR] Ellenőrizd az [B]internetkapcsolatodat[/B].\n"
            msg += "[COLOR lime]•[/COLOR] Ha van internet, próbáld újra később.\n"
        
        if server_errors:
            msg += "[COLOR lime]•[/COLOR] A szolgáltatás szerver oldali hibás ([COLOR orange]500-as hiba[/COLOR]).\n"
            msg += "[COLOR lime]•[/COLOR] Próbáld újra [B]10-15 perc[/B] múlva.\n"
        
        if other_errors:
            msg += "[COLOR lime]•[/COLOR] Ismeretlen hiba történt.\n"
            msg += "[COLOR lime]•[/COLOR] Próbáld újra később, vagy ellenőrizd a beállításokat.\n"
        
        msg += "\n[COLOR grey]Ez az üzenet 12 óránként jelenik meg újra, amíg a hiba fennáll.[/COLOR]"
        
        try:
            window = AuthErrorWindow(title, msg)
            window.doModal()
            del window
        except Exception as e:
            xbmc.log(f"AuthErrorWindow Error: {e}", xbmc.LOGERROR)

    def _sort_result_items(self, items):
        """sort=quality: REMUX/felbontás/seeder pontszám szerint; különben a régi (már nézett előre)."""
        if self.params.get('sort') == 'quality':
            pref = quality.pref_from_setting(self.params.get('quality') or addon.getSetting('tmdbh_quality'))
            items.sort(key=lambda x: quality.score(x.get('q_title', ''), x.get('q_cat', ''), x.get('q_seed', 0), pref), reverse=True)
        else:
            items.sort(key=lambda x: x['is_played'], reverse=True)
        return items

    # ------------------------------------------------------------------
    # TMDb Helper player + widget menü
    # ------------------------------------------------------------------
    def _tmdb_to_imdb(self, tmdb_id, media_type):
        _key = f'nCore_t2i_{media_type}_{tmdb_id}'
        _win = xbmcgui.Window(10000)
        _hit = _win.getProperty(_key)
        if _hit:
            return _hit
        try:
            url = f"https://api.themoviedb.org/3/{media_type}/{tmdb_id}/external_ids?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}"
            _res = (nc_get(url, timeout=8).json() or {}).get('imdb_id') or ''
            if _res: _win.setProperty(_key, _res)
            return _res
        except Exception as e:
            xbmc.log(f"[nCore_TMDBH] tmdb->imdb hiba: {e}", xbmc.LOGERROR)
            return ''

    def _tmdbh_candidates(self, imdb_id, mtype, season=None, episode=None, max_pages=3):
        """IMDb-azonosító alapján a találati oldalak beolvasása -> jelöltlista (nincs UI)."""
        cookies = {'nick': user_name, 'pass': saved_pass_cookie}
        url = f"{base_url}{imdb_kereso}{imdb_id}"
        want_series = (mtype != 'movie')
        cands = []
        for _ in range(max_pages):
            resp = nc_get(url, cookies=cookies, headers=headers)
            soup = _FastSoup(resp.text)
            boxes = soup.find_all('div', class_='box_torrent')
            if not boxes:
                break
            for t in boxes:
                s = str(t)
                m = re.search(r'id=(.*?)\" onclick=\"torrent', s)
                tid = m.group(1) if m else ''
                cm = re.search(r'torrents.php\?tipus=(.*?)\"', s)
                cat = cm.group(1) if cm else ''
                if not tid or not cat or cat in ('mp3_hun', 'mp3', 'lossless_hun', 'lossless', 'clip', 'xxx_xvid', 'xxx_hd'):
                    continue
                if ('ser' in cat) != want_series:
                    continue
                m1 = re.search(r'onclick=\".*title=\"(.*)\">', str(t.find('div', class_='torrent_txt')))
                title_1 = html.unescape(m1.group(1)) if m1 else ''
                n2 = t.find('div', class_='box_nev2')
                m2 = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(n2))
                title_2 = html.unescape(m2.group(1)) if m2 else ''
                name = title_1 or title_2
                if not name:
                    continue
                if want_series and season:
                    rel = parse_release_robust(name)
                    try:
                        s_i = int(season)
                        e_i = int(episode) if episode else None
                    except ValueError:
                        continue
                    if e_i:
                        ok = rel["is_complete"] or (s_i in rel["seasons"] and (rel["episode"] is None or rel["episode"] == e_i))
                    else:
                        ok = rel["is_complete"] or (s_i in rel["seasons"])
                    if not ok:
                        continue
                seed_el = t.find('div', class_='box_s2')
                size_el = t.find('div', class_='box_meret2')
                cands.append({
                    'torrent_id': tid, 'cat': cat, 'title': name, 'title_1': title_1, 'title_2': title_2,
                    'seeders': (seed_el.text.strip() if seed_el else '0'),
                    'size': (size_el.text.strip() if size_el else ''),
                })
            nxt = soup.find('a', id='nPa')
            if not nxt or not nxt.get('href'):
                break
            url = f"{base_url}{nxt.get('href')}"
            if len(cands) >= 8:
                break
        return cands

    def TmdbHelper(self):
        """
        TMDb Helper player belépési pont.
        action=tmdbh&mode=play|search&type=movie|episode&imdb_id=..&tmdb_id=..&season=..&episode=..&quality=auto|remux|2160p|1080p
        """
        p = self.params
        mode = p.get('mode', 'search')
        mtype = 'movie' if p.get('type', 'movie') == 'movie' else 'episode'
        imdb = p.get('imdb_id') or ''
        tmdb = p.get('tmdb_id') or ''
        season, episode = p.get('season'), p.get('episode')

        def fail(msg):
            xbmcgui.Dialog().notification("nCore TV", msg, xbmcgui.NOTIFICATION_WARNING, 3500)
            if mode in ('play', 'select'):
                xbmcplugin.setResolvedUrl(syshandle, False, listitem=xbmcgui.ListItem())
            else:
                xbmcplugin.endOfDirectory(syshandle, succeeded=False)

        # Epizódnál a sorozat IMDb-je kell; a TMDb-ből feloldott azonosító megbízhatóbb, mint egy esetleges epizód-IMDb.
        if tmdb and (mtype == 'episode' or not imdb.startswith('tt')):
            resolved = self._tmdb_to_imdb(tmdb, 'movie' if mtype == 'movie' else 'tv')
            imdb = resolved or imdb
        if not imdb.startswith('tt'):
            return fail("Nincs IMDb azonosító ehhez a tartalomhoz.")

        target_ep = ''
        if mtype == 'episode' and season:
            try:
                target_ep = f"S{int(season):02d}E{int(episode):02d}" if episode else f"S{int(season):02d}"
            except ValueError:
                target_ep = ''

        if mode not in ('play', 'select'):
            self.params['sort'] = 'quality'
            if target_ep:
                self.params['target_episode'] = target_ep
            xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', f"{base_url}{imdb_kereso}{imdb}")
            return self.doSearch_3(f"{base_url}{imdb_kereso}", imdb)

        try:
            cands = self._tmdbh_candidates(imdb, mtype, season, episode)
        except Exception as e:
            xbmc.log(f"[nCore_TMDBH] keresési hiba: {e}", xbmc.LOGERROR)
            return fail("Hiba a keresés közben.")
        if not cands:
            return fail("Nincs találat az nCore-on.")

        pref = quality.pref_from_setting(p.get('quality') or addon.getSetting('tmdbh_quality'))
        ordered = sorted(cands, key=lambda c: quality.score(c['title'], c['cat'], c['seeders'], pref), reverse=True)
        if mode == 'select':
            pairs = [quality.dialog_item(c['title'], c['cat'], c['size'], c['seeders']) for c in ordered]
            heading = f"nCore TV  \u2013  {len(ordered)} verzi\u00f3" + (f"  ({target_ep})" if target_ep else '')
            try:
                idx = xbmcgui.Dialog().select(heading, [xbmcgui.ListItem(label=l1, label2=l2) for l1, l2 in pairs], useDetails=True)
            except TypeError:
                idx = xbmcgui.Dialog().select(heading, [f"{l1}  |  {l2}" for l1, l2 in pairs])
            if idx < 0:
                xbmcplugin.setResolvedUrl(syshandle, False, listitem=xbmcgui.ListItem())
                return
            best = ordered[idx]
        else:
            best = ordered[0]
        tid = best['torrent_id']
        xbmc.log(f"[nCore_TMDBH] {len(cands)} jelölt, választott: {best['title']} (seed {best['seeders']}, pref {pref})", xbmc.LOGINFO)

        try:
            self.db.save_torrent_metadata({
                'torrent_id': tid, 'imdb_id': imdb, 'tmdb_id': tmdb,
                'title_1': best['title_1'], 'title_2': best['title_2'],
                'timestamp': datetime.now().isoformat(),
            })
            if target_ep and not self.db.has_torrent_structure(tid):
                self.sync_torrent_files_to_db(tid)
        except Exception as e:
            xbmc.log(f"[nCore_TMDBH] metaadat/fájllista hiba: {e}", xbmc.LOGERROR)

        play = (f"plugin://{addon_str}/?action=playmovie&url={tid}&torrent_id={tid}"
                f"&imdb_id={imdb}&tmdb_id={tmdb}&title_1={quote_plus(best['title_1'] or best['title'])}")
        if target_ep:
            play += f"&target_episode={target_ep}"
        xbmcgui.Dialog().notification("nCore TV", best['title'][:60], xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.setResolvedUrl(syshandle, True, listitem=xbmcgui.ListItem(path=play))

    def install_tmdbh_player(self):
        """A resources/players/ alatti player-fájlokat másolja a TMDb Helper players mappájába (a4k-openplayers elnevezés), majd ellenőrzi az eredményt."""
        import shutil, json as _json
        if not xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
            xbmcgui.Dialog().ok("nCore TV", "A TMDb Helper nincs telepítve (vagy le van tiltva).")
            return
        src_dir = os.path.join(translatePath(addon.getAddonInfo('path')), 'resources', 'players')
        folder = 'special://profile/addon_data/plugin.video.themoviedb.helper/players/'
        try:
            xbmcvfs.mkdirs(folder)
            dst_dir = translatePath(folder)
            os.makedirs(dst_dir, exist_ok=True)
            # az előző változatok fájljai duplikált playert adnának
            for old in ('ncore_tv.json', 'ncore_tv_remux.json'):
                try: os.remove(os.path.join(dst_dir, old))
                except OSError: pass
            names = sorted(f for f in os.listdir(src_dir) if f.endswith('.json'))
            if not names:
                raise RuntimeError(f"nincs player-fájl a forrásban: {src_dir}")
            ok_names, bad = [], []
            for fname in names:
                target = os.path.join(dst_dir, fname)
                shutil.copyfile(os.path.join(src_dir, fname), target)
                try:
                    with open(target, 'r', encoding='utf-8') as f:
                        d = _json.load(f)
                    ok_names.append(f"{fname} -> {d.get('plugin')}")
                except Exception as je:
                    bad.append(f"{fname}: {je}")
            # A Kodi a feltételekben kisbetűsít, így a nagybetűs azonosító ('nCore_TV') miatt a HasAddon hamis: a playerek ezért 'xbmc.core' pluginnal készülnek.
            plugin_ok = True
            xbmc.log(f"[nCore_TMDBH] player telepítve: {dst_dir} | {ok_names} | hibás: {bad} | HasAddon({addon_str})={plugin_ok}", xbmc.LOGINFO)
            msg = f"Ide másoltam:\n{dst_dir}\n" + "\n".join(ok_names)
            if bad: msg += "\nHIBÁS: " + "; ".join(bad)
            if not plugin_ok: msg += f"\nFIGYELEM: a Kodi nem látja az addont ({addon_str}) telepítettként."
            msg += "\nNyisd meg újra a TMDb Helper-t; a lejátszó-dialógusban 'Play with nCore TV' jelenik meg."
            xbmcgui.Dialog().ok("nCore TV", msg)
        except Exception as e:
            xbmc.log(f"[nCore_TMDBH] telepítési hiba: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("nCore TV", f"Nem sikerült telepíteni: {e}")

    SORT_OPTIONS = (
        ('Feltöltés ideje (legújabb elöl)', 'ctime', 'DESC'),
        ('Seed szerint (legtöbb elöl)', 'seeders', 'DESC'),
        ('Letöltések száma (legtöbb elöl)', 'times_completed', 'DESC'),
        ('Méret (legnagyobb elöl)', 'size', 'DESC'),
        ('Méret (legkisebb elöl)', 'size', 'ASC'),
        ('Név szerint (A → Z)', 'name', 'ASC'),
        ('Feltöltés ideje (legrégebbi elöl)', 'ctime', 'ASC'),
    )

    @staticmethod
    def _sorted_url(url, key, direction):
        """/torrents.php?...miszerint=X&hogyan=Y... -> a kért rendezéssel."""
        if 'miszerint=' in url:
            url = re.sub(r'miszerint=[^&]*', 'miszerint=%s' % key, url, count=1)
        else:
            url += ('&' if '?' in url else '?') + 'miszerint=%s' % key
        if 'hogyan=' in url:
            url = re.sub(r'hogyan=[^&]*', 'hogyan=%s' % direction, url, count=1)
        else:
            url += '&hogyan=%s' % direction
        return url

    def SortPick(self, target, url):
        """Kategória megnyitásakor felugró rendezés-választó (feltöltés ideje, seed, ...).
        A lista a rendezett URL-lel nyílik meg (Container.Update), így a Vissza gomb /
        frissítés nem kérdez újra."""
        opts = self.SORT_OPTIONS
        try:
            default_idx = int(addon.getSetting('sort_default') or 0)
        except ValueError:
            default_idx = 0
        if addon.getSetting('sort_popup') == 'false':
            idx = default_idx
        else:
            try:
                last = int(addon.getSetting('sort_last') or default_idx)
            except ValueError:
                last = default_idx
            idx = xbmcgui.Dialog().select('Rendezés', [o[0] for o in opts],
                                          preselect=last if 0 <= last < len(opts) else 0)
            if idx < 0:
                xbmcplugin.endOfDirectory(syshandle, succeeded=False, cacheToDisc=False)
                return
            addon.setSetting('sort_last', str(idx))
        idx = idx if 0 <= idx < len(opts) else 0
        new_url = self._sorted_url(url or '', opts[idx][1], opts[idx][2])
        if target not in ('movie_items', 'series_items'):
            target = 'movie_items'
        xbmcplugin.endOfDirectory(syshandle, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(%s?action=%s&url=%s)' % (sysaddon, target, quote_plus(new_url)))

    def WidgetMenu(self):
        """Skin-widgetnek választható, dialógusmentes, cache-elhető listák (REMUX / 4K / 1080)."""
        def link(action, mire, tipus, content, base=None):
            u = quote_plus(f"{base or mire_hd}={mire}&miben=name&tipus={tipus}")
            return f"{action}&url={u}&widget=1&content={content}"
        items = [
            ("Film HU REMUX", link('movie_items', 'remux', 'hd_hun', 'movies')),
            ("Film EN REMUX", link('movie_items', 'remux', 'hd', 'movies')),
            ("Film HU REMUX (seed szerint)", link('movie_items', 'remux', 'hd_hun', 'movies', mire_hd_seed)),
            ("Film EN REMUX (seed szerint)", link('movie_items', 'remux', 'hd', 'movies', mire_hd_seed)),
            ("Film HU 4K", link('movie_items', '2160p', 'hd_hun', 'movies')),
            ("Film EN 4K", link('movie_items', '2160p', 'hd', 'movies')),
            ("Film HU 1080", link('movie_items', '1080i%7C1080p', 'hd_hun', 'movies')),
            ("Sorozat HU REMUX", link('series_items', 'remux', 'hdser_hun', 'tvshows')),
            ("Sorozat EN REMUX", link('series_items', 'remux', 'hdser', 'tvshows')),
            ("Sorozat HU REMUX (seed szerint)", link('series_items', 'remux', 'hdser_hun', 'tvshows', mire_hd_seed)),
            ("Sorozat EN REMUX (seed szerint)", link('series_items', 'remux', 'hdser', 'tvshows', mire_hd_seed)),
            ("Sorozat HU 4K", link('series_items', '2160p', 'hdser_hun', 'tvshows')),
            ("Sorozat HU 1080", link('series_items', '1080i%7C1080p', 'hdser_hun', 'tvshows')),
        ]
        self.addDirectoryItem("[COLOR yellow]Widgetek: ezeket válaszd a skin widget-beállításában[/COLOR]", '', '', 'DefaultAddonsUpdates.png', isFolder=False)
        for name, q in items:
            self.addDirectoryItem(f"[B]{name}[/B]", q, '', 'DefaultFolder.png')
        xbmcplugin.setContent(syshandle, 'files')
        xbmcplugin.endOfDirectory(syshandle, succeeded=True, cacheToDisc=True)

    def _carry_params(self):
        """Lapozáskor átvitt paraméterek (quality/sort/widget/content/limit)."""
        out = ''
        for k in ('quality', 'sort', 'widget', 'content', 'limit'):
            v = self.params.get(k)
            if v: out += f'&{k}={quote_plus(str(v))}'
        return out

    def _quality_filter_state(self):
        """(aktív, chosen) – először a hívás quality= paramétere (widget/TMDb Helper), különben a beállítások."""
        qp = self.params.get('quality') if hasattr(self, 'params') and self.params else None
        if qp and qp.lower() not in ('auto', ''):
            ch = quality.chosen_from(qp)
            if ch: return True, ch
        if addon.getSetting('custom_filter_active') == 'true':
            return True, addon.getSetting('custom_filter_list').split(',')
        return False, []

    def custom_filter_menu(self):
        options = [
            "SD tartalmak",
            "720 tartalmak",
            "1080 tartalmak",
            "DV/HDR (1080)",
            "4K DV/HDR tartalmak",
            "REMUX (bármely felbontás)"
        ]
        
        saved_filter = addon.getSetting('custom_filter_list')
        current_indices = [int(x) for x in saved_filter.split(',') if x.isdigit()] if saved_filter else []

        sel = xbmcgui.Dialog().multiselect("Válaszd ki, mik jelenjenek meg (lehet több is)", options, preselect=current_indices)
        
        if sel is not None:
            if len(sel) == 0:
                addon.setSetting('custom_filter_active', 'false')
                addon.setSetting('custom_filter_list', '')
            else:
                addon.setSetting('custom_filter_active', 'true')
                addon.setSetting('custom_filter_list', ','.join(map(str, sel)))
            
            xbmc.executebuiltin(f'Container.Update({sys.argv[0]})')

    def disable_filter_and_refresh(self):
        addon.setSetting('custom_filter_active', 'false')
        current_path = xbmc.getInfoLabel('Container.FolderPath')
        xbmc.executebuiltin(f'Container.Update({current_path})')

    def get_prev_file_info(self, torrent_id, current_file_name):
        def extract_season_episode(text):
            if not text: return None, None
            patterns = [
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
            ]
            for series_patt in patterns:
                match = re.search(series_patt, str(text))
                if match: 
                    return int(match.group('season')), int(match.group('episode'))
            return None, None
        
        try:
            with self.db._get_connection() as conn:
                rows = conn.execute("SELECT file_name FROM torrent_files WHERE torrent_id = ?", (str(torrent_id),)).fetchall()
                if not rows: return None
                
                from urllib.parse import unquote_plus
                
                def normalize_filename(f):
                    if not f: return ""
                    decoded = unquote_plus(f)
                    clean_name = decoded.replace('\\', '/').split('/')[-1]
                    return clean_name.strip().lower()
                
                file_list = [r['file_name'] for r in rows]
                file_list.sort(key=lambda x: extract_season_episode(x) or (999, 999))
                
                target_norm = normalize_filename(current_file_name)
                
                current_index = -1
                for i, f in enumerate(file_list):
                    if normalize_filename(f) == target_norm:
                        current_index = i
                        break
                
                if current_index == -1:
                    for i, f in enumerate(file_list):
                        if target_norm in normalize_filename(f) or normalize_filename(f) in target_norm:
                            current_index = i
                            break
                
                if current_index > 0:
                    return file_list[current_index - 1]
                return None
        except Exception as e:
            xbmc.log(f"[ERROR] get_prev_file_info: {e}", xbmc.LOGERROR)
            return None
    
    def get_next_file_info(self, torrent_id, current_file_name):
        def extract_season_episode(text):
            if not text: return None, None
            patterns = [
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
            ]
            for series_patt in patterns:
                match = re.search(series_patt, str(text))
                if match: 
                    return int(match.group('season')), int(match.group('episode'))
            return None, None
        
        try:
            with self.db._get_connection() as conn:
                rows = conn.execute("SELECT file_name FROM torrent_files WHERE torrent_id = ?", (str(torrent_id),)).fetchall()
                if not rows: return None
                
                from urllib.parse import unquote_plus
                
                def normalize_filename(f):
                    if not f: return ""
                    decoded = unquote_plus(f)
                    clean_name = decoded.replace('\\', '/').split('/')[-1]
                    return clean_name.strip().lower()
                
                file_list = [r['file_name'] for r in rows]
                file_list.sort(key=lambda x: extract_season_episode(x) or (999, 999))
                
                target_norm = normalize_filename(current_file_name)
                
                current_index = -1
                for i, f in enumerate(file_list):
                    if normalize_filename(f) == target_norm:
                        current_index = i
                        break
                
                if current_index == -1:
                    for i, f in enumerate(file_list):
                        if target_norm in normalize_filename(f) or normalize_filename(f) in target_norm:
                            current_index = i
                            break
                
                if current_index != -1 and current_index + 1 < len(file_list):
                    return file_list[current_index + 1]
                return None
        except Exception as e:
            xbmc.log(f"[ERROR] get_next_file_info: {e}", xbmc.LOGERROR)
            return None

    def listFilePositions(self):
        from urllib.parse import urlencode, quote_plus
        torrent_id = self.params.get('torrent_id')
        file_name = self.params.get('f_name')
        p_link = self.params.get('poster_link', '')

        all_pos = self.db.get_video_positions(torrent_id, file_name)

        start_params = self.params.copy()
        start_params.pop('action', None) 

        start_params.update({'resume_seconds': '0', 'resume_time': '', 'direct_resume': 'true'})
        q_start = f"single_item_folder&{urlencode(start_params)}"
        self.addDirectoryItem("[B][COLOR white][ Lejátszás az elejétől ][/COLOR][/B]", q_start, p_link, 'DefaultVideo.png', isFolder=True)

        seen_labels = set()
        
        for p in all_pos:
            p_sec = float(p['position'])
            p_dur = float(p.get('duration', 0))
            label = p['label']

            if label in seen_labels:
                continue
            seen_labels.add(label)

            if p_dur > 0 and (p_dur - p_sec) < 15:
                continue

            rem_text = ""
            if p_dur > 0:
                rem_sec = int(p_dur - p_sec)
                m_r, s_r = divmod(rem_sec, 60); h_r, m_r = divmod(m_r, 60)
                rem_fmt = f"{h_r:02d}:{m_r:02d}:{s_r:02d}" if h_r > 0 else f"{m_r:02d}:{s_r:02d}"
                rem_text = f" [COLOR orange](-{rem_fmt} hátra)[/COLOR]"

            display = f"Folytatás: [{label}]{rem_text}"

            pos_params = self.params.copy()
            pos_params.pop('action', None)
            pos_params.update({
                'resume_seconds': str(p['position']), 
                'resume_time': label,
                'direct_resume': 'true'
            })
            q_pos = f"single_item_folder&{urlencode(pos_params)}"

            self.addDirectoryItem(display, q_pos, p_link, 'DefaultVideo.png', isFolder=True)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def getFileList(self, torrent_id):
        import os
        import re
        import requests
        from bs4 import BeautifulSoup
        from urllib.parse import quote_plus, unquote_plus

        imdb_id = self.params.get('imdb_id', '')

        if torrent_id:
            if not self.db.has_torrent_structure(torrent_id):
                #xbmc.log(f"[nCore_SQL] Uj torrent detektalva ({torrent_id}), fajllista szinkron indul...", xbmc.LOGINFO)
                self.sync_torrent_files_to_db(torrent_id)

        _, ncore_cat = self.torrent_filename_and_category(torrent_id)
        series_cats = ['hdser_hun', 'hdser', 'xvidser_hun', 'xvidser']
        is_series_pack = ncore_cat in series_cats

        def convert_to_bytes(size_str):
            size_str = size_str.upper().replace('IB', 'B')
            units = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4}
            match = re.match(r"([0-9.]+)\s*([A-Z]{1,2})", size_str)
            if not match: return 0
            return int(float(match.group(1)) * units.get(match.group(2), 1))
        
        def format_size_force_5(num_bytes):
            for unit in ['B', 'K', 'M', 'G', 'T']:
                if num_bytes < 1024.0:
                    if num_bytes >= 100: res = f"{num_bytes:>4.0f}{unit}"
                    elif num_bytes >= 10: res = f"{num_bytes:>4.1f}{unit}"
                    else: res = f"{num_bytes:>3.1f}{unit}"
                    return f"{res:>5}"
                num_bytes /= 1024.0
            return " 0.0B"

        def local_extract_se(text):
            if not text: return None, None
            patterns = [
                r'[sS](?P<season>\d{1,2})[.\s-]*[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
            ]
            for p in patterns:
                m = re.search(p, str(text))
                if m: return int(m.group('season')), int(m.group('episode'))
            return None, None

        cookies = {'nick': user_name, 'pass': saved_pass_cookie}
        params = {'action': 'files', 'id': f'{torrent_id}'}
    
        try:
            resp = nc_get('https://ncore.pro/ajax.php', params=params, cookies=cookies, headers=headers)
            soup = BeautifulSoup(resp.text, 'html.parser')
            rows = soup.find_all('tr', class_=['listrow_odd', 'listrow_even'])

            p_link = self.params.get('poster_link', '')
            desc = self.params.get('description', '')
            tmdb_id = self.params.get('tmdb_id', '')
            imdb_id = self.params.get('imdb_id', '')
            t1 = self.params.get('title_1', '')
            t2 = self.params.get('title_2', '')

            for row in rows:
                cols = row.find_all('td')
                if len(cols) >= 3:
                    raw_path = cols[1].get_text(strip=True)
                    full_file_name = os.path.basename(raw_path.replace('\\', '/'))

                    video_exts = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.mp3', '.flac')
                    if not full_file_name.lower().endswith(video_exts):
                        continue

                    file_parts = full_file_name.rsplit('.', 1)
                    file_base = file_parts[0]
                    ext_raw = file_parts[1].lower()[:3] if len(file_parts) > 1 else "   "
                    
                    bytes_val = convert_to_bytes(cols[2].get_text(strip=True))
                    display_size = format_size_force_5(bytes_val)

                    all_pos = self.db.get_video_positions(torrent_id, full_file_name)

                    valid_positions = []
                    seen_labels_count = set()
                    
                    for p in all_pos:
                        p_sec = float(p['position'])
                        p_dur = float(p.get('duration', 0))
                        label = p['label']
                        if p_dur > 0 and (p_dur - p_sec) < 15: continue
                        if label in seen_labels_count: continue
                        valid_positions.append(p)
                        seen_labels_count.add(label)
                    
                    pos_count = len(valid_positions)
                    save_info = ""

                    query = f"single_item_folder&torrent_id={torrent_id}&f_name={quote_plus(full_file_name)}&f_size={bytes_val}&direct_resume=true"

                    if pos_count > 0:
                        last_label = valid_positions[0]['label']
                        save_info = f" [COLOR yellow]>> {last_label}[/COLOR]"
                        if pos_count > 1:
                            save_info += f" [COLOR orange]({pos_count} mentés)[/COLOR]"
                            query = f"list_file_positions&torrent_id={torrent_id}&f_name={quote_plus(full_file_name)}&f_size={bytes_val}&direct_resume=true"
                        else:
                            query += f"&resume_time={quote_plus(last_label)}&resume_seconds={valid_positions[0]['position']}&direct_resume=true"

                    cur_s, cur_e = 0, 0
                    cur_r_type = 'movie'
                    r_label = "Film értékelése"
                    
                    if is_series_pack:
                        s_found, e_found = local_extract_se(full_file_name)
                        if s_found is not None and e_found is not None:
                            cur_s, cur_e = s_found, e_found
                            cur_r_type = 'episode'
                            r_label = f"Epizód értékelése (S{cur_s:02d}E{cur_e:02d})"
                        else:
                            cur_r_type = 'show'
                            r_label = "Sorozat értékelése"

                    local_rating = self.db.get_trakt_rating(imdb_id, cur_r_type, cur_s, cur_e)
                    rating_plot_info = ""
                    if local_rating:
                        rating_plot_info = f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]\n"

                    file_context_menu = []
                    if self.is_trakt_active() and imdb_id:
                        rating_query = (f"set_trakt_rating_action&imdb_id={imdb_id}"
                                        f"&r_type={cur_r_type}&s={cur_s}&e={cur_e}"
                                        f"&title_1={quote_plus(file_base)}")
                        file_context_menu.append(("[B][COLOR gold]" + r_label + "[/COLOR][/B]", rating_query))

                    inherited = {
                        'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'poster_link': p_link, 
                        'description': desc, 'title_1': t1, 'title_2': t2,
                        'is_music': self.params.get('is_music'),
                        'is_xxx': self.params.get('is_xxx')
                    }
                    for k, v in inherited.items():
                        if v: query += f"&{k}={quote_plus(str(v))}"

                    entry_string = f"{save_info} [{display_size}][{ext_raw:<3}] {file_base}"
                    
                    metadata = {
                        'title': f'[B]{entry_string}[/B]', 
                        'plot': f'{rating_plot_info}Fájlnév: {full_file_name}\nÉrvényes mentett pontok: {pos_count}\n\n{desc}'
                    }
                    
                    self.addDirectoryItem(
                        name=f'[B]{entry_string}[/B]', 
                        query=query, 
                        thumb=p_link,
                        icon='DefaultMovies.png', 
                        context=file_context_menu,
                        isFolder=True, 
                        meta=metadata
                    )

        except Exception as e:
            xbmc.log(f"[nCore_FileList] Hiba: {str(e)}", xbmc.LOGERROR)
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:
            self.endDirectory(user_change_view)

    def getFileListContext(self):
        t_id = self.params.get('torrent_id')
        from urllib.parse import urlencode
        
        target_params = {
            'action': 'get_file_list',
            'torrent_id': t_id
        }

        for key in ['poster_link', 'imdb_id', 'tmdb_id', 'title_1', 'title_2', 'description', 'is_music', 'is_xxx']:
            val = self.params.get(key)
            if val: target_params[key] = val
            
        plugin_url = f"plugin://{addon_str}/?{urlencode(target_params)}"
        xbmc.executebuiltin(f'Container.Update({plugin_url})')

    def playPrevEpisodeAction(self):
        torrent_id = self.params.get('torrent_id')
        original_args_b64 = self.params.get('original_args', '')
        is_music = self.params.get('is_music') == 'true'
        is_xxx = self.params.get('is_xxx') == 'true'

        from urllib.parse import unquote_plus, unquote
        playing_file = xbmc.Player().getPlayingFile()
        
        import os
        raw_name = os.path.basename(playing_file.replace('\\', '/'))
        current_file_name = unquote(raw_name)

        if not is_music and any(current_file_name.lower().endswith(ext) for ext in ['.mp3', '.flac', '.wav', '.m4a', '.aac']):
            is_music = True

        prev_file = self.get_prev_file_info(torrent_id, current_file_name)
        #xbmc.log(f"[nCore_NEXT_Debug] Előző rész keresése -> Aktuális: {current_file_name} | Talált: {prev_file}", xbmc.LOGINFO)

        if prev_file:
            match = re.search(r'[sS](\d+)[eExX](\d+)', prev_file)
            if match:
                notif_tag = f"S{int(match.group(1)):02d}E{int(match.group(2)):02d}"
            else:
                notif_tag = prev_file[:25]

            xbmc.executebuiltin('PlayerControl(Stop)')
            xbmc.sleep(3000)

            try:
                import base64
                from urllib.parse import parse_qsl, urlencode
                
                args_raw = base64.b64decode(original_args_b64).decode('utf-8')
                if args_raw.startswith('?'): args_raw = args_raw[1:]
                params_dict = dict(parse_qsl(args_raw))
                
                for key in ['resume_percent', 'resume_seconds', 'resume_time', 'target_episode', 'f_name', 'select', 'position', 'direct_resume']:
                    params_dict.pop(key, None)

                params_dict['f_name'] = prev_file
                xbmcgui.Window(10000).setProperty('nCore_TV_Switching', 'true')

                if is_music: params_dict['is_music'] = 'true'
                if is_xxx: params_dict['is_xxx'] = 'true'
                
                clean_query = urlencode(params_dict)
                new_addon_url = f'plugin://plugin.video.nCore_TV/?{clean_query}'

                xbmc.executebuiltin(f'AlarmClock(nCorePrev, PlayMedia("{new_addon_url}"), 00:02, silent)')
            except Exception as e:
                xbmc.log(f"[nCore_DEBUG] playPrev -> KRITIKUS HIBA: {str(e)}", xbmc.LOGERROR)

    def playNextEpisodeAction(self):
        torrent_id = self.params.get('torrent_id')
        original_args_b64 = self.params.get('original_args', '')
        is_music = self.params.get('is_music') == 'true'
        is_xxx = self.params.get('is_xxx') == 'true'

        from urllib.parse import unquote_plus, unquote
        playing_file = xbmc.Player().getPlayingFile()
        
        import os
        raw_name = os.path.basename(playing_file.replace('\\', '/'))
        current_file_name = unquote(raw_name)
        
        if not is_music and any(current_file_name.lower().endswith(ext) for ext in ['.mp3', '.flac', '.wav', '.m4a', '.aac']):
            is_music = True

        next_file = self.get_next_file_info(torrent_id, current_file_name)
        #xbmc.log(f"[nCore_NEXT_Debug] Következő rész keresése -> Aktuális: {current_file_name} | Talált: {next_file}", xbmc.LOGINFO)

        if next_file:
            match = re.search(r'[sS](\d+)[eExX](\d+)', next_file)
            if match:
                notif_tag = f"S{int(match.group(1)):02d}E{int(match.group(2)):02d}"
            else:
                notif_tag = next_file[:25]

            xbmc.executebuiltin('PlayerControl(Stop)')
            xbmc.sleep(3000)

            try:
                import base64
                from urllib.parse import parse_qsl, urlencode
                
                args_raw = base64.b64decode(original_args_b64).decode('utf-8')
                if args_raw.startswith('?'): args_raw = args_raw[1:]
                params_dict = dict(parse_qsl(args_raw))
                
                for key in ['resume_percent', 'resume_seconds', 'resume_time', 'target_episode', 'f_name', 'select', 'position', 'direct_resume']:
                    params_dict.pop(key, None)

                params_dict['f_name'] = next_file
                xbmcgui.Window(10000).setProperty('nCore_TV_Switching', 'true')

                if is_music: params_dict['is_music'] = 'true'
                if is_xxx: params_dict['is_xxx'] = 'true'
                
                clean_query = urlencode(params_dict)
                new_addon_url = f'plugin://plugin.video.nCore_TV/?{clean_query}'

                xbmc.executebuiltin(f'AlarmClock(nCoreNext, PlayMedia("{new_addon_url}"), 00:02, silent)')
            except Exception as e:
                xbmc.log(f"[nCore_DEBUG] playNext -> KRITIKUS HIBA: {str(e)}", xbmc.LOGERROR)

    def root(self):
        self.checkAuthFast()
        self.check_background_sync()
        
        last_update_str = addon.getSetting("last_update")

        calculated_logout_time_str = ""
        if last_update_str and last_update_str.replace('.', '', 1).isdigit():
            try:
                last_update_timestamp = float(last_update_str)
                dt_object = datetime.fromtimestamp(last_update_timestamp)
                next_logout_time = dt_object + timedelta(days=28)
                calculated_logout_time_str = next_logout_time.strftime("%Y-%m-%d %H:%M:%S")
            except (ValueError, OSError):
                calculated_logout_time_str = ""

        display_value_for_settings = calculated_logout_time_str 
        if display_value_for_settings:
            display_value_for_settings = f"{calculated_logout_time_str}"

        addon.setSetting("next_logout_display", display_value_for_settings)
        
        meta_utoljara_nezett = (f'\n[COLOR lime]-[/COLOR] GitHub szinkronizáció (ha aktív)')
        self.addDirectoryItem(f"[B]Utoljára nézettek[/B]{ncore_coloring}", f"played_torrents", '', 'DefaultFolder.png', meta={'plot': f'{meta_utoljara_nezett}'})
        
        meta_watchlist = (f'\n[COLOR lime]-[/COLOR] Megnézendők\nTrakt/Simkl/Plex (ha aktív)')
        self.addDirectoryItem(f"[B]Megnézendők ([COLOR orange]Trakt[/COLOR]/[COLOR cyan]Simkl[/COLOR]/[COLOR yellow]Plex[/COLOR])[/B]{ncore_coloring}", f"all_merged_watchlist", '', 'DefaultFolder.png', meta={'plot': f'{meta_watchlist}'})
        
        self.addDirectoryItem(f"[B]Film[/B]{ncore_coloring}", f"movie_categories", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat[/B]{ncore_coloring}", f"series_categories", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Zene[/B]{ncore_coloring}", f"zene_categories", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Widgetek (REMUX / 4K / 1080)[/B]{ncore_coloring}", f"widget_menu", '', 'DefaultFolder.png')
        
        if xxx_contents == 'true':
            self.addDirectoryItem(f"[B]XXX[/B]{ncore_coloring}", f"xxx_categories", '', 'DefaultFolder.png')
        
        if h_w_n.strip().lower() == file_test.strip().lower():
            pass
        else:
            forum_meta = {
                'plot': f"[COLOR black].[/COLOR]\n[B] [COLOR lightgreen]Rövidített link a fórumhoz:[/COLOR] {forum_roviditett_link}\n\n [COLOR lightgreen]Teljes link a fórumhoz:[/COLOR] {forum_link}[/B]",
                'title': forum_szoveg
            }
            
            forum_qr_code_path = "special://home/addons/plugin.video.nCore_TV/resources/qrcode.png"
            self.addDirectoryItem(
                forum_szoveg, '', '', forum_qr_code_path,
                meta=forum_meta
            )
        
        meta_sorozat_figyelo = (f'\n[COLOR lime]-[/COLOR] Context menüvel hozáadott sorozatok profilokra bontva')
        meta_sorozat_figyelo += f'\n[COLOR lime]-[/COLOR] GitHub szinkronizáció (ha aktív)'
        self.addDirectoryItem(f"[B]SorozatFigyelő ([COLOR yellow]IMDb ID[/COLOR])[/B]{ncore_coloring}", f"show_watching_series", '', 'DefaultFolder.png', meta={'plot': f'{meta_sorozat_figyelo}'})

        if self.is_trakt_active():
            show_t_name = addon.getSetting('trakt_username_visible') == 'true'
            t_user = addon.getSetting('trakt_username')

            if show_t_name and t_user and t_user != "" and t_user != "None":
                meta_trakt = f'\nTrakt: [B][COLOR orange]{t_user}[/COLOR][/B]'
            else:
                meta_trakt = f'\nTrakt: [COLOR lime]Hitelesítve[/COLOR]'
            
            meta_trakt += f'\n[COLOR lime]-[/COLOR] Félbehagyottak (Continue Watching)'
            meta_trakt += f'\n[COLOR lime]-[/COLOR] Megnézett Filmek / Elkezdett Sorozatok'
            meta_trakt += f'\n[COLOR lime]-[/COLOR] Watchlist / Up Next / History / Airing Next'
        else:
            meta_trakt = (f'\n[COLOR grey]A Trakt segítségével minden eszközöd szinkronban marad.[/COLOR]')
            meta_trakt += f'\n[COLOR lime]•[/COLOR] Onnan folytathatod a filmet vagy sorozatot, ahol a másikon abbahagytad'
            meta_trakt += f'\n[COLOR lime]•[/COLOR] Automatikusan naplózza, amit elkezdtél/megnéztél (Scrobbling)\n'
            meta_trakt += f'\n[COLOR lime]-[/COLOR] A Beállításokban tudod aktiválni a Trakt.tv figyelőt.'
            
        self.addDirectoryItem(f"[B]Trakt.tv[/B]{ncore_coloring}", f"show_trakt_categories", '', trakt_notif_icon, meta={'plot': f'{meta_trakt}'})

        if self.is_simkl_active():
            show_s_name = addon.getSetting('simkl_username_visible') == 'true'
            s_user = addon.getSetting('simkl_username')
            
            if show_s_name and s_user and s_user != "" and s_user != "None":
                meta_simkl = f'\nSimkl: [B][COLOR cyan]{s_user}[/COLOR][/B]'
            else:
                meta_simkl = f'\nSimkl: [COLOR lime]Hitelesítve[/COLOR]'

            meta_simkl += f'\n[COLOR lime]-[/COLOR] Félbehagyottak (Continue Watching)'
            meta_simkl += f'\n[COLOR lime]-[/COLOR] Megnézett Filmek / Elkezdett Sorozatok'
            meta_simkl += f'\n[COLOR lime]-[/COLOR] Plan to Watch / History / Airing Next'
        else:    
            meta_simkl = (f'[COLOR grey]A Simkl segítségével minden eszközöd szinkronban marad.[/COLOR]')
            meta_simkl += f'\n[COLOR lime]•[/COLOR] Onnan folytathatod a filmet vagy sorozatot, ahol a másikon abbahagytad'
            meta_simkl += f'\n[COLOR lime]•[/COLOR] Automatikusan naplózza, amit elkezdtél/megnéztél (Scrobbling)\n'
            meta_simkl += f'\n[COLOR lime]-[/COLOR] A Beállításokban tudod aktiválni a Simkl.com figyelőt.'
            
        self.addDirectoryItem(f"[B]Simkl.com[/B]{ncore_coloring}", f"show_simkl_categories", '', simkl_notif_icon, meta={'plot': f'{meta_simkl}'})

        if self.is_plex_active():
            show_p_name = addon.getSetting('plex_username_visible') == 'true'
            p_user = addon.getSetting('plex_username')
            
            if show_p_name and p_user and p_user != "" and p_user != "None":
                meta_plex = f'\nPlex: [B][COLOR dodgerblue]{p_user}[/COLOR][/B]'
            else:
                meta_plex = f'\nPlex: [COLOR lime]Hitelesítve[/COLOR]'
            
            meta_plex += f'\n[COLOR lime]-[/COLOR] Félbehagyottak (Continue Watching)'
            meta_plex += f'\n[COLOR lime]-[/COLOR] Megnézett Filmek / Elkezdett Sorozatok'
            meta_plex += f'\n[COLOR lime]-[/COLOR] Watchlist / History'
        else:
            meta_plex = (f'\n[COLOR grey]A Plex segítségével minden eszközöd szinkronban marad.[/COLOR]')
            meta_plex += f'\n[COLOR lime]•[/COLOR] Onnan folytathatod a filmet vagy sorozatot, ahol a másikon abbahagytad'
            meta_plex += f'\n[COLOR lime]•[/COLOR] Automatikusan naplózza, amit elkezdtél/megnéztél (Scrobbling)\n'
            meta_plex += f'\n[COLOR lime]-[/COLOR] A Beállításokban tudod aktiválni a Plex.tv figyelőt.'
            
        self.addDirectoryItem(f"[B]Plex.tv[/B]{ncore_coloring}", f"show_plex_categories", '', plex_notif_icon, meta={'plot': f'{meta_plex}'})
        
        #
        meta_ajanlo = (f'\n[COLOR lime]-[/COLOR] themoviedb.org (TMDB)')
        meta_ajanlo += f'\n[COLOR lime]-[/COLOR] JustWatch'
        meta_ajanlo += f'\n[COLOR lime]-[/COLOR] TheTVDB'
        meta_ajanlo += f'\n[COLOR lime]-[/COLOR] Simkl'
        meta_ajanlo += f'\n[COLOR lime]-[/COLOR] Trakt'
        meta_ajanlo += f'\n[COLOR lime]-[/COLOR] TMDb api'
        self.addDirectoryItem(f"[B][COLOR gold]Ajánlók[/B][/COLOR]{ncore_coloring}", f"get_ajanlo_categs", '', 'DefaultFolder.png', meta={'plot': f'{meta_ajanlo}'})

        
        extend_s = (f'\nKülönböző Keresések:')
        extend_s += f'\n[COLOR lime]-[/COLOR] Keresési előzmények'
        extend_s += f'\n[COLOR lime]-[/COLOR] Beépített keresések'
        extend_s += f'\n[COLOR lime]-[/COLOR] Sorozatokra & filmekre'
        extend_s += f'\n[COLOR lime]-[/COLOR] IMDb-id-ra'
        extend_s += f'\n[COLOR lime]-[/COLOR] Bővített kereső'
        extend_s += f'\n[COLOR lime]-[/COLOR] Színészre'
        extend_s += f'\n[COLOR lime]-[/COLOR] IMDb-n keresztül'
        self.addDirectoryItem(f"[B]Kereső[/B]{ncore_coloring}", f"extend_searches", '', 'DefaultFolder.png', meta={'plot': f'{extend_s}'})

        is_active_custom_filter_active = addon.getSetting('custom_filter_active') == 'true'
        if is_active_custom_filter_active:
            saved = addon.getSetting('custom_filter_list').split(',')
            names = quality.FILTER_NAMES
            readable = [names[int(i)] for i in saved if i.isdigit() and int(i) < len(names)]
            filter_status = ", ".join(readable)
            status_color = "orange"
        else:
            filter_status = "Nincs szűrés (Minden látszik)"
            status_color = "lime"

        self.addDirectoryItem(
            f"[B]Kereső (felbontás) szűrő: [COLOR {status_color}]{filter_status}[/COLOR][/B]", 
            "custom_filter_menu", '', 'DefaultFolder.png',
            meta={'plot': f'[B]Beállított szűrési profil:[/B]\n[COLOR orange]{filter_status}[/COLOR]'}, 
            isFolder=True
        )

        self.addDirectoryItem(f"[B]Könyvjelzők[/B]{ncore_coloring}", f"book_mark", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Futtatott Torrentek[/B]{ncore_coloring}", f"seeded_torrents", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Utoljára hozzáadott ([COLOR FFF56C00]hit'n'run[/COLOR] Torrentek)[/B]{ncore_coloring}", f"get_hnr", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Elindított Torrentek (Elementum)[/B]{ncore_coloring}", f"elementum_part", '', 'DefaultFolder.png')

        display_text = f"[B]Statisztika[/B]{ncore_coloring}"

        enable_2fa_status_for_menu = addon.getSetting("enable_2fa")

        if enable_2fa_status_for_menu == 'true' and calculated_logout_time_str:
            display_text = f"[B]Statisztika[/B] - (aktív 2fa: [COLOR FFF56C00]Kiléptetés >[/COLOR] [COLOR ffff0000][B]{calculated_logout_time_str}[/B][/COLOR]){ncore_coloring}"

        self.addDirectoryItem(display_text, f"stats", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Adatbázis Statisztika[/B]{ncore_coloring}", f"db_summary", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Válasz Check: Simkl | Plex | Trakt [/B]{ncore_coloring}", f"cloud_auth_diagnostic", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:
            self.endDirectory(user_change_view)


    def SearchWindow(self):
        is_refresh = xbmcgui.Window(10000).getProperty('nCore_Rating_Refreshing') == 'true'
        last_url = xbmcgui.Window(10000).getProperty('nCore_LastSearchUrl')

        if is_refresh and last_url:
            xbmcgui.Window(10000).clearProperty('nCore_Rating_Refreshing')
            self.getItems(last_url)
            return

        pop_up_ExtendedSearchWindow = ExtendedSearchWindow("[B]Bővített Kereső:[/B]")
        pop_up_ExtendedSearchWindow.doModal()
        del pop_up_ExtendedSearchWindow

        self.endDirectory(cache=False)

    def OpenRatingWindow(self):
        t_id = self.params.get('torrent_id')
        i_id = self.params.get('imdb_id')
        title = self.params.get('title_1')

        pop_up_Rating = RatingManagerWindow(title, t_id, i_id)
        pop_up_Rating.doModal()
        del pop_up_Rating

    def OpenRatingManager(self):
        t_id = self.params.get('torrent_id')
        i_id = self.params.get('imdb_id')
        title = unquote_plus(self.params.get('title_1', 'Értékelés'))
        
        if t_id and not self.db.has_torrent_structure(t_id):
            self.sync_torrent_files_to_db(t_id)

        _, ncore_cat = self.torrent_filename_and_category(t_id)
        series_cats = ['hdser_hun', 'hdser', 'xvidser_hun', 'xvidser']
        is_tv = ncore_cat in series_cats

        options = []
        if is_tv:
            options.append("[B][COLOR gold]Teljes Sorozat értékelése[/COLOR][/B]")
            options.append("[B][COLOR cyan]Epizódok / Évadok kezelése[/COLOR][/B]")
        else:
            options.append("[B][COLOR gold]Film értékelése[/COLOR][/B]")

        sel = xbmcgui.Dialog().select(f"Értékelés: {title}", options)
        
        if sel == 0:
            r_type = 'show' if is_tv else 'movie'
            self.params.update({'imdb_id': i_id, 'r_type': r_type, 's': '0', 'e': '0', 'title_1': title})
            self.setTraktRatingAction()
        elif sel == 1 and is_tv:
            pop_up_Rating = RatingManagerWindow(f"[B]Kezelő: {title}[/B]", t_id, i_id, self.db)
            pop_up_Rating.doModal()
            del pop_up_Rating

            xbmcgui.Window(10000).setProperty('nCore_Rating_Refreshing', 'true')
            
            xbmc.sleep(500)
            xbmc.executebuiltin("Container.Refresh")

    def show_playback_menu(self, torrent_id, elementum_url, original_args):
        from resources.lib.indexers.pause_menu import PlaybackSettingsMenu

        f_pos = self.params.get('f_pos', '0')
        f_count = self.params.get('f_count', '0')

        window = PlaybackSettingsMenu(torrent_id, elementum_url, original_args, f_pos=f_pos, f_count=f_count)
        window.doModal()
        del window

        xbmc.executebuiltin('SetFocus(12005)')
        xbmc.executebuiltin('Action(Down)')
        xbmc.executebuiltin('Action(Up)')

    def TraktMenu(self):
        window = TraktInterface("[B]Trakt.tv Engedélyezés[/B]")
        window.doModal()
        del window

    def SimklMenu(self):
        window = SimklInterface("[B]Simkl.com Engedélyezés[/B]")
        window.doModal()
        del window

    def PlexMenu(self):
        window = PlexInterface("[B]Plex.tv Engedélyezés[/B]")
        window.doModal()
        del window

    def is_trakt_active(self):
        return addon.getSetting('trakt_enabled') == 'true' and addon.getSetting('trakt_access_token') != ''

    def is_simkl_active(self):
        return addon.getSetting('simkl_enabled') == 'true' and addon.getSetting('simkl_access_token') != ''

    def is_plex_active(self):
        return addon.getSetting('plex_enabled') == 'true' and addon.getSetting('plex_token') != ''

    def check_background_sync(self):
        if not self.is_trakt_active() and not self.is_simkl_active() and not self.is_plex_active():
            return

        last_sync = addon.getSetting('last_full_sync_timestamp')
        if not last_sync: last_sync = 0
        
        current_time = time.time()
        try:
            _interval = max(15, int(addon.getSetting('sync_interval_min') or 360)) * 60
        except ValueError:
            _interval = 360 * 60
        if (current_time - float(last_sync)) > _interval:
            sync_thread = threading.Thread(target=self.run_silent_sync)
            sync_thread.daemon = True
            sync_thread.start()
            addon.setSetting('last_full_sync_timestamp', str(current_time))

    def run_silent_sync(self):
        try:
            if self.is_trakt_active():
                res = TraktInterface.sync_full_trakt_history(return_data=True)
                if res:
                    w_data, id_map = res
                    self.db.update_full_service_sync('trakt', w_data, id_map)

                    ratings_data = TraktInterface.fetch_all_trakt_ratings()
                    if ratings_data:
                        self.db.sync_bulk_trakt_ratings(ratings_data)
                    
                    from datetime import datetime
                    addon.setSetting('trakt_last_sync_time', datetime.now().strftime('%Y-%m-%d %H:%M'))

            if self.is_simkl_active():
                res = SimklInterface.sync_full_simkl_history(return_data=True)
                if res:
                    w_data, id_map = res
                    self.db.update_full_service_sync('simkl', w_data, id_map)
                    from datetime import datetime
                    addon.setSetting('simkl_last_sync_time', datetime.now().strftime('%Y-%m-%d %H:%M'))

            if self.is_plex_active():
                res = PlexInterface.sync_full_plex_history(return_data=True)
                if res:
                    w_data, id_map = res
                    self.db.update_full_service_sync('plex', w_data, id_map)
                    from datetime import datetime
                    addon.setSetting('plex_last_sync_time', datetime.now().strftime('%Y-%m-%d %H:%M'))
                    
        except Exception as e:
            xbmc.log(f"[nCore_TV] Sync error: {e}", xbmc.LOGERROR)


    def get_saved_device_names(self):
        return self.db.get_device_names()

    def save_device_name(self, device_name):
        self.db.add_device_name(device_name)
        self.db.export_to_json(self.seriesWatchFileName, self.saved_device_names_file)
    
    def extWatchingSeries(self, url, imdb_id, title_1, title_2, title_3, poster_link):
        dialog = xbmcgui.Dialog()
        egyedi_eszkoz_name = None

        while egyedi_eszkoz_name is None:
            saved_names = self.get_saved_device_names()
            selection_list_options = []

            if not saved_names:
                new_name_input = dialog.input('Adj meg egy felhasználónevet:', type=xbmcgui.INPUT_ALPHANUM)
                if new_name_input:
                    egyedi_eszkoz_name = new_name_input.strip()
                    if egyedi_eszkoz_name:
                        self.save_device_name(egyedi_eszkoz_name)
                    else:
                        xbmcgui.Dialog().notification('nCore TV', 'Érvénytelen felhasználónév, megszakítva.', xbmcgui.NOTIFICATION_WARNING)
                        return
                else:
                    return

            else:
                selection_list_options.append("Új felhasználó megadása...")
                selection_list_options.extend(saved_names)
                selected_index = dialog.select('Válaszd ki a felhasználót vagy adj meg egy újat:', selection_list_options)

                if selected_index == -1: return
                elif selected_index == 0:
                    new_name_input = dialog.input('Adj meg egy új felhasználónevet:', type=xbmcgui.INPUT_ALPHANUM)
                    if new_name_input:
                        egyedi_eszkoz_name = new_name_input.strip()
                        if egyedi_eszkoz_name:
                            self.save_device_name(egyedi_eszkoz_name)
                        else: return
                    else: return
                else:
                    egyedi_eszkoz_name = saved_names[selected_index - 1]
        
        current_timestamp = time.time()
        rogzitett_date_and_time_str = datetime.fromtimestamp(current_timestamp).strftime('%Y-%m-%d %H:%M:%S')        

        new_entry = {
            "imdb_id": str(imdb_id),
            "egyedi_eszkoz_name": egyedi_eszkoz_name,
            "title_1": str(title_1),
            "title_2": str(title_2),
            "title_3": str(title_3),
            "poster_link": str(poster_link),
            "full_link": str(url),
            "rogzitett_timestamp": current_timestamp,
            "rogzitett_date_and_time": rogzitett_date_and_time_str
        }

        self.db.add_watching_series(new_entry)

        self.db.export_to_json(self.seriesWatchFileName, self.saved_device_names_file)

        pick_title = title_2 if title_2 and title_2.lower() != 'none' else (title_3 if title_3 and title_3.lower() != 'none' else title_1)

        github_sync_enabled = addon.getSetting('github_sync_enabled') == 'true'
        if github_sync_enabled:
            sync_success = self.github_sync_manager.sync_watching_series_files(self.saved_device_names_file, self.seriesWatchFileName)
            msg = f'Sorozat követve: [COLOR lime]{pick_title}[/COLOR] és szinkronizálva!' if sync_success else f'Sorozat követve, de szinkronizálási hiba!'
            xbmcgui.Dialog().notification('nCore TV', msg, xbmcgui.NOTIFICATION_INFO if sync_success else xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmcgui.Dialog().notification('nCore TV', f'Sorozat követve: [COLOR lime]{pick_title}[/COLOR] [{egyedi_eszkoz_name}]')
    
    def getWatchingSeries(self, url, imdb_id, title_1, title_2, poster_link):
        safe_url = str(url) if url is not None else ''
        safe_imdb_id = str(imdb_id) if imdb_id is not None else ''
        safe_title_1 = str(title_1) if title_1 is not None else ''
        safe_title_2 = str(title_2) if title_2 is not None else ''
        safe_poster_link = str(poster_link) if poster_link is not None else ''

        if not safe_imdb_id or not safe_imdb_id.startswith('tt'):
            xbmcgui.Dialog().notification(
                'nCore TV',
                'Hiányzó vagy érvénytelen IMDb azonosító (nem "tt" kezdetű). Sorozat követése megszakítva.',
                xbmcgui.NOTIFICATION_ERROR, 3000
            )
            return

        title_3_from_imdb = ''
        current_poster_link = safe_poster_link

        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'hu',
            'origin': 'https://www.imdb.com',
            'referer': 'https://www.imdb.com/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        }
        
        try:
            resp = nc_get(f'https://v3.sg.media-imdb.com/suggestion/x/{safe_imdb_id}.json', headers=headers).json()

            found_valid_entry = None
            if 'd' in resp and isinstance(resp['d'], list):
                for entry_data in resp['d']:
                    if 'id' in entry_data and entry_data['id'].startswith('tt'):
                        found_valid_entry = entry_data
                        break
            
            if found_valid_entry:
                if 'i' in found_valid_entry and found_valid_entry['i'] is not None and 'imageUrl' in found_valid_entry['i']:
                    current_poster_link = found_valid_entry['i']['imageUrl']
                
                if 'l' in found_valid_entry:
                    title_3_from_imdb = found_valid_entry['l']

        except requests.exceptions.RequestException as req_e:
            xbmc.log(f'{base_log_info}| getWatchingSeries | Hálózati hiba az IMDb lekérésekor: {str(req_e)}. A művelet folytatódik az eredeti poster_link és üres title_3 mellett.', xbmc.LOGERROR)
        except json.JSONDecodeError as json_e:
            xbmc.log(f'{base_log_info}| getWatchingSeries | JSON dekódolási hiba az IMDb lekérésekor: {str(json_e)}. A művelet folytatódik az eredeti poster_link és üres title_3 mellett.', xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f'{base_log_info}| getWatchingSeries | Általános hiba az IMDb adatok lekérésekor: {str(e)}. A művelet folytatódik az eredeti poster_link és üres title_3 mellett.', xbmc.LOGERROR)

        plugin_next_action = (
            f"plugin://{addon_str}/?action=ext_watching_series"
            f"&url={quote_plus(safe_url)}"
            f"&imdb_id={quote_plus(safe_imdb_id)}"
            f"&title_1={quote_plus(safe_title_1)}"
            f"&title_2={quote_plus(safe_title_2)}"
            f"&title_3={quote_plus(title_3_from_imdb)}"
            f"&poster_link={quote_plus(current_poster_link)}"
        )

        xbmc.executebuiltin(f'Container.Update({plugin_next_action})')

    def ShowWatchingSeries(self):
        github_sync_enabled = addon.getSetting('github_sync_enabled')

        if github_sync_enabled == 'true':
            self.addDirectoryItem(name=f"[B]SorozatFigyelő profilok [COLOR orange]feltöltése GitHubra[/COLOR][/B]{ncore_coloring}", query=f"github_sync_watching_series_action", thumb='DefaultFolder.png', meta={'plot': 'Feltöltés...'})
            self.addDirectoryItem(name=f"[B]SorozatFigyelő profilok [COLOR yellow]letöltése GitHubról[/COLOR][/B]{ncore_coloring}", query=f"github_download_and_merge_watching_series_action", thumb='DefaultFolder.png', meta={'plot': 'Letöltés és összefésülés...'})

        unique_users_in_history = self.db.get_device_names()
        selected_user_to_filter = None
        
        if unique_users_in_history:
            selection_options = ["Összes felhasználó"]
            if github_sync_enabled == 'true':
                selection_options.append("[B]Profilok egyesítése GitHubról[/B]")
            
            selection_options.extend(unique_users_in_history)
            selected_index = xbmcgui.Dialog().select('Válassz felhasználót:', selection_options)
        
            if selected_index == -1:
                xbmc.executebuiltin(f'Container.Update("plugin://{addon_str}/")')
                return
            elif selected_index == 0:
                selected_user_to_filter = None
            elif github_sync_enabled == 'true' and selected_index == 1:
                self.github_download_and_merge_watching_series_action()
                return
            else:
                offset = 2 if github_sync_enabled == 'true' else 1
                selected_user_to_filter = unique_users_in_history[selected_index - offset]

        series_items = self.db.get_watching_series(filter_user=selected_user_to_filter)
        
        for entry in series_items:
            entry_user_name = entry.get("user_name")
            item_url = entry.get('full_link', '')
            item_imdb_id = entry.get('imdb_id', '')
            
            pick_title = entry.get('title_2') if entry.get('title_2') and entry.get('title_2').lower() != 'none' else (entry.get('title_3') if entry.get('title_3') and entry.get('title_3').lower() != 'none' else entry.get('title_1'))

            delete_it = (
                f'[B][COLOR ffff0000]Törlés innen: [COLOR lime][{entry_user_name}][/COLOR][/B]',
                f'delete_watching_series&full_link={quote_plus(item_url)}&imdb_id={item_imdb_id}&watching_user_name={entry_user_name}'
            )
            
            self.addDirectoryItem(
                name=f"[{entry_user_name}] {pick_title} ({entry.get('rogzitett_date_and_time', 'N/A')})",
                query=f"newsearch_3&url={quote_plus(item_url)}&imdb_id={item_imdb_id}",
                thumb=entry.get('poster_link', 'DefaultVideo.png'),
                context=[delete_it],
                isFolder=True,
                meta={'title': pick_title, 'plot': f"Követve: {entry.get('rogzitett_date_and_time', 'N/A')}", 'imdbnumber': item_imdb_id}
            )
        
        if not series_items:
            xbmcgui.Dialog().notification('nCore TV', 'Nincs követett tartalom.', xbmcgui.NOTIFICATION_INFO, 2000)
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def github_download_and_merge_watching_series_action(self):
        self.db.export_to_json(self.seriesWatchFileName, self.saved_device_names_file)
        success_devices = self.github_sync_manager.download_and_merge_saved_device_names(self.saved_device_names_file)
        success_history = self.github_sync_manager.download_and_merge_series_watch_history(self.seriesWatchFileName)

        if success_devices and success_history:
            #xbmc.log(f'{base_log_info}| github_download_and_merge_watching_series_action | Sorozat figyelő adatok sikeresen frissítve!', xbmc.LOGINFO)
            xbmcgui.Dialog().notification("GitHub Letöltés", "SorozatFigyelő sikeresen frissítve!", xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            #xbmc.log(f'{base_log_info}| github_download_and_merge_watching_series_action | Hiba a Sorozat figyelő adatok letöltése vagy egyesítése közben!', xbmc.LOGERROR)
            xbmcgui.Dialog().notification("GitHub Letöltés", "Hiba a Sorozat figyelő adatok letöltése vagy egyesítése közben!", xbmcgui.NOTIFICATION_ERROR, 5000)

    def github_sync_watching_series_action(self):
        github_sync_enabled = addon.getSetting('github_sync_enabled')
        if github_sync_enabled == 'true':
            self.db.export_to_json(self.seriesWatchFileName, self.saved_device_names_file)

        if github_sync_enabled == 'true':
            sync_success = self.github_sync_manager.sync_watching_series_files(
                self.saved_device_names_file,
                self.seriesWatchFileName
            )
            if sync_success:
                #xbmc.log(f'{base_log_info}| github_sync_watching_series_action | Sorozat figyelő adatok sikeresen feltöltve!', xbmc.LOGINFO)
                xbmcgui.Dialog().notification("GitHub Szinkronizálás", "SorozatFigyelő sikeresen feltöltve!", xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                #xbmc.log(f'{base_log_info}| github_sync_watching_series_action | Hiba a sorozat figyelő adatok feltöltésekor!', xbmc.LOGERROR)
                xbmcgui.Dialog().notification("GitHub Szinkronizálás", "Hiba a sorozat figyelő adatok feltöltésekor!", xbmcgui.NOTIFICATION_ERROR, 5000)
        else:
            #xbmc.log(f'{base_log_info}| github_sync_watching_series_action | A GitHub szinkronizáció nincs engedélyezve az addon beállításaiban.', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Sorozat figyelő szinkronizálás", "A GitHub szinkronizáció nincs engedélyezve az addon beállításaiban.", xbmcgui.NOTIFICATION_WARNING, 5000)

    def delete_watching_series(self, full_link, imdb_id, watching_user_name):
        self.db.delete_watching_series(imdb_id, watching_user_name)
        self.db.export_to_json(self.seriesWatchFileName, self.saved_device_names_file)

        xbmcgui.Dialog().notification('nCore TV', f'Eltávolítva: {imdb_id} [{watching_user_name}]', xbmcgui.NOTIFICATION_INFO, 2000)

        if addon.getSetting('github_sync_enabled') == 'true':
            self.github_sync_manager.sync_watching_series_files(self.saved_device_names_file, self.seriesWatchFileName)

        xbmc.executebuiltin(f'Container.Update("plugin://{addon_str}/?action=show_watching_series")')


    def GithubPlayedList(self):
        if addon.getSetting('github_sync_enabled') != 'true':
            self.addDirectoryItem("[B]A GitHub szinkronizálás ki van kapcsolva.[/B]", '', '', 'DefaultFolder.png')
            self.endDirectory('plot')
            return

        export_data = self.db.get_all_played_data_for_export()
        if export_data:
            self.save_data_automatically(self.local_played_torrents_file, export_data)

        sync_success = self.github_sync_manager.sync_played_torrents_and_view(self)

        if os.path.exists(self.local_played_torrents_file):
            try: os.remove(self.local_played_torrents_file)
            except: pass

        if sync_success:
            xbmc.executebuiltin('Container.Refresh()')
            self.view_github_played_list()
        else:
            xbmcgui.Dialog().notification(
                "Utoljára nézettek (Szinkronizálás)",
                "Szinkronizálás hibával befejezve.",
                xbmcgui.NOTIFICATION_ERROR, 5000
            )
            self.addDirectoryItem("[B]Szinkronizálás hibával befejezve.[/B]", '', '', 'DefaultFolder.png')
            self.endDirectory('plot')

    def load_merged_played_torrents_from_github(self):
        #xbmc.log(f'{base_log_info}| load_merged_played_torrents_from_github | Kísérlet a GitHubról egyesített lejátszott torrentek betöltésére.', xbmc.LOGINFO)
        merged_torrents_data = []

        local_merged_path = self.merged_played_torrents_filename

        if not os.path.exists(local_merged_path):
            #xbmc.log(f'{base_log_info}| load_merged_played_torrents_from_github | A helyi egyesített lejátszott torrentek fájl nem található: {local_merged_path}', xbmc.LOGINFO)
            return merged_torrents_data

        try:
            with open(local_merged_path, "r", encoding="utf-8") as f:
                merged_torrents_data = json.load(f)
            #xbmc.log(f'{base_log_info}| load_merged_played_torrents_from_github | Egyesített lejátszott torrentek sikeresen betöltve a helyi fájlból.', xbmc.LOGINFO)
        except json.JSONDecodeError as e:
            #xbmc.log(f'{base_log_info}| load_merged_played_torrents_from_github | Hiba az egyesített lejátszott torrentek JSON dekódolásakor ({local_merged_path}): {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('nCore TV', 'Hiba az egyesített lejátszott torrentek betöltésekor.', xbmcgui.NOTIFICATION_ERROR)
        except Exception as e:
            #xbmc.log(f'{base_log_info}| load_merged_played_torrents_from_github | Általános hiba az egyesített lejátszott torrentek betöltésekor ({local_merged_path}): {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('nCore TV', 'Hiba az egyesített lejátszott torrentek betöltésekor.', xbmcgui.NOTIFICATION_ERROR)
        
        return merged_torrents_data

    def view_github_played_list(self):
        success = self.github_sync_manager.download_github_merged_list(self)
        if success:
            self.all_merged_played_torrents()
        else:
            xbmcgui.Dialog().notification(
                "Utoljára nézettek (GitHub megtekintés)",
                "Nem sikerült letölteni a GitHub listát.",
                xbmcgui.NOTIFICATION_ERROR, 5000
            )
            self.addDirectoryItem("[B]Nem sikerült betölteni a GitHub listát.[/B]", '', '', 'DefaultFolder.png')
            self.endDirectory('plot')


    def parse_and_format_torrent_details(self, title_1, hnr_tstart):
        if _lite_on():
            # gyors mód: nyers nCore-név + feltöltés (a PTN-elemzés elemenként ~1,5 ms x86-on, gyenge boxon 5-10x)
            return {'plot': f'[COLOR lightblue]{title_1}[/COLOR]\n{hnr_tstart}'}
        PTN_title_list = PTN.parse(title_1)
        #xbmc.log(f"parse_and_format_torrent_details | title_1: {title_1}\n {PTN_title_list}\n", xbmc.LOGINFO)
        
        extr_parsed_title = PTN_title_list.get('title', title_1)
        extr_resolution = PTN_title_list.get('resolution', 'SD')
        extr_quality = PTN_title_list.get('quality')
        extr_year = PTN_title_list.get('year')
        extr_codec = PTN_title_list.get('codec')
        extr_audio = PTN_title_list.get('audio')
        
        extr_language_set = set()
        initial_language = PTN_title_list.get('language')
        if initial_language:
            if isinstance(initial_language, list):
                for lang in initial_language:
                    extr_language_set.add(lang.strip().capitalize())
            else:
                extr_language_set.add(initial_language.strip().capitalize())

        extr_season_raw = PTN_title_list.get('season')
        extr_episode_raw = PTN_title_list.get('episode')

        extr_season_display = None
        if isinstance(extr_season_raw, list) and extr_season_raw:
            try:
                int_seasons = sorted([int(s) for s in extr_season_raw])
                if len(int_seasons) > 1:
                    extr_season_display = f"{int_seasons[0]:02d}-{int_seasons[-1]:02d}"
                else:
                    extr_season_display = f"{int_seasons[0]:02d}"
            except (ValueError, TypeError):
                extr_season_display = str(extr_season_raw)
        elif extr_season_raw is not None:
            try:
                extr_season_display = f"{int(extr_season_raw):02d}"
            except (ValueError, TypeError):
                extr_season_display = str(extr_season_raw)

        extr_episode_display = None
        if isinstance(extr_episode_raw, list) and extr_episode_raw:
             try:
                int_episodes = sorted([int(e) for e in extr_episode_raw])
                if len(int_episodes) > 1:
                    extr_episode_display = f"{int_episodes[0]:02d}-{int_episodes[-1]:02d}"
                else:
                    extr_episode_display = f"{int_episodes[0]:02d}"
             except (ValueError, TypeError):
                extr_episode_display = str(extr_episode_raw)
        elif extr_episode_raw is not None:
            try:
                extr_episode_display = f"{int(extr_episode_raw):02d}"
            except (ValueError, TypeError):
                extr_episode_display = str(extr_episode_raw)

        extr_network = PTN_title_list.get('network')
        extr_hdr_flag = PTN_title_list.get('hdr')
        extr_uhd_flag = PTN_title_list.get('uhd')
        extr_repack_flag = PTN_title_list.get('repack')
        
        extr_encoder = PTN_title_list.get('encoder')
        extr_excess_list = PTN_title_list.get('excess', [])

        if isinstance(extr_excess_list, str):
            extr_excess_list = [extr_excess_list]

        extr_dolby_vision_flag = PTN_title_list.get('dolby_vision')
        if not extr_dolby_vision_flag:
            temp_excess_list = list(extr_excess_list)
            for item in temp_excess_list:
                if isinstance(item, str) and item.lower() in ['dv', 'dovi', 'dolby.vision', 'dolbyvision']:
                    extr_dolby_vision_flag = True
                    if item in extr_excess_list:
                        extr_excess_list.remove(item)
                    break

        hungarian_indicators = ['hun', 'magyar']

        if extr_encoder:
            match_hun_prefix = re.match(r'(hun|magyar)-(.+)', extr_encoder, re.IGNORECASE)
            if match_hun_prefix:
                extr_language_set.add('[COLOR green][B]Magyar[/B][/COLOR]')
                extr_encoder = match_hun_prefix.group(2).strip()
            else:
                if extr_encoder.lower() in hungarian_indicators:
                    extr_language_set.add('[COLOR green][B]Magyar[/B][/COLOR]')
                    extr_encoder = None
        
        temp_excess_list = list(extr_excess_list)
        for item in temp_excess_list:
            if isinstance(item, str) and item.lower() in hungarian_indicators:
                extr_language_set.add('[COLOR green][B]Magyar[/B][/COLOR]')
                extr_excess_list.remove(item)
        
        extr_display_language = ', '.join(sorted(list(extr_language_set))) if extr_language_set else None
        
        
        resolution_display = ''
        if extr_uhd_flag or '2160p' in extr_resolution.lower() or '4k' in extr_resolution.lower():
            resolution_display = '[COLOR cyan][B]2160p[/B][/COLOR]'
        elif re.search(r'1080[pi]', extr_resolution.lower()):
            resolution_display = f'[COLOR yellow]{extr_resolution}[/COLOR]'
        elif re.search(r'720[pi]', extr_resolution.lower()):
            resolution_display = f'[COLOR gold]{extr_resolution}[/COLOR]'
        elif '480p' in extr_resolution.lower():
            resolution_display = f'[COLOR ffff0000]{extr_resolution} (SD)[/COLOR]'
        elif '360p' in extr_resolution.lower():
            resolution_display = f'[COLOR ffff0000]{extr_resolution} (SD)[/COLOR]'        
        else:
            resolution_display = ''
        
        ### >
        full_plot_details = [f'{hnr_tstart}']

        combined_res_parts = []
        if resolution_display:
            combined_res_parts.append(f"[COLOR gold][B]Felbontás:[/B][/COLOR] {resolution_display}")

        if extr_hdr_flag:
            combined_res_parts.append("[COLOR ffed9b18][B]HDR[/B][/COLOR]")
        
        if extr_dolby_vision_flag:
            combined_res_parts.append("[COLOR ff105ee6][B]DoVi[/B][/COLOR]")        
        
        if combined_res_parts:
            full_plot_details.append(" [COLOR magenta] | [/COLOR] ".join(combined_res_parts))

        title_to_display = extr_parsed_title
        if extr_season_display:
            title_to_display += f"[COLOR gold] - [/COLOR][COLOR ff4091ed]S{extr_season_display}[/COLOR]"
            if extr_episode_display:
                title_to_display += f"[COLOR ff4091ed]E{extr_episode_display}[/COLOR]"
        elif extr_year: 
            title_to_display += f" ({extr_year})"
            
        if title_to_display:
            full_plot_details.append(f"[COLOR ff9ef542][B]{title_to_display}[/B][/COLOR]")

        if extr_display_language:
            full_plot_details.append(f"Nyelv: {extr_display_language}")

        if extr_encoder:
            full_plot_details.append(f"Releaser: {extr_encoder}")
        
        if extr_quality:
            full_plot_details.append(f"Minőség: {extr_quality}")
        
        # if extr_codec:
            # full_plot_details.append(f"Codec: {extr_codec}")
        
        if extr_audio:
            full_plot_details.append(f"Hang: {extr_audio}")

        
        if extr_network:
            full_plot_details.append(f"Forrás: {extr_network}")
        
        if extr_repack_flag:
            full_plot_details.append(f"Repack: Igen")
        
        if extr_excess_list:
            full_plot_details.append(f"További infó: {', '.join(extr_excess_list)}")

        meta_plot_text = "\n".join(full_plot_details)
        
        return {'plot': meta_plot_text}


    def getMovieCategories(self):
        self.addDirectoryItem(f"[B]Film HU 4K[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=2160p&miben=name&tipus=hd_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film HU 4K (Dolby Vision)[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_dovi}&miben=name&tipus=hd_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film HU REMUX[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=remux&miben=name&tipus=hd_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film HU REMUX[/B] [COLOR lime](seed szerint)[/COLOR]{ncore_coloring}", f"movie_items&url={quote_plus(f'{mire_hd_seed}=remux&miben=name&tipus=hd_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film HU 1080[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=1080i%7C1080p&miben=name&tipus=hd_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film HU 720[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=720i%7C720p&miben=name&tipus=hd_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film HU SD[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_sd}=xvid_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[COLOR lime][B]Kereső HU: Film[/B][/COLOR]", f"newsearch&url={quote_plus(f'{base_url}{movie_hu_kereso}')}", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Film EN 4K[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=2160p&miben=name&tipus=hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film EN 4K (Dolby Vision)[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_dovi}&miben=name&tipus=hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film EN REMUX[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=remux&miben=name&tipus=hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film EN REMUX[/B] [COLOR lime](seed szerint)[/COLOR]{ncore_coloring}", f"movie_items&url={quote_plus(f'{mire_hd_seed}=remux&miben=name&tipus=hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film EN 1080[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=1080i%7C1080p&miben=name&tipus=hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film EN 720[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_hd}=720i%7C720p&miben=name&tipus=hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Film EN SD[/B]{ncore_coloring}", f"sort_pick&target=movie_items&url={quote_plus(f'{mire_sd}=xvid')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[COLOR FFF56C00][B]Kereső EN: Film[/B][/COLOR]", f"newsearch&url={quote_plus(f'{base_url}{movie_en_kereso}')}", '', 'DefaultFolder.png')
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def getSeriesCategories(self):
        self.addDirectoryItem(f"[B]Sorozat HU 4K[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=2160p&miben=name&tipus=hdser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat HU 4K (Dolby Vision)[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_dovi}&miben=name&tipus=hdser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat HU REMUX[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=remux&miben=name&tipus=hdser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat HU REMUX[/B] [COLOR lime](seed szerint)[/COLOR]{ncore_coloring}", f"series_items&url={quote_plus(f'{mire_hd_seed}=remux&miben=name&tipus=hdser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat HU 1080[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=1080i%7C1080p&miben=name&tipus=hdser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat HU 720[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=720i%7C720p&miben=name&tipus=hdser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat HU SD[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_sd}=xvidser_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[COLOR lime][B]Kereső HU: Sorozat[/B][/COLOR]", f"newsearch&url={quote_plus(f'{base_url}{series_hu_kereso}')}", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Sorozat EN 4K[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=2160p&miben=name&tipus=hdser')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat EN 4K (Dolby Vision)[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_dovi}&miben=name&tipus=hdser')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat EN REMUX[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=remux&miben=name&tipus=hdser')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat EN REMUX[/B] [COLOR lime](seed szerint)[/COLOR]{ncore_coloring}", f"series_items&url={quote_plus(f'{mire_hd_seed}=remux&miben=name&tipus=hdser')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat EN 1080[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=1080i%7C1080p&miben=name&tipus=hdser')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat EN 720[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_hd}=720i%7C720p&miben=name&tipus=hdser')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozat EN SD[/B]{ncore_coloring}", f"sort_pick&target=series_items&url={quote_plus(f'{mire_sd}=xvidser')}", '', 'DefaultFolder.png')        
        self.addDirectoryItem(f"[COLOR FFF56C00][B]Kereső EN: Sorozat[/B][/COLOR]", f"newsearch&url={quote_plus(f'{base_url}{series_en_kereso}')}", '', 'DefaultFolder.png')
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def getZeneCategories(self):
        self.addDirectoryItem(f"[B]Zene HU MP3[/B]{ncore_coloring}", f"zene_items&url={quote_plus(f'{mire_sd}=&miben=name&tipus=mp3_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Zene HU FLAC[/B]{ncore_coloring}", f"zene_items&url={quote_plus(f'{mire_sd}&miben=name&tipus=lossless_hun')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[COLOR lime][B]Kereső HU: Zene, Clip[/B][/COLOR]", f"newsearch&url={quote_plus(f'{base_url}{zene_hu_kereso}')}", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Clip[/B]{ncore_coloring}", f"zene_items&url={quote_plus(f'{mire_sd}=&miben=name&tipus=clip')}", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Zene EN MP3[/B]{ncore_coloring}", f"zene_items&url={quote_plus(f'{mire_sd}=&miben=name&tipus=mp3')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Zene EN FLAC[/B]{ncore_coloring}", f"zene_items&url={quote_plus(f'{mire_sd}&miben=name&tipus=lossless')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[COLOR FFF56C00][B]Kereső EN: Zene, Clip[/B][/COLOR]", f"newsearch&url={quote_plus(f'{base_url}{zene_en_kereso}')}", '', 'DefaultFolder.png')
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def getXXXCategories(self):
        self.addDirectoryItem(f"[B]XXX 4K[/B]{ncore_coloring}", f"xxx_items&url={quote_plus(f'{mire_hd}=2160p&miben=name&tipus=xxx_hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]XXX 1440[/B]{ncore_coloring}", f"xxx_items&url={quote_plus(f'{mire_hd}=1440p&miben=name&tipus=xxx_hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]XXX 1080[/B]{ncore_coloring}", f"xxx_items&url={quote_plus(f'{mire_hd}=1080i%7C1080p&miben=name&tipus=xxx_hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]XXX 720[/B]{ncore_coloring}", f"xxx_items&url={quote_plus(f'{mire_hd}=720i%7C720p&miben=name&tipus=xxx_hd')}", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]XXX SD[/B]{ncore_coloring}", f"xxx_items&url={quote_plus(f'{mire_sd}=xxx_xvid')}", '', 'DefaultFolder.png')
        self.addDirectoryItem("[B][COLOR FFF56C00]Kereső[/COLOR][/B]", f"newsearch&url={quote_plus(f'{base_url}{xxx_kereso}')}", '', 'DefaultFolder.png')
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def getElementum(self):
        self.addDirectoryItem(f"[B]Elindított Torrentek (Elementum)[/B]{ncore_coloring}", 'plugin://plugin.video.elementum/history', '', 'DefaultFolder.png', isAction=False)
        self.addDirectoryItem(f"[B]Elementum Beállítások[/B]{ncore_coloring}", 'plugin://plugin.video.elementum/settings/plugin.video.elementum', '', 'DefaultFolder.png', isAction=False)
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def getStats(self):
        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }
    
        resp = nc_get('https://ncore.pro/hitnrun.php?showall=false', cookies=cookies, headers=headers)
        soup = BeautifulSoup(resp.text, 'html.parser')
        if known_errors(str(soup)):
            return
        
        stats = []
        for label, value in zip(soup.find_all('div', class_='dt'), soup.find_all('div', class_='dd')):
            stat_item = {"label": label.get_text(strip=True), "value": value.get_text(strip=True)}
            stats.append(stat_item)
    
        profile_div = soup.find('div', id='infosav_adatok')
        if profile_div:
            username = profile_div.find('a').get_text(strip=True)
            rank = profile_div.get_text(strip=True).split(')')[0].split('(')[-1]
    
            points = re.findall(r'Pontok:.*?>(.*?)<', str(profile_div))
            points = points[0].strip() if points else "N/A"
    
            upload_data = re.findall(r'Fel:.*?>(.*?)<', str(profile_div))
            upload_data = upload_data[0].strip() if upload_data else "N/A"
        
        stats_message = "\n".join(f"{stat['label']} {stat['value']}" for stat in stats) if stats else "nem található."
        message = f"Felhasználó: {username} ({rank})\nPontok: {points}\nFel: {upload_data}\n\n{stats_message}"
        xbmcgui.Dialog().textviewer("Statisztika:", message)


    #Trakt
    def ShowTraktCategories(self):
        if not self.is_trakt_active():
            from xbmcgui import Dialog
            Dialog().ok("Trakt.tv", "Ez a funkció Trakt.tv fiókhoz kötött.[CR]Aktiváld a szolgáltatást a beállításokban!")
            return
        
        self.check_background_sync()
        
        self.addDirectoryItem(f"[B][COLOR yellow]Félbehagyottak (Continue Watching)[/COLOR][/B]", f"trakt_continue", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Megnézett Filmek[/B]", f"watched_trakt_movies", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Elkezdett Sorozatok[/B]", f"watched_trakt_series", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Filmek (Watchlist)[/B]", f"trakt_watchlist_movies", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozatok (Watchlist)[/B]", f"trakt_watchlist_series", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Elkezdett Sorozatok következő részei ([COLOR FF98fc03]Up Next[/COLOR])[/B]", f"trakt_up_next", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Film és Sorozat előzmények (History)[/B]", f"trakt_history", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Saját Menetrend (Airing Next)[/B]", f"trakt_calendar", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Felfedezés (Évszám / Kategória)[/B]", f"trakt_discovery_select", '', 'DefaultFolder.png')

        plot_info = "Borítók és ID pakk gyors begyűjtése Trakthoz"
        self.addDirectoryItem(f"[B][COLOR cyan]>>> Borítók és ID pakk gyors begyűjtése Trakthoz <<<[/COLOR][/B]", "manual_metadata_cloud_sync", '', 'DefaultAddonService.png', meta={'plot': plot_info})

        last_sync = addon.getSetting('trakt_last_sync_time') or "Még nem futott"
        trakt_meta_last_update = (f'\n[COLOR lime]-[/COLOR] Utolsó auto. frissítés:\n  {last_sync}')
        self.addDirectoryItem(f"[B][COLOR gold]Trakt adatok manuális frissítése[/COLOR][/B]", f"trakt_full_sync_action", '', 'DefaultFolder.png', meta={'plot': f'{trakt_meta_last_update}'})
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def TraktDiscoveryTypeSelect(self):
        self.addDirectoryItem("[B]Filmek[/B]", "trakt_genres_menu&media_type=movies", '', trakt_notif_icon)
        self.addDirectoryItem("[B]Sorozatok[/B]", "trakt_genres_menu&media_type=shows", '', trakt_notif_icon)
        self.endDirectory(user_change_view)

    def WatchedTraktMovies(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        watched_data = TraktInterface.get_watched_movies()
        
        if not watched_data:
            xbmcgui.Dialog().notification("Trakt", "Üres lista vagy hiba.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = watched_data[start:end]
        remaining = len(watched_data) - end

        for item in paged_items:
            movie = item.get('movie', {})
            overview = movie.get('overview', '')
            title = movie.get('title', 'Unknown')
            year = movie.get('year', '')
            ids = movie.get('ids', {})
            imdb_id = ids.get('imdb', '')
            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
            
            display_name = f"[B]{title}[/B] ({year})" if year else f"[B]{title}[/B]"

            meta_data = {
                "title": title,
                "year": year,
                "mediatype": "movie",
                "plot": f"[B]{title}[/B] ({year})\n\n{overview}"
            }

            self.addDirectoryItem(f"{display_name} - [{imdb_id}]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", poster, '', 'DefaultFolder.png', meta=meta_data)

        if remaining > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Next Page ({next_p}) [Remaining: {remaining}] >>>[/COLOR][/B]"
            self.addDirectoryItem(label, f"watched_trakt_movies&page={next_p}", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def WatchedTraktSeries(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        watched_data = TraktInterface.get_watched_shows()
        
        if not watched_data:
            xbmcgui.Dialog().notification("Trakt", "A lista üres vagy hiba történt.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = watched_data[start:end]
        remaining = len(watched_data) - end

        for item in paged_items:
            show = item.get('show', {})
            title = show.get('title', 'Unknown')
            overview = show.get('overview', '')
            year = show.get('year', '')
            ids = show.get('ids', {})
            imdb_id = ids.get('imdb', '')
            
            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            ls, le = 0, 0
            for season in item.get('seasons', []):
                sn = season.get('number', 0)
                for episode in season.get('episodes', []):
                    en = episode.get('number', 0)
                    if sn > ls or (sn == ls and en > le):
                        ls, le = sn, en

            target_ep_str = f"S{ls:02d}E{le:02d}" if ls > 0 else ""

            last_watched_info = f"[B][COLOR orange]Utoljára nézett:[/COLOR] [COLOR yellow]{target_ep_str}[/COLOR][/B] - " if ls > 0 else ""
            
            display_name = f"[B]{title}[/B] ({year})" if year else f"[B]{title}[/B]"

            meta_data = {
                "title": title,
                "year": year,
                "mediatype": "tvshow",
                "plot": f"[B]{title}[/B] ({year})\n\n[COLOR orange]Utoljára nézett:[/COLOR] {target_ep_str}\n\n{overview}"
            }

            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={target_ep_str}"
            
            self.addDirectoryItem(f"{last_watched_info}{display_name} - [{imdb_id}]", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', meta=meta_data)

        if remaining > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Következő oldal ({next_p}) [Még {remaining} sorozat] >>>[/COLOR][/B]"
            self.addDirectoryItem(label, f"watched_trakt_series&page={next_p}", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def TraktWatchlistMovies(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30
    
        data = TraktInterface.get_trakt_watchlist('movies')
        if not data:
            xbmcgui.Dialog().notification("Trakt", "A lista üres.", xbmcgui.NOTIFICATION_INFO, 3000)
            return
    
        if self.is_simkl_active():
            p_dialog = xbmcgui.DialogProgress()
            p_dialog.create("nCore TV", "Borító adatbázis szinkronizálása a Simkl-ről...")
            SimklInterface.get_simkl_watched_items()
            p_dialog.close()
    
        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = data[start:end]
        remaining = len(data) - end
    
        for item in paged_items:
            movie = item.get('movie', {})
            title = movie.get('title', 'Unknown')
            overview = movie.get('overview', '')
            year = movie.get('year', '')
            imdb_id = movie.get('ids', {}).get('imdb', '')

            poster = None
            images = movie.get('images', {})

            if images and 'poster' in images and images['poster']:
                poster_url = images['poster'][0] if isinstance(images['poster'], list) else images['poster']
                if not poster_url.startswith('http'):
                    poster_url = f"https://{poster_url}"
                poster = poster_url

            if not poster:
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            if not poster and images:
                for img_type in ['thumb', 'fanart', 'banner']:
                    if img_type in images and images[img_type]:
                        poster_url = images[img_type][0] if isinstance(images[img_type], list) else images[img_type]
                        if not poster_url.startswith('http'):
                            poster_url = f"https://{poster_url}"
                        poster = poster_url
                        break
            
            display_name = f"[B]{title}[/B] ({year})"
            self.addDirectoryItem(f"{display_name} - [{imdb_id}]", 
                                  f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                                  poster, '', 'DefaultFolder.png', meta={"title": title, "plot": f"{title}\n\n{overview}"})
    
        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal >>>[/COLOR][/B]", f"trakt_watchlist_movies&page={current_page + 1}", '', 'DefaultFolder.png')
    
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
    
    
    def TraktWatchlistSeries(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30
    
        data = TraktInterface.get_trakt_watchlist('shows')
        if not data:
            xbmcgui.Dialog().notification("Trakt", "A lista üres.", xbmcgui.NOTIFICATION_INFO, 3000)
            return
    
        if self.is_simkl_active():
            p_dialog = xbmcgui.DialogProgress()
            p_dialog.create("nCore TV", "Borító adatbázis szinkronizálása a Simkl-ről...")
            SimklInterface.get_simkl_watched_items()
            p_dialog.close()
    
        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = data[start:end]
        remaining = len(data) - end
    
        for item in paged_items:
            show = item.get('show', {})
            title = show.get('title', 'Unknown')
            overview = show.get('overview', '')
            year = show.get('year', '')
            imdb_id = show.get('ids', {}).get('imdb', '')
            raw_status = show.get('status', '').upper()

            poster = None
            images = show.get('images', {})

            if images and 'poster' in images and images['poster']:
                poster_url = images['poster'][0] if isinstance(images['poster'], list) else images['poster']
                if not poster_url.startswith('http'):
                    poster_url = f"https://{poster_url}"
                poster = poster_url

            if not poster:
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            if not poster and images:
                for img_type in ['thumb', 'fanart', 'banner']:
                    if img_type in images and images[img_type]:
                        poster_url = images[img_type][0] if isinstance(images[img_type], list) else images[img_type]
                        if not poster_url.startswith('http'):
                            poster_url = f"https://{poster_url}"
                        poster = poster_url
                        break

            if not poster or poster == "":
                poster = 'DefaultFolder.png'
            
            display_name = f"[B]{title}[/B] ({year}) [COLOR lime]{raw_status}[/COLOR]"
            
            self.addDirectoryItem(f"{display_name} [{imdb_id}]", 
                                  f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                                  poster, '', 'DefaultFolder.png', meta={"title": title, "plot": f"{title}\n\n{overview}"})
    
        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) [Még {remaining} sorozat] >>>[/COLOR][/B]", 
                                  f"trakt_watchlist_series&page={current_page + 1}", '', 'DefaultFolder.png')
    
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TraktWatchlistCombined(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        data = TraktInterface.get_trakt_watchlist('all')
        if not data:
            xbmcgui.Dialog().notification("Trakt", "A lista üres.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        if self.is_simkl_active():
            p_dialog = xbmcgui.DialogProgress()
            p_dialog.create("nCore TV", "Borító adatbázis szinkronizálása a Simkl-ről...")
            SimklInterface.get_simkl_watched_items()
            p_dialog.close()

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = data[start:end]
        remaining = len(data) - end

        for item in paged_items:
            item_type = item.get('type', '')

            if item_type == 'movie':
                movie = item.get('movie', {})
                title = movie.get('title', 'Unknown')
                overview = movie.get('overview', '')
                year = movie.get('year', '')
                imdb_id = movie.get('ids', {}).get('imdb', '')
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
                display_name = f"[B][COLOR deepskyblue]FILM[/COLOR] {title}[/B] ({year})"

            elif item_type == 'show':
                show = item.get('show', {})
                title = show.get('title', 'Unknown')
                overview = show.get('overview', '')
                year = show.get('year', '')
                imdb_id = show.get('ids', {}).get('imdb', '')
                raw_status = show.get('status', '').upper()
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

                if not poster or poster == "":
                    poster = 'DefaultFolder.png'

                display_name = f"[B][COLOR lime]SOROZAT[/COLOR] {title}[/B] ({year}) [COLOR lime]{raw_status}[/COLOR]"

            else:
                continue

            self.addDirectoryItem(f"{display_name} - [{imdb_id}]",
                                  f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}",
                                  poster, '', 'DefaultFolder.png',
                                  meta={"title": title, "plot": f"{title}\n\n{overview}"})

        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) [Még {remaining} tétel] >>>[/COLOR][/B]",
                                  f"trakt_watchlist_combined&page={current_page + 1}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TraktUpNext(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 15 

        watched_shows = TraktInterface.get_watched_shows()
        if not watched_shows:
            xbmcgui.Dialog().notification("Trakt", "Nincsenek folyamatban lévő sorozatok.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        watched_shows.sort(key=lambda x: x.get('last_watched_at', ''), reverse=True)

        start_index = (current_page - 1) * items_per_page
        end_index = start_index + items_per_page
        target_shows = watched_shows[start_index:end_index]
        
        remaining_count = len(watched_shows) - end_index

        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV - Up Next", f"Epizódok szinkronizálása ({current_page}. oldal)...")

        for idx, item in enumerate(target_shows):
            show = item.get('show', {})
            title = show.get('title', 'Unknown')
            imdb_id = show.get('ids', {}).get('imdb')
            
            if p_dialog.iscanceled(): break
            
            percent = int((idx / len(target_shows)) * 100)
            p_dialog.update(percent, f"Sorozat ellenőrzése: [B]{title}[/B]")

            if imdb_id:
                progress = TraktInterface.get_trakt_show_progress(imdb_id)
                
                if progress:
                    s_num = progress['season']
                    e_num = progress['number']
                    ep_title = progress['title']
                    ep_plot = progress['plot']
                    ep_thumb = progress['thumb']
                    
                    target_ep_str = f"S{s_num:02d}E{e_num:02d}"
                    
                    stats = f"[COLOR grey]({progress['completed']}/{progress['aired']} rész kész)[/COLOR]"
                    display_name = f"[COLOR lime][UP NEXT][/COLOR] [B]{title}[/B] - [COLOR orange]S{s_num:02d}E{e_num:02d}[/COLOR] {stats}"
                    
                    meta = {
                        "title": f"{s_num}x{e_num} - {ep_title}",
                        "plot": f"[B]{ep_title}[/B]\n\n{ep_plot}",
                        "mediatype": "episode",
                        "season": s_num,
                        "episode": e_num,
                        "tvshowtitle": title
                    }

                    thumb = ep_thumb if ep_thumb else 'DefaultFolder.png'

                    self.addDirectoryItem(display_name, 
                                          f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={target_ep_str}", 
                                          thumb, '', 'DefaultFolder.png', meta=meta)

        p_dialog.close()

        if remaining_count > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Következő oldal ({next_p}) [Még {remaining_count} sorozat van hátra] >>>[/COLOR][/B]"
            self.addDirectoryItem(label, f"trakt_up_next&page={next_p}", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def TraktHistory(self):
        current_page = int(self.params.get('page', 1))
        
        data = TraktInterface.get_trakt_history(page=current_page)
        if not data:
            xbmcgui.Dialog().notification("Trakt", "Nincs előzmény.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        for item in data:
            itype = item.get('type')
            watched_at = item.get('watched_at', '')[:10]

            target_ep_str = ""
            
            if itype == 'movie':
                movie = item.get('movie', {})
                title = movie.get('title', 'Unknown')
                overview = movie.get('overview', '')
                year = movie.get('year', '')
                imdb_id = movie.get('ids', {}).get('imdb', '')
                year_display = f" ({year})" if year else ""
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B]{year_display} [COLOR grey]({watched_at})[/COLOR]"
                plot = f"{title}{year_display}\n\n{overview}"
            else:
                show = item.get('show', {})
                episode = item.get('episode', {})
                title = show.get('title', 'Unknown')
                overview = show.get('overview', '')
                year = show.get('year', '')
                imdb_id = show.get('ids', {}).get('imdb', '')
                
                s_num = episode.get('season', 0)
                e_num = episode.get('number', 0)
                ep_title = episode.get('title', '')

                target_ep_str = f"S{s_num:02d}E{e_num:02d}"
                
                year_display = f" ({year})" if year else ""
                display_name = f"[B][COLOR orange]RÉSZ[/COLOR][/B] | [B]{title}[/B]{year_display} - [COLOR yellow]S{s_num:02d}E{e_num:02d}[/COLOR] [COLOR grey]({watched_at})[/COLOR]"
                plot = f"{ep_title}\n\nSorozat: {title}{year_display}\n\n{overview}"

            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={target_ep_str}"

            self.addDirectoryItem(f"{display_name} [{imdb_id}]", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', meta={"title": title, "plot": plot})

        self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) >>>[/COLOR][/B]", f"trakt_history&page={current_page + 1}", '', 'DefaultFolder.png')
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def add_trakt_watchlist_action(self, imdb_id, is_series):
        status = TraktInterface.trakt_add_watchlist(imdb_id, is_series == 'true')
        if status:
            xbmcgui.Dialog().notification("Trakt", "Hozzáadva: Watchlist", trakt_notif_icon, 3000)

    def TraktFullSync(self):
        res = TraktInterface.sync_full_trakt_history(return_data=True)
        if res:
            w_data, id_map = res
            self.db.update_full_service_sync('trakt', w_data, id_map)

            ratings_data = TraktInterface.fetch_all_trakt_ratings()
            if ratings_data:
                self.db.sync_bulk_trakt_ratings(ratings_data)
            
            from datetime import datetime
            addon.setSetting('trakt_last_sync_time', datetime.now().strftime('%Y-%m-%d %H:%M'))
            xbmcgui.Dialog().notification("Trakt", "Szinkronizáció kész (pontszámokkal)!", trakt_notif_icon, 3000)

        self.endDirectory(type=user_change_view, cache=False, update=True)

    def TraktCalendar(self):
        import datetime
        
        data = TraktInterface.get_trakt_calendar()
        if not data:
            xbmcgui.Dialog().notification("Trakt", "A naptár üres.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        today = datetime.datetime.now().date()

        for item in data:
            episode = item.get('episode', {})
            s_num = episode.get('season', 0)

            if s_num == 0: continue 

            show = item.get('show', {})
            title = show.get('title', 'Unknown')
            imdb_id = show.get('ids', {}).get('imdb', '')
            description = show.get('overview', '')
            
            raw_date_str = item.get('first_aired', '')[:10]
            
            e_num = episode.get('number', 0)

            episode_label = f"S{s_num:02d}E{e_num:02d}"

            try:
                item_date = datetime.datetime.strptime(raw_date_str, '%Y-%m-%d').date()
            except:
                item_date = today

            date_color = "lime" if item_date <= today else "grey"
            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
            
            display_name = f"[COLOR {date_color}]{raw_date_str}[/COLOR] | [B][COLOR orange]{episode_label}[/COLOR] - {title}[/B]"
            
            meta = {"title": f"{title} - {episode_label}", "plot": f"Epizód: {episode.get('title', '')}\nPremier: {raw_date_str}\n\n{description}", "mediatype": "episode"}

            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={episode_label}"

            self.addDirectoryItem(f"{display_name}", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', meta=meta)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TraktContinueWatching(self):
        from resources.lib.indexers.trakt_parts import TraktInterface
        
        current_page = int(self.params.get('page', 1))
        items_per_page = 20
        
        data, total_items = TraktInterface.get_trakt_playback(page=current_page, limit=items_per_page)
        
        if data == "AUTH_ERROR":
            xbmcgui.Dialog().ok("Trakt Hiba", "A Trakt hitelesítés lejárt.")
            return        
        if not data:
            if current_page == 1:
                xbmcgui.Dialog().notification("Trakt", "Nincs félbehagyott tartalom.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        remaining_count = max(0, total_items - (current_page * items_per_page))

        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV", "Trakt lista összeállítása...")

        for idx, item in enumerate(data):
            if p_dialog.iscanceled(): break
            
            progress_pct = int(float(item.get('progress', 0)))
            itype = item.get('type')
            media = item.get('movie') if itype == 'movie' else item.get('show')
            title = media.get('title', 'Ismeretlen')
            imdb_id = media.get('ids', {}).get('imdb', '')
            tmdb_id = media.get('ids', {}).get('tmdb', '')

            target_ep_str = ""

            if itype == 'movie':
                year = media.get('year', '')
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B] ({year}) - [COLOR yellow]{progress_pct}%[/COLOR]"
                plot_header = f"[B]{title} ({year})[/B]"
            else:
                ep = item.get('episode', {})
                s, e = ep.get('season', 0), ep.get('number', 0)

                target_ep_str = f"S{s:02d}E{e:02d}"
                
                display_name = f"[B][COLOR orange]RÉSZ[/COLOR][/B] | [B]{title}[/B] - [COLOR yellow]S{s:02d}E{e:02d} ({progress_pct}%)[/COLOR]"
                plot_header = f"[B]{title} - S{s:02d}E{e:02d}[/B]"

            p_dialog.update(int((idx / len(data)) * 100), f"Feldolgozás: [B]{title}[/B]")

            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
            if (not poster or "DefaultMovies" in poster) and tmdb_id:
                poster = TraktInterface.get_tmdb_poster_path_profi(tmdb_id, itype)

            full_plot = f"{plot_header}\n[COLOR yellow]Folytatás: {progress_pct}%[/COLOR]\n\n{media.get('overview', '')}"

            url_params = (f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}"
                          f"&imdb_id={imdb_id}"
                          f"&target_episode={target_ep_str}"
                          f"&resume_percent={progress_pct}")

            self.addDirectoryItem(f"{display_name}", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', 
                                  meta={"title": title, "plot": full_plot})

        p_dialog.close()

        if remaining_count > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) - ({remaining_count} tartalom maradt) >>>[/COLOR][/B]", 
                                  f"trakt_continue&page={current_page + 1}", 
                                  '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def TraktGenresMenu(self):
        media_type = self.params.get('media_type', 'movies')
        
        from resources.lib.indexers.trakt_parts import TraktInterface
        genres = TraktInterface.get_trakt_genres(media_type)
        
        if not genres:
            xbmcgui.Dialog().notification("Trakt", "Nem sikerült lekérni a kategóriákat.", xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        for g in genres:
            name = g.get('name')
            slug = g.get('slug')

            url_params = "trakt_years_menu&media_type={}&genre_slug={}&genre_name={}".format(
                media_type, slug, quote_plus(name)
            )
            self.addDirectoryItem(f"[B]{name}[/B]", url_params, '', trakt_notif_icon)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TraktYearsMenu(self):
        m_type = self.params.get('media_type')
        g_slug = self.params.get('genre_slug')
        g_name = self.params.get('genre_name')
        
        for year in range(datetime.now().year, 1949, -1):
            u_params = f"trakt_filtered_items&media_type={m_type}&genre_slug={g_slug}&year={year}&page=1"
            self.addDirectoryItem(f"[B]{year}[/B] - {g_name}", u_params, '', trakt_notif_icon)
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TraktFilteredItems(self):
        m_type = self.params.get('media_type')
        g_slug = self.params.get('genre_slug')
        year = self.params.get('year')
        page = int(self.params.get('page', 1))
        
        from resources.lib.indexers.trakt_parts import TraktInterface
        data, total = TraktInterface.get_trakt_filtered_content(m_type, g_slug, year, page)
        if not data:
            self.endDirectory(user_change_view)
            return
    
        imdb_ids_on_page = []
        for item in data:
            media = item.get('movie') or item.get('show') or item
            i_id = media.get('ids', {}).get('imdb')
            if i_id: imdb_ids_on_page.append(i_id)
            
        db_sync_data = self.db.get_indicators_for_list(imdb_ids_on_page) if imdb_ids_on_page else {}
    
        for item in data:
            media = item.get('movie') or item.get('show') or item
            title = media.get('title')
            imdb_id = media.get('ids', {}).get('imdb')
    
            indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])

            poster = None
            images = media.get('images', {})

            if images and 'poster' in images and images['poster']:
                poster_url = images['poster'][0] if isinstance(images['poster'], list) else images['poster']
                if not poster_url.startswith('http'):
                    poster_url = f"https://{poster_url}"
                poster = poster_url

            if not poster:
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            if not poster and images:
                for img_type in ['thumb', 'fanart', 'banner']:
                    if img_type in images and images[img_type]:
                        poster_url = images[img_type][0] if isinstance(images[img_type], list) else images[img_type]
                        if not poster_url.startswith('http'):
                            poster_url = f"https://{poster_url}"
                        poster = poster_url
                        break
    
            context_menu_items = [
                (f"[B][COLOR gold]Adatbázis ID Check[/COLOR][/B]", f"id_database_audit&imdb_id={imdb_id}"),
            ]
            
            if self.is_trakt_active(): 
                context_menu_items.append(("[B][COLOR orange]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series={'true' if m_type == 'shows' else 'false'}"))
    
            u_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}"
            
            metadata = {
                "title": title, 
                "plot": f"{plot_status_line}\n\n{media.get('overview', 'Nincs leírás.')}",
                "year": media.get('year')
            }
    
            self.addDirectoryItem(
                name=f"[B]{indicator}{title}[/B]", 
                query=u_params, 
                thumb=poster, 
                icon='DefaultFolder.png', 
                context=context_menu_items, 
                meta=metadata
            )
    
        if total > (page * 20):
            u_next = f"trakt_filtered_items&media_type={m_type}&genre_slug={g_slug}&year={year}&page={page + 1}"
            self.addDirectoryItem(f"[B][COLOR orange]>>> Következő oldal ({page + 1}) >>>[/COLOR][/B]", u_next, '', trakt_notif_icon)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TraktTrendingLists(self):
        current_page = int(self.params.get('page', 1))
        from resources.lib.indexers.trakt_parts import TraktInterface
        
        lists_data = TraktInterface.get_trakt_trending_lists(page=current_page)
        
        if not lists_data:
            xbmcgui.Dialog().notification("Trakt", "Nem sikerült betölteni a listákat.", xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        for item in lists_data:
            trakt_list = item.get('list', {})
            list_name = trakt_list.get('name')
            list_id = trakt_list.get('ids', {}).get('trakt')
            user_slug = trakt_list.get('user', {}).get('ids', {}).get('slug') or trakt_list.get('user', {}).get('username')
            list_description = trakt_list.get('description', 'Nincs leírás.')
            item_count = trakt_list.get('item_count', 0)
            likes = trakt_list.get('likes', 0)
            user_name = trakt_list.get('user', {}).get('username', 'Ismeretlen')

            display_label = f"[B]{list_name}[/B] [COLOR grey]({item_count} db)[/COLOR]"

            plot = f"[B]{list_name}[/B]\n"
            plot += f"[COLOR orange]Készítette:[/COLOR] {user_name}\n"
            plot += f"[COLOR yellow]Kedvelések:[/COLOR] {likes} 👍\n\n"
            plot += list_description

            url_params = f"trakt_list_items&list_id={list_id}&user_slug={user_slug}&list_name={quote_plus(list_name)}&page=1"
            
            self.addDirectoryItem(display_label, url_params, '', 'DefaultFolder.png', meta={"title": list_name, "plot": plot})

        u_next = f"trakt_trending_lists&page={current_page + 1}"
        self.addDirectoryItem(f"[B][COLOR orange]>>> Következő oldal ({current_page + 1}) >>>[/COLOR][/B]", u_next, '', trakt_notif_icon)
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def _clean_trakt_desc(self, text):
        if not text: return "Nincs leírás."
        for char in ['*', '_', '#']:
            text = text.replace(char, '')
        return text.strip()

    def TraktListItems(self):
        list_id = self.params.get('list_id')
        user_slug = self.params.get('user_slug')
        list_name = self.params.get('list_name')
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        from resources.lib.indexers.trakt_parts import TraktInterface
        raw_data = TraktInterface.get_trakt_list_items(list_id, user_slug)

        if not raw_data:
            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
            return

        filtered_list = []
        seen_ids = set()

        for item in raw_data:
            media = item.get('movie') or item.get('show')
            if not media: 
                continue
            
            imdb_id = media.get('ids', {}).get('imdb')
            if not imdb_id: 
                continue
                
            if imdb_id in seen_ids: 
                continue
            
            item['clean_media'] = media
            filtered_list.append(item)
            seen_ids.add(imdb_id)

        total_items = len(filtered_list)
        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = filtered_list[start:end]
        remaining = total_items - end

        imdb_ids_on_page = [i['clean_media'].get('ids', {}).get('imdb') for i in paged_items]
        db_sync_data = self.db.get_indicators_for_list(imdb_ids_on_page) if imdb_ids_on_page else {}

        for item in paged_items:
            media = item['clean_media']
            itype = item.get('type')
            imdb_id = media.get('ids', {}).get('imdb', '')

            indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])

            title = media.get('title', 'Unknown')
            year = media.get('year', '')
            rating = media.get('rating', 0)
            overview = self._clean_trakt_desc(media.get('overview', ''))
            type_label = "[COLOR lightgreen]FILM[/COLOR]" if itype == 'movie' else "[COLOR orange]SOROZAT[/COLOR]"

            images = media.get('images', {})
            poster = ""
            if images.get('poster'):
                img_url = images['poster'][0]
                poster = "https://" + img_url if not img_url.startswith('http') else img_url
            else:
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            display_name = f"{indicator}{title} ({year}) - [COLOR yellow]★ {rating:.1f}[/COLOR]"
            
            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}"

            metadata = {
                "title": title, 
                "plot": f"{plot_status_line}\n{type_label}\n\n{overview}", 
                "year": year
            }

            self.addDirectoryItem(
                name=f"[B]{display_name}[/B]", 
                query=url_params, 
                thumb=poster, 
                meta=metadata
            )

        if remaining > 0:
            u_next = f"trakt_list_items&list_id={list_id}&user_slug={user_slug}&list_name={quote_plus(list_name)}&page={current_page + 1}"
            self.addDirectoryItem(f"[B][COLOR orange]>>> Következő oldal (Még {remaining} db) >>>[/COLOR][/B]", u_next, '', trakt_notif_icon)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def ManualMetadataCloudSync(self):
        import xbmcgui, requests, json, time

        last_sync = addon.getSetting('metadata_cloud_last_sync') or "0"
        current_time = int(time.time())
        wait_period = 432000
        
        if (current_time - int(float(last_sync))) < wait_period:
            if not xbmcgui.Dialog().yesno("nCore TV", "A központi borítótár naprakész. Biztosan újra le akarod tölteni?"):
                return
        
        dp = xbmcgui.DialogProgress()
        dp.create("nCore TV", "Biztonságos kapcsolat felépítése...")
        
        try:
            r = requests.get(t_k_d, timeout=25)
            if r.status_code != 200:
                raise Exception(f"Szerver hiba: {r.status_code}")

            try:
                data = r.json()
            except:
                raise Exception("A letöltött fájl nem érvényes JSON formátum.")

            if not isinstance(data, dict) or len(data) == 0:
                raise Exception("A borítótár üres vagy hibás struktúrájú.")

            total = len(data)
            dp.update(30, f"Adatok elemzése: {total} elem...")

            conn = self.db._get_connection()
            cursor = conn.cursor()

            cursor.execute("BEGIN TRANSACTION")
            
            count = 0
            for imdb_id, meta in data.items():
                if dp.iscanceled(): 
                    conn.rollback()
                    return

                if not imdb_id or not str(imdb_id).startswith('tt'):
                    continue

                poster_id = meta.get('pi')
                if not poster_id:
                    continue

                count += 1
                if count % 500 == 0:
                    percent = 30 + int((count / total) * 70)
                    dp.update(percent, f"Biztonságos beírás: {count}...")

                cursor.execute('INSERT OR IGNORE INTO sync_status (imdb_id, last_updated) VALUES (?, ?)', 
                               (imdb_id, current_time))

                cursor.execute('''
                    UPDATE sync_status SET 
                        trakt_id = COALESCE(sync_status.trakt_id, ?),
                        simkl_id = COALESCE(sync_status.simkl_id, ?),
                        simkl_poster = COALESCE(sync_status.simkl_poster, ?),
                        last_updated = ?
                    WHERE imdb_id = ? 
                      AND (simkl_poster IS NULL OR simkl_poster = "")
                ''', (meta.get('tr'), meta.get('si'), poster_id, current_time, imdb_id))

            conn.commit()
            addon.setSetting('metadata_cloud_last_sync', str(current_time))
            
            dp.close()
            if not dp.iscanceled():
                xbmcgui.Dialog().ok("Siker", f"Az adatbázis frissítése kész.[CR]{count} borító párosítva.")

        except Exception as e:
            if 'conn' in locals(): conn.rollback()
            if 'dp' in locals(): dp.close()
            xbmc.log(f"MetadataCloudSync KRITIKUS HIBA: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Hiba", f"Sikertelen szinkronizálás.[CR]Az adatbázisod érintetlen maradt.")

    def setTraktRatingAction(self):
        imdb_id = self.params.get('imdb_id')
        r_type = self.params.get('r_type', 'movie')
        season = int(self.params.get('s', 0))
        episode = int(self.params.get('e', 0))
        title = unquote_plus(self.params.get('title_1', 'Tartalom'))

        if not imdb_id:
            xbmcgui.Dialog().notification("Hiba", "Nincs IMDb azonosító az értékeléshez.", "", 3000)
            return

        list_items = [f"{i} Csillag" for i in range(10, 0, -1)]
        sel = xbmcgui.Dialog().select(f"Trakt Értékelés: {title}", list_items)
        
        if sel >= 0:
            score = 10 - sel
            from resources.lib.indexers.trakt_parts import TraktInterface
            xbmcgui.Dialog().notification("Trakt", "Értékelés küldése...", "", 1500)
            
            success = TraktInterface.send_trakt_rating(imdb_id, r_type, score, season, episode)
            
            if success:
                self.db.save_trakt_rating(imdb_id, r_type, score, season, episode)
                xbmcgui.Dialog().notification("Sikeres", f"Értékelve: {score}/10 ★", "", 3000)

                xbmcgui.Window(10000).setProperty('nCore_Rating_Refreshing', 'true')
                
                xbmc.sleep(500) 
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("Trakt Hiba", "Nem sikerült az értékelést elküldeni.")

    #Simkl
    def ShowSimklCategories(self):
        if not self.is_simkl_active():
            from xbmcgui import Dialog
            Dialog().ok("Simkl.com", "Ez a funkció Simkl.com fiókhoz kötött.[CR]Aktiváld a szolgáltatást a beállításokban!")
            return
        
        self.check_background_sync()
        
        self.addDirectoryItem(f"[B][COLOR yellow]Félbehagyottak (Continue Watching)[/COLOR][/B]", f"simkl_continue", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Megnézett Filmek[/B]", f"watched_simkl_movies", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Elkezdett Sorozatok[/B]", f"watched_simkl_series", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Tervezett (Plan to Watch)[/B]", f"simkl_plan_to_watch", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Film és Sorozat előzmények (History)[/B]", f"simkl_history", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Saját Menetrend (Airing Next)[/B]", f"simkl_calendar", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Elkezdett Sorozatok következő részei ([COLOR FF98fc03]Up Next[/COLOR])[/B]", f"simkl_up_next", '', 'DefaultFolder.png')
        
        discovery_plot_info = "Keress filmeket és sorozatokat konkrét műfaj és megjelenési évszám alapján a Simkl adatbázisából."
        self.addDirectoryItem(f"[B]Felfedezés (Évszám / Kategória)[/B]", f"simkl_discovery_select", '', 'DefaultFolder.png', meta={'plot': discovery_plot_info})
        
        last_sync = addon.getSetting('simkl_last_sync_time') or "Még nem futott"
        simkl_meta_last_update = (f'\n[COLOR lime]-[/COLOR] Utolsó auto. frissítés:\n  {last_sync}')
        self.addDirectoryItem(f"[B][COLOR gold]Simkl adatok manuális frissítése[/COLOR][/B]", f"simkl_full_sync_action", '', 'DefaultFolder.png', meta={'plot': f'{simkl_meta_last_update}'})
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def SimklDiscoveryTypeSelect(self):
        self.addDirectoryItem("[B]Filmek[/B]", "simkl_genres_menu&media_type=movies", '', simkl_notif_icon)
        self.addDirectoryItem("[B]Sorozatok[/B]", "simkl_genres_menu&media_type=shows", '', simkl_notif_icon)
        self.endDirectory(user_change_view)

    def WatchedSimklMovies(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        all_data = SimklInterface.get_simkl_watched_items()
        if not all_data: return

        movies = all_data.get('movies', [])

        movies.sort(key=lambda x: str(x.get('last_watched_at', '') or ''), reverse=True)

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = movies[start:end]
        remaining = len(movies) - end

        for item in paged_items:
            movie = item.get('movie', {})
            title = movie.get('title', 'Unknown')
            year = movie.get('year', '')
            imdb_id = movie.get('ids', {}).get('imdb', '')
            poster_url = item.get('poster_link')

            watched_date = str(item.get('last_watched_at', ''))[:10]
            
            display_name = f"[B]{title}[/B] ({year})"
            
            meta_data = {
                "title": title,
                "year": year,
                "mediatype": "movie",
                "plot": f"[B]{title}[/B] ({year})\n\nLáttam: {watched_date}\nIMDb: {imdb_id}"
            }

            self.addDirectoryItem(f"{display_name}", 
                                  f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                                  poster_url, '', 'DefaultFolder.png', meta=meta_data)

        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) [Még {remaining} film] >>>[/COLOR][/B]", 
                                  f"watched_simkl_movies&page={current_page + 1}", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)
    
    def WatchedSimklSeries(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        all_data = SimklInterface.get_simkl_watched_items()
        if not all_data:
            xbmcgui.Dialog().notification("Simkl", "A lista üres vagy hiba történt.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        watched_shows = all_data.get('shows', []) + all_data.get('anime', [])

        watched_shows.sort(key=lambda x: str(x.get('last_watched_at', '') or ''), reverse=True)
        
        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = watched_shows[start:end]
        remaining = len(watched_shows) - end

        for item in paged_items:
            show_data = item.get('show', {})
            title = show_data.get('title', 'Unknown')
            year = show_data.get('year', '')
            ids = show_data.get('ids', {})
            imdb_id = ids.get('imdb', '')
            poster_url = item.get('poster_link')
            
            watched_count = item.get('watched_episodes_count', 0)
            total_count = item.get('total_episodes_count', 0)

            last_ep_raw = str(item.get('last_watched', ''))
            
            if last_ep_raw.lower() == "none" or last_ep_raw == "":
                last_ep = ""
            else:
                last_ep = last_ep_raw

            if watched_count > 0 and watched_count >= total_count:
                user_status = " [COLOR lime](MINDET LÁTTAD)[/COLOR]"
            elif watched_count == 0:
                user_status = f" [COLOR yellow]({total_count} RÉSZ)[/COLOR]"
            else:
                diff = total_count - watched_count
                user_status = f" [COLOR yellow]({diff} ÚJ RÉSZ)[/COLOR]"

            last_info = f"[B][COLOR orange]Utoljára nézett:[/COLOR] [COLOR yellow]{last_ep}[/COLOR][/B] - " if last_ep != "" else ""
            display_name = f"[B]{title}[/B] ({year})"

            meta_data = {
                "title": title,
                "year": year,
                "mediatype": "tvshow",
                "plot": f"[B]{title}[/B]\nLátott részek: {watched_count}/{total_count}\n[COLOR orange]Utoljára nézett:[/COLOR] {last_ep}"
            }

            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={last_ep}"

            self.addDirectoryItem(f"{last_info}{display_name}{user_status}", 
                                  url_params, 
                                  poster_url, '', 'DefaultFolder.png', meta=meta_data)

        if remaining > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Következő oldal ({next_p}) [Még {remaining} sorozat] >>>[/COLOR][/B]"
            self.addDirectoryItem(label, f"watched_simkl_series&page={next_p}", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def SimklPlanToWatch(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        all_data = SimklInterface.get_simkl_watched_items()
        if not all_data:
            xbmcgui.Dialog().notification("Simkl", "Üres lista vagy hiba.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        plan_list = []
        
        # Sorozatok és Animék
        for item in all_data.get('shows', []) + all_data.get('anime', []):
            if item.get('status') == 'plantowatch':
                item['type_flag'] = 'series'
                plan_list.append(item)
                
        # Filmek
        for item in all_data.get('movies', []):
            if item.get('status') == 'plantowatch':
                item['type_flag'] = 'movie'
                plan_list.append(item)

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = plan_list[start:end]
        remaining = len(plan_list) - end

        for item in paged_items:
            is_series = item.get('type_flag') == 'series'
            inner_data = item.get('show') if is_series else item.get('movie')
            if not inner_data: continue

            title = inner_data.get('title', 'Unknown')
            year = inner_data.get('year', '')
            imdb_id = inner_data.get('ids', {}).get('imdb', '')
            poster_url = item.get('poster_link')

            if is_series:
                total_eps = item.get('total_episodes_count', 0)
                type_label = "[COLOR cyan]Sorozat [/COLOR]"
                eps_label = f" ({total_eps} rész)" if total_eps > 0 else ""
                plot_text = f"[B]{title}[/B]\nTípus: SOROZAT\nÖsszes epizód: {total_eps}"
            else:
                type_label = "   [B][COLOR lightgreen]Film[/COLOR][/B]   "
                eps_label = ""
                plot_text = f"[B]{title}[/B]\nTípus: FILM"

            display_name = f"{type_label} | [B]{title}[/B] ({year}){eps_label}"

            meta_data = {
                "title": title,
                "year": year,
                "plot": plot_text
            }

            self.addDirectoryItem(display_name, 
                                  f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                                  poster_url, '', 'DefaultFolder.png', meta=meta_data)

        if remaining > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Következő oldal ({next_p}) [Még {remaining} maradt] >>>[/COLOR][/B]"
            self.addDirectoryItem(label, f"simkl_plan_to_watch&page={next_p}", '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def SimklHistory(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        all_data = SimklInterface.get_simkl_watched_items()
        if not all_data: return

        combined = []
        for cat in ['movies', 'shows', 'anime']:
            for item in all_data.get(cat, []):
                if item.get('last_watched_at'):
                    item['item_category'] = cat
                    combined.append(item)

        combined.sort(key=lambda x: x.get('last_watched_at', ''), reverse=True)

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        paged_items = combined[start:end]
        remaining = len(combined) - end

        for item in paged_items:
            cat = item.get('item_category')
            inner = item.get('movie') if cat == 'movies' else item.get('show')
            if not inner: continue

            title = inner.get('title', 'Unknown')
            year = inner.get('year', '')
            imdb_id = inner.get('ids', {}).get('imdb', '')
            poster = item.get('poster_link')
            date = item.get('last_watched_at', '')[:10]

            year_display = f" ({year})" if year else ""

            target_ep = ""
            last_ep = str(item.get('last_watched', ''))
            
            if last_ep.lower() != "none" and last_ep != "":
                target_ep = last_ep
                display_name = f"[B][COLOR orange]RÉSZ[/COLOR][/B] | [B]{title}[/B]{year_display} - [B][COLOR yellow]{last_ep}[/COLOR][/B]"
            else:
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B]{year_display}"

            meta_data = {
                "title": f"{title}{year_display}",
                "plot": f"Láttam: {date}",
                "year": year
            }

            if target_ep:
                meta_data["plot"] = f"Láttam: {date}\n[COLOR orange]Utoljára rögzítve:[/COLOR] {target_ep}"

            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={target_ep}"

            self.addDirectoryItem(f"{display_name} [COLOR grey]({date})[/COLOR]", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', meta=meta_data)

        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) >>>[/COLOR][/B]", 
                                  f"simkl_history&page={current_page + 1}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def add_simkl_plan_action(self, imdb_id, is_series):
        status = SimklInterface.simkl_add_plan(imdb_id, is_series == 'true')
        if status:
            xbmcgui.Dialog().notification("Simkl", "Hozzáadva: Plan to Watch", simkl_notif_icon, 3000)

    def SimklFullSync(self):
        res = SimklInterface.sync_full_simkl_history(return_data=True)
        if res:
            w_data, id_map = res
            self.db.update_full_service_sync('simkl', w_data, id_map)
            
            from datetime import datetime
            addon.setSetting('simkl_last_sync_time', datetime.now().strftime('%Y-%m-%d %H:%M'))
            xbmcgui.Dialog().notification("Simkl", "Szinkronizáció kész!", simkl_notif_icon, 3000)

        self.endDirectory(type=user_change_view, cache=False, update=True)

    def SimklCalendar(self):
        import datetime

        user_data = SimklInterface.get_simkl_watched_items()
        if not user_data: return

        followed_ids = set()
        for cat in ['shows', 'anime']:
            for item in user_data.get(cat, []):
                if item.get('status') != 'completed':
                    imdb = item.get('show', {}).get('ids', {}).get('imdb')
                    if imdb: followed_ids.add(imdb)

        global_calendar = SimklInterface.get_simkl_global_calendar()
        if not global_calendar: return

        today = datetime.datetime.now().date()

        for item in global_calendar:
            ids = item.get('ids', {})
            imdb_id = ids.get('imdb')

            if imdb_id in followed_ids:
                title = item.get('title', 'Unknown')
                raw_date_str = item.get('date', '')[:10]

                ep_data = item.get('episode', {})
                s_num = ep_data.get('season', 0)
                e_num = ep_data.get('episode', 0)

                if s_num > 99:
                    episode_label = f"S{s_num}E{e_num:02d}"
                else:
                    episode_label = f"S{s_num:02d}E{e_num:02d}"

                try:
                    item_date = datetime.datetime.strptime(raw_date_str, '%Y-%m-%d').date()
                except:
                    item_date = today

                date_color = "lime" if item_date <= today else "grey"
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
                
                display_name = f"[COLOR {date_color}]{raw_date_str}[/COLOR] | [B][COLOR orange]{episode_label}[/COLOR] - {title}[/B]"
                
                meta = {"title": title, "plot": f"Epizód: {episode_label}\nPremier: {raw_date_str}", "mediatype": "episode"}

                url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}&target_episode={episode_label}"

                self.addDirectoryItem(f"{display_name}", 
                                      url_params, 
                                      poster, '', 'DefaultFolder.png', meta=meta)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklContinueWatching(self):
        from resources.lib.indexers.simkl_tracks import SimklInterface
        from resources.lib.indexers.trakt_parts import TraktInterface
        
        data = SimklInterface.get_simkl_playback()
        if not data:
            xbmcgui.Dialog().notification("Simkl", "Nincs félbehagyott tartalom.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV", "Simkl lista összeállítása...")
        total_items = len(data)

        for idx, item in enumerate(data):
            if p_dialog.iscanceled(): break
            
            progress_pct = int(float(item.get('progress', 0)))
            itype = item.get('type')
            media = item.get('movie') if itype == 'movie' else item.get('show')
            
            if not media: continue

            title = media.get('title', 'Ismeretlen')
            year = media.get('year', '')
            imdb_id = media.get('ids', {}).get('imdb', '')
            tmdb_id = media.get('ids', {}).get('tmdb', '')

            target_ep_str = ""

            if itype == 'movie':
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B] ({year}) - [COLOR yellow]{progress_pct}%[/COLOR]"
                plot_header = f"[B]{title} ({year})[/B]"
            else:
                ep = item.get('episode', {})
                s, e = ep.get('season', 0), ep.get('number', 0)

                target_ep_str = f"S{s:02d}E{e:02d}"
                
                ep_title = ep.get('title', 'Rész')
                display_name = f"[B][COLOR orange]RÉSZ[/COLOR][/B] | [B]{title}[/B] - [COLOR yellow]S{s:02d}E{e:02d} ({progress_pct}%)[/COLOR]"
                plot_header = f"[B]{title} - S{s:02d}E{e:02d}: {ep_title}[/B]"

            p_dialog.update(int((idx / total_items) * 100), f"Feldolgozás: [B]{title}[/B]")

            poster = None

            if imdb_id:
                db_data = self.db.get_indicators_for_list([imdb_id]).get(imdb_id)
                if db_data:
                    db_row = dict(db_data)
                    pid = db_row.get('simkl_poster')
                    if pid:
                        poster = f"https://simkl.in/posters/{pid}_m.jpg"

            if not poster or "DefaultMovies" in poster:
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            if (not poster or "DefaultMovies" in poster) and tmdb_id:
                poster = TraktInterface.get_tmdb_poster_path_profi(tmdb_id, itype)

            if not poster: poster = 'DefaultFolder.png'

            full_plot = f"{plot_header}\n[COLOR yellow]Folytatás: {progress_pct}%[/COLOR]\n\n{media.get('overview', '')}"

            url_params = (f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}"
                          f"&imdb_id={imdb_id}"
                          f"&target_episode={target_ep_str}"
                          f"&resume_percent={progress_pct}")

            self.addDirectoryItem(f"{display_name} [{imdb_id}]", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', 
                                  meta={"title": title, "plot": full_plot})

        p_dialog.close()
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def _render_playback_list(self, data, service_name):
        from resources.lib.indexers.trakt_parts import TraktInterface
        from resources.lib.indexers.simkl_tracks import SimklInterface

        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV", f"{service_name} lista összeállítása...")
        
        total_items = len(data)
        
        for idx, item in enumerate(data):
            if p_dialog.iscanceled(): break

            progress_pct = int(float(item.get('progress', 0)))
            itype = item.get('type')
            
            if itype == 'movie':
                inner = item.get('movie', {})
                title = inner.get('title', 'Ismeretlen')
                year = inner.get('year', '')
                imdb_id = inner.get('ids', {}).get('imdb', '')
                tmdb_id = inner.get('ids', {}).get('tmdb', '')
                
                year_display = f" ({year})" if year else ""
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B]{year_display} - [COLOR yellow]{progress_pct}%[/COLOR]"
                plot = f"[B]{title}{year_display}[/B]\nFolytatás: {progress_pct}%"
            else:
                show = item.get('show', {})
                episode = item.get('episode', {})
                title = show.get('title', 'Ismeretlen')
                year = show.get('year', '')
                imdb_id = show.get('ids', {}).get('imdb', '')
                tmdb_id = show.get('ids', {}).get('tmdb', '')
                
                s_num = episode.get('season', 0)
                e_num = episode.get('number', 0)
                ep_title = episode.get('title', '')
                
                year_display = f" ({year})" if year else ""
                display_name = f"[B][COLOR orange]RÉSZ[/COLOR][/B] | [B]{title}[/B]{year_display} - [COLOR yellow]S{s_num:02d}E{e_num:02d} ({progress_pct}%)[/COLOR]"
                plot = f"[B]{title} - S{s_num:02d}E{e_num:02d}[/B]\n{ep_title}\nFolytatás: {progress_pct}%"

            p_dialog.update(int((idx / total_items) * 100), f"Borító lekérése:\n[B]{title}[/B]")

            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            if "DefaultMovies" in poster and self.is_simkl_active() and imdb_id:
                poster_id = SimklInterface.harvest_poster_by_imdb(imdb_id)
                if poster_id:
                    poster = f"https://simkl.in/posters/{poster_id}_m.jpg"

            if "DefaultMovies" in poster and tmdb_id:
                tmdb_poster = TraktInterface.get_tmdb_poster_path_profi(tmdb_id, itype)
                if tmdb_poster:
                    poster = tmdb_poster

            self.addDirectoryItem(f"{display_name} [{imdb_id}]", 
                                  f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                                  poster, '', 'DefaultFolder.png', 
                                  meta={"title": title, "plot": plot})

        p_dialog.close()
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklUpNext(self):
        from resources.lib.indexers.simkl_tracks import SimklInterface

        current_page = int(self.params.get('page', 1))
        
        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV", f"Simkl szinkronizálás ({current_page}. oldal)...")

        def update_progress(pct, title):
            p_dialog.update(pct, f"Epizód adatok:\n[B]{title}[/B]")

        data, remaining = SimklInterface.get_simkl_up_next(page=current_page, progress_callback=update_progress)
        p_dialog.close()

        if not data:
            xbmcgui.Dialog().notification("Simkl", "Nincs több epizód.", "", 3000)
            return

        for item in data:
            s, e = item['season'], item['episode']

            target_ep_str = f"S{s:02d}E{e:02d}"

            display_name = f"[COLOR lime][UP NEXT][/COLOR] [B]{item['show_title']}[/B] - [COLOR yellow]S{s:02d}E{e:02d}[/COLOR] [COLOR grey]({item['progress']} rész kész)[/COLOR]"
            
            meta = {
                "title": f"{s}x{e} - {item['ep_title']}",
                "plot": f"[B]{item['ep_title']}[/B]\n\n{item['plot']}\n\n[COLOR grey]Sorozat: {item['show_title']}[/COLOR]",
                "mediatype": "episode",
                "season": s, "episode": e, "tvshowtitle": item['show_title']
            }

            image = item['thumb'] if item['thumb'] else f"https://wsrv.nl/?url=https://simkl.in/posters/{item['poster']}_m.jpg"

            url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={item['imdb_id']}&target_episode={target_ep_str}"

            self.addDirectoryItem(display_name, url_params, image, '', 'DefaultFolder.png', meta=meta)

        if remaining > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Következő oldal ({next_p}) [Még {remaining} sorozat van hátra] >>>[/COLOR][/B]"
            self.addDirectoryItem(label, f"simkl_up_next&page={next_p}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklGenresMenu(self):
        media_type = self.params.get('media_type', 'movies')

        genres_list = SimklInterface.get_simkl_genres(media_type)
        
        for name, slug in genres_list:
            url_params = "simkl_years_menu&media_type={}&genre_slug={}&genre_name={}".format(
                media_type, slug, quote_plus(name)
            )

            self.addDirectoryItem(f"[B]{name}[/B]", url_params, '', simkl_notif_icon)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklYearsMenu(self):
        media_type = self.params.get('media_type')
        genre_slug = self.params.get('genre_slug')
        genre_name = self.params.get('genre_name')

        current_year = datetime.now().year
        
        for year in range(current_year, 1949, -1):
            url_params = "simkl_filtered_items&media_type={}&genre_slug={}&year={}&page=1".format(
                media_type, genre_slug, year
            )
            self.addDirectoryItem(f"[B]{year}[/B] - {genre_name}", url_params, '', simkl_notif_icon)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklFilteredItems(self):
        media_type = self.params.get('media_type')
        genre_slug = self.params.get('genre_slug')
        year = self.params.get('year')
        current_page = int(self.params.get('page', 1))
        
        from resources.lib.indexers.simkl_tracks import SimklInterface
        data, has_next = SimklInterface.get_simkl_filtered_content(media_type, genre_slug, year, current_page)
        
        if not data:
            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
            return

        harvest_posters = {}
        for item in data:
            imdb_id = item.get('ids', {}).get('imdb')
            poster_id = item.get('poster')
            if imdb_id and poster_id:
                harvest_posters[imdb_id] = poster_id

        if harvest_posters:
            import threading
            t = threading.Thread(target=self.db.update_bulk_sync_status, args=(harvest_posters, 'simkl_poster'))
            t.daemon = True
            t.start()

        for item in data:
            item_year = item.get('year')
            if str(item_year) != str(year):
                continue

            title = item.get('title')
            simkl_id = item.get('ids', {}).get('simkl_id')
            poster_id = item.get('poster')
            poster_url = f"https://simkl.in/posters/{poster_id}_m.jpg" if poster_id else 'DefaultMovies.png'
            
            url_params = "simkl_to_ncore&simkl_id={}&media_type={}".format(simkl_id, media_type)
            
            self.addDirectoryItem(
                f"{title} ({item_year})", 
                url_params, 
                poster_url, 
                '', 
                'DefaultFolder.png', 
                meta={"title": title, "year": int(item_year) if item_year else 0}
            )
            
        if has_next:
            next_page = current_page + 1
            url_next = "simkl_filtered_items&media_type={}&genre_slug={}&year={}&page={}".format(
                media_type, genre_slug, year, next_page
            )
            self.addDirectoryItem(f"[B][COLOR cyan]>>> Következő oldal ({next_page}) >>>[/COLOR][/B]", url_next, '', simkl_notif_icon)
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklToNcore(self):
        simkl_id = self.params.get('simkl_id')
        imdb_id_param = self.params.get('imdb_id')
        media_type = self.params.get('media_type', 'movies')
        
        from resources.lib.indexers.simkl_tracks import SimklInterface
        full_info = None

        if simkl_id and simkl_id != "":
            full_info = SimklInterface.get_simkl_summary(media_type, simkl_id)
            if not full_info:
                alt_type = 'shows' if media_type == 'movies' else 'movies'
                full_info = SimklInterface.get_simkl_summary(alt_type, simkl_id)
        elif imdb_id_param:
            full_info = SimklInterface.get_simkl_summary_by_imdb(imdb_id_param)

        if full_info:
            imdb_id = full_info.get('ids', {}).get('imdb') or imdb_id_param
            poster_id = full_info.get('poster')
            
            if imdb_id and poster_id:
                try:
                    self.db.update_bulk_sync_status({imdb_id: poster_id}, 'simkl_poster')
                except: pass

            if imdb_id:
                self.doSearch_3(f"{base_url}{imdb_kereso}", imdb_id)
                return
        
        xbmcgui.Dialog().notification("Simkl", "Sikertelen azonosítás.", xbmcgui.NOTIFICATION_WARNING, 4000)



    #Plex
    def ShowPlexCategories(self):
        if not self.is_plex_active():
            from xbmcgui import Dialog
            Dialog().ok("Plex.tv", "Ez a funkció Plex.tv fiókhoz kötött.[CR]Aktiváld a szolgáltatást a beállításokban!")
            return        
        
        self.check_background_sync()

        self.addDirectoryItem(f"[B][COLOR yellow]Félbehagyottak (Continue Watching)[/COLOR][/B]", f"plex_continue", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Megnézett Filmek[/B]", f"watched_plex_movies", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Elkezdett Sorozatok[/B]", f"watched_plex_series", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Plex Watchlist (Filmek)[/B]", f"plex_watchlist_movies", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Plex Watchlist (Sorozatok)[/B]", f"plex_watchlist_series", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Plex Watchlist (Filmek&Sorozatok)[/B]", f"plex_watchlist_combined", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Film és Sorozat előzmények (History)[/B]", f"plex_history", '', 'DefaultFolder.png')

        last_sync = addon.getSetting('plex_last_sync_time') or "Még nem futott"
        plex_meta_last_update = (f'\n[COLOR lime]-[/COLOR] Utolsó auto. frissítés:\n  {last_sync}')
        self.addDirectoryItem(f"[B][COLOR gold]Plex adatok manuális frissítése[/COLOR][/B]", f"plex_full_sync_action", '', 'DefaultFolder.png', meta={'plot': f'{plex_meta_last_update}'})
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def WatchedPlexMovies(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        data = PlexInterface.get_plex_library_items(media_type='movie', filter_watched=True)
        if not data:
            xbmcgui.Dialog().notification("Plex", "Nincs megnézett filmed.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_data = data[start_idx:end_idx]
        remaining = len(data) - end_idx

        self._render_plex_items(paged_data, "Megnézett Filmek")

        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) >>>[/COLOR][/B]", 
                                  f"watched_plex_movies&page={current_page + 1}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def WatchedPlexSeries(self):
        from resources.lib.indexers.plex_tracks import PlexInterface

        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        data = PlexInterface.get_plex_library_items(media_type='show', filter_watched=True)
        
        if not data:
            xbmcgui.Dialog().notification("Plex", "Nincs elkezdett sorozatod.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_data = data[start_idx:end_idx]
        remaining = len(data) - end_idx

        self._render_plex_items(paged_data, f"Megnézett Sorozatok ({current_page}. oldal)")

        if remaining > 0:
            next_p = current_page + 1
            label = f"[B][COLOR yellow]>>> Következő oldal ({next_p}) [Még {remaining} sorozat] >>>[/COLOR][/B]"

            self.addDirectoryItem(label, f"watched_plex_series&page={next_p}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def PlexWatchlistMovies(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        data = PlexInterface.get_plex_watchlist(media_type='movie')
        
        if not data:
            xbmcgui.Dialog().notification("Plex", "A Watchlist üres vagy hiba történt.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_data = data[start_idx:end_idx]
        remaining = len(data) - end_idx

        self._render_plex_items(paged_data, f"Plex Watchlist - Filmek ({current_page}. oldal)")

        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) [Még {remaining} film] >>>[/COLOR][/B]", 
                                  f"plex_watchlist_movies&page={current_page + 1}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def PlexWatchlistSeries(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        
        current_page = int(self.params.get('page', 1))
        items_per_page = 30

        data = PlexInterface.get_plex_watchlist(media_type='show')
        
        if not data:
            xbmcgui.Dialog().notification("Plex", "A Sorozat Watchlist üres.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_data = data[start_idx:end_idx]
        remaining = len(data) - end_idx

        self._render_plex_items(paged_data, f"Plex Watchlist - Sorozatok ({current_page}. oldal)")

        if remaining > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) [Még {remaining} sorozat] >>>[/COLOR][/B]", 
                                  f"plex_watchlist_series&page={current_page + 1}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def PlexWatchlistCombined(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        
        current_page = int(self.params.get('page', 1))
        items_per_page = 30
    
        data = PlexInterface.get_plex_watchlist(media_type='all')
        
        if not data:
            xbmcgui.Dialog().notification("Plex", "A Watchlist üres vagy hiba történt.", xbmcgui.NOTIFICATION_INFO, 3000)
            return
    
        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_data = data[start_idx:end_idx]
        remaining = len(data) - end_idx

        self._render_plex_items(paged_data, f"Plex Watchlist - Összes ({current_page}. oldal)")
    
        if remaining > 0:
            self.addDirectoryItem(
                f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) [Még {remaining} elem] >>>[/COLOR][/B]", 
                f"plex_watchlist_combined&page={current_page + 1}", '', 'DefaultFolder.png')
    
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def PlexFullSync(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        res = PlexInterface.sync_full_plex_history(return_data=True)
        if res:
            w_data, id_map = res
            self.db.update_full_service_sync('plex', w_data, id_map)
            
            from datetime import datetime
            addon.setSetting('plex_last_sync_time', datetime.now().strftime('%Y-%m-%d %H:%M'))
            xbmcgui.Dialog().notification("Plex", "Szinkronizáció kész!", plex_notif_icon, 3000)

        self.endDirectory(type=user_change_view, cache=False, update=True)


    def PlexContinueWatching(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        from resources.lib.indexers.trakt_parts import TraktInterface
        
        data = PlexInterface.get_plex_playback()
        if not data:
            xbmcgui.Dialog().notification("Plex", "Nincs félbehagyott tartalom vagy hiba.", "", 3000)
            return

        token = addon.getSetting('plex_token')
        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV", "Plex lista összeállítása...")
        
        total_items = len(data)
        for idx, item in enumerate(data):
            if p_dialog.iscanceled(): break
            
            imdb_id = item['imdb_id']
            title = item['title']
            progress_pct = int(item.get('progress', 0))

            target_ep_str = ""
            
            if item['type'] == 'movie':
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B] ({item.get('year', '')}) - [COLOR yellow]{progress_pct}%[/COLOR]"
                plot_header = f"[B]{title} ({item.get('year', '')})[/B]"
            else:
                s, e = item.get('parentIndex', 0), item.get('index', 0)

                target_ep_str = f"S{s:02d}E{e:02d}"
                
                show_title = item.get('grandparentTitle', 'Sorozat')
                display_name = f"[B][COLOR orange]RÉSZ[/COLOR][/B] | [B]{show_title}[/B] - [COLOR yellow]S{s:02d}E{e:02d} ({progress_pct}%)[/COLOR]"
                plot_header = f"[B]{show_title} - S{s:02d}E{e:02d}: {title}[/B]"

            p_dialog.update(int((idx / total_items) * 100), f"Feldolgozás: [B]{title}[/B]")

            poster = None
            if imdb_id:
                db_data = self.db.get_indicators_for_list([imdb_id]).get(imdb_id)
                if db_data:
                    db_row = dict(db_data)
                    pid = db_row.get('simkl_poster')
                    if pid: poster = f"https://simkl.in/posters/{pid}_m.jpg"

            if (not poster or "DefaultMovies" in poster) and item.get('thumb'):
                poster = f"{item['server_uri']}{item['thumb']}?X-Plex-Token={token}"

            if not poster or "DefaultMovies" in poster:
                poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            full_plot = f"{plot_header}\n[COLOR yellow]Folytatás: {progress_pct}%[/COLOR]\n\n{item.get('summary', '')}"

            url_params = (f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}"
                          f"&imdb_id={imdb_id}"
                          f"&target_episode={target_ep_str}"
                          f"&resume_percent={progress_pct}")

            self.addDirectoryItem(f"{display_name} [{imdb_id}]", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', 
                                  meta={"title": title, "plot": full_plot})

        p_dialog.close()
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def _render_plex_items(self, data, service_label):
        from resources.lib.indexers.trakt_parts import TraktInterface
        token = addon.getSetting('plex_token')

        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("nCore TV", f"{service_label} összeállítása...")
        
        total_items = len(data)

        for idx, item in enumerate(data):
            if p_dialog.iscanceled(): break
            
            title = item.get('title', 'Ismeretlen')
            imdb_id = item.get('imdb_id')
            last_ep = item.get('last_ep', '')
            summary = item.get('summary', '') 
            tagline = item.get('tagline', '')
            year = item.get('year', '')

            progress_pct = item.get('progress', '')

            target_ep_str = last_ep if item.get('type') == 'show' else ""

            if item.get('type') == 'show':
                display_name = f"[B][COLOR orange]SHOW[/COLOR][/B] | [B]{title}[/B]"
                if last_ep:
                    pct_label = f" ({progress_pct}%)" if progress_pct else ""
                    display_name += f" - [COLOR yellow]{last_ep}{pct_label}[/COLOR]"
            else:
                display_name = f"[B][COLOR lightgreen]FILM[/COLOR][/B]  | [B]{title}[/B] ({year})"
                if progress_pct:
                    display_name += f" - [COLOR yellow]{progress_pct}%[/COLOR]"

            p_dialog.update(int((idx / total_items) * 100), f"Adatok: [B]{title}[/B]")

            poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
            if "DefaultMovies" in poster:
                thumb = item.get('thumb', '')
                if thumb.startswith('http'):
                    poster = thumb
                elif thumb:
                    base = item.get('server_uri') or "https://metadata.provider.plex.tv"
                    poster = f"{base}{thumb}?X-Plex-Token={token}"

            full_plot = f"[B]{title}[/B] ({year})"
            if tagline: full_plot += f"\n[I]'{tagline}'[/I]"

            if progress_pct:
                full_plot += f"\n[COLOR yellow]Folytatás: {progress_pct}%[/COLOR]"
            if target_ep_str:
                full_plot += f"\n[COLOR orange]Utoljára rögzítve:[/COLOR] {target_ep_str}"
                
            if summary: full_plot += f"\n\n{summary}"

            meta = {
                "title": title,
                "plot": full_plot,
                "year": year,
                "mediatype": "movie" if item.get('type') == 'movie' else "tvshow"
            }

            url_params = (f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}"
                          f"&imdb_id={imdb_id}"
                          f"&target_episode={target_ep_str}"
                          f"&resume_percent={progress_pct}")

            self.addDirectoryItem(f"{display_name} [{imdb_id}]", 
                                  url_params, 
                                  poster, '', 'DefaultFolder.png', isFolder=True,
                                  meta=meta)

        p_dialog.close()


    def PlexHistory(self):
        from resources.lib.indexers.plex_tracks import PlexInterface
        
        current_page = int(self.params.get('page', 1))

        data = PlexInterface.get_plex_history(page=current_page)
        
        if not data:
            xbmcgui.Dialog().notification("Plex", "Nincsenek előzmények.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        self._render_plex_items(data, f"Plex Előzmények ({current_page}. oldal)")

        if len(data) >= 40:
            next_p = current_page + 1
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({next_p}) >>>[/COLOR][/B]", 
                                  f"plex_history&page={next_p}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def add_plex_watchlist_action(self, imdb_id, is_series):
        status = PlexInterface.plex_add_watchlist(imdb_id, is_series == 'true')
        if status:
            xbmcgui.Dialog().notification("Plex", "Hozzáadva: Watchlist", plex_notif_icon, 3000)

    def TMDBToNcore(self):
        tmdb_id = self.params.get('tmdb_id')
        m_type = self.params.get('media_type')

        url = f"https://api.themoviedb.org/3/{m_type}/{tmdb_id}/external_ids?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}"
        
        try:
            r = requests.get(url, timeout=10).json()
            imdb_id = r.get('imdb_id')
            
            if imdb_id:
                self.doSearch_3(f"{base_url}{imdb_kereso}", imdb_id)
            else:
                xbmcgui.Dialog().notification("TMDB", "Nincs IMDb ID ehhez a tartalomhoz.", xbmcgui.NOTIFICATION_WARNING)
        except:
            xbmcgui.Dialog().notification("TMDB", "Hiba az ID lekérésekor.", xbmcgui.NOTIFICATION_ERROR)

    def getHNR(self, url, title_1, torrent_id, hnr_tstart):
        from bs4 import BeautifulSoup
        import requests
        import urllib.parse
        import re

        current_page = int(self.params.get('page', 1))
        items_per_page = 20

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = nc_get('https://ncore.pro/hitnrun.php?id=138302&showall=false&order_by=start&o=desc', cookies=cookies, headers=headers)
        soup = BeautifulSoup(resp.text, 'html.parser')
        if known_errors(str(soup)):
            return

        torrent_divs = soup.find_all("div", class_="hnr_torrents")

        temp_t_ids = []
        for torrent in torrent_divs:
            a_tag = torrent.find("div", class_="hnr_tname").find("a")
            if a_tag:
                t_id_match = a_tag.get("href", "").split("id=")[-1] if "id=" in a_tag.get("href", "") else None
                if t_id_match: temp_t_ids.append(t_id_match)

        db_sync_data = {}      
        db_local_played = set() 
        db_torrent_to_imdb = {} 
        db_torrent_to_poster = {}

        if temp_t_ids:
            with self.db._get_connection() as conn:
                placeholders = ', '.join(['?'] * len(temp_t_ids))
                t_rows = conn.execute(f'SELECT torrent_id, imdb_id, full_url, poster_link FROM torrents WHERE torrent_id IN ({placeholders})', temp_t_ids).fetchall()
                
                found_imdb_ids = []
                for r in t_rows:
                    t_id = r['torrent_id']
                    db_torrent_to_imdb[t_id] = r['imdb_id']
                    db_torrent_to_poster[t_id] = r['poster_link']
                    if r['imdb_id']: found_imdb_ids.append(r['imdb_id'])
                    
                    has_url = r['full_url'] is not None and r['full_url'] != ""
                    has_pos = conn.execute('SELECT 1 FROM video_positions WHERE torrent_id = ? LIMIT 1', (t_id,)).fetchone() is not None
                    if has_url or has_pos:
                        db_local_played.add(t_id)
                
                if found_imdb_ids:
                    db_sync_data = self.db.get_indicators_for_list(found_imdb_ids)

        total_items = len(torrent_divs)
        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_divs = torrent_divs[start_idx:end_idx]
        remaining = total_items - end_idx

        for torrent in paged_divs:
            a_tag = torrent.find("div", class_="hnr_tname").find("a")
            if a_tag:
                href = a_tag.get("href", "")
                torrent_id = href.split("id=")[-1] if "id=" in href else None
                title_1 = a_tag.get("title", "").strip()
            else:
                torrent_id = None
                title_1 = None
            
            if not torrent_id: continue
            
            imdb_id = db_torrent_to_imdb.get(torrent_id)
            hnr_poster = db_torrent_to_poster.get(torrent_id)

            if (not hnr_poster or hnr_poster == "") and imdb_id:
                from resources.lib.indexers.trakt_parts import TraktInterface
                hnr_poster = TraktInterface.get_simkl_poster_for_imdb(imdb_id)

            final_poster = self.clean_base64_data(hnr_poster) if hnr_poster else 'DefaultMovies.png'

            indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, torrent_id, db_sync_data, db_local_played)
            
            hnr_tstart_div = torrent.find("div", class_="hnr_tstart")
            hnr_tstart_val = hnr_tstart_div.text.strip() if hnr_tstart_div else None
            
            torrent_link = f'https://ncore.pro/torrents.php?action=details&id={torrent_id}'
            
            url_params = (
                f'extr_bookmark_torrent&url={urllib.parse.quote_plus(torrent_link)}'
                f'&title_1={urllib.parse.quote_plus(title_1)}'
                f'&torrent_id={torrent_id}&hnr_tstart={hnr_tstart_val}'
            )
            
            parsed_details = self.parse_and_format_torrent_details(title_1, f"[COLOR orange][B]Bekerülve: [COLOR FFF56C00](hit'n'run)[/COLOR][/B] {hnr_tstart_val}[/COLOR]")
            meta_plot = {'plot': f'{plot_status_line}{parsed_details["plot"]}'}
            
            if xxx_contents == 'true' or not re.search(r'Hentai|xxx', title_1, re.IGNORECASE):
                bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f'getContextBookmark&torrent_id={torrent_id}')
                torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
                context_menu_items = [bookmark_context, torrent_to_seed]

                if imdb_id:
                    context_menu_items.append(("[B]Stáblista / Színészek[/B]", f"get_cast_list&imdb_id={imdb_id}&media_type=movie&poster_link={urllib.parse.quote_plus(str(final_poster or ''))}"))
                    context_menu_items.append(("[B][COLOR yellow]Más verziók (IMDb): {}[/COLOR][/B]".format(imdb_id), f"search_with_imdb&imdb_id={imdb_id}"))

                display_indicator = f"{indicator} " if indicator else ""
                display_label = f"{display_indicator}{title_1}"

                self.addDirectoryItem(display_label, url_params, final_poster, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=meta_plot)

        if remaining > 0:
            u_next = f"get_hnr&page={current_page + 1}"
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal (Még {remaining} db) >>>[/COLOR][/B]", u_next, '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def getJustWatchCategories(self):
        self.addDirectoryItem(f"[B]Kategóriák ([COLOR orange]JustWatch[/COLOR])[/B]{ncore_coloring}", f"pick_justwatch_categorys", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Dátum választó ([COLOR FFF56C00]teljes hét találatai[/COLOR]) | Új a kínálatban ([COLOR orange]JustWatch[/COLOR])[/B]{ncore_coloring}", f"get_justwatch_date", '', 'DefaultFolder.png')
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getJustWatchDate(self, real_slug_url, poster_link, description, title_1, selected_date):
        selected_date = date_picker(selected_date)
        if selected_date:
            import requests
            import re
            from datetime import datetime, timedelta
            
            def get_week_dates_custom(date_str, fmt='%Y-%m-%d'):
                date = datetime.strptime(date_str, fmt).date()
                today = datetime.today().date()
            
                date_iso  = (date.isocalendar()[0], date.isocalendar()[1])
                today_iso = (today.isocalendar()[0], today.isocalendar()[1])
            
                monday = date - timedelta(days=date.weekday())
                full_week = [(monday + timedelta(days=i)).isoformat() for i in range(7)]
                
                if date_iso < today_iso:
                    return full_week
                elif date_iso == today_iso:
                    start = monday
                    end   = today
                    return [(start + timedelta(days=i)).isoformat() 
                            for i in range((end - start).days + 1)]
                else:
                    return []
            
            def fetch_for_date(selected_date):
                headers = {
                    'accept-language': 'hu',
                    'content-type': 'application/json',
                    'origin': 'https://www.justwatch.com',
                    'referer': 'https://www.justwatch.com/',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
                }             
                
                def get_modified_query():
                    return getJustWatchDate_original_query.replace(
                        'content(country: $country, language: $language) {',
                        'content(country: $country, language: $language) {' + getJustWatchDate_extend_with_this,
                        1
                    )
                
                json_data = {
                    'operationName': 'GetNewTitles',
                    'variables': {
                        'first': 99,
                        'pageType': 'NEW',
                        'date': selected_date,
                        'filter': {
                            'ageCertifications': [],
                            'excludeGenres': [],
                            'excludeProductionCountries': [],
                            'objectTypes': [],
                            'productionCountries': [],
                            'subgenres': [],
                            'genres': [],
                            'packages': ["dnp", "nfx", "prv", "itu", "ply", "atp", "flb", "sst", "mxx"],
                            'excludeIrrelevantTitles': False,
                            'presentationTypes': [],
                            'monetizationTypes': [],
                        },
                        'language': 'hu',
                        'country': 'HU',
                        'priceDrops': False,
                        'platform': 'WEB',
                        'showDateBadge': True,
                        'availableToPackages': ["dnp", "nfx", "prv", "itu", "ply", "atp", "flb", "sst", "mxx"],
                        'backdropProfile': 'S1440',
                        'allowSponsoredRecommendations': {
                            'pageType': 'NEW',
                            'placement': 'NEW_TIMELINE',
                            'language': 'hu',
                            'country': 'HU',
                            'applicationContext': {
                                'platform': 'webapp',
                                'isTestBuild': False,
                            },
                            'platform': 'WEB',
                            'supportedFormats': [
                                'IMAGE',
                                'VIDEO',
                            ],
                            'supportedObjectTypes': [
                                'MOVIE',
                                'SHOW',
                                'GENERIC_TITLE_LIST',
                                'SHOW_SEASON',
                            ],
                            'alwaysReturnBidID': True,
                            'testingModeForceHoldoutGroup': False,
                            'testingMode': False,
                        },
                    },
                    'query': get_modified_query()
                }
            
                resp = nc_post(
                    'https://apis.justwatch.com/graphql',
                    headers=headers,
                    json=json_data
                )
                resp.raise_for_status()
                return resp.json()
            
            def process_response(response):
                items = []
                for stuffs in response['data']['newTitles']['edges']:
                    node = stuffs['node']
                    pkg  = stuffs['newOffer']['package']
            
                    service_shortname = pkg["shortName"]
                    service_longname = pkg["clearName"]
                    service_technicalName = pkg["technicalName"]
            
                    posterUrl = node["content"]["posterUrl"]
                    if posterUrl:
                        posterUrl = re.sub(r'\{profile\}', 's718', posterUrl)
                        posterUrl = re.sub(r'\{format\}', '', posterUrl)
                        posterUrl = f'https://images.justwatch.com{posterUrl}'
                    else:
                        posterUrl = ""
                    
                    shortDescription = node["content"].get("shortDescription", "")
                    
                    originalReleaseYear = node["content"].get("originalReleaseYear", "")
                    if not originalReleaseYear:
                        originalReleaseYear = ""
                    
                    imdb_id = node["content"]["externalIds"].get("imdbId", "")
                    if not imdb_id:
                        imdb_id = ""
                    
                    real_slug_url = node["content"]["fullPath"]
                    slug_url = f'https://www.justwatch.com{real_slug_url}'
            
                    if node['__typename'] == 'Season':
                        newElementCount = stuffs['newOffer']["newElementCount"]
                        ser_title = node["show"]["content"]["title"]
                        type_name = node["__typename"]
                        seasonNumber = node["content"]["seasonNumber"]
            
                        upcoming_list = node["content"].get("upcomingReleases", [])
                        upcomingReleases = upcoming_list[0].get("releaseDate") if upcoming_list else None
            
                        item = {
                            'date_x': selected_date,
                            'type': 'Season',
                            'service_shortname': service_shortname,
                            'service_longname': service_longname,
                            'service_technicalName': service_technicalName,
                            'newElementCount': newElementCount,
                            'ser_title': ser_title,
                            'type_name': type_name,
                            'seasonNumber': seasonNumber,
                            'upcomingReleases': upcomingReleases,
                            'posterUrl': posterUrl,
                            'shortDescription': shortDescription,
                            'originalReleaseYear': originalReleaseYear,
                            'imdb_id': imdb_id,
                            'real_slug_url': real_slug_url,
                            'slug_url': slug_url
                        }
            
                    else:  # Movie
                        type_name = node["__typename"]
                        movie_title = node["content"]["title"]
            
                        item = {
                            'date_x': selected_date,
                            'type': 'Movie',
                            'service_shortname': service_shortname,
                            'service_longname': service_longname,
                            'service_technicalName': service_technicalName,
                            'movie_title': movie_title,
                            'type_name': type_name,
                            'posterUrl': posterUrl,
                            'shortDescription': shortDescription,
                            'originalReleaseYear': originalReleaseYear,
                            'imdb_id': imdb_id,
                            'real_slug_url': real_slug_url,
                            'slug_url': slug_url
                        }
            
                    items.append(item)
                return items

            week_dates = get_week_dates_custom(selected_date)
            
            all_results = []
            for selected_date in week_dates:
                resp = fetch_for_date(selected_date)
                day_items = process_response(resp)
                all_results.extend(day_items)

            imdb_ids_to_query = [r['imdb_id'] for r in all_results if r.get('imdb_id')]
            db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)

            last_date = None
            flip_flag = False
            
            for r in all_results:
                date_x = r['date_x']

                date_obj = datetime.strptime(date_x, '%Y-%m-%d')

                english_day_name = date_obj.strftime('%A')
                date_day_name = hungarian_day_names.get(english_day_name, english_day_name)
            
                if date_x != last_date:
                    flip_flag = not flip_flag
                    last_date = date_x
            
                color = 'lime' if flip_flag else 'orange'
                date_colored = f'[COLOR {color}]{date_x}[/COLOR]'

                service_shortname = r['service_shortname']
                service_longname = r['service_longname']
                service_technicalName = r['service_technicalName']
                poster_link = r['posterUrl']
                shortDescription = r['shortDescription']
                real_slug_url = r['real_slug_url']
                slug_url = r['slug_url']
                imdb_id = r['imdb_id']
                originalReleaseYear = r['originalReleaseYear']

                indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])

                if r['type'] == 'Season': # Series
                    newElementCount = r['newElementCount']
                    title_1 = r['ser_title']
                    type_name = r['type_name']
                    seasonNumber = r['seasonNumber']
                    upcomingReleases = r['upcomingReleases']
                    
                    all_info = (f"{date_colored} | {newElementCount:2d} Epizód | {indicator}{title_1} - {seasonNumber}. Évad")
                    if originalReleaseYear: all_info += f" - ([COLOR gold]{originalReleaseYear}[/COLOR])"
                    if upcomingReleases: all_info += f" - Következő rész: {upcomingReleases}"
                
                else: # Movie
                    title_1 = r['movie_title']
                    type_name = r['type_name']
                    all_info = (f"{date_colored} |  Film  | {indicator}{title_1}")
                    if originalReleaseYear: all_info += f" - ([COLOR gold]{originalReleaseYear}[/COLOR])"
                
                metadata = {'title': f'{title_1} ([COLOR gold]{originalReleaseYear}[/COLOR])', 'plot': f'{plot_status_line}{title_1} ([COLOR gold]{originalReleaseYear}[/COLOR])\n\n{date_x} - [{date_day_name}]\n\n{service_longname}\n\n{shortDescription}'}
                
                if imdb_id:
                    add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={quote_plus(title_1)}&title_2={quote_plus(title_1)}")
                    url_params_imdb = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&poster_link={quote_plus(str(poster_link))}&description={quote_plus(shortDescription)}&title_1={quote_plus(title_1)}&imdb_id={imdb_id}"
                    self.addDirectoryItem(f'[B]{all_info}[/B]', url_params_imdb, poster_link, 'DefaultFolder.png', context=[add_series_watching], isFolder=True, meta=metadata)
                else:
                    url_params_no_imdb = f"newsearch_4&url={quote_plus(f'{base_url}{movie_ser_en_hu_kereso}{title_1}')}&poster_link={quote_plus(str(poster_link))}&description={quote_plus(shortDescription)}&title_1={quote_plus(title_1)}"
                    self.addDirectoryItem(f"[B]{all_info} | [COLOR FFF56C00]nincs imdb ID[/COLOR][/B] | Keresés [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B]: [B][COLOR lime]{title_1}[/COLOR][/B] ", url_params_no_imdb, poster_link, 'DefaultFolder.png', meta=metadata)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def PickJustWatchCategories(self, popularTitlesSortBy_title=None, popularTitlesSortBy_id=None, objectTypes_title=None, objectTypes_id=None, genres_title=None, genres_id=None):

        popularTitlesSortBy_data = [
            {"popularTitlesSortBy_title": "Népszerűség", "popularTitlesSortBy_id": "POPULAR"},
            {"popularTitlesSortBy_title": "Trending", "popularTitlesSortBy_id": "TRENDING"},
            {"popularTitlesSortBy_title": "Véletlen", "popularTitlesSortBy_id": "RANDOM"},
            {"popularTitlesSortBy_title": "Betűrendes", "popularTitlesSortBy_id": "ALPHABETICAL"},
            {"popularTitlesSortBy_title": "Kiadás éve", "popularTitlesSortBy_id": "RELEASE_YEAR"},
            {"popularTitlesSortBy_title": "TMDB pontszám", "popularTitlesSortBy_id": "TMDB_POPULARITY"},
            {"popularTitlesSortBy_title": "IMDB pontszám", "popularTitlesSortBy_id": "IMDB_SCORE"}
        ]

        objectTypes_data = [
            {"objectTypes_title": "Film", "objectTypes_id": "MOVIE"},
            {"objectTypes_title": "Sorozat", "objectTypes_id": "SHOW"}
        ]

        genres_data = [
            {"genres_title": "Akció és kaland", "genres_id": "act"},
            {"genres_title": "Sci-fi", "genres_id": "scf"},
            {"genres_title": "Vígjáték", "genres_id": "cmy"},
            {"genres_title": "Gyerek- és családi filmek", "genres_id": "fml"},
            {"genres_title": "Animációs", "genres_id": "ani"},
            {"genres_title": "Fantasy", "genres_id": "fnt"},
            {"genres_title": "Romantikus", "genres_id": "rma"},
            {"genres_title": "Rejtély és thriller", "genres_id": "trl"},
            {"genres_title": "Krimi", "genres_id": "crm"},
            {"genres_title": "Horror", "genres_id": "hrr"},
            {"genres_title": "Dráma", "genres_id": "drm"},
            {"genres_title": "Háborús", "genres_id": "war"},
            {"genres_title": "Valóságshow", "genres_id": "rly"},
            {"genres_title": "Sport", "genres_id": "spt"},
            {"genres_title": "Történelmi", "genres_id": "hst"},
            {"genres_title": "Dokumentumfilm", "genres_id": "doc"},
            {"genres_title": "Európai gyártású", "genres_id": "eur"},
            {"genres_title": "Zenés film és musical", "genres_id": "msc"},
            {"genres_title": "Western", "genres_id": "wsn"}
        ]

        if not popularTitlesSortBy_id:
            for sort_by in popularTitlesSortBy_data:
                current_popularTitlesSortBy_title = sort_by["popularTitlesSortBy_title"]
                current_popularTitlesSortBy_id = sort_by["popularTitlesSortBy_id"]
                
                query_string = (
                    f"pick_justwatch_categorys"
                    f"&popularTitlesSortBy_title={quote_plus(current_popularTitlesSortBy_title)}"
                    f"&popularTitlesSortBy_id={quote_plus(current_popularTitlesSortBy_id)}"
                )
                self.addDirectoryItem(f"[B]{current_popularTitlesSortBy_title}[/B]", query_string, 'DefaultFolder.png', '', isFolder=True)
            
            if custom_view_list == 'true':
                self.endDirectory(fixed_wide_view)
            else:    
                self.endDirectory(user_change_view)
            
            
            return

        elif popularTitlesSortBy_id and not objectTypes_id:
            for obj_type in objectTypes_data:
                current_objectTypes_title = obj_type["objectTypes_title"]
                current_objectTypes_id = obj_type["objectTypes_id"]

                query_string = (
                    f"pick_justwatch_categorys"
                    f"&popularTitlesSortBy_title={quote_plus(popularTitlesSortBy_title)}"
                    f"&popularTitlesSortBy_id={quote_plus(popularTitlesSortBy_id)}"
                    f"&objectTypes_title={quote_plus(current_objectTypes_title)}"
                    f"&objectTypes_id={quote_plus(current_objectTypes_id)}"
                )
                self.addDirectoryItem(f"[B]{current_objectTypes_title}[/B]", query_string, 'DefaultFolder.png', '', isFolder=True)
            
            if custom_view_list == 'true':
                self.endDirectory(fixed_wide_view)
            else:    
                self.endDirectory(user_change_view)
            
            return

        elif popularTitlesSortBy_id and objectTypes_id and not genres_id:
            for genre in genres_data:
                current_genres_title = genre["genres_title"]
                current_genres_id = genre["genres_id"]

                query_string = (
                    f"extr_justwatch_categorys"
                    f"&popularTitlesSortBy_title={quote_plus(popularTitlesSortBy_title)}"
                    f"&popularTitlesSortBy_id={quote_plus(popularTitlesSortBy_id)}"
                    f"&objectTypes_title={quote_plus(objectTypes_title)}"
                    f"&objectTypes_id={quote_plus(objectTypes_id)}"
                    f"&genres_title={quote_plus(current_genres_title)}"
                    f"&genres_id={quote_plus(current_genres_id)}"
                )
                self.addDirectoryItem(f"[B]{current_genres_title}[/B]", query_string, 'DefaultFolder.png', '', isFolder=True)
            
            if custom_view_list == 'true':
                self.endDirectory(fixed_wide_view)
            else:    
                self.endDirectory(user_change_view)
            
            
            return

    def ExtJustWatchCategories(self, popularTitlesSortBy_title, popularTitlesSortBy_id, objectTypes_title, objectTypes_id, genres_title, genres_id, after_cursor=None):
        headers = {
            'accept-language': 'hu',
            'app-version': '3.9.3-web-web',
            'content-type': 'application/json',
            'origin': 'https://www.justwatch.com',
            'referer': 'https://www.justwatch.com/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
        }

        def get_modified_query_string():
            injection_point = 'content(country: $country, language: $language) {'
            parts = ExtJustWatchCategories_original_query.rsplit(injection_point, 1) 
            if len(parts) < 2: return ExtJustWatchCategories_original_query
            return parts[0] + injection_point + ExtJustWatchCategories_extend_with_this + parts[1]
        
        json_data = {
            'operationName': 'GetPopularTitles',
            'variables': {
                'first': 99,
                'popularTitlesSortBy': popularTitlesSortBy_id,
                'sortRandomSeed': 0,
                'offset': None,
                'creditsRole': 'DIRECTOR',
                'after': after_cursor,
                'popularTitlesFilter': {
                    'ageCertifications': [], 'excludeGenres': [], 'excludeProductionCountries': [],
                    'objectTypes': [objectTypes_id], 'productionCountries': [], 'subgenres': [], 'genres': [genres_id],
                    'packages': ['dnp','nfx','prv','itu','ply','atp','flb','sst','mxx'],
                    'excludeIrrelevantTitles': False, 'presentationTypes': [], 'monetizationTypes': [], 'searchQuery': '',
                },
                'watchNowFilter': {
                    'packages': ['dnp','nfx','prv','itu','ply','atp','flb','sst','mxx'],
                    'monetizationTypes': [],
                },
                'language': 'hu',
                'country': 'HU',
            },
            'query': get_modified_query_string()
        }
        
        try:
            response = nc_post('https://apis.justwatch.com/graphql', headers=headers, json=json_data).json()
            if 'data' in response and 'popularTitles' in response['data']:
                popular_titles = response['data']['popularTitles']

                imdb_ids_to_query = []
                for edge in popular_titles.get('edges', []):
                    node = edge.get('node')
                    if node and node.get('content'):
                        i_id = node['content'].get('externalIds', {}).get('imdbId', '')
                        if i_id: imdb_ids_to_query.append(i_id)
                db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)

                for edge in popular_titles.get('edges', []):
                    node = edge.get('node')
                    if not node or not node.get('content'): continue

                    content = node['content']
                    title = content.get('title', 'Ismeretlen Cím')
                    imdb_id = content.get('externalIds', {}).get('imdbId', '')

                    indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])

                    poster_url = content.get('posterUrl', '')
                    if poster_url:
                        cleaned_path = poster_url.replace('{format}', '').replace('{profile}', 's718')
                        poster_url = f"https://images.justwatch.com{cleaned_path}"
                    else:
                        poster_url = ""

                    original_release_year = node.get('originalReleaseYear') or content.get('originalReleaseYear', '')
                    plot_description = content.get('shortDescription', '')
                    originalTitle = content.get('originalTitle', '')

                    full_plot_text = [plot_status_line]
                    if originalTitle:
                        year_display = f" ([COLOR gold]{original_release_year}[/COLOR])" if original_release_year else ""
                        full_plot_text.append(f"[B]Eredeti cím:[/B] {originalTitle}{year_display}")
                    
                    imdb_score = content.get('scoring', {}).get('imdbScore')
                    tmdb_popularity = content.get('scoring', {}).get('tmdbPopularity')
                    rating_info = []
                    if imdb_score is not None: rating_info.append(f"[B]IMDb:[/B] {imdb_score:.1f}")
                    if tmdb_popularity is not None: rating_info.append(f"[B]TMDb Pop.:[/B] {tmdb_popularity:.0f}")
                    if rating_info: full_plot_text.append(" | ".join(rating_info))
                    
                    genres = [g.get('translation') for g in content.get('genres', []) if g.get('translation')]
                    if genres: full_plot_text.append(f"[B]Műfaj:[/B] {', '.join(genres)}")
                    if plot_description: full_plot_text.append(f"\n[B]Tartalom:[/B]\n{plot_description}")

                    metadata = {'title': title, 'plot': "\n".join(full_plot_text)}

                    all_info = f"{indicator}{title}"
                    if original_release_year: all_info += f" - ([COLOR gold]{original_release_year}[/COLOR])"

                    if imdb_id:
                        add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={quote_plus(title)}&title_2={quote_plus(title)}")
                        url_params_imdb = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&poster_link={quote_plus(poster_url)}&description={quote_plus(plot_description)}&title_1={quote_plus(title)}&imdb_id={imdb_id}"
                        self.addDirectoryItem(f'[B]{all_info}[/B]', url_params_imdb, poster_url, 'DefaultFolder.png', context=[add_series_watching], isFolder=True, meta=metadata)
                    else:
                        url_params_no_imdb = f"newsearch_4&url={quote_plus(f'{base_url}{movie_ser_en_hu_kereso}{title}')}&poster_link={quote_plus(poster_url)}&description={quote_plus(plot_description)}&title_1={quote_plus(title)}"
                        self.addDirectoryItem(f"[B]{all_info} | [COLOR FFF56C00]nincs imdb ID[/COLOR][/B] | Keresés [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B]: [B][COLOR lime]{title}[/COLOR][/B] ", url_params_no_imdb, poster_url, 'DefaultFolder.png', meta=metadata)

                page_info = popular_titles.get('pageInfo', {})
                if page_info.get('hasNextPage', False) and page_info.get('endCursor'):
                    next_q = f"extr_justwatch_categorys&popularTitlesSortBy_title={quote_plus(popularTitlesSortBy_title)}&popularTitlesSortBy_id={quote_plus(popularTitlesSortBy_id)}&objectTypes_title={quote_plus(objectTypes_title)}&objectTypes_id={quote_plus(objectTypes_id)}&genres_title={quote_plus(genres_title)}&genres_id={quote_plus(genres_id)}&after_cursor={quote_plus(page_info['endCursor'])}"
                    self.addDirectoryItem('[B]Következő oldal >[/B]', next_q, 'DefaultFolder.png', '', isFolder=True)

        except Exception as e:
            xbmc.log(f"ExtJustWatchCategories | Error: {e}", xbmc.LOGERROR)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def allMergedWatchlist(self):
        if not self.is_trakt_active() and not self.is_simkl_active() and not self.is_plex_active():
            xbmcgui.Dialog().notification("Figyelmeztetés", "Egyik szolgáltatás sincs hitelesítve.", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
    
        current_page = int(self.params.get('page', 1))
        items_per_page = 30
        
        combined_data = []

        if self.is_trakt_active():
            trakt_data = TraktInterface.get_trakt_watchlist('all') or []
            #xbmc.log(f'trakt_data: {trakt_data}', xbmc.LOGINFO)
            
            for item in trakt_data:
                item_type = item.get('type', '')
                
                if item_type == 'movie':
                    movie = item.get('movie', {})
                    imdb_id = movie.get('ids', {}).get('imdb')
                    if not imdb_id:
                        continue
                        
                    added_at = item.get('listed_at', '')
                    try:
                        dt = datetime.fromisoformat(added_at.replace('Z', '+00:00')) if added_at else None
                        added_at = int(dt.timestamp()) if dt else 0
                    except:
                        added_at = 0
                    
                    # 🔑 POSTER LEKÉRÉS - Trakt-ból
                    poster_url = None
                    images = movie.get('images', {})
                    if images.get('poster'):
                        poster_list = images['poster']
                        if isinstance(poster_list, list) and poster_list:
                            # A Trakt relatív URL-t ad, hozzá kell adni a https:// előtagot
                            poster_path = poster_list[0] if isinstance(poster_list[0], str) else ''
                            if poster_path and not poster_path.startswith('http'):
                                poster_url = f"https://{poster_path}"
                            else:
                                poster_url = poster_path
                    
                    # Ha nincs Trakt kép, próbáljuk Simkl-ből
                    if not poster_url:
                        poster_url = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
                    
                    combined_data.append({
                        'imdb_id': imdb_id,
                        'title': movie.get('title', 'Ismeretlen'),
                        'year': movie.get('year', ''),
                        'overview': movie.get('overview', ''),
                        'poster': poster_url if poster_url else 'DefaultFolder.png',  # 🔑 Frissítve
                        'source': 'Trakt',
                        'source_priority': 1,
                        'type': 'movie',
                        'added_at': added_at,
                        'rating': movie.get('rating', 0),
                        'certification': movie.get('certification', ''),
                        'genres': ', '.join(movie.get('genres', [])),
                        'runtime': movie.get('runtime', 0),
                        'status': movie.get('status', ''),
                        'network': movie.get('network', ''),
                        'raw_data': item,
                        'available_sources': ['Trakt']
                    })
                
                elif item_type == 'show':
                    show = item.get('show', {})
                    imdb_id = show.get('ids', {}).get('imdb')
                    if not imdb_id:
                        continue
                        
                    added_at = item.get('listed_at', '')
                    try:
                        dt = datetime.fromisoformat(added_at.replace('Z', '+00:00')) if added_at else None
                        added_at = int(dt.timestamp()) if dt else 0
                    except:
                        added_at = 0
                    
                    # 🔑 POSTER LEKÉRÉS - Trakt-ból
                    poster_url = None
                    images = show.get('images', {})
                    if images.get('poster'):
                        poster_list = images['poster']
                        if isinstance(poster_list, list) and poster_list:
                            poster_path = poster_list[0] if isinstance(poster_list[0], str) else ''
                            if poster_path and not poster_path.startswith('http'):
                                poster_url = f"https://{poster_path}"
                            else:
                                poster_url = poster_path
                    
                    # Ha nincs Trakt kép, próbáljuk Simkl-ből
                    if not poster_url:
                        poster_url = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
                    
                    combined_data.append({
                        'imdb_id': imdb_id,
                        'title': show.get('title', 'Ismeretlen'),
                        'year': show.get('year', ''),
                        'overview': show.get('overview', ''),
                        'poster': poster_url if poster_url else 'DefaultFolder.png',  # 🔑 Frissítve
                        'source': 'Trakt',
                        'source_priority': 1,
                        'type': 'show',
                        'added_at': added_at,
                        'rating': show.get('rating', 0),
                        'certification': show.get('certification', ''),
                        'genres': ', '.join(show.get('genres', [])),
                        'runtime': show.get('runtime', 0),
                        'status': show.get('status', ''),
                        'network': show.get('network', ''),
                        'aired_episodes': show.get('aired_episodes', 0),
                        'raw_data': item,
                        'available_sources': ['Trakt']
                    })

        if self.is_simkl_active():
            simkl_data = SimklInterface.get_simkl_watched_items()
            if simkl_data:
                for item in simkl_data.get('shows', []) + simkl_data.get('anime', []):
                    if item.get('status') == 'plantowatch':
                        show = item.get('show', {})
                        imdb_id = show.get('ids', {}).get('imdb')
                        if imdb_id:
                            added_at = item.get('added_to_watchlist_at', '')
                            try:
                                dt = datetime.fromisoformat(added_at.replace('Z', '+00:00')) if added_at else None
                                added_at = int(dt.timestamp()) if dt else 0
                            except:
                                added_at = 0
                                
                            combined_data.append({
                                'imdb_id': imdb_id,
                                'title': show.get('title', 'Ismeretlen'),
                                'year': show.get('year', ''),
                                'overview': '',
                                'poster': item.get('poster_link', 'DefaultFolder.png'),
                                'source': 'Simkl',
                                'source_priority': 2,
                                'type': 'show',
                                'added_at': added_at,
                                'rating': 0,
                                'certification': '',
                                'genres': '',
                                'runtime': 0,
                                'status': '',
                                'network': '',
                                'next_to_watch': item.get('next_to_watch', ''),
                                'watched_episodes': item.get('watched_episodes_count', 0),
                                'total_episodes': item.get('total_episodes_count', 0),
                                'raw_data': item,
                                'available_sources': ['Simkl']
                            })
                
                for item in simkl_data.get('movies', []):
                    if item.get('status') == 'plantowatch':
                        movie = item.get('movie', {})
                        imdb_id = movie.get('ids', {}).get('imdb')
                        if imdb_id:
                            added_at = item.get('added_to_watchlist_at', '')
                            try:
                                dt = datetime.fromisoformat(added_at.replace('Z', '+00:00')) if added_at else None
                                added_at = int(dt.timestamp()) if dt else 0
                            except:
                                added_at = 0
                                
                            combined_data.append({
                                'imdb_id': imdb_id,
                                'title': movie.get('title', 'Ismeretlen'),
                                'year': movie.get('year', ''),
                                'overview': '',
                                'poster': item.get('poster_link', 'DefaultFolder.png'),
                                'source': 'Simkl',
                                'source_priority': 2,
                                'type': 'movie',
                                'added_at': added_at,
                                'rating': 0,
                                'certification': '',
                                'genres': '',
                                'runtime': 0,
                                'status': '',
                                'network': '',
                                'raw_data': item,
                                'available_sources': ['Simkl']
                            })

        if self.is_plex_active():
            plex_data = PlexInterface.get_plex_watchlist(media_type='all') or []
            for item in plex_data:
                added_at = item.get('addedAt', 0)
                try:
                    added_at = int(added_at) if added_at else 0
                except (ValueError, TypeError):
                    added_at = 0
                    
                combined_data.append({
                    'imdb_id': item.get('imdb_id'),
                    'title': item.get('title', 'Ismeretlen'),
                    'year': item.get('year', ''),
                    'overview': item.get('summary', ''),
                    'poster': item.get('thumb', 'DefaultFolder.png'),
                    'source': 'Plex',
                    'source_priority': 3,
                    'type': item.get('type', 'movie'),
                    'added_at': added_at,
                    'rating': 0,
                    'certification': '',
                    'genres': '',
                    'runtime': 0,
                    'status': '',
                    'network': '',
                    'raw_data': item,
                    'available_sources': ['Plex']
                })

        source_map = {}
        for item in combined_data:
            imdb = item['imdb_id']
            if imdb:
                if imdb not in source_map:
                    source_map[imdb] = {
                        'sources': set(),
                        'items': []
                    }
                source_map[imdb]['sources'].add(item['source'])
                source_map[imdb]['items'].append(item)

        unique_data = []
        for imdb, data in source_map.items():
            sorted_items = sorted(data['items'], key=lambda x: x.get('source_priority', 99))
            best_item = sorted_items[0]

            best_item['available_sources'] = sorted(data['sources'])
            
            unique_data.append(best_item)

        unique_data.sort(key=lambda x: x.get('added_at', 0), reverse=True)
        
        if not unique_data:
            xbmcgui.Dialog().notification("Megnézendők", "Egyik watchlist sem tartalmaz elemet.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_data = unique_data[start_idx:end_idx]
        remaining = len(unique_data) - end_idx

        for item in paged_data:
            source_indicators = []
            source_colors = {
                'Trakt': 'orange',
                'Simkl': 'cyan',
                'Plex': 'yellow'
            }
            
            for src in sorted(item['available_sources']):
                color = source_colors.get(src, 'gray')
                source_indicators.append(f"[COLOR {color}]{src[0]}[/COLOR]")
            
            source_label = f"({'/'.join(source_indicators)})" if source_indicators else ""

            if item['type'] == 'movie':
                m_type_text, t_color = "      FILM     ", "lightgreen"
            else:
                m_type_text, t_color = "SOROZAT", "orange"
            
            m_label = f"{m_type_text:^9}"
            type_label = f"[B][COLOR {t_color}]|{m_label}|[/COLOR][/B]"

            extra_info = []

            if item.get('year'):
                extra_info.append(f"{item['year']}")

            if item.get('rating', 0) > 0:
                extra_info.append(f"★ {item['rating']:.1f}")

            status_map = {
                'returning series': '[COLOR lime]Fut[/COLOR]',
                'ended': '[COLOR red]ENDED[/COLOR]',
                'in production': '[COLOR yellow]Készül[/COLOR]',
                'canceled': '[COLOR red]CANCELED[/COLOR]'
            }
            if item.get('status') and item['source'] == 'Trakt' and item['type'] == 'show':
                status_text = status_map.get(item['status'].lower(), item['status'])
                extra_info.append(status_text)

            if extra_info:
                extra_str = ' | '.join(extra_info)
                display_name = f"{type_label} {source_label} [B]{item['title']}[/B] {extra_str}"
            else:
                display_name = f"{type_label} {source_label} [B]{item['title']}[/B]"

            plot_parts = [f"[B]{item['title']}[/B]"]
            plot_parts.append(f"Felvéve: {', '.join(item['available_sources'])}")
            plot_parts.append(f"Info forrás: {item['source']}")
            plot_parts.append(f"Típus: {item['type'].upper()}")
            
            if item.get('year'):
                plot_parts.append(f"Év: {item['year']}")
            
            if item.get('rating', 0) > 0:
                plot_parts.append(f"Értékelés: {item['rating']:.1f}/10")
            
            if item.get('status') and item['source'] == 'Trakt' and item['type'] == 'show':
                status_map_plot = {
                    'returning series': 'Futó sorozat',
                    'ended': 'Befejezett sorozat',
                    'in production': 'Készülő sorozat',
                    'canceled': 'Törölt sorozat'
                }
                plot_parts.append(f"Státusz: {status_map_plot.get(item['status'].lower(), item['status'])}")
            
            if item.get('genres'):
                plot_parts.append(f"Műfaj: {item['genres']}")
            
            if item.get('overview'):
                plot_parts.append(f"\n{item['overview']}")
            
            meta_data = {
                "title": item['title'],
                "year": item.get('year', ''),
                "plot": '\n'.join(plot_parts)
            }
            
            self.addDirectoryItem(
                display_name,
                f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={item['imdb_id']}",
                item.get('poster', 'DefaultFolder.png'),
                '',
                'DefaultFolder.png',
                meta=meta_data
            )

        if remaining > 0:
            next_page = current_page + 1
            self.addDirectoryItem(
                f"[B][COLOR yellow]>>> Következő oldal ({next_page}) [Még {remaining} elem] >>>[/COLOR][/B]",
                f"all_merged_watchlist&page={next_page}",
                '',
                'DefaultFolder.png'
            )
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    
    def getItems(self, url, ignore_filter='false'):
        from bs4 import BeautifulSoup
        import requests
        import urllib.parse
        import html
        import json
        import time

        if not hasattr(self, 'db'):
            from resources.lib.indexers.database import DatabaseManager
            db_file = os.path.join(translatePath(addon.getAddonInfo('profile')), 'ncore_tv.db')
            self.db = DatabaseManager(db_file)

        t_ep = self.params.get('target_episode', '')
        r_pct = self.params.get('resume_percent', '')
        ignore_ep_filter = self.params.get('ignore_ep_filter', 'false')

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        if t_ep and ignore_ep_filter != 'true':
            current_url = url
            all_found_items = []
            final_next_page_url = None
            max_pages_to_scan = 5
            pages_scanned = 0

            show_all_url_params = f"items&url={urllib.parse.quote_plus(url)}&ignore_ep_filter=true"
            show_all_title = f"[COLOR yellow][B]>> Minden találat megjelenítése (szűrés nélkül)[/B][/COLOR]"
            self.addDirectoryItem(show_all_title, show_all_url_params, 'DefaultFolder.png', '', isFolder=True)
            
            while pages_scanned < max_pages_to_scan and current_url:
                pages_scanned += 1
                resp = nc_get(current_url, cookies=cookies, headers=headers)
                soup = _FastSoup(resp.text)

                if known_errors(str(soup)):
                    break
                
                torrents = soup.find_all('div', class_='box_torrent')
                if not torrents:
                    break

                imdb_ids_to_query = []
                torrent_ids_to_query = []
                parsed_torrents_list = []

                for torrent in torrents:
                    t_id_match = re.search(r'id=(.*?)\" onclick=\"torrent', _tstr(torrent))
                    t_id = t_id_match.group(1) if t_id_match else ""
                    imdb_id = ""
                    imdb_link_element = torrent.find('div', class_='siterank').find('a') if torrent.find('div', class_='siterank') else None
                    if imdb_link_element:
                        imdb_link = re.sub(r'https://dereferer\.link/\?', r'', imdb_link_element['href'])
                        try: imdb_id = re.findall(r'(tt\d+)', imdb_link)[0].strip()
                        except: imdb_id = ""
                    parsed_torrents_list.append({'html': torrent, 't_id': t_id, 'imdb_id': imdb_id})
                    if imdb_id: imdb_ids_to_query.append(imdb_id)
                    if t_id: torrent_ids_to_query.append(t_id)

                db_sync_data, db_local_played = self.db.get_all_statuses_for_page(imdb_ids_to_query, torrent_ids_to_query)
                items_on_this_page = []

                for item in parsed_torrents_list:
                    torrent = item['html']
                    torrent_id = item['t_id']
                    imdb_id = item['imdb_id']
                    
                    torrent_details_link = f'{base_url}/torrents.php?action=details&id={torrent_id}'

                    title_element_1 = torrent.find('div', class_='torrent_txt')
                    title_match = re.search(r'onclick=\".*title=\"(.*)\">', str(title_element_1))
                    title_1 = html.unescape(title_match.group(1)) if title_match else ""

                    title_element_2 = torrent.find('div', class_='box_nev2')
                    title_2_match = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(title_element_2))
                    title_2 = html.unescape(title_2_match.group(1)) if title_2_match else ""

                    if title_1 == title_2 or not title_2:
                        title_2_match = re.search(r'<span title=\"(.*?)\">', str(title_element_2))
                        title_2 = html.unescape(title_2_match.group(1)) if title_2_match else ""

                    imdb_rate = ""
                    try:
                        imdb_rate_text = torrent.find('div', class_='siterank').text.strip()
                        imdb_rate_match = re.search(r'\[imdb: (.*?)\]', imdb_rate_text)
                        imdb_rate = imdb_rate_match.group(1) if imdb_rate_match else ""
                    except AttributeError:
                        imdb_rate = ""

                    c_c = ""
                    try:
                        cover_img_element = torrent.find('img', class_='infobar') or torrent.find('img', class_='infobar_ico')
                        if cover_img_element:
                            onmouseover = cover_img_element.get('onmouseover', '')
                            if "mutat('" in onmouseover:
                                c_c = onmouseover.split("mutat('")[1].split("',")[0]
                                c_c = re.sub(r'\?.*', r'', c_c)
                    except (AttributeError, IndexError):
                        pass

                    c_i = ""
                    if c_c and str(c_c).startswith('http'):
                        if proxy_needed == 'true':
                            c_i = f"http://{proxy_host}:{proxy_port}/?url={c_c}"
                        else:
                            c_i = c_c
                    else:
                        c_i = "DefaultMovies.png"

                    feltoltve = ""
                    feltoltve_element = torrent.find('div', class_='box_feltoltve2')
                    if feltoltve_element:
                        feltoltve = feltoltve_element.text.strip()
                        feltoltve = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2}:\d{2})', r'\1 \2', feltoltve)

                    feltoltve_formatted = f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]'
                    size = ""; size_element = torrent.find('div', class_='box_meret2');
                    if size_element: size = size_element.text.strip()
                    seeder = ""; seeder_element = torrent.find('div', class_='box_s2');
                    if seeder_element: seeder = seeder_element.text.strip()
                    leecher = ""; leecher_element = torrent.find('div', class_='box_l2');
                    if leecher_element: leecher = leecher_element.text.strip()
                    find_type_match = re.search(r'torrents.php\?tipus=(.*?)\"', _tstr(torrent));
                    cat_type_match = find_type_match.group(1) if find_type_match else ""
                    pick_title = title_2 if not title_1 else title_1

                    zene_kateg_list = ['mp3_hun', 'mp3', 'lossless_hun', 'lossless', 'clip']
                    _q_active, _q_chosen = self._quality_filter_state()
                    if _q_active and ignore_filter != 'true' and cat_type_match not in zene_kateg_list:
                        if not quality.allowed(pick_title, cat_type_match, _q_chosen): continue
                    
                    indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, torrent_id, db_sync_data, db_local_played)

                    rating_plot_info = ""
                    if imdb_id:
                        rtype = 'show' if cat_type_match in ['xvidser_hun', 'hdser_hun', 'xvidser', 'hdser'] else 'movie'
                        local_rating = self.db.get_trakt_rating(imdb_id, rtype, 0, 0)
                        if local_rating:
                            rating_plot_info = f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]\n"              
                    
                    url_params_base = f'url={urllib.parse.quote_plus(torrent_details_link)}&title_1={title_1}&title_2={title_2}&torrent_id={torrent_id}&c_i={c_i}&feltoltve={feltoltve}&seeder={seeder}&leecher={leecher}'
                    if t_ep: url_params_base += f"&target_episode={t_ep}"
                    if r_pct: url_params_base += f"&resume_percent={r_pct}"
                    detailed_cats = ['xvidser_hun', 'hdser_hun', 'xvidser', 'hdser', 'xvid_hun', 'hd_hun', 'xvid', 'hd']; metadata = {}
                    if cat_type_match in detailed_cats:
                        parsed_details = self.parse_and_format_torrent_details(title_1, feltoltve_formatted)
                        metadata_plot = f'[COLOR ff9ef542][B]{title_2}[/B][/COLOR]\n' if title_2 else ""
                        metadata_plot += f'{rating_plot_info}'
                        metadata_plot += f'{plot_status_line}[COLOR lightgreen][B]Méret:[/B] {size}[/COLOR]\n[COLOR lightgreen][B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]\n{parsed_details["plot"]}'
                        if cat_type_match in ['xvidser_hun', 'hdser_hun', 'xvidser', 'hdser']:
                            extr_type = 'extr_series'; lang_prefix = "[COLOR orange]HU[/COLOR]" if 'hun' in cat_type_match else "[COLOR yellow]EN[/COLOR]"; quality_color = "[COLOR ffff0000]SD[/COLOR]" if 'xvid' in cat_type_match else "[COLOR lime]HD[/COLOR]"; ep_color = "[COLOR lightblue]" if re.search(r'(S\d+E\d+)', pick_title) else "[COLOR lightgreen]"; hs_prefix = "[COLOR blue]HSUB[/COLOR] " if re.search(r'(hunsub)', pick_title, re.IGNORECASE) else ""; title_text = f'{indicator}[B]{lang_prefix} {hs_prefix}{quality_color}{ep_color} - {pick_title}[/COLOR][/B]'
                        else:
                            extr_type = 'extr_movie'; lang_prefix = "[COLOR orange]HU[/COLOR]" if 'hun' in cat_type_match else "[COLOR yellow]EN[/COLOR]"; quality_color = "[COLOR ffff0000]SD[/COLOR]" if 'xvid' in cat_type_match else "[COLOR lime]HD[/COLOR]"; hs_prefix = "[COLOR blue]HSUB[/COLOR] " if re.search(r'(hunsub)', pick_title, re.IGNORECASE) else ""; title_text = f'{indicator}[B]{lang_prefix} {hs_prefix}{quality_color} - {pick_title}[/B]'
                        url_params_base += f'&imdb_id={imdb_id}&imdb_rate={imdb_rate}'; metadata = {'plot': metadata_plot}
                    elif cat_type_match in ['xxx_xvid', 'xxx_hd']:
                        extr_type = 'extr_xxx'; q_color = "[COLOR ffff0000]SD[/COLOR]" if cat_type_match == 'xxx_xvid' else "[COLOR lime]HD[/COLOR]"; title_text = f'[B]{q_color} - {pick_title}[/B]'; metadata = {'plot': f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]\n{title_2}\n[COLOR lightgreen][B]Méret:[/B] {size}\n[B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]'}
                    elif cat_type_match in ['mp3_hun', 'mp3', 'lossless_hun', 'lossless', 'clip']:
                        extr_type = 'extr_zene'; z_lbls = {'mp3_hun': '[COLOR lime]HU MP3[/COLOR]', 'mp3': '[COLOR lightblue]EN MP3[/COLOR]', 'lossless_hun': '[COLOR lightgreen]HU Flac[/COLOR]', 'lossless': '[COLOR yellow]EN Flac[/COLOR]', 'clip': '[COLOR orange]Clip[/COLOR]'}; title_text = f'[B]{z_lbls.get(cat_type_match, "Zene")} - {pick_title}[/B]'; metadata = {'plot': f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]\n{title_2}\n[COLOR lightgreen][B]Méret:[/B] {size}\n[B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]'}
                    else: continue
                    
                    url_params = f'{extr_type}&{url_params_base}'

                    c_m = []

                    if self.is_trakt_active() and imdb_id:
                        rating_mgr_query = f"open_rating_manager&torrent_id={torrent_id}&imdb_id={imdb_id}&title_1={urllib.parse.quote_plus(pick_title)}"
                        c_m.append(("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", rating_mgr_query))

                    if imdb_id:
                        watch_series_query = f"get_watching_series&url={urllib.parse.quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={title_1}&title_2={title_2}"
                        c_m.append((f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", watch_series_query))

                    c_m.append((f"[B][COLOR yellow]Más verziók: {imdb_id}[/COLOR][/B]", f"search_with_imdb&imdb_id={imdb_id}"))
                    c_m.append(("[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]", f"more_like_this_imdb&imdb_id={imdb_id}"))
                    c_m.append(("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}"))
                    c_m.append(("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}"))

                    if imdb_id and extr_type == "extr_movie":
                        franchise_query = f"tmdb_get_collection_context&imdb_id={imdb_id}&torrent_id={torrent_id}"
                        c_m.append(("[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", franchise_query))

                    is_series_val = 'true' if extr_type == 'extr_series' else 'false'
                    
                    if self.is_trakt_active() and imdb_id:
                        c_m.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series={is_series_val}"))
                    
                    if self.is_simkl_active() and imdb_id:
                        c_m.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series={is_series_val}"))
                        
                    if self.is_plex_active() and imdb_id:
                        c_m.append(("[B][COLOR yellow]Plex => Watchlist[/COLOR][/B]", f"add_plex_watchlist_action&imdb_id={imdb_id}&is_series={is_series_val}"))

                    items_on_this_page.append({
                        'release_name': pick_title, 
                        'title_text': title_text, 
                        'url_params': url_params, 
                        'c_i': c_i, 
                        'context_menu_items': c_m, 
                        'metadata': metadata, 
                        'q_title': pick_title, 'q_cat': cat_type_match, 'q_seed': seeder,
                        'is_played': is_already_played
                    })

                query = parse_release_robust(t_ep)
                search_season = list(query["seasons"])[0] if query["seasons"] else None
                search_episode = query["episode"]
                filtered_items_on_page = []
                if search_season:
                    for item_to_check in items_on_this_page:
                        release_name = item_to_check.get('release_name', '')
                        rel = parse_release_robust(release_name)
                        match = False
                        if search_episode:
                            if rel["is_complete"] or (search_season in rel["seasons"] and (rel["episode"] is None or rel["episode"] == search_episode)): match = True
                        else:
                            if rel["is_complete"] or (search_season in rel["seasons"]): match = True
                        if match: filtered_items_on_page.append(item_to_check)

                if filtered_items_on_page:
                    all_found_items.extend(filtered_items_on_page)
                    nPa_tag = soup.find('a', id='nPa')
                    if nPa_tag: final_next_page_url = f"{base_url}{nPa_tag.get('href')}"
                    break
                
                nPa_tag = soup.find('a', id='nPa')
                current_url = f"{base_url}{nPa_tag.get('href')}" if nPa_tag else None

            all_found_items = self._sort_result_items(all_found_items)
            for item in all_found_items:
                self.addDirectoryItem(item['title_text'], item['url_params'], item['c_i'], 'DefaultMovies.png', context=item['context_menu_items'], isFolder=True, meta=item['metadata'])
            
            if not all_found_items:
                msg = f"[COLOR yellow][B]Nincs találat a '{t_ep}' szűrésre (maximum {max_pages_to_scan} oldal átnézve)[/B][/COLOR]"
                plot = f"[COLOR orange][B]Információ:[/B][/COLOR]\nA szkript automatikusan átnézett több oldalt, de nem talált a feltételnek megfelelő torrentet."
                self.addDirectoryItem(msg, "", 'DefaultAddonsUpdates.png', '', isFolder=False, meta={'plot': plot})

            if final_next_page_url:
                n_encoded = urllib.parse.quote_plus(final_next_page_url)
                n_query = f"items&url={n_encoded}&ignore_filter={ignore_filter}&target_episode={t_ep}{self._carry_params()}"
                self.addDirectoryItem('[I]Következő oldal (a találatok után)[/I]', n_query, '', 'DefaultFolder.png')

        else:
            resp = nc_get(url, cookies=cookies, headers=headers)
            soup = _FastSoup(resp.text)

            if known_errors(str(soup)):
                return

            torrents = soup.find_all('div', class_='box_torrent')
            total_torrents_on_page = len(torrents)

            imdb_ids_to_query = []
            torrent_ids_to_query = []
            parsed_torrents_list = []

            for torrent in torrents:
                t_id_match = re.search(r'id=(.*?)\" onclick=\"torrent', _tstr(torrent))
                t_id = t_id_match.group(1) if t_id_match else ""
                
                imdb_id = ""
                imdb_link_element = torrent.find('div', class_='siterank').find('a') if torrent.find('div', class_='siterank') else None
                if imdb_link_element:
                    imdb_link = re.sub(r'https://dereferer\.link/\?', r'', imdb_link_element['href'])
                    try: imdb_id = re.findall(r'(tt\d+)', imdb_link)[0].strip()
                    except: imdb_id = ""

                parsed_torrents_list.append({'html': torrent, 't_id': t_id, 'imdb_id': imdb_id})
                if imdb_id: imdb_ids_to_query.append(imdb_id)
                if t_id: torrent_ids_to_query.append(t_id)

            db_sync_data, db_local_played = self.db.get_all_statuses_for_page(imdb_ids_to_query, torrent_ids_to_query)

            items_displayed_count = 0
            all_items_to_render = []

            for item in parsed_torrents_list:
                torrent = item['html']
                torrent_id = item['t_id']
                imdb_id = item['imdb_id']
                
                torrent_details_link = f'{base_url}/torrents.php?action=details&id={torrent_id}'

                title_element_1 = torrent.find('div', class_='torrent_txt')
                title_match = re.search(r'onclick=\".*title=\"(.*)\">', str(title_element_1))
                title_1 = html.unescape(title_match.group(1)) if title_match else ""

                title_element_2 = torrent.find('div', class_='box_nev2')
                title_2_match = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(title_element_2))
                title_2 = html.unescape(title_2_match.group(1)) if title_2_match else ""

                if title_1 == title_2 or not title_2:
                    title_2_match = re.search(r'<span title=\"(.*?)\">', str(title_element_2))
                    title_2 = html.unescape(title_2_match.group(1)) if title_2_match else ""

                imdb_rate = ""
                try:
                    imdb_rate_text = torrent.find('div', class_='siterank').text.strip()
                    imdb_rate_match = re.search(r'\[imdb: (.*?)\]', imdb_rate_text)
                    imdb_rate = imdb_rate_match.group(1) if imdb_rate_match else ""
                except AttributeError:
                    imdb_rate = ""

                c_c = ""
                try:
                    cover_img_element = torrent.find('img', class_='infobar') or torrent.find('img', class_='infobar_ico')
                    if cover_img_element:
                        onmouseover = cover_img_element.get('onmouseover', '')
                        if "mutat('" in onmouseover:
                            c_c = onmouseover.split("mutat('")[1].split("',")[0]
                            c_c = re.sub(r'\?.*', r'', c_c)
                except (AttributeError, IndexError):
                    pass

                c_i = ""
                if c_c and str(c_c).startswith('http'):
                    if proxy_needed == 'true':
                        c_i = f"http://{proxy_host}:{proxy_port}/?url={c_c}"
                    else:
                        c_i = c_c
                else:
                    c_i = "DefaultMovies.png"

                feltoltve = ""
                feltoltve_element = torrent.find('div', class_='box_feltoltve2')
                if feltoltve_element:
                    feltoltve = feltoltve_element.text.strip()
                    feltoltve = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2}:\d{2})', r'\1 \2', feltoltve)

                feltoltve_formatted = f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]'

                size = ""
                size_element = torrent.find('div', class_='box_meret2')
                if size_element: size = size_element.text.strip()

                seeder = ""
                seeder_element = torrent.find('div', class_='box_s2')
                if seeder_element: seeder = seeder_element.text.strip()

                leecher = ""
                leecher_element = torrent.find('div', class_='box_l2')
                if leecher_element: leecher = leecher_element.text.strip()

                find_type_match = re.search(r'torrents.php\?tipus=(.*?)\"', _tstr(torrent))
                cat_type_match = find_type_match.group(1) if find_type_match else ""

                pick_title = title_2 if not title_1 else title_1

                zene_kateg_list = ['mp3_hun', 'mp3', 'lossless_hun', 'lossless', 'clip']
                _q_active, _q_chosen = self._quality_filter_state()
                if _q_active and ignore_filter != 'true' and cat_type_match not in zene_kateg_list:
                    if not quality.allowed(pick_title, cat_type_match, _q_chosen): continue
                
                indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, torrent_id, db_sync_data, db_local_played)

                rating_plot_info = ""
                if imdb_id:
                    rtype = 'show' if cat_type_match in ['xvidser_hun', 'hdser_hun', 'xvidser', 'hdser'] else 'movie'
                    local_rating = self.db.get_trakt_rating(imdb_id, rtype, 0, 0)
                    if local_rating:
                        rating_plot_info = f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]\n"

                url_params_base = f'url={urllib.parse.quote_plus(torrent_details_link)}&title_1={title_1}&title_2={title_2}&torrent_id={torrent_id}&c_i={c_i}&feltoltve={feltoltve}&seeder={seeder}&leecher={leecher}'

                if t_ep: url_params_base += f"&target_episode={t_ep}"
                if r_pct: url_params_base += f"&resume_percent={r_pct}"
                
                detailed_cats = ['xvidser_hun', 'hdser_hun', 'xvidser', 'hdser', 'xvid_hun', 'hd_hun', 'xvid', 'hd']
                metadata = {}

                if cat_type_match in detailed_cats:
                    parsed_details = self.parse_and_format_torrent_details(title_1, feltoltve_formatted)
                    metadata_plot = f'[COLOR ff9ef542][B]{title_2}[/B][/COLOR]\n' if title_2 else ""
                    metadata_plot += f'{rating_plot_info}'
                    metadata_plot += f'{plot_status_line}[COLOR lightgreen][B]Méret:[/B] {size}[/COLOR]\n[COLOR lightgreen][B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]\n{parsed_details["plot"]}'

                    if cat_type_match in ['xvidser_hun', 'hdser_hun', 'xvidser', 'hdser']:
                        extr_type = 'extr_series'
                        lang_prefix = "[COLOR orange]HU[/COLOR]" if 'hun' in cat_type_match else "[COLOR yellow]EN[/COLOR]"
                        quality_color = "[COLOR ffff0000]SD[/COLOR]" if 'xvid' in cat_type_match else "[COLOR lime]HD[/COLOR]"
                        ep_color = "[COLOR lightblue]" if re.search(r'(S\d+E\d+)', pick_title) else "[COLOR lightgreen]"
                        hs_prefix = "[COLOR blue]HSUB[/COLOR] " if re.search(r'(hunsub)', pick_title, re.IGNORECASE) else ""
                        title_text = f'{indicator}[B]{lang_prefix} {hs_prefix}{quality_color}{ep_color} - {pick_title}[/COLOR][/B]'
                    else:
                        extr_type = 'extr_movie'
                        lang_prefix = "[COLOR orange]HU[/COLOR]" if 'hun' in cat_type_match else "[COLOR yellow]EN[/COLOR]"
                        quality_color = "[COLOR ffff0000]SD[/COLOR]" if 'xvid' in cat_type_match else "[COLOR lime]HD[/COLOR]"
                        hs_prefix = "[COLOR blue]HSUB[/COLOR] " if re.search(r'(hunsub)', pick_title, re.IGNORECASE) else ""
                        title_text = f'{indicator}[B]{lang_prefix} {hs_prefix}{quality_color} - {pick_title}[/B]'

                    url_params_base += f'&imdb_id={imdb_id}&imdb_rate={imdb_rate}'
                    metadata = {'plot': metadata_plot}

                elif cat_type_match in ['xxx_xvid', 'xxx_hd']:
                    extr_type = 'extr_xxx'
                    q_color = "[COLOR ffff0000]SD[/COLOR]" if cat_type_match == 'xxx_xvid' else "[COLOR lime]HD[/COLOR]"
                    title_text = f'[B]{q_color} - {pick_title}[/B]'
                    metadata = {'plot': f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]\n{title_2}\n[COLOR lightgreen][B]Méret:[/B] {size}\n[B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]'}
                elif cat_type_match in ['mp3_hun', 'mp3', 'lossless_hun', 'lossless', 'clip']:
                    extr_type = 'extr_zene'
                    z_lbls = {'mp3_hun': '[COLOR lime]HU MP3[/COLOR]', 'mp3': '[COLOR lightblue]EN MP3[/COLOR]', 'lossless_hun': '[COLOR lightgreen]HU Flac[/COLOR]', 'lossless': '[COLOR yellow]EN Flac[/COLOR]', 'clip': '[COLOR orange]Clip[/COLOR]'}
                    title_text = f'[B]{z_lbls.get(cat_type_match, "Zene")} - {pick_title}[/B]'
                    metadata = {'plot': f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]\n{title_2}\n[COLOR lightgreen][B]Méret:[/B] {size}\n[B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]'}
                else: continue

                url_params = f'{extr_type}&{url_params_base}'

                c_m = []

                if self.is_trakt_active() and imdb_id:
                    rating_mgr_query = f"open_rating_manager&torrent_id={torrent_id}&imdb_id={imdb_id}&title_1={urllib.parse.quote_plus(pick_title)}"
                    c_m.append(("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", rating_mgr_query))

                if imdb_id:
                    watch_series_query = f"get_watching_series&url={urllib.parse.quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={title_1}&title_2={title_2}"
                    c_m.append((f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", watch_series_query))

                c_m.append((f"[B][COLOR yellow]Más verziók: {imdb_id}[/COLOR][/B]", f"search_with_imdb&imdb_id={imdb_id}"))
                c_m.append(("[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]", f"more_like_this_imdb&imdb_id={imdb_id}"))
                c_m.append(("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}"))
                c_m.append(("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}"))

                if imdb_id and extr_type == "extr_movie":
                    franchise_query = f"tmdb_get_collection_context&imdb_id={imdb_id}&torrent_id={torrent_id}"
                    c_m.append(("[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", franchise_query))

                is_series_val = 'true' if extr_type == 'extr_series' else 'false'
                
                if self.is_trakt_active() and imdb_id:
                    c_m.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series={is_series_val}"))
                
                if self.is_simkl_active() and imdb_id:
                    c_m.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series={is_series_val}"))
                
                if self.is_plex_active() and imdb_id:
                    c_m.append(("[B][COLOR yellow]Plex => Watchlist[/COLOR][/B]", f"add_plex_watchlist_action&imdb_id={imdb_id}&is_series={is_series_val}"))

                all_items_to_render.append({
                    'title_text': title_text, 
                    'url_params': url_params, 
                    'c_i': c_i, 
                    'context_menu_items': c_m, 
                    'metadata': metadata, 
                    'q_title': pick_title, 'q_cat': cat_type_match, 'q_seed': seeder,
                    'is_played': is_already_played
                })

            all_items_to_render = self._sort_result_items(all_items_to_render)
            for item in all_items_to_render:
                items_displayed_count += 1
                self.addDirectoryItem(item['title_text'], item['url_params'], item['c_i'], 'DefaultMovies.png', context=item['context_menu_items'], isFolder=True, meta=item['metadata'])
            
            if items_displayed_count == 0 and total_torrents_on_page > 0:
                if addon.getSetting('fallback_search_result') == 'true':
                    msg = f"[COLOR yellow][B]Nincs megjeleníthető találat a szűrővel ({total_torrents_on_page} találat rejtve lett)[/B][/COLOR]"
                    plot = f"[COLOR orange][B]Információ:[/B][/COLOR]\nA szűrőbeállításaid miatt ezen az oldalon nem maradt megjeleníthető elem.\n\n[COLOR lightgreen]Kattints ide a szűrés IDEIGLENES kikapcsolásához ezen az oldalon![/COLOR]"
                    self.addDirectoryItem(msg, f"items&url={urllib.parse.quote_plus(url)}&ignore_filter=true", '', 'DefaultAddonsUpdates.png', isFolder=True, meta={'plot': plot})

            try:
                nPa_tag = soup.find('a', id='nPa')
                if nPa_tag:
                    n_href = nPa_tag.get('href')
                    n_full = f"{base_url}{n_href}"
                    n_encoded = urllib.parse.quote_plus(n_full)
                    n_query = f"items&url={n_encoded}&ignore_filter={ignore_filter}{self._carry_params()}"
                    self.addDirectoryItem('[I]Következő oldal[/I]', n_query, '', 'DefaultFolder.png')
            except: pass

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def getMovieItems(self, url, title_1, title_2, torrent_id, imdb_id, imdb_rate, c_i, feltoltve, seeder, leecher):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re
        import html
        import json

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = nc_get(f'{base_url}{url}', cookies=cookies, headers=headers)
        soup = _FastSoup(resp.text)
        if known_errors(str(soup)):
            return

        torrents = soup.find_all('div', class_='box_torrent')

        imdb_ids_to_query = []
        torrent_ids_to_query = []
        parsed_data_list = []

        for torrent in torrents:
            t_id_match = re.search(r'id=(.*?)\" onclick=\"torrent', _tstr(torrent))
            t_id = t_id_match.group(1) if t_id_match else ""

            i_id = ""
            imdb_link_element = torrent.find('div', class_='siterank')
            if imdb_link_element and imdb_link_element.find('a'):
                link = re.sub(r'https://dereferer\.link/\?', r'', imdb_link_element.find('a').get('href', ""))
                try: i_id = re.findall(r'(tt\d+)', link)[0].strip()
                except: i_id = ""

            parsed_data_list.append({'html': torrent, 't_id': t_id, 'imdb_id': i_id})
            if i_id: imdb_ids_to_query.append(i_id)
            if t_id: torrent_ids_to_query.append(t_id)

        db_sync_data, db_local_played = self.db.get_all_statuses_for_page(imdb_ids_to_query, torrent_ids_to_query)

        for item in parsed_data_list:
            torrent = item['html']
            torrent_id = item['t_id']
            imdb_id = item['imdb_id']
            
            torrent_details_link = f'{base_url}/torrents.php?action=details&id={torrent_id}'

            title_element_1 = torrent.find('div', class_='torrent_txt')
            if title_element_1:
                title_match = re.search(r'onclick=\".*title=\"(.*)\">', str(title_element_1))
                title_1 = title_match.group(1) if title_match else ""

            title_element_2 = torrent.find('div', class_='box_nev2')
            if title_element_2:
                title_2_match = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(title_element_2))
                title_2 = title_2_match.group(1) if title_2_match else ""
                if title_1 == title_2:
                    title_2_match_span = re.search(r'<span title=\"(.*?)\">', str(title_element_2))
                    title_2 = title_2_match_span.group(1) if title_2_match_span else title_2

            imdb_link_element = torrent.find('div', class_='siterank')
            imdb_rate = ""
            if imdb_link_element:
                imdb_rate_text = imdb_link_element.text.strip()
                imdb_rate_match = re.search(r'\[imdb: (.*?)\]', imdb_rate_text)
                imdb_rate = imdb_rate_match.group(1) if imdb_rate_match else ""

            indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, torrent_id, db_sync_data, db_local_played)

            rating_plot_info = ""
            if imdb_id:
                local_rating = self.db.get_trakt_rating(imdb_id, 'movie', 0, 0)
                if local_rating:
                    rating_plot_info = f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]\n"

            c_c = ""
            try:
                cover_img_element = torrent.find('img', class_='infobar') or torrent.find('img', class_='infobar_ico')
                if cover_img_element:
                    onmouseover = cover_img_element.get('onmouseover', '')
                    if "mutat('" in onmouseover:
                        c_c = onmouseover.split("mutat('")[1].split("',")[0]
                        c_c = re.sub(r'\?.*', r'', c_c)
            except (AttributeError, IndexError):
                pass

            c_i = ""
            if c_c and str(c_c).startswith('http'):
                if proxy_needed == 'true':
                    c_i = f"http://{proxy_host}:{proxy_port}/?url={c_c}"
                else:
                    c_i = c_c
            else:
                c_i = "DefaultMovies.png"

            feltoltve_element = torrent.find('div', class_='box_feltoltve2')
            if feltoltve_element:
                feltoltve = feltoltve_element.text.strip()
                feltoltve = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2}:\d{2})', r'\1 \2', feltoltve)

            feltoltve_formatted = f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]'
            size_element = torrent.find('div', class_='box_meret2')
            size = size_element.text.strip() if size_element else ""
            seeder_element = torrent.find('div', class_='box_s2')
            seeder = seeder_element.text.strip() if seeder_element else ""
            leecher_element = torrent.find('div', class_='box_l2')
            leecher = leecher_element.text.strip() if leecher_element else ""

            parsed_details = self.parse_and_format_torrent_details(title_1, feltoltve_formatted)

            metadata_plot_content = ""
            if title_2 and str(title_2).strip().lower() not in ["none", ""] and title_2 != title_1:
                metadata_plot_content += f'[COLOR ff9ef542][B]{title_2}[/B][/COLOR]\n'

            metadata_plot_content += (
                f'{rating_plot_info}'
                f'{plot_status_line}'                
                f'[COLOR yellow][B]Imdb:[/B] {imdb_rate}[/COLOR]\n'
                f'[COLOR lightgreen][B]Méret:[/B] {size}[/COLOR]\n'
                f'[COLOR lightgreen][B]Seeder:[/B] {seeder} [COLOR magenta] | [/COLOR] [B]Leecher:[/B] {leecher}[/COLOR]\n'
                f'{parsed_details["plot"]}\n'
            )
            metadata = {'plot': metadata_plot_content}

            url_params = f'extr_movie&url={quote_plus(torrent_details_link)}&title_1={title_1}&title_2={title_2}&torrent_id={torrent_id}&imdb_id={imdb_id}&imdb_rate={imdb_rate}&c_i={c_i}&feltoltve={feltoltve}&seeder={seeder}&leecher={leecher}'

            if not title_1:
                pick_title = title_2
            else:
                pick_title = title_1

            search_imdb_context = (f"[B][COLOR yellow]Más verziók: {imdb_id}[/COLOR][/B]", f"search_with_imdb&imdb_id={imdb_id}")
            more_like_this_context = ("[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]", f"more_like_this_imdb&imdb_id={imdb_id}")
            bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
            torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
            
            context_menu_items = [search_imdb_context, more_like_this_context, bookmark_context, torrent_to_seed]

            if imdb_id:
                franchise_query = f"tmdb_get_collection_context&imdb_id={imdb_id}&torrent_id={torrent_id}"
                context_menu_items.append(("[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", franchise_query))

            if self.is_trakt_active() and imdb_id:
                rating_mgr_context = ("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", 
                                      f"open_rating_manager&torrent_id={torrent_id}&imdb_id={imdb_id}&title_1={quote_plus(pick_title)}")
                context_menu_items.insert(0, rating_mgr_context)

                context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series=false"))

            if self.is_simkl_active() and imdb_id: context_menu_items.append(("[B][COLOR yellow]Simkl => Watchlist[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series=false"))
            if self.is_plex_active() and imdb_id: context_menu_items.append(("[B][COLOR yellow]Plex => Watchlist[/COLOR][/B]", f"add_plex_watchlist_action&imdb_id={imdb_id}&is_series=false"))

            self.addDirectoryItem(f'{indicator}[B]{pick_title}[/B]', url_params, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=metadata)

        try:
            nPa_tag = soup.find('a', id='nPa')
            if nPa_tag:
                next_page_url = f'{base_url}{nPa_tag["href"]}'
                next_p = re.findall(r'(/torrents.php.*)', str(next_page_url))[0].strip()
                if not self._is_widget():
                    self.addDirectoryItem('[I]Következő oldal[/I]', f'movie_items&url={quote_plus(next_p)}{self._carry_params()}', '', 'DefaultFolder.png')
        except: pass

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getSeriesItems(self, url, title_1, title_2, torrent_id, imdb_id, imdb_rate, c_i, feltoltve, seeder, leecher):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re
        import html
        import json

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = nc_get(f'{base_url}{url}', cookies=cookies, headers=headers)
        soup = _FastSoup(resp.text)
        if known_errors(str(soup)):
            return

        torrents = soup.find_all('div', class_='box_torrent')

        imdb_ids_to_query = []
        torrent_ids_to_query = []
        parsed_data_list = []

        for torrent in torrents:
            t_id_match = re.search(r'id=(.*?)\" onclick=\"torrent', _tstr(torrent))
            t_id = t_id_match.group(1) if t_id_match else ""

            i_id = ""
            imdb_link_element = torrent.find('div', class_='siterank')
            if imdb_link_element and imdb_link_element.find('a'):
                link = re.sub(r'https://dereferer\.link/\?', r'', imdb_link_element.find('a').get('href', ""))
                try: i_id = re.findall(r'(tt\d+)', link)[0].strip()
                except: i_id = ""

            parsed_data_list.append({'html': torrent, 't_id': t_id, 'imdb_id': i_id})
            if i_id: imdb_ids_to_query.append(i_id)
            if t_id: torrent_ids_to_query.append(t_id)

        db_sync_data, db_local_played = self.db.get_all_statuses_for_page(imdb_ids_to_query, torrent_ids_to_query)

        for item in parsed_data_list:
            torrent = item['html']
            torrent_id = item['t_id']
            imdb_id = item['imdb_id']
            
            title_1 = "" 
            title_2 = ""
            imdb_rate = ""
            feltoltve = ""
            
            torrent_details_link = f'{base_url}/torrents.php?action=details&id={torrent_id}'

            title_element_1 = torrent.find('div', class_='torrent_txt')
            if title_element_1:
                title_match = re.search(r'onclick=\".*title=\"(.*)\">', str(title_element_1))
                title_1 = title_match.group(1) if title_match else ""

            title_element_2 = torrent.find('div', class_='box_nev2')
            if title_element_2:
                title_2_match = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(title_element_2))
                title_2 = title_2_match.group(1) if title_2_match else ""
                if title_1 == title_2:
                    title_2_match_span = re.search(r'<span title=\"(.*?)\">', str(title_element_2))
                    title_2 = title_2_match_span.group(1) if title_2_match_span else title_2

            imdb_link_element = torrent.find('div', class_='siterank')
            if imdb_link_element:
                imdb_rate_text = imdb_link_element.text.strip()
                imdb_rate_match = re.search(r'\[imdb: (.*?)\]', imdb_rate_text)
                imdb_rate = imdb_rate_match.group(1) if imdb_rate_match else ""

            indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, torrent_id, db_sync_data, db_local_played)

            rating_plot_info = ""
            if imdb_id:
                local_rating = self.db.get_trakt_rating(imdb_id, 'show', 0, 0)
                if local_rating:
                    rating_plot_info = f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]\n"

            c_c = ""
            try:
                cover_img_element = torrent.find('img', class_='infobar') or torrent.find('img', class_='infobar_ico')
                if cover_img_element:
                    onmouseover = cover_img_element.get('onmouseover', '')
                    if "mutat('" in onmouseover:
                        c_c = onmouseover.split("mutat('")[1].split("',")[0]
                        c_c = re.sub(r'\?.*', r'', c_c)
            except (AttributeError, IndexError):
                pass

            c_i = ""
            if c_c and str(c_c).startswith('http'):
                if proxy_needed == 'true':
                    c_i = f"http://{proxy_host}:{proxy_port}/?url={c_c}"
                else:
                    c_i = c_c
            else:
                c_i = "DefaultMovies.png"

            feltoltve_element = torrent.find('div', class_='box_feltoltve2')
            if feltoltve_element:
                feltoltve = feltoltve_element.text.strip()
                feltoltve = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2}:\d{2})', r'\1 \2', feltoltve)

            feltoltve_formatted = f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]'
            size_element = torrent.find('div', class_='box_meret2')
            size = size_element.text.strip() if size_element else ""
            seeder_element = torrent.find('div', class_='box_s2')
            seeder = seeder_element.text.strip() if seeder_element else ""
            leecher_element = torrent.find('div', class_='box_l2')
            leecher = leecher_element.text.strip() if leecher_element else ""

            url_params = f'extr_series&url={quote_plus(torrent_details_link)}&title_1={title_1}&title_2={title_2}&torrent_id={torrent_id}&imdb_id={imdb_id}&imdb_rate={imdb_rate}&c_i={c_i}&feltoltve={feltoltve}&seeder={seeder}&leecher={leecher}'

            if not title_1:
                pick_title = title_2
            else:
                pick_title = title_1

            if re.search(r'(S\d+E\d+)', pick_title):
                title_text = f'{indicator}[B][COLOR lightblue]{pick_title}[/COLOR][/B]'
            else:
                title_text = f'{indicator}[B][COLOR lightgreen]{pick_title}[/COLOR][/B]'

            parsed_details = self.parse_and_format_torrent_details(title_1, feltoltve_formatted)

            metadata_plot_content = ""
            if title_2 and str(title_2).strip().lower() not in ["none", ""] and title_2 != title_1:
                metadata_plot_content += f'[COLOR ff9ef542][B]{title_2}[/B][/COLOR]\n'

            metadata_plot_content += (
                f'{rating_plot_info}'
                f'{plot_status_line}'                
                f'[COLOR yellow][B]Imdb:[/B] {imdb_rate}[/COLOR]\n'
                f'[COLOR lightgreen][B]Méret:[/B] {size}[/COLOR]\n'
                f'[COLOR lightgreen][B]Seeder:[/B] {seeder} [COLOR magenta] | [/COLOR] [B]Leecher:[/B] {leecher}[/COLOR]\n'
                f'{parsed_details["plot"]}\n'
            )
            metadata = {'plot': metadata_plot_content}

            add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={title_1}&title_2={title_2}")
            search_imdb_context = (f"[B][COLOR yellow]Más verziók: {imdb_id}[/COLOR][/B]", f"search_with_imdb&imdb_id={imdb_id}")
            more_like_this_context = ("[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]", f"more_like_this_imdb&imdb_id={imdb_id}")
            bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
            torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")

            context_menu_items = [add_series_watching, search_imdb_context, more_like_this_context, bookmark_context, torrent_to_seed]

            if self.is_trakt_active() and imdb_id:
                context_menu_items.insert(0, ("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", 
                                             f"open_rating_manager&torrent_id={torrent_id}&imdb_id={imdb_id}&title_1={quote_plus(pick_title)}"))
                context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series=true"))

            if self.is_simkl_active() and imdb_id: context_menu_items.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series=true"))
            if self.is_plex_active() and imdb_id: context_menu_items.append(("[B][COLOR yellow]Plex => Watchlist[/COLOR][/B]", f"add_plex_watchlist_action&imdb_id={imdb_id}&is_series=true"))

            self.addDirectoryItem(title_text, url_params, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=metadata)

        try:
            nPa_tag = soup.find('a', id='nPa')
            if nPa_tag:
                next_page_url = f'{base_url}{nPa_tag["href"]}'
                next_p = re.findall(r'(/torrents.php.*)', str(next_page_url))[0].strip()
                if not self._is_widget():
                    self.addDirectoryItem('[I]Következő oldal[/I]', f'series_items&url={quote_plus(next_p)}{self._carry_params()}', '', 'DefaultFolder.png')
        except: pass

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)



    def getZeneItems(self, url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = nc_get(f'{base_url}{url}', cookies=cookies, headers=headers)

        soup = _FastSoup(resp.text)
        if known_errors(str(soup)):
            return

        torrents = soup.find_all('div', class_='box_torrent')

        for torrent in torrents:
            torrent_id = ""
            title_1 = ""
            title_2 = ""
            c_c = ""
            c_i = ""
            feltoltve = ""
            size = ""
            seeder = ""
            leecher = ""

            torrent_id_match = re.search(r'id=(.*?)\" onclick=\"torrent', _tstr(torrent))
            torrent_id = torrent_id_match.group(1) if torrent_id_match else ""
            torrent_details_link = f'{base_url}/torrents.php?action=details&id={torrent_id}'

            title_element_1 = torrent.find('div', class_='torrent_txt')
            if title_element_1:
                title_match = re.search(r'onclick=\".*title=\"(.*)\">', str(title_element_1))
                title_1 = title_match.group(1) if title_match else ""

            title_element_2 = torrent.find('div', class_='box_nev2')
            if title_element_2:
                title_2_match = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(title_element_2))
                title_2 = title_2_match.group(1) if title_2_match else ""

                if title_1 == title_2:
                    title_2_match_span = re.search(r'<span title=\"(.*?)\">', str(title_element_2))
                    title_2 = title_2_match_span.group(1) if title_2_match_span else title_2

            cover_img_element = torrent.find('img', class_='infobar') or torrent.find('img', class_='infobar_ico')
            if cover_img_element:
                onmouseover_attr = cover_img_element.get('onmouseover')
                if onmouseover_attr:
                    try:
                        c_c = onmouseover_attr.split("mutat('")[1].split("',")[0]
                        c_c = re.sub(r'\?.*', r'', c_c)
                    except IndexError:
                        c_c = ""

            if c_c:
                if proxy_needed == 'true':
                    c_i = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(c_c, safe='')}"
                else:
                    c_i = c_c

            feltoltve_element = torrent.find('div', class_='box_feltoltve2')
            if feltoltve_element:
                feltoltve = feltoltve_element.text.strip()
                feltoltve = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2}:\d{2})', r'\1 \2', feltoltve)

            size_element = torrent.find('div', class_='box_meret2')
            if size_element:
                size = size_element.text.strip()

            seeder_element = torrent.find('div', class_='box_s2')
            if seeder_element:
                seeder = seeder_element.text.strip()

            leecher_element = torrent.find('div', class_='box_l2')
            if leecher_element:
                leecher = leecher_element.text.strip()

            url_params = f'extr_zene&url={quote_plus(torrent_details_link)}&title_1={title_1}&title_2={title_2}&torrent_id={torrent_id}&c_i={c_i}&feltoltve={feltoltve}&seeder={seeder}&leecher={leecher}'

            if not title_1:
                pick_title = title_2
            else:
                pick_title = title_1

            title_text = f'[B]{pick_title}[/B]'

            metadata = {'plot': f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]\n{title_2}\n[COLOR lightgreen][B]Méret:[/B] {size}\n[B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]'}

            bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
            torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
            context_menu_items = [bookmark_context, torrent_to_seed]

            self.addDirectoryItem(title_text, url_params, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=metadata)

        try:
            nPa_tag = soup.find('a', id='nPa')

            if nPa_tag:
                next_page_url = f'{base_url}{nPa_tag["href"]}'

                next_p = re.findall(r'(/torrents.php.*)', str(next_page_url))[0].strip()

                self.addDirectoryItem('[I]Következő oldal[/I]', f'zene_items&url={quote_plus(next_p)}', '', 'DefaultFolder.png')
        except Exception as e:
            xbmc.log(f'{base_log_info}| getZeneItems | next_page_url | csak egy oldal található: {e}', xbmc.LOGINFO)

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getXXXItems(self, url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = nc_get(f'{base_url}{url}', cookies=cookies, headers=headers)

        soup = _FastSoup(resp.text)
        if known_errors(str(soup)):
            return

        torrents = soup.find_all('div', class_='box_torrent')

        for torrent in torrents:
            torrent_id = ""
            title_1 = ""
            title_2 = ""
            c_c = ""
            c_i = ""
            feltoltve = ""
            size = ""
            seeder = ""
            leecher = ""

            torrent_id_match = re.search(r'id=(.*?)\" onclick=\"torrent', _tstr(torrent))
            torrent_id = torrent_id_match.group(1) if torrent_id_match else ""
            torrent_details_link = f'{base_url}/torrents.php?action=details&id={torrent_id}'

            title_element_1 = torrent.find('div', class_='torrent_txt')
            if title_element_1:
                title_match = re.search(r'onclick=\".*title=\"(.*)\">', str(title_element_1))
                title_1 = title_match.group(1) if title_match else ""

            title_element_2 = torrent.find('div', class_='box_nev2')
            if title_element_2:
                title_2_match = re.search(r'onclick=\".*title=\"(.*)\"><nobr>', str(title_element_2))
                title_2 = title_2_match.group(1) if title_2_match else ""

                if title_1 == title_2:
                    title_2_match_span = re.search(r'<span title=\"(.*?)\">', str(title_element_2))
                    title_2 = title_2_match_span.group(1) if title_2_match_span else title_2

            cover_img_element = torrent.find('img', class_='infobar') or torrent.find('img', class_='infobar_ico')
            if cover_img_element:
                onmouseover_attr = cover_img_element.get('onmouseover')
                if onmouseover_attr:
                    try:
                        c_c = onmouseover_attr.split("mutat('")[1].split("',")[0]
                        c_c = re.sub(r'\?.*', r'', c_c)
                    except IndexError:
                        c_c = ""

            if c_c:
                if proxy_needed == 'true':
                    c_i = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(c_c, safe='')}"
                else:
                    c_i = c_c

            feltoltve_element = torrent.find('div', class_='box_feltoltve2')
            if feltoltve_element:
                feltoltve = feltoltve_element.text.strip()
                feltoltve = re.sub(r'(\d{4}-\d{2}-\d{2})(\d{2}:\d{2}:\d{2})', r'\1 \2', feltoltve)

            size_element = torrent.find('div', class_='box_meret2')
            if size_element:
                size = size_element.text.strip()

            seeder_element = torrent.find('div', class_='box_s2')
            if seeder_element:
                seeder = seeder_element.text.strip()

            leecher_element = torrent.find('div', class_='box_l2')
            if leecher_element:
                leecher = leecher_element.text.strip()

            url_params = f'extr_xxx&url={quote_plus(torrent_details_link)}&title_1={title_1}&title_2={title_2}&torrent_id={torrent_id}&c_i={c_i}&feltoltve={feltoltve}&seeder={seeder}&leecher={leecher}'

            if not title_1:
                pick_title = title_2
            else:
                pick_title = title_1

            title_text = f'[B]{pick_title}[/B]'

            metadata = {'plot': f'[COLOR orange][B]Feltöltve:[/B] {feltoltve}[/COLOR]\n{title_2}\n[COLOR lightgreen][B]Méret:[/B] {size}\n[B]Seeder:[/B] {seeder}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {leecher}[/COLOR]'}

            bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
            torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
            context_menu_items = [bookmark_context, torrent_to_seed]

            self.addDirectoryItem(title_text, url_params, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=metadata)

        try:
            nPa_tag = soup.find('a', id='nPa')

            if nPa_tag:
                next_page_url = f'{base_url}{nPa_tag["href"]}'

                next_p = re.findall(r'(/torrents.php.*)', str(next_page_url))[0].strip()

                self.addDirectoryItem('[I]Következő oldal[/I]', f'xxx_items&url={quote_plus(next_p)}', '', 'DefaultFolder.png')
        except Exception as e:
            xbmc.log(f'{base_log_info}| getXXXItems | next_page_url | csak egy oldal található: {e}', xbmc.LOGINFO)

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def get_info_from_tmdb(self, tmdb_id, media_type, poster, title):
        if not tmdb_id: 
            xbmcplugin.endOfDirectory(syshandle, succeeded=False)
            return
        
        try:
            ext_url = f"https://api.themoviedb.org/3/{media_type}/{tmdb_id}/external_ids?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}"
            res = requests.get(ext_url, timeout=10).json()
            imdb_id = res.get('imdb_id')
            
            if imdb_id:
                self.getInfoImdb(imdb_id, poster, title)
            else:
                xbmcgui.Dialog().notification("nCore TV", "Nem található IMDb azonosító.", xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(syshandle, succeeded=False)
        except Exception as e:
            xbmc.log(f"[nCore_TMDB_ERROR] {str(e)}", xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(syshandle, succeeded=False)

    def MoreLikeThis(self, imdb_id):
        try:
            find_url = f"https://api.themoviedb.org/3/find/{imdb_id}?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}&external_source=imdb_id&language=hu-HU"
            find_res = requests.get(find_url, timeout=10).json()
            
            tmdb_internal_id = None
            m_type = None
            
            if find_res.get('movie_results'):
                tmdb_internal_id = find_res['movie_results'][0]['id']
                m_type = 'movie'
            elif find_res.get('tv_results'):
                tmdb_internal_id = find_res['tv_results'][0]['id']
                m_type = 'tv'
                
            if not tmdb_internal_id:
                self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
                return

            recommend_url = f"https://api.themoviedb.org/3/{m_type}/{tmdb_internal_id}/recommendations?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}&language=hu-HU"
            data = requests.get(recommend_url, timeout=10).json()
            results = data.get('results', [])

        except Exception as e:
            xbmc.log(f"[nCore_TMDB_ERROR] MoreLikeThis API hiba: {str(e)}", xbmc.LOGERROR)
            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
            return
        
        for item in results:
            title = item.get('title') or item.get('name')
            orig_title = item.get('original_title') or item.get('original_name')
            year = (item.get('release_date') or item.get('first_air_date') or '----')[:4]
            rating = item.get('vote_average', 0)
            plot = item.get('overview', 'Nincs leírás.')
            poster_path = item.get('poster_path')
            poster_link = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""

            full_plot_text = f"\n[B]Eredeti cím:[/B] {orig_title} ([COLOR gold]{year}[/COLOR])\n[B]IMDb (TMDb):[/B] {rating:.1f}\n\n{plot}"
            
            url_params = f"get_info_from_tmdb&tmdb_id={item['id']}&media_type={m_type}&poster_link={poster_link}&title={quote_plus(title)}"

            self.addDirectoryItem(
                f"[B]{title} ({year})[/B]",
                url_params,
                poster_link, '', 'DefaultFolder.png', meta={'title': title, 'plot': full_plot_text}
            )

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def extrMovie(self, url, title_1, title_2, torrent_id, imdb_id, imdb_rate, poster_link, clear_logo, feltoltve, seeder, leecher, description):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        response = nc_get(url, cookies=cookies, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')

        if not description:
            description = ''

        if not clear_logo:
             clear_logo = ''

        tmdb = ''
        type_for_tmdb = ''
        trailer_name = ''
        trailer_id = ''

        if imdb_id:
            import requests
            try:
                response_2 = nc_get(f'{k_h_n_o}/movies/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                if response_2:
                    new_desc = response_2.get('overview', '')
                    if new_desc:
                        description = new_desc

                    tmdb_ids = response_2.get('ids', {})
                    tmdb = int(tmdb_ids.get('tmdb', '')) if tmdb_ids.get('tmdb') else ''

                    poster_path = response_2.get('poster')

                    if poster_path:
                        old_poster = poster_link
                        poster_link = f'{a_d}{s_s}{s_g}{poster_path}_m.jpg'

                    type_for_tmdb = response_2.get('type')
                    if type_for_tmdb and type_for_tmdb != 'movie':
                        type_for_tmdb = 'tv'
                    elif not type_for_tmdb:
                        type_for_tmdb = ''

                    if tmdb and type_for_tmdb:
                        import requests
                        cookies_tmdb = {
                            'tmdb.prefs': '%7B%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
                            '__e_inc': '1',
                        }

                        headers_tmdb = {
                            'authority': 'www.themoviedb.org',
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6287.198 Safari/537.36',
                        }

                        try:
                            html_tmdb = nc_get(f'https://www.themoviedb.org/{type_for_tmdb}/{tmdb}', cookies=cookies_tmdb, headers=headers_tmdb)
                            soup_tmdb = BeautifulSoup(html_tmdb.text, 'html.parser')

                            description_tag = soup_tmdb.find('meta', property='og:description')
                            description = description_tag['content'] if description_tag else description
                        except requests.exceptions.RequestException as e:
                            xbmc.log(f'{base_log_info}| extrMovie | TMDB scrape failed: {e}', xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log(f'{base_log_info}| extrMovie | TMDB soup parsing failed: {e}', xbmc.LOGINFO)

            except requests.exceptions.RequestException as e:
                xbmc.log(f'{base_log_info}| extrMovie | Trakt API call failed: {e}', xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f'{base_log_info}| extrMovie | Trakt JSON parsing failed: {e}', xbmc.LOGINFO)

        img_title = ''
        sample_i = ''
        sample_link = ''

        download_link = f'{torrent_id}'

        status_lines = []

        if imdb_id:
            local_rating = self.db.get_trakt_rating(imdb_id, 'movie', 0, 0)
            if local_rating:
                status_lines.append(f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]")          
            db_sync_map = self.db.get_indicators_for_list([imdb_id])
            if imdb_id in db_sync_map:
                db_status = dict(db_sync_map[imdb_id])
                if self.is_trakt_active() and db_status.get('trakt_status'):
                    status_lines.append(str(db_status['trakt_status']).strip())
                if self.is_simkl_active() and db_status.get('simkl_status'):
                    status_lines.append(str(db_status['simkl_status']).strip())
                if self.is_plex_active() and db_status.get('plex_status'):
                    status_lines.append(str(db_status['plex_status']).strip())

        local_time_info = ""
        try:
            with self.db._get_connection() as conn:
                row_pos = conn.execute('''
                    SELECT label, position, duration FROM video_positions 
                    WHERE torrent_id = ? 
                    ORDER BY timestamp DESC LIMIT 1
                ''', (str(torrent_id) if _local_tracking_on() else '',)).fetchone()
                
                if row_pos:
                    r_label = row_pos['label']
                    r_pos = row_pos['position']
                    r_dur = row_pos['duration'] or 0
                    
                    if r_dur > 0:
                        rem_sec = max(0, r_dur - r_pos)
                        percent = int((r_pos / r_dur) * 100)

                        if percent > 89 or rem_sec < 45:
                            local_time_info = "[COLOR lime]Állapot: Megtekintve[/COLOR]"
                        else:
                            m_rem, s_rem = divmod(int(rem_sec), 60)
                            h_rem, m_rem = divmod(m_rem, 60)
                            rem_fmt = f"{h_rem:02d}:{m_rem:02d}:{s_rem:02d}" if h_rem > 0 else f"{m_rem:02d}:{s_rem:02d}"

                            pm, ps = divmod(int(r_pos), 60)
                            ph, pm = divmod(pm, 60)

                            tm, ts = divmod(int(r_dur), 60)
                            th, tm = divmod(tm, 60)

                            pos_fmt = f"{ph:02d}:{pm:02d}:{ps:02d}" if th > 0 else f"{pm:02d}:{ps:02d}"
                            total_fmt = f"{th:02d}:{tm:02d}:{ts:02d}" if th > 0 else f"{tm:02d}:{ts:02d}"

                            local_time_info = f"[COLOR yellow][ {percent}% ]  {pos_fmt} / {total_fmt}  [COLOR orange](-{rem_fmt})[/COLOR][/COLOR]"
                    else:
                        local_time_info = f"[COLOR yellow]Utolsó (helyi) időpont: {r_label}[/COLOR]"
        except: 
            pass

        if local_time_info:
            status_lines.append(local_time_info)

        db_torrent = self.db.get_torrent_details(torrent_id) if _local_tracking_on() else None
        if db_torrent:
            has_url = db_torrent.get('full_url') is not None and db_torrent.get('full_url') != ""
            with self.db._get_connection() as conn:
                has_pos = conn.execute('SELECT 1 FROM video_positions WHERE torrent_id = ? LIMIT 1', (str(torrent_id),)).fetchone() is not None
            if has_url or has_pos:
                status_lines.append("[B][COLOR lime]Ezt a verziót már elindítottad! [*][/COLOR][/B]")

        status_display = "\n".join(status_lines) + "\n\n" if status_lines else ""

        full_description = f"{status_display}{description}"

        try:
            meta_to_save = {
                'torrent_id': str(torrent_id) if 'torrent_id' in locals() else '',
                'imdb_id': str(imdb_id) if 'imdb_id' in locals() else '',
                'tmdb_id': str(tmdb) if 'tmdb' in locals() else '',
                'imdb_rate': str(imdb_rate) if 'imdb_rate' in locals() else '',
                'title_1': title_1 if 'title_1' in locals() else '',
                'title_2': title_2 if 'title_2' in locals() else '',
                'poster_link': poster_link if 'poster_link' in locals() else '',
                'description': description if 'description' in locals() else '',
                'feltoltve': feltoltve if 'feltoltve' in locals() else '',
                'seeder': seeder if 'seeder' in locals() else '',
                'leecher': leecher if 'leecher' in locals() else ''
            }

            if meta_to_save['torrent_id']:
                self.db.save_torrent_metadata(meta_to_save)
                
        except Exception as db_err:
            xbmc.log(f'[nCore_DB] Nemkritikus hiba az extrMovie mentésnél: {str(db_err)}', xbmc.LOGDEBUG)

        t_pct = self.params.get('resume_percent', '')

        url_params = f'single_item_folder&url={quote_plus(str(download_link))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&torrent_id={quote_plus(str(torrent_id))}&imdb_id={quote_plus(str(imdb_id))}&imdb_rate={quote_plus(str(imdb_rate))}&poster_link={quote_plus(str(poster_link))}&clear_logo={quote_plus(str(clear_logo))}&feltoltve={quote_plus(str(feltoltve))}&seeder={quote_plus(str(seeder))}&leecher={quote_plus(str(leecher))}&description={quote_plus(str(description))}&tmdb_id={quote_plus(str(tmdb))}&resume_percent={quote_plus(str(t_pct))}'
        
        if not title_1:
            pick_title = title_2
        else:
            pick_title = title_1

        bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
        torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
        
        context_menu_items = [bookmark_context, torrent_to_seed]

        if self.is_trakt_active() and imdb_id:
            rating_mgr_query = f"open_rating_manager&torrent_id={torrent_id}&imdb_id={imdb_id}&title_1={quote_plus(pick_title)}"
            context_menu_items.insert(0, ("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", rating_mgr_query))       

        if self.is_trakt_active():
            context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series=false"))
        if self.is_simkl_active():
            context_menu_items.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series=false"))
        
        self.addDirectoryItem(f'[B][COLOR lime][Lejátszás][/COLOR] {pick_title}[/B]', url_params, poster_link, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})

        for a_tag in soup.find_all('a', class_='fancy_groups'):
            img_tag = a_tag.find('img')
            if img_tag:
                parent_td = a_tag.find_parent('td')
                if parent_td:
                    em_tag = parent_td.find_next('em')
                    if em_tag:
                        img_title = em_tag.text
                        sample_i = a_tag.get('href', "")
                        sample_i = re.sub(r'\?.*', r'', sample_i)
                        if sample_i:
                            if proxy_needed == 'true':
                                sample_link = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(sample_i, safe='')}"
                            else:
                                sample_link = sample_i
                            self.addDirectoryItem(f'[B]sample kép {img_title}[/B]', '', sample_link, 'DefaultMovies.png', isFolder=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
        
        if imdb_id != '':
            self.addDirectoryItem(f"[B][COLOR lightgreen][I]--[/I] Szereplők (stáblista) [I]--[/I][/COLOR][/B]", f"get_cast_list&imdb_id={imdb_id}&media_type=movie&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultActor.png', isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
            
            self.addDirectoryItem(f"[B][COLOR yellow]Más verziók (imdb: {imdb_id})[/COLOR][/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", poster_link, '', 'DefaultFolder.png', meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})

            self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{pick_title}', "plot": description})
            
            try:
                import requests
                response_1_x = nc_get(f'{ab_t}.{kf_t}/search/id?imdb={imdb_id}&extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()

                if response_1_x and isinstance(response_1_x, list) and len(response_1_x) > 0 and 'ids' in response_1_x[0]:
                    simkl_ids = response_1_x[0].get('ids', {})
                    simkl_id = simkl_ids.get('simkl')
                    if simkl_id:
                        response_2_x = nc_get(f'{a_d}{c_d}{i_d}{simkl_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()

                        if response_2_x and 'trailers' in response_2_x and len(response_2_x['trailers']) > 0:
                            trailer_data = response_2_x['trailers'][0]
                            trailer_name = trailer_data.get('name', '')
                            trailer_id = trailer_data.get('youtube', '')

                            if trailer_id:
                                self.addDirectoryItem(f"[B][COLOR lime][Bemutató][/COLOR] ({trailer_name}):[/B] {pick_title}", f'plugin://plugin.video.youtube/play/?video_id={trailer_id}', poster_link, 'DefaultFolder.png', isFolder=False, isAction=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
            except (IndexError, TypeError, requests.exceptions.RequestException, KeyError) as e:
                xbmc.log(f'{base_log_info}| extrMovie | Trailer fetch failed: {e}', xbmc.LOGINFO)

        if tmdb:
            f_query = f"tmdb_get_collection&tmdb_id={tmdb}"
            self.addDirectoryItem(
                name=f"[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", 
                query=f_query, 
                thumb=poster_link, 
                icon='DefaultVideoPlaylists.png', 
                isFolder=True, 
                meta={"title": f"{pick_title} - Franchise", "plot": description}
            )

        url_params_2 = f'get_file_list&torrent_id={quote_plus(str(torrent_id))}&tmdb_id={quote_plus(str(tmdb))}&imdb_id={quote_plus(str(imdb_id))}&poster_link={quote_plus(str(poster_link))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&description={quote_plus(str(description))}'
        self.addDirectoryItem(f'[B][COLOR orange][FájlLista][/COLOR] (.torrent fájl tartalma)[/B]', url_params_2, poster_link, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
        
        self.endDirectory(user_change_view)

    def extrSeries(self, url, title_1, title_2, torrent_id, imdb_id, imdb_rate, poster_link, clear_logo, c_i, feltoltve, seeder, leecher, description):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        response = nc_get(url, cookies=cookies, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')

        download_link = f'{torrent_id}'

        description = ''
        poster_link = c_i
        tmdb = ''
        type_for_tmdb = ''
        trailer_name = ''
        trailer_id = ''
        clear_logo = ''


        if imdb_id:
            import requests
            try:
                response_2 = nc_get(f'{a_d}{c_d}{i_d}{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()

                if response_2:
                    ids_data = response_2.get('ids', {})
                    tmdb = int(ids_data.get('tmdb', '')) if ids_data.get('tmdb') else ''

                    description = response_2.get('overview', '')

                    poster_path = response_2.get('poster')
                    if poster_path:
                        poster_link = f'{a_d}{s_s}{s_g}{poster_path}_m.jpg'
                    else:
                        poster_link = c_i

                    type_for_tmdb = response_2.get('type')
                    if type_for_tmdb and type_for_tmdb != 'movie':
                        type_for_tmdb = 'tv'
                    elif not type_for_tmdb:
                        type_for_tmdb = ''


                    if tmdb and type_for_tmdb:
                        import requests
                        cookies_tmdb = {
                            'tmdb.prefs': '%7B%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
                            '__e_inc': '1',
                        }

                        headers_tmdb = {
                            'authority': 'www.themoviedb.org',
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6287.198 Safari/537.36',
                        }

                        try:
                            html_tmdb = nc_get(f'https://www.themoviedb.org/{type_for_tmdb}/{tmdb}', cookies=cookies_tmdb, headers=headers_tmdb)
                            soup_tmdb = BeautifulSoup(html_tmdb.text, 'html.parser')

                            description_tag = soup_tmdb.find('meta', property='og:description')
                            description = description_tag['content'] if description_tag else description
                        except requests.exceptions.RequestException as e:
                            xbmc.log(f'{base_log_info}| extrSeries | TMDB scrape failed: {e}', xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log(f'{base_log_info}| extrSeries | TMDB soup parsing failed: {e}', xbmc.LOGINFO)

            except requests.exceptions.RequestException as e:
                xbmc.log(f'{base_log_info}| extrSeries | Trakt API call failed: {e}', xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f'{base_log_info}| extrSeries | Trakt JSON parsing failed: {e}', xbmc.LOGINFO)

        img_title = ''
        sample_i = ''
        sample_link = ''

        status_lines = []
        if imdb_id:
            local_rating = self.db.get_trakt_rating(imdb_id, 'show', 0, 0)
            if local_rating:
                status_lines.append(f"[B][COLOR gold]Értékelésed: {local_rating}/10 ★[/COLOR][/B]")          
            db_sync_map = self.db.get_indicators_for_list([imdb_id])
            if imdb_id in db_sync_map:
                db_status = dict(db_sync_map[imdb_id])
                if self.is_trakt_active() and db_status.get('trakt_status'):
                    status_lines.append(str(db_status['trakt_status']).strip())
                if self.is_simkl_active() and db_status.get('simkl_status'):
                    status_lines.append(str(db_status['simkl_status']).strip())
                if self.is_plex_active() and db_status.get('plex_status'):
                    status_lines.append(str(db_status['plex_status']).strip())

        local_time_info = ""
        try:
            with self.db._get_connection() as conn:
                row_pos = conn.execute('''
                    SELECT file_name, label, position, duration FROM video_positions 
                    WHERE torrent_id = ? 
                    ORDER BY timestamp DESC LIMIT 1
                ''', (str(torrent_id) if _local_tracking_on() else '',)).fetchone()
                
                if row_pos:
                    r_file = row_pos['file_name']
                    r_label = row_pos['label']
                    r_pos = row_pos['position']
                    r_dur = row_pos['duration'] or 0

                    import re
                    f_tag = ""
                    m = re.search(r'[sS](\d{1,2})[eExX](\d{1,2})', r_file)
                    if m:
                        f_tag = f"[B][COLOR white]S{int(m.group(1)):02d}E{int(m.group(2)):02d}[/COLOR][/B] "
                    else:
                        f_tag = f"[COLOR grey]{r_file[:15]}...[/COLOR] "

                    if r_dur > 0:
                        rem_sec = max(0, r_dur - r_pos)
                        percent = int((r_pos / r_dur) * 100)

                        if percent > 89 or rem_sec < 45:
                            local_time_info = f"[COLOR yellow][B]Helyi:[/B][/COLOR] {f_tag}[COLOR lime]Állapot: Megtekintve[/COLOR]"
                        else:
                            m_rem, s_rem = divmod(int(rem_sec), 60)
                            h_rem, m_rem = divmod(m_rem, 60)
                            rem_fmt = f"{h_rem:02d}:{m_rem:02d}:{s_rem:02d}" if h_rem > 0 else f"{m_rem:02d}:{s_rem:02d}"

                            pm, ps = divmod(int(r_pos), 60)
                            ph, pm = divmod(pm, 60)
                            
                            tm, ts = divmod(int(r_dur), 60)
                            th, tm = divmod(tm, 60)

                            pos_fmt = f"{ph:02d}:{pm:02d}:{ps:02d}" if th > 0 else f"{pm:02d}:{ps:02d}"
                            total_fmt = f"{th:02d}:{tm:02d}:{ts:02d}" if th > 0 else f"{tm:02d}:{ts:02d}"
                            
                            local_time_info = f"[COLOR yellow][B]Helyi:[/B][/COLOR] {f_tag}\n[COLOR yellow][ {percent}% ]  {pos_fmt} / {total_fmt}  [COLOR orange](-{rem_fmt})[/COLOR][/COLOR]"
                    else:
                        local_time_info = f"[COLOR yellow][B]Helyi:[/B][/COLOR] {f_tag}[COLOR yellow]Utolsó időpont: {r_label}[/COLOR]"
        except: 
            pass

        if local_time_info:
            status_lines.append(local_time_info)

        db_torrent = self.db.get_torrent_details(torrent_id) if _local_tracking_on() else None
        if db_torrent:
            has_url = db_torrent.get('full_url') is not None and db_torrent.get('full_url') != ""
            with self.db._get_connection() as conn:
                has_pos = conn.execute('SELECT 1 FROM video_positions WHERE torrent_id = ? LIMIT 1', (str(torrent_id),)).fetchone() is not None
            if has_url or has_pos:
                status_lines.append("[B][COLOR lime]Ezt a verziót már elindítottad! [*][/COLOR][/B]")

        status_display = "\n".join(status_lines) + "\n\n" if status_lines else ""
        full_description = f"{status_display}{description}"

        try:
            meta_to_save = {
                'torrent_id': str(torrent_id) if 'torrent_id' in locals() else '',
                'imdb_id': str(imdb_id) if 'imdb_id' in locals() else '',
                'tmdb_id': str(tmdb) if 'tmdb' in locals() else '',
                'imdb_rate': str(imdb_rate) if 'imdb_rate' in locals() else '',
                'title_1': title_1 if 'title_1' in locals() else '',
                'title_2': title_2 if 'title_2' in locals() else '',
                'poster_link': poster_link if 'poster_link' in locals() else '',
                'description': description if 'description' in locals() else '',
                'feltoltve': feltoltve if 'feltoltve' in locals() else '',
                'seeder': seeder if 'seeder' in locals() else '',
                'leecher': leecher if 'leecher' in locals() else ''
            }

            if meta_to_save['torrent_id']:
                self.db.save_torrent_metadata(meta_to_save)
                
        except Exception as db_err:
            xbmc.log(f'[nCore_DB] Nemkritikus hiba az extrSeries mentésnél: {str(db_err)}', xbmc.LOGDEBUG)
        
        t_ep = self.params.get('target_episode', '')
        r_pct = self.params.get('resume_percent', '')
        
        url_params = f'single_item_folder&url={quote_plus(str(download_link))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&torrent_id={quote_plus(str(torrent_id))}&imdb_id={quote_plus(str(imdb_id))}&imdb_rate={quote_plus(str(imdb_rate))}&poster_link={quote_plus(str(poster_link))}&clear_logo={quote_plus(str(clear_logo))}&feltoltve={quote_plus(str(feltoltve))}&seeder={quote_plus(str(seeder))}&leecher={quote_plus(str(leecher))}&description={quote_plus(str(description))}&target_episode={quote_plus(str(t_ep))}'

        if t_ep: url_params += f"&target_episode={t_ep}"
        if r_pct: url_params += f"&resume_percent={r_pct}"
        
        if not title_1:
            pick_title = title_2
        else:
            pick_title = title_1

        add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={title_1}&title_2={title_2}")
        bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
        torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
        context_menu_items = [add_series_watching, bookmark_context, torrent_to_seed]

        if self.is_trakt_active() and imdb_id:
            rating_mgr_query = f"open_rating_manager&torrent_id={torrent_id}&imdb_id={imdb_id}&title_1={quote_plus(pick_title)}"
            context_menu_items.insert(0, ("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", rating_mgr_query))

        if self.is_trakt_active():
            context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series=true"))
        if self.is_simkl_active():
            context_menu_items.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series=true"))

        self.addDirectoryItem(f'[B][COLOR lime][Lejátszás][/COLOR] {pick_title}[/B]', url_params, poster_link, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})

        for a_tag in soup.find_all('a', class_='fancy_groups'):
            img_tag = a_tag.find('img')
            if img_tag:
                parent_td = a_tag.find_parent('td')
                if parent_td:
                    em_tag = parent_td.find_next('em')
                    if em_tag:
                        img_title = em_tag.text
                        sample_i = a_tag.get('href', "")
                        sample_i = re.sub(r'\?.*', r'', sample_i)
                        if sample_i:
                            if proxy_needed == 'true':
                                sample_link = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(sample_i, safe='')}"
                            else:
                                sample_link = sample_i
                            self.addDirectoryItem(f'[B]sample kép {img_title}[/B]', '', sample_link, 'DefaultMovies.png', isFolder=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})

        if imdb_id != '':
            self.addDirectoryItem(f"[B][COLOR lightgreen][I]--[/I] Szereplők (stáblista) [I]--[/I][/COLOR][/B]", f"get_cast_list&imdb_id={imdb_id}&media_type=tv&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultActor.png', isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
            
            self.addDirectoryItem(f"[B][COLOR yellow]Más verziók (imdb: {imdb_id})[/COLOR][/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", poster_link, '', 'DefaultFolder.png', meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
            
            self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})

            try:
                import requests
                response_1_x = nc_get(f'{ab_t}.{kf_t}/search/id?imdb={imdb_id}&extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()

                if response_1_x and isinstance(response_1_x, list) and len(response_1_x) > 0 and 'ids' in response_1_x[0]:
                    simkl_ids = response_1_x[0].get('ids', {})
                    simkl_id = simkl_ids.get('simkl')
                    if simkl_id:
                        response_2_x = nc_get(f'{a_d}{c_d}{i_d}{simkl_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()

                        if response_2_x and 'trailers' in response_2_x and len(response_2_x['trailers']) > 0:
                             trailer_data = response_2_x['trailers'][0]
                             trailer_name = trailer_data.get('name', '')
                             trailer_id = trailer_data.get('youtube', '')

                             if trailer_id:
                                 self.addDirectoryItem(f"[B][COLOR lime][Bemutató][/COLOR] ({trailer_name}):[/B] {pick_title}", f'plugin://plugin.video.youtube/play/?video_id={trailer_id}', poster_link, 'DefaultFolder.png', isFolder=False, isAction=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})
            except (IndexError, TypeError, requests.exceptions.RequestException, KeyError) as e:
                xbmc.log(f'{base_log_info}| extrSeries | Trailer fetch failed: {e}', xbmc.LOGINFO)

        url_params_2 = f'get_file_list&torrent_id={quote_plus(str(torrent_id))}&tmdb_id={quote_plus(str(tmdb))}&imdb_id={quote_plus(str(imdb_id))}&poster_link={quote_plus(str(poster_link))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&description={quote_plus(str(description))}'
        self.addDirectoryItem(f'[B][COLOR orange][FájlLista][/COLOR] (.torrent fájl tartalma)[/B]', url_params_2, poster_link, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{full_description}'})

        self.endDirectory(user_change_view)



    def extrZene(self, url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher, description):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        response = nc_get(url, cookies=cookies, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')

        download_link = f'{torrent_id}'

        description = ''
        img_title = ''
        sample_i = ''
        sample_link = ''

        url_params = f'single_item_folder&url={quote_plus(str(download_link))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&torrent_id={quote_plus(str(torrent_id))}&c_i={quote_plus(str(c_i))}&feltoltve={quote_plus(str(feltoltve))}&seeder={quote_plus(str(seeder))}&leecher={quote_plus(str(leecher))}&description={quote_plus(str(description))}&is_music=true'

        if not title_1:
            pick_title = title_2
        else:
            pick_title = title_1

        bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
        torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
        context_menu_items = [bookmark_context, torrent_to_seed]

        self.addDirectoryItem(f'[B][COLOR lime][Lejátszás][/COLOR] {pick_title}[/B]', url_params, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})

        for a_tag in soup.find_all('a', class_='fancy_groups'):
            img_tag = a_tag.find('img')
            if img_tag:
                parent_td = a_tag.find_parent('td')
                if parent_td:
                    em_tag = parent_td.find_next('em')
                    if em_tag:
                        img_title = em_tag.text
                        sample_i = a_tag.get('href', "")
                        sample_i = re.sub(r'\?.*', r'', sample_i)
                        if sample_i:
                            if proxy_needed == 'true':
                                sample_link = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(sample_i, safe='')}"
                            else:
                                sample_link = sample_i
                            self.addDirectoryItem(f'[B]sample kép {img_title}[/B]', '', sample_link, 'DefaultMovies.png', isFolder=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})

        url_params_2 = f'get_file_list&torrent_id={quote_plus(str(torrent_id))}&poster_link={quote_plus(str(c_i))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&description={quote_plus(str(description))}&is_music=true'
        self.addDirectoryItem(f'[B][COLOR orange][FájlLista][/COLOR] (.torrent fájl tartalma)[/B]', url_params_2, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})
        
        self.endDirectory(user_change_view)

    def extrXXX(self, url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher, description):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        response = nc_get(url, cookies=cookies, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')

        download_link = f'{torrent_id}'

        description = ''
        img_title = ''
        sample_i = ''
        sample_link = ''
        image_link = ''
        thumb_link = ''

        url_params = f'single_item_folder&url={quote_plus(str(download_link))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&torrent_id={quote_plus(str(torrent_id))}&c_i={quote_plus(str(c_i))}&feltoltve={quote_plus(str(feltoltve))}&seeder={quote_plus(str(seeder))}&leecher={quote_plus(str(leecher))}&description={quote_plus(str(description))}&is_xxx=true'

        if not title_1:
            pick_title = title_2
        else:
            pick_title = title_1

        bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
        torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
        context_menu_items = [bookmark_context, torrent_to_seed]

        self.addDirectoryItem(f'[B][COLOR lime][Lejátszás][/COLOR] {pick_title}[/B]', url_params, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})

        for a_tag in soup.find_all('a', class_='fancy_groups'):
            img_tag = a_tag.find('img')
            if img_tag:
                parent_td = a_tag.find_parent('td')
                if parent_td:
                    em_tag = parent_td.find_next('em')
                    if em_tag:
                        img_title = em_tag.text
                        sample_i = a_tag.get('href', "")
                        sample_i = re.sub(r'\?.*', r'', sample_i)
                        if sample_i:
                            if proxy_needed == 'true':
                                sample_link = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(sample_i, safe='')}"
                            else:
                                sample_link = sample_i
                            self.addDirectoryItem(f'[B]sample kép {img_title}[/B]', '', sample_link, 'DefaultMovies.png', isFolder=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})

        quote_div = soup.find('div', class_='bb-quote')
        if quote_div:
            anchor_tag = quote_div.find('a', class_='bb-url')
            if anchor_tag:
                image_link = anchor_tag.get('href', "")
                if image_link:
                    thumb_link_match = re.findall(r'\?(http.*)', str(image_link))
                    if thumb_link_match:
                        thumb_link = thumb_link_match[0].strip()
                        self.addDirectoryItem(f'[B]thumbnail[/B]', '', thumb_link, 'DefaultMovies.png', isFolder=False, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})

        url_params_2 = f'get_file_list&torrent_id={quote_plus(str(torrent_id))}&poster_link={quote_plus(str(c_i))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title_2))}&description={quote_plus(str(description))}&is_xxx=true'
        self.addDirectoryItem(f'[B][COLOR orange][FájlLista][/COLOR] (.torrent fájl tartalma)[/B]', url_params_2, c_i, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": pick_title, "plot": f'\n\n[B]{pick_title}[/B]\n\n{description}'})
        
        self.endDirectory(user_change_view)


    def getExtendSearches(self):
        self.addDirectoryItem(f"[B][COLOR FF1cd496]Keresési előzmények[/COLOR][/B]{ncore_coloring}", f"already_searched", '', 'DefaultFolder.png')

        beepitett_keresesek = (f'\nElőre meghatározott keresések pl.')
        beepitett_keresesek += f'\n[COLOR lime]-[/COLOR] Netflix'
        beepitett_keresesek += f'\n[COLOR lime]-[/COLOR] RTL+'
        beepitett_keresesek += f'\n[COLOR lime]-[/COLOR] BBC Iplayer'
        beepitett_keresesek += f'\n[COLOR lime]-[/COLOR] Legtöbbet seedelt ...stb'
        self.addDirectoryItem(f"[B][COLOR yellow]Beépített keresések[/COLOR][/B]{ncore_coloring}", "listStaticSearches", "", "DefaultFolder.png", meta={'plot': f'{beepitett_keresesek}'})

        self.addDirectoryItem("[B]Kereső [COLOR lime]HU[/COLOR][/B]: Sorozat & Film", f"newsearch&url={quote_plus(f'{base_url}{movie_ser_hu_kereso}')}", '', 'DefaultFolder.png')
        self.addDirectoryItem("[B]Kereső [COLOR lime]HU[/COLOR][/B]: imdb_id", f"newsearch_2&url={quote_plus(f'{base_url}{imdb_hu_kereso}')}", '', 'DefaultFolder.png')
        self.addDirectoryItem("[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B]: Sorozat & Film", f"newsearch&url={quote_plus(f'{base_url}{movie_ser_en_kereso}')}", '', 'DefaultFolder.png')
        self.addDirectoryItem("[B]Kereső [COLOR FFF56C00]EN[/COLOR][/B]: imdb_id", f"newsearch_2&url={quote_plus(f'{base_url}{imdb_en_kereso}')}", '', 'DefaultFolder.png')

        bovitett_kereso = (f'\nItt lehet keresni:')     
        bovitett_kereso += f'\n[COLOR lime]-[/COLOR] leírásban'
        bovitett_kereso += f'\n[COLOR lime]-[/COLOR] kategóriákban'
        bovitett_kereso += f'\n[COLOR lime]-[/COLOR] feltöltőkre ...stb'
        self.addDirectoryItem(f"[B][COLOR gold]Bővített Kereső[/COLOR][/B]{ncore_coloring}", f"search_window", '', 'DefaultFolder.png', meta={'plot': f'{bovitett_kereso}'})
        
        self.addDirectoryItem(f"[B][COLOR orange]Keresés színészre[/COLOR][/B]{ncore_coloring}", f"search_name&url=https://v3.sg.media-imdb.com/suggestion/x/", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B][COLOR FF98fc03]Keresés IMDb oldalon keresztül[/COLOR][/B]{ncore_coloring}", f"imdb_search&url=https://api.tiffara.com/search/titles?query=", '', 'DefaultFolder.png')
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def ImdbSearch(self, url):
        import requests
        import json
        from urllib.parse import quote_plus
        
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'hu',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        }
        
        try:
            response = nc_get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            if 'titles' not in data or not data['titles']:
                xbmcgui.Dialog().ok("Keresés", "Nincs találat a keresésre!")
                return

            imdb_ids_on_page = []
            items_to_display = []
            
            for item in data['titles']:
                media_type = item.get('type', '')

                if media_type not in ['movie', 'tvSeries']:
                    continue
                
                imdb_id = item.get('id', '')
                if imdb_id:
                    imdb_ids_on_page.append(imdb_id)
                    items_to_display.append(item)

            db_sync_data = self.db.get_indicators_for_list(imdb_ids_on_page) if imdb_ids_on_page else {}
            
            for item in items_to_display:
                imdb_id = item.get('id', '')
                media_type = item.get('type', '')
                title = item.get('primaryTitle', 'Ismeretlen cím')
                original_title = item.get('originalTitle', '')
                year = item.get('startYear', '')
                
                rating = item.get('rating', {})
                aggregate_rating = rating.get('aggregateRating', 'N/A')
                vote_count = rating.get('voteCount', 0)
                
                primary_image = item.get('primaryImage', {})
                poster_url = primary_image.get('url', '')

                indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])

                if media_type == 'movie':
                    m_type_text, t_color = "      FILM     ", "lightgreen"
                else:
                    m_type_text, t_color = "SOROZAT", "orange"
                
                m_label = f"|{m_type_text:^9}|"

                year_display = f"({year})" if year else ""

                if original_title and original_title != title:
                    display_title = f"{original_title} ({title})"
                else:
                    display_title = title

                if aggregate_rating != 'N/A':
                    rating_display = f"[COLOR yellow]★ {aggregate_rating}[/COLOR]"
                else:
                    rating_display = ""

                display_label = f"[COLOR {t_color}]{m_label}[/COLOR] {indicator}{display_title} [COLOR gold]{year_display}[/COLOR] - {rating_display}"

                plot_info = []
                if plot_status_line:
                    plot_info.append(plot_status_line)
                    plot_info.append("")
                
                if original_title:
                    plot_info.append(f"Eredeti cím: {original_title}")
                if title and title != original_title:
                    plot_info.append(f"Cím: {title}")
                if year:
                    plot_info.append(f"Év: {year}")
                if media_type:
                    plot_info.append(f"Típus: {'Film' if media_type == 'movie' else 'Sorozat'}")
                if aggregate_rating != 'N/A':
                    plot_info.append(f"Értékelés: {aggregate_rating} ★ ({vote_count} szavazat)")
                if imdb_id:
                    plot_info.append(f"IMDb ID: {imdb_id}")
                
                plot_text = "\n".join(plot_info)
                
                metadata = {
                    'title': display_title,
                    'plot': plot_text,
                    'year': str(year) if year else '',
                    'genre': 'Film' if media_type == 'movie' else 'Sorozat'
                }
                
                url_params = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}"
                
                self.addDirectoryItem(
                    name=f"[B]{display_label}[/B]",
                    query=url_params,
                    thumb=poster_url,
                    isFolder=True,
                    meta=metadata
                )

            if not items_to_display:
                xbmcgui.Dialog().ok("Keresés", "Nincs elérhető film vagy sorozat a keresésre!")
                return
            
            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
            
        except Exception as e:
            xbmc.log(f"IMDB Search Error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Hiba", f"Nem sikerült a keresés: {str(e)}")

    def doSearchImdb_Name(self, url):
        search_text = self.getImdbSearchTextName()
        if not search_text.strip(): return
        full_link = f"{url}{search_text}"
        self.ImdbSearch(full_link)
    
    def getImdbSearchTextName(self, preloaded_text=None):
        if preloaded_text:
            return preloaded_text.strip()
        keyb = xbmc.Keyboard('', 'Add meg a film vagy sorozat címét')
        keyb.doModal()
        if keyb.isConfirmed():
            text = keyb.getText().strip()
            return text
        return ''

    def getAjanloCategs(self, url):
        self.addDirectoryItem(f"[B]Filmek | Sorozatok ([COLOR orange]themoviedb.org[/COLOR])[/B]{ncore_coloring}", f"get_recommend_both", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]kategóriák | Dátum választó ([COLOR orange]JustWatch[/COLOR])[/B]{ncore_coloring}", f"get_justwatch_categories", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Gyűjtemények | Listák | Franchiseok ([COLOR orange]thetvdb[/COLOR])[/B]{ncore_coloring}", f"get_lists&url=https://www.thetvdb.com/lists", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Simkl Felfedezés ([COLOR orange]Simkl[/COLOR])[/B]{ncore_coloring}", 
                              "simkl_discovery_menu", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Közösségi válogatások (Top Listák) ([COLOR orange]Trakt[/COLOR])[/B]{ncore_coloring}", 
                              "trakt_trending_lists&page=1", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]TMDb Felfedezés ([COLOR orange]TMDb api[/COLOR])[/B]{ncore_coloring}", 
                              "tmdb_discovery_menu", '', 'DefaultFolder.png')
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimkldiscoveryMenu(self):
        self.addDirectoryItem(f"[B]Napi népszerű Streaming szolgáltatók / műfajok ([COLOR orange]Simkl[/COLOR])[/B]{ncore_coloring}", 
                              "simkl_trending_menu&timeframe=today", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Heti népszerű Streaming szolgáltatók / műfajok ([COLOR orange]Simkl[/COLOR])[/B]{ncore_coloring}", 
                              "simkl_trending_menu&timeframe=week", '', 'DefaultFolder.png')

        self.addDirectoryItem(f"[B]Havi népszerű Streaming szolgáltatók / műfajok ([COLOR orange]Simkl[/COLOR])[/B]{ncore_coloring}", 
                              "simkl_trending_menu&timeframe=month", '', 'DefaultFolder.png')

        plot_mixed = "Az 500 legnépszerűbb tartalom (Filmek, Sorozatok és Animék vegyesen) az elmúlt 30 napból."
        self.addDirectoryItem(f"[B]Hónap Top 500 - Vegyes lista ([COLOR orange]Simkl[/COLOR])[/B]{ncore_coloring}", 
                              "simkl_mixed_items&timeframe=month&page=1", '', 'DefaultFolder.png', meta={'plot': plot_mixed})

        self.addDirectoryItem(f"[B]Digitális megjelenések ([COLOR orange]Simkl[/COLOR])[/B]{ncore_coloring}", 
                              "simkl_streaming_networks&media_type=dvd", '', 'DefaultFolder.png')
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)



    def TMDBDiscoveryMenu(self):
        import datetime
        from urllib.parse import quote_plus
        
        today = datetime.datetime.now().strftime('%Y-%m-%d')
        two_weeks_ago = (datetime.datetime.now() - datetime.timedelta(days=14)).strftime('%Y-%m-%d')

        self.addDirectoryItem("[B][COLOR orange]Sorozatok: MA adásba kerülő epizódok[/COLOR][/B]", "tmdb_list&endpoint=tv/airing_today", '', 'DefaultFolder.png')

        self.addDirectoryItem("[B]Sorozatok: Jelenleg futó évadok (Heti friss)[/B]", "tmdb_list&endpoint=tv/on_the_air", '', 'DefaultFolder.png')

        new_series_endpoint = f"discover/tv?sort_by=first_air_date.desc&first_air_date.lte={today}&first_air_date.gte={two_weeks_ago}&with_original_language=en|hu"
        self.addDirectoryItem("[B]Sorozatok: Legújabb premier sorozatok[/B]", f"tmdb_list&endpoint={quote_plus(new_series_endpoint)}", '', 'DefaultFolder.png')

        self.addDirectoryItem("[B][COLOR yellow]Streaming szolgáltatók ÚJDONSÁGAI (Sorozatok)[/COLOR][/B]", "tmdb_streaming_news_menu", '', 'DefaultFolder.png')

        self.addDirectoryItem("[B]Globális Trendek (Heti vegyes)[/B]", "tmdb_list&endpoint=trending/all/week", '', 'DefaultFolder.png')
        self.addDirectoryItem("[B]Mozis és Digitális Újdonságok[/B]", "tmdb_list&endpoint=movie/now_playing", '', 'DefaultFolder.png')
        self.addDirectoryItem("[B]Népszerű Sorozatok[/B]", "tmdb_list&endpoint=tv/popular", '', 'DefaultFolder.png')

        plot_themes = "Válogass konkrét témák és hangulatok szerint: Zombik, Időutazás, Igaz történetek, Űrutazás és még sok más."
        self.addDirectoryItem("[B]Böngészés témák szerint[/B]", "tmdb_themes_menu", '', 'DefaultFolder.png', meta={'plot': plot_themes})
        self.addDirectoryItem("[B][COLOR yellow]Streaming szolgáltatók kínálata[/COLOR][/B]", "tmdb_streaming_menu", '', 'DefaultFolder.png')
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TMDBThemesMenu(self):
        themes = [
            ("Akció és Bűnügyi", "Bosszúállás (Revenge)", 9717),
            ("Akció és Bűnügyi", "Kémek és Ügynökök (Spy)", 470),

            ("Sci-Fi és Világvége", "Mesterséges Intelligencia", 310),
            ("Sci-Fi és Világvége", "Űrutazás", 3801),
            ("Sci-Fi és Világvége", "Cyberpunk", 12190),
            ("Sci-Fi és Világvége", "Idegen invázió (Alien)", 14909),

            ("Horror és Misztikum", "Zombis filmek", 12377),
            ("Horror és Misztikum", "Vámpírok", 3133),
            ("Horror és Misztikum", "Slasher (Maszkos gyilkosok)", 12339),
            ("Horror és Misztikum", "Szellemjárás / Kísértetház", 10224),

            ("Dráma és Valóság", "Igaz történet alapján", 9672),
            ("Dráma és Valóság", "Életrajzi filmek", 5565),
            ("Dráma és Valóság", "Túlélés (Survival)", 10349),
            
            ("Disney+", "Disney Világa", 180547),
        ]
        
        for cats, name, k_id in themes:
            endpoint = f"discover/movie?with_keywords={k_id}&sort_by=popularity.desc"

            self.addDirectoryItem(
                name=f"[B]{name}[/B]", 
                query=f"tmdb_list&endpoint={quote_plus(endpoint)}", 
                thumb='', 
                isFolder=True, 
                meta={"plot": f"[COLOR gold]{cats}[/COLOR]"}
            )
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def TMDBGetCollectionContext(self):
        tmdb_id = self.params.get('tmdb_id')
        imdb_id = self.params.get('imdb_id')
        torrent_id = self.params.get('torrent_id')

        if (not tmdb_id or tmdb_id == 'None' or tmdb_id == '') and imdb_id:
            import requests
            try:
                api_url = f'{k_h_n_o}/movies/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}'
                res = requests.get(api_url, timeout=10).json()
                if res:
                    tmdb_ids = res.get('ids', {})
                    tmdb_id = tmdb_ids.get('tmdb')

                    if tmdb_id and torrent_id:
                        self.db.save_torrent_metadata({'torrent_id': str(torrent_id), 'tmdb_id': str(tmdb_id)})
                        # xbmc.log(f"[nCore_SQL] Régi előzmény frissítve TMDB ID-val: {tmdb_id}", xbmc.LOGINFO)
            except: 
                pass

        if tmdb_id:
            plugin_next_action = f"plugin://plugin.video.nCore_TV/?action=tmdb_get_collection&tmdb_id={tmdb_id}"
            xbmc.executebuiltin(f'Container.Update({plugin_next_action})')
        else:
            xbmcgui.Dialog().notification("TMDB", "Nem sikerült TMDB azonosítót rendelni a filmhez.", 3000)

    def TMDBGetCollection(self):
        import json, requests
        from urllib.parse import quote_plus

        tmdb_id = self.params.get('tmdb_id')
        imdb_id = self.params.get('imdb_id')
        torrent_id = self.params.get('torrent_id')
        collection_id = self.params.get('collection_id')
        c_name = self.params.get('collection_name')

        if (not tmdb_id or str(tmdb_id).lower() in ['none', '']) and imdb_id:
            try:
                api_url = f'{k_h_n_o}/movies/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}'
                res = requests.get(api_url, timeout=10).json()
                if res:
                    tmdb_ids = res.get('ids', {})
                    tmdb_id = tmdb_ids.get('tmdb')

                    if tmdb_id and torrent_id:
                        self.db.save_torrent_metadata({'torrent_id': str(torrent_id), 'tmdb_id': str(tmdb_id)})
                        # xbmc.log(f"[nCore_TMDB] Automata adatbázis javítás: IMDb {imdb_id} -> TMDB {tmdb_id}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[nCore_TMDB] Resolver hiba: {e}", xbmc.LOGERROR)

        if not collection_id and tmdb_id:
            url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}&language=hu-HU"
            try:
                r = requests.get(url, timeout=10)
                if r.status_code == 200:
                    data = r.json()
                    collection = data.get('belongs_to_collection')
                    if collection:
                        collection_id = collection.get('id')
                        c_name = collection.get('name')
                    else:
                        xbmcgui.Dialog().notification("TMDB Franchise", "Ez a film nem része egy gyűjteménynek sem.", 3000)
                        return
                else:
                    return
            except: 
                return

        if not collection_id: 
            return

        if not c_name: c_name = "Gyűjtemény"
        c_url = f"https://api.themoviedb.org/3/collection/{collection_id}?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}&language=hu-HU"
        
        try:
            c_resp = requests.get(c_url, timeout=10)
            if c_resp.status_code != 200: return
            
            parts = c_resp.json().get('parts', [])
            parts.sort(key=lambda x: x.get('release_date', '9999-99-99') or '9999-99-99')
            total_parts = len(parts)

            p_dialog = xbmcgui.DialogProgress()
            p_dialog.create("nCore TV", f"Gyűjtemény elemzése: [B]{c_name}[/B]")
            
            imdb_ids_to_query = []
            enriched_parts = []

            for idx, m in enumerate(parts):
                if p_dialog.iscanceled(): break
                m_id, m_title = m.get('id'), m.get('title')
                percent = int((idx / total_parts) * 100)
                p_dialog.update(percent, f"Adatok lekérése ({idx+1}/{total_parts}):[CR][B]{m_title}[/B]")

                ext_url = f"https://api.themoviedb.org/3/movie/{m_id}/external_ids?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}"
                try:
                    ext_data = requests.get(ext_url, timeout=5).json()
                    m_imdb = ext_data.get('imdb_id')
                    if m_imdb:
                        m['imdb_id'] = m_imdb
                        imdb_ids_to_query.append(m_imdb)
                except: m['imdb_id'] = None
                enriched_parts.append(m)

            p_dialog.close()

            db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)

            for m in enriched_parts:
                m_imdb = m.get('imdb_id', '')
                title = m.get('title')

                indicator, plot_status_line, is_played = self._build_indicators(m_imdb, None, db_sync_data, [])

                year = m.get('release_date', '').split('-')[0] if m.get('release_date') else ''
                year_display = f"({year})" if year else ""
                poster = f"https://image.tmdb.org/t/p/w500{m.get('poster_path')}" if m.get('poster_path') else 'DefaultVideo.png'
                rating = f"{m.get('vote_average', 0):.1f}"
                
                m_label = "|      FILM     |"
                display_indicator = f"{indicator} " if indicator else "- "
                display_label = f"[COLOR lightgreen]{m_label}[/COLOR] {display_indicator}{title} [COLOR gold]{year_display}[/COLOR] - [COLOR yellow]★ {rating}[/COLOR]"

                self.addDirectoryItem(
                    name=f"[B]{display_label}[/B]", 
                    query=f"tmdb_to_ncore&tmdb_id={m.get('id')}&media_type=movie", 
                    thumb=poster, 
                    isFolder=True, 
                    meta={"title": title, "plot": f"{plot_status_line}\n\n{m.get('overview', '')}"}
                )

            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

        except Exception as e:
            if 'p_dialog' in locals(): p_dialog.close()
            xbmc.log(f"TMDB Collection Error: {e}", xbmc.LOGERROR)

    def TMDBStreamingNewsMenu(self):
        providers = [
            ("Netflix", 8, "US"),
            ("HBO Max / Max", 1899, "US"),
            ("Disney+", 337, "US"),
            ("Amazon Prime Video", 9, "US"),
            ("Apple TV+", 350, "US"),
            ("SkyShowtime", 1773, "HU"),

            ("Hulu", 15, "US"),
            ("Peacock", 386, "US"),
            ("Paramount+", 531, "US"),
            ("MGM+", 34, "US"),
            ("Starz", 43, "US"),

            ("Crunchyroll", 283, "US"),
            ("Shudder", 99, "US"),
            ("BritBox", 151, "US"),

            ("Apple TV (iTunes)", 2, "US"),
            ("Google Play Movies", 3, "US"),
            ("YouTube Premium", 192, "US"),
            ("Vudu / Fandango", 7, "US"),
            ("Microsoft Store", 68, "US"),
            ("Rakuten TV", 35, "HU")
        ]
        
        for name, p_id, region in providers:
            url_params = f"tmdb_streaming_news_select&provider_id={p_id}&provider_name={quote_plus(name)}&region={region}"
            self.addDirectoryItem(f"[B]{name}[/B]", url_params, '', 'DefaultFolder.png')
        
        self.endDirectory(user_change_view)

    def TMDBStreamingNewsSelect(self):
        p_id = self.params.get('provider_id')
        p_name = self.params.get('provider_name')
        region = self.params.get('region', 'US')
        
        import datetime
        today = datetime.datetime.now().strftime('%Y-%m-%d')

        three_months_ago = (datetime.datetime.now() - datetime.timedelta(days=90)).strftime('%Y-%m-%d')
        six_months_ago = (datetime.datetime.now() - datetime.timedelta(days=180)).strftime('%Y-%m-%d')

        episodes_endpoint = f"discover/tv?with_watch_providers={p_id}&watch_region={region}&air_date.gte={three_months_ago}&air_date.lte={today}&sort_by=popularity.desc"
        self.addDirectoryItem(
            f"[B]{p_name} - [COLOR orange]Friss epizódok és évadok[/COLOR][/B]", 
            f"tmdb_list&endpoint={quote_plus(episodes_endpoint)}", 
            '', 'DefaultFolder.png',
            meta={"plot": "Olyan sorozatok, amiknek az elmúlt 3 hónapban jelent meg új része (legyen az új évad vagy folytatás)."}
        )

        new_series_endpoint = f"discover/tv?with_watch_providers={p_id}&watch_region={region}&first_air_date.gte={six_months_ago}&first_air_date.lte={today}&sort_by=popularity.desc"
        self.addDirectoryItem(
            f"[B]{p_name} - [COLOR yellow]Vadonatúj sorozat premierek[/COLOR][/B]", 
            f"tmdb_list&endpoint={quote_plus(new_series_endpoint)}", 
            '', 'DefaultFolder.png',
            meta={"plot": "Olyan teljesen új sorozatok, amiknek az első évada az elmúlt fél évben indult el."}
        )

        movie_endpoint = f"discover/movie?with_watch_providers={p_id}&watch_region={region}&primary_release_date.gte={three_months_ago}&primary_release_date.lte={today}&sort_by=popularity.desc"
        self.addDirectoryItem(
            f"[B]{p_name} - [COLOR lightgreen]Legfrissebb filmek[/COLOR][/B]", 
            f"tmdb_list&endpoint={quote_plus(movie_endpoint)}", 
            '', 'DefaultFolder.png'
        )
        
        self.endDirectory(user_change_view)

    def TMDBStreamingMenu(self):
        providers = [
            ("Netflix", 8, "US"),
            ("HBO Max / Max", 1899, "US"),
            ("Disney+", 337, "US"),
            ("Amazon Prime Video", 9, "US"),
            ("Apple TV+", 350, "US"),
            ("SkyShowtime", 1773, "HU"),

            ("Hulu", 15, "US"),
            ("Peacock", 386, "US"),
            ("Paramount+", 531, "US"),
            ("MGM+", 34, "US"),
            ("Starz", 43, "US"),

            ("Crunchyroll", 283, "US"),
            ("Shudder", 99, "US"),
            ("BritBox", 151, "US"),

            ("Apple TV (iTunes)", 2, "US"),
            ("Google Play Movies", 3, "US"),
            ("YouTube Premium", 192, "US"),
            ("Vudu / Fandango", 7, "US"),
            ("Microsoft Store", 68, "US"),
            ("Rakuten TV", 35, "HU")
        ]
        for name, p_id, region in providers:
            url_params = f"tmdb_streaming_type&provider_id={p_id}&provider_name={quote_plus(name)}&region={region}"
            self.addDirectoryItem(f"[B]{name}[/B]", url_params, '', 'DefaultFolder.png')
        
        self.endDirectory(user_change_view)

    def TMDBStreamingTypeSelect(self):
        p_id = self.params.get('provider_id')
        p_name = self.params.get('provider_name')
        region = self.params.get('region', 'US')

        movie_endpoint = f"discover/movie?with_watch_providers={p_id}&watch_region={region}&sort_by=popularity.desc"
        self.addDirectoryItem(
            f"[B]{p_name}[/B] - [COLOR lightgreen]Filmek[/COLOR]", 
            f"tmdb_list&endpoint={quote_plus(movie_endpoint)}", 
            '', 'DefaultFolder.png'
        )

        tv_endpoint = f"discover/tv?with_watch_providers={p_id}&watch_region={region}&sort_by=popularity.desc"
        self.addDirectoryItem(
            f"[B]{p_name}[/B] - [COLOR orange]Sorozatok[/COLOR]", 
            f"tmdb_list&endpoint={quote_plus(tv_endpoint)}", 
            '', 'DefaultFolder.png'
        )
        
        self.endDirectory(user_change_view)

    def TMDBList(self):
        endpoint = self.params.get('endpoint')
        page = int(self.params.get('page', 1))

        sep = "&" if "?" in endpoint else "?"
        url = f"https://api.themoviedb.org/3/{endpoint}{sep}api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}&language=hu-HU&page={page}"

        try:
            r = requests.get(url, timeout=15)
            #xbmc.log(f"Status Code: {r.status_code}", xbmc.LOGINFO)
            
            if r.status_code == 200:
                response = r.json()
                results = response.get('results', [])

                for item in results:
                    m_type = item.get('media_type')
                    if not m_type:
                        m_type = 'tv' if 'tv' in endpoint or 'discover/tv' in endpoint else 'movie'
                    
                    tmdb_id = item.get('id')
                    title = item.get('title') or item.get('name') or "Ismeretlen"

                    date_str = item.get('release_date') or item.get('first_air_date', '')
                    item_year = date_str.split('-')[0] if '-' in date_str else ''
                    year_display = f"({item_year})" if item_year else ""

                    if m_type == 'movie':
                        m_type_text, t_color = "      FILM     ", "lightgreen"
                    else:
                        m_type_text, t_color = "SOROZAT", "orange"
                    
                    m_label = f"|{m_type_text:^9}|"

                    poster_path = item.get('poster_path')
                    poster = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else 'DefaultVideo.png'
                    
                    url_params = f"tmdb_to_ncore&tmdb_id={tmdb_id}&media_type={m_type}"

                    context_menu_items = []
                    if m_type == 'movie':
                        context_menu_items.append(
                            ("[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", 
                             f"tmdb_get_collection_context&tmdb_id={tmdb_id}")
                        )

                    rating = f"{item.get('vote_average', 0):.1f}"

                    display_label = f"[COLOR {t_color}]{m_label}[/COLOR] {title} [COLOR gold]{year_display}[/COLOR] - [COLOR yellow]★ {rating}[/COLOR]"

                    self.addDirectoryItem(
                        name=f"[B]{display_label}[/B]", 
                        query=url_params, 
                        thumb=poster, 
                        context=context_menu_items,
                        isFolder=True,
                        meta={
                            "title": title, 
                            "plot": item.get('overview', 'Nincs leírás.')
                        }
                    )

                if page < response.get('total_pages', 1):
                    u_next = f"tmdb_list&endpoint={quote_plus(endpoint)}&page={page + 1}"
                    self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({page + 1}) >>>[/COLOR][/B]", u_next, '', 'DefaultFolder.png')

        except Exception as e:
            xbmc.log(f"TMDBList Kritikus Hiba: {e}", xbmc.LOGERROR)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)



    def SimklWeeklyDiscoveryMenu(self):
        self.addDirectoryItem("[B]Filmek[/B] (Heti népszerű műfajok)", "simkl_streaming_networks&media_type=movies", '', simkl_notif_icon)
        self.addDirectoryItem("[B]Sorozatok[/B] (Heti népszerű szolgáltatók)", "simkl_streaming_networks&media_type=tv", '', simkl_notif_icon)
        self.endDirectory(user_change_view)

    def SimklStreamingNetworks(self):
        media_type = self.params.get('media_type', 'tv')
        timeframe = self.params.get('timeframe', 'week')
        
        from resources.lib.indexers.simkl_tracks import SimklInterface
        data = SimklInterface.get_simkl_static_trending(media_type, timeframe, 500)
        
        if not data:
            self.endDirectory(user_change_view)
            return

        new_posters = {item['ids']['imdb']: item['poster'] for item in data if item.get('ids', {}).get('imdb') and item.get('poster')}
        if new_posters:
            import threading
            t = threading.Thread(target=self.db.update_bulk_sync_status, args=(new_posters, 'simkl_poster'))
            t.daemon = True 
            t.start()

        categories = {}
        for item in data:
            if media_type == 'tv':
                key = item.get('network')
            else:
                genre_list = item.get('genres', [])
                key = genre_list[0] if genre_list else "Egyéb"
            if key:
                categories[key] = categories.get(key, 0) + 1
        
        sorted_categories = sorted(categories.items(), key=lambda x: x[1], reverse=True)
        
        for name, count in sorted_categories:
            url_params = "simkl_streaming_items&media_type={}&filter_value={}&timeframe={}&page=1".format(
                media_type, quote_plus(name), timeframe
            )
            label = f"[B]{name}[/B] ({count})"
            self.addDirectoryItem(label, url_params, '', simkl_notif_icon)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklStreamingItems(self):
        media_type = self.params.get('media_type')
        target_value = self.params.get('filter_value')
        timeframe = self.params.get('timeframe', 'week') 
        current_page = int(self.params.get('page', 1))
        items_per_page = 20
        
        from resources.lib.indexers.simkl_tracks import SimklInterface
        data = SimklInterface.get_simkl_static_trending(media_type, timeframe, 500)

        filtered = []
        for i in data:
            if media_type == 'tv':
                if i.get('network') == target_value: filtered.append(i)
            else:
                if target_value in i.get('genres', []): filtered.append(i)
        
        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        page_items = filtered[start:end]

        imdb_ids = [i.get('ids', {}).get('imdb') for i in page_items if i.get('ids', {}).get('imdb')]
        db_sync_data = self.db.get_indicators_for_list(imdb_ids)
        
        for item in page_items:
            title = item.get('title')
            imdb_id = item.get('ids', {}).get('imdb')
            if not imdb_id: continue

            indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])
            
            poster_url = f"https://simkl.in/posters/{item.get('poster')}_m.jpg" if item.get('poster') else 'DefaultMovies.png'
            rel_date = item.get('release_date', '')
            year = rel_date.split('/')[-1] if '/' in rel_date else ''

            clean_indicator = f"{indicator}" if indicator else ""

            display_label = f"{clean_indicator} {title} [COLOR gold]({year})[/COLOR]"

            imdb_rating = item.get('ratings', {}).get('imdb', {}).get('rating', 'N/A')
            display_label += f" - [COLOR yellow]★ {imdb_rating}[/COLOR]"
            
            self.addDirectoryItem(
                name=f"[B]{display_label}[/B]", 
                query=f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                thumb=poster_url, 
                meta={"title": title, "plot": f"{plot_status_line}\n\n{item.get('overview', '')}", "year": year}
            )
            
        if len(filtered) > end:
            url_next = "simkl_streaming_items&media_type={}&filter_value={}&timeframe={}&page={}".format(
                media_type, quote_plus(target_value), timeframe, current_page + 1
            )
            self.addDirectoryItem(f"[B][COLOR gold]>>> Következő oldal ({current_page + 1}) >>>[/COLOR][/B]", url_next, '', simkl_notif_icon)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def SimklTrendingMenu(self):
        timeframe = self.params.get('timeframe', 'week')
        label_suffix = ""
        if timeframe == 'today': label_suffix = "(Napi)"
        elif timeframe == 'week': label_suffix = "(Heti)"
        elif timeframe == 'month': label_suffix = "(Havi)"
        
        self.addDirectoryItem(f"[B]Filmek[/B] {label_suffix}", f"simkl_streaming_networks&media_type=movies&timeframe={timeframe}", '', simkl_notif_icon)
        self.addDirectoryItem(f"[B]Sorozatok[/B] {label_suffix}", f"simkl_streaming_networks&media_type=tv&timeframe={timeframe}", '', simkl_notif_icon)
        self.addDirectoryItem(f"[B]Animék[/B] {label_suffix}", f"simkl_streaming_networks&media_type=anime&timeframe={timeframe}", '', simkl_notif_icon)
        self.endDirectory(user_change_view)

    def SimklMixedItems(self):
        timeframe = self.params.get('timeframe', 'month')
        current_page = int(self.params.get('page', 1))
        items_per_page = 20
        
        from resources.lib.indexers.simkl_tracks import SimklInterface
        raw_dict = SimklInterface.get_simkl_static_trending('mixed', timeframe, 500)
        
        if not raw_dict or not isinstance(raw_dict, dict):
            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
            return

        tv_list = raw_dict.get('tv', [])
        movie_list = raw_dict.get('movies', [])
        anime_list = raw_dict.get('anime', [])

        all_for_harvest = tv_list + movie_list + anime_list
        new_posters = {i['ids']['imdb']: i['poster'] for i in all_for_harvest if i.get('ids', {}).get('imdb') and i.get('poster')}
        if new_posters:
            import threading
            t = threading.Thread(target=self.db.update_bulk_sync_status, args=(new_posters, 'simkl_poster'))
            t.daemon = True
            t.start()

        combined_data = []
        max_len = max(len(tv_list), len(movie_list), len(anime_list))
        for i in range(max_len):
            if i < len(tv_list): combined_data.append(tv_list[i])
            if i < len(movie_list): combined_data.append(movie_list[i])
            if i < len(anime_list): combined_data.append(anime_list[i])

        start = (current_page - 1) * items_per_page
        end = start + items_per_page
        page_items = combined_data[start:end]

        imdb_ids_to_query = [i.get('ids', {}).get('imdb') for i in page_items if i.get('ids', {}).get('imdb')]
        db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)
        
        for item in page_items:
            title = item.get('title')
            imdb_id = item.get('ids', {}).get('imdb')
            if not imdb_id: continue

            rel_date = item.get('release_date', '')
            item_year = rel_date.split('/')[-1] if rel_date and '/' in rel_date else ''
            year_display = f"({item_year})" if item_year else ""
            
            indicator, plot_status_line, is_played = self._build_indicators(imdb_id, None, db_sync_data, [])

            url_path = item.get('url', '')
            if "/movie/" in url_path:
                m_type, t_color = "      FILM     ", "lightgreen"
                m_label = f"|{m_type:^9}|" 
            elif "/tv/" in url_path:
                m_type, t_color = "SOROZAT", "orange"
                m_label = f"|{m_type:^9}|"
            elif "/anime/" in url_path:
                m_type, t_color = "    ANIME   ", "cyan"
                m_label = f"|{m_type:^9}|"
            else:
                m_type, t_color = "    EGYÉB   ", "grey"
                m_label = f"|{m_type:^9}|"

            poster_url = f"https://simkl.in/posters/{item.get('poster')}_m.jpg" if item.get('poster') else 'DefaultMovies.png'
            rating = item.get('ratings', {}).get('imdb', {}).get('rating', 'N/A')
            rank_val = item.get('rank', '?')

            display_indicator = f"{indicator} " if indicator else "- "

            display_label = f"[COLOR {t_color}]{m_label}[/COLOR] {display_indicator}{title} [COLOR gold]{year_display}[/COLOR] - [COLOR yellow]★ {rating}[/COLOR]"
            
            self.addDirectoryItem(
                name=f"[B]{display_label}[/B]", 
                query=f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", 
                thumb=poster_url, 
                meta={
                    "title": title, 
                    "plot": f"{plot_status_line}\nTípus: [COLOR {t_color}]{m_type.strip()}[/COLOR] | Helyezés: #{rank_val}\n\n{item.get('overview', 'Nincs leírás.')}",
                    "year": item_year
                }
            )
            
        if len(combined_data) > end:
            u_next = f"simkl_mixed_items&timeframe={timeframe}&page={current_page + 1}"
            self.addDirectoryItem(f"[B][COLOR gold]>>> Következő oldal ({current_page + 1}) >>>[/COLOR][/B]", u_next, '', simkl_notif_icon)
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)




    def getLists(self, url):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests

        resp = nc_get(url)
        soup = BeautifulSoup(resp.text, 'html.parser')

        main_content_div = soup.find('div', class_='col-xs-12 col-sm-8')
        list_items = main_content_div.find_all('div', class_='row mb-3')
        for item in list_items:
        
            title = ''
            slug_url = ''
            description = ''
            poster_url = ''
            stars = ''
            films = ''

            title_tag = item.find('h3', class_='mt-0 mb-0')
            if title_tag:
                link_tag = title_tag.find('a')
                if link_tag:
                    title = link_tag.get_text(strip=True)
                    relative_url = link_tag.get('href')
                    if relative_url:
                        slug_url = f"https://www.thetvdb.com{relative_url}"

            description_tag = item.find('p')
            if description_tag:
                description = description_tag.get_text(strip=True)

            img_tag = item.find('img', class_='lazy img-responsive')
            if img_tag:
                poster_url = img_tag.get('src')

            details_div = item.find('div', class_='small mb-1 text-muted')
            if details_div:
                spans = details_div.find_all('span')
                if len(spans) > 0:
                    star_span = spans[0]
                    stars = star_span.get_text(strip=True).replace(' ', '')
                if len(spans) > 1:
                    film_span = spans[1]
                    films = film_span.get_text(strip=True).replace(' ', '')

            metadata = {'title': f'[B]{title}[/B]', 'plot': f'\n[B]A listában:[/B] {films}\n[B]Stars:[/B] {stars}\n[B]Tartalom:[/B] {description}'}
            
            url_params = f'ext_lists&url={slug_url}'
            
            self.addDirectoryItem(f'[B]{title}[/B] ([COLOR yellow]{films}[/COLOR])', url_params, poster_url, 'DefaultMovies.png', isFolder=True, meta=metadata)

        next_page_link = soup.find('a', rel='next')
        if next_page_link:
            next_page_url = 'https://www.thetvdb.com/lists' + next_page_link.get('href')
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_lists&url={urllib.parse.quote_plus(next_page_url)}', '', 'DefaultFolder.png')

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def extLists(self, url, poster_link, year):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import re

        resp = nc_get(url)
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        item_containers = soup.find_all('div', class_='row')
        for item_container in item_containers:
            content_col = item_container.find('div', class_='col-xs-12 col-sm-9 col-md-10 mt-2')
            if not content_col:
                continue

            title_link_tag = content_col.find('h3', class_='mt-0 mb-0')
            poster_img_tag = item_container.find('img', class_='img-responsive img-rounded')
            description_p_tag = content_col.find('p')
            year_div_tag = content_col.find('div', class_='mb-1')

            item_title = ''
            item_url = ''
            poster_link = ''
            release_year = ''
            description = ''
            main_type = ''

            link_element = title_link_tag.find('a')
            if link_element:
                item_title = link_element.get_text(strip=True)
                relative_url = link_element.get('href')
                if relative_url:
                    item_url = f"https://www.thetvdb.com{relative_url}"

            if poster_img_tag:
                poster_link = poster_img_tag.get('src')

            if year_div_tag:
                year_text = year_div_tag.get_text(strip=True)
                year_match = re.search(r'\b\d{4}\b', year_text)
                if year_match:
                    release_year = year_match.group(0)

            if description_p_tag:
                description = description_p_tag.get_text(strip=True)

            if re.search('series', relative_url):
                main_type = 'Sorozat'
                formatted_main_type = main_type
            else:
                main_type = 'Film'
                formatted_main_type = f'{main_type:^10}'

            title = f'| [B]{formatted_main_type}[/B] | [B]{item_title}[/B]'

            if release_year:
                title = f'{title} [B]({release_year})[/B]'

            final_display_title = f'{title}'

            metadata = {'title': final_display_title, 'plot': f'\n\n[B]Tartalom:[/B] {description}'}
            
            url_params = f'ext_tvdb&url={item_url}&poster_link={poster_link}&year={release_year}'
            
            self.addDirectoryItem(final_display_title, url_params, poster_link, 'DefaultMovies.png', isFolder=True, meta=metadata)
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def extTvdb(self, url, poster_link, year):
        from bs4 import BeautifulSoup
        import html
        import requests
        import re

        request_headers = {
            'Accept-Language': 'hu, en;q=0.9',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
        }

        final_description = ""
        final_title = ""
        imdb_id = ""

        try:
            response = requests.get(url, headers=request_headers, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')

            hun_block = soup.find('div', {'data-language': 'hun'})
            eng_block = soup.find('div', {'data-language': 'eng'})

            if hun_block:
                hun_desc_tag = hun_block.find('p')
                if hun_desc_tag:
                    hun_description = hun_desc_tag.get_text(strip=True)
                    if hun_description:
                        final_description = hun_description

            if not final_description and eng_block:
                eng_desc_tag = eng_block.find('p')
                if eng_desc_tag:
                    final_description = eng_desc_tag.get_text(strip=True)

            if hun_block:
                hun_raw_title = hun_block.get('data-title', '')
                if hun_raw_title:
                    final_title = html.unescape(hun_raw_title)

            if not final_title and eng_block:
                eng_raw_title = eng_block.get('data-title', '')
                if eng_raw_title:
                    final_title = html.unescape(eng_raw_title)
            
            if year:
                final_title = f'{final_title} ({year})'
            else:
                final_title = f'{final_title}'
            
            imdb_link_tag = soup.find('a', href=re.compile(r'imdb\.com/title/tt\d+'))
            if imdb_link_tag:
                match = re.search(r'(tt\d+)', imdb_link_tag['href'])
                if match:
                    imdb_id = match.group(1)
            if not imdb_id:
                match = re.search(r'(tt\d+)', str(soup))
                if match:
                    imdb_id = match.group(1)

            db_sync_data = {}
            if imdb_id:
                db_sync_data = self.db.get_indicators_for_list([imdb_id])

            indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, None, db_sync_data, [])

            metadata = {'plot': f'{plot_status_line}\n[B]Tartalom:[/B]\n{final_description}'}

            imdb_id_match = re.findall(r'(tt\d+)', str(soup))
            if imdb_id_match:
                imdb_id = imdb_id_match[0].strip()
                url_params_imdb = f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&poster_link={poster_link}&description={final_description}&title_1={final_title}&imdb_id={imdb_id}"
                
                self.addDirectoryItem(f'{indicator}[B]{final_title} [imdb: {imdb_id}][/B]', url_params_imdb, poster_link, 'DefaultFolder.png', meta=metadata)
            else:
                url_params_no_imdb = f"newsearch_4&url={quote_plus(f'{base_url}{movie_ser_en_hu_kereso}{final_title}')}&poster_link={poster_link}&description={final_description}&title_1={final_title}"
                
                self.addDirectoryItem(f"[B]{final_title} | [COLOR FFF56C00]nincs imdb ID[/COLOR][/B] | Keresés [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B]: [B][COLOR lime]{final_title}[/COLOR][/B] ", url_params_no_imdb, poster_link, 'DefaultFolder.png', meta=metadata)
        
        except requests.exceptions.RequestException as e:
            xbmc.log(f'{base_log_info}| extTvdb | An error occurred during the request: {e}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'{base_log_info}| extTvdb | An unexpected error occurred: {e}', xbmc.LOGINFO)
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendBoth(self, url):
        self.addDirectoryItem(f"[B]Filmek[/B]{ncore_coloring}", f"get_recommend_movie&url=https://www.themoviedb.org/discover/movie", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Sorozatok[/B]{ncore_coloring}", f"get_recommend_series&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')
        
        self.addDirectoryItem(f"[B]Amazon Prime (Sorozatok)[/B]{ncore_coloring}", f"get_recommend_series_amazon&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Disney+ (Sorozatok)[/B]{ncore_coloring}", f"get_recommend_series_disney&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]MAX (Sorozatok)[/B]{ncore_coloring}", f"get_recommend_series_max&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Netflix (Sorozatok)[/B]{ncore_coloring}", f"get_recommend_series_netflix&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Skyshowtime (Sorozatok)[/B]{ncore_coloring}", f"get_recommend_series_skyshowtime&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')
        self.addDirectoryItem(f"[B]Apple TV+ (Sorozatok)[/B]{ncore_coloring}", f"get_recommend_series_apple&url=https://www.themoviedb.org/discover/tv", '', 'DefaultFolder.png')        
        
        if custom_view_list == 'true':
            self.endDirectory('plot')
        else:    
            self.endDirectory(user_change_view)

    def getRecommendMovie(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup

        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }

        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }

        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendMovie_data)

        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')

        for card in cards:
            title_element = card.find('h2')
            title = title_element.text.strip() if title_element else 'Unknown Title'

            data_id_element = card.find('div', class_='options')
            data_id = int(data_id_element['data-id']) if data_id_element and 'data-id' in data_id_element.attrs else None

            link_slug_element = card.find('a', class_='image')
            link_slug = link_slug_element['href'] if link_slug_element else ''
            link_slug_id = ''
            if link_slug:
                match = re.findall(r'.*/(.*/\d+)', link_slug)
                link_slug_id = match[0].strip() if match else ''

            poster_link_element = card.find('img')
            poster_link = poster_link_element['src'] if poster_link_element else ''

            date_element = card.find('p')
            date = date_element.text.strip() if date_element else 'N/A'

            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_movie&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})

        try:
            next_page_url_element = soup.find('p', class_='load_more')
            if next_page_url_element and next_page_url_element.find('a'):
                next_page_url = 'https://www.themoviedb.org' + next_page_url_element.find('a')['href']
                self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_movie&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
            else:
                xbmc.log(f'{base_log_info}| getRecommendMovie | next_page_url | csak egy oldal található', xbmc.LOGINFO)
        except AttributeError:
            xbmc.log(f'{base_log_info}| getRecommendMovie | next_page_url | csak egy oldal található (AttributeError)', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def ExtRecommendMovie(self, url, link_slug_id, imdb_id, description, poster_link):
        import requests

        url_x = f'https://api.themoviedb.org/3/{link_slug_id}'
        params = {
            'api_key': f'{bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}',
            'language': 'hu-HU',
            'append_to_response': 'external_ids'
        }

        response = nc_get(url_x, params=params)

        if response.status_code == 200:
            movie_info = response.json()

            imdb_id = movie_info.get('imdb_id') or movie_info.get('external_ids', {}).get('imdb_id', '')
            title = movie_info.get('title', '')
            description = movie_info.get('overview', '')

            db_sync_data = {}
            if imdb_id:
                db_sync_data = self.db.get_indicators_for_list([imdb_id])

            indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, None, db_sync_data, [])

            if imdb_id and imdb_id != '':
                metadata = {'plot': f'{plot_status_line}\n[B]{title}[/B]\n{description}'}

                self.addDirectoryItem(f"{indicator}[B]{title} (imdb: {imdb_id})[/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&link_slug_id={link_slug_id}&imdb_id={imdb_id}&description={description}&poster_link={poster_link}", poster_link, 'DefaultFolder.png', meta=metadata)

                self.addDirectoryItem(f"[B][COLOR lightgreen][I]--[/I] Szereplők (stáblista) [I]--[/I][/COLOR][/B]", f"get_cast_list&imdb_id={imdb_id}&media_type=movie&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{title}', "plot": f'{plot_status_line}\n{description}'})
                
                self.addDirectoryItem(f'[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]', f"tmdb_get_collection&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{title}', "plot": f'{plot_status_line}\n{description}'})

                self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{title}', "plot": f'{plot_status_line}\n{description}'})

            try:
                response_1 = nc_get(f'{ab_t}.{kf_t}/search/id?imdb={imdb_id}&extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                
                simkl_id = response_1[0]['ids']['simkl']
                response_2 = nc_get(f'{a_d}{c_d}{i_d}{simkl_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                
                trailer_name = response_2['trailers'][0]['name']
                trailer_id = response_2['trailers'][0]['youtube']
                
                if trailer_id:
                    self.addDirectoryItem(f"[B][COLOR lime][Bemutató][/COLOR] ({trailer_name}):[/B] {title}", f'plugin://plugin.video.youtube/play/?video_id={trailer_id}', poster_link, 'DefaultFolder.png', isFolder=False, isAction=False, meta={'plot': f'{plot_status_line}\n[B]{title}[/B]\n{description}'})
            except (IndexError, TypeError, KeyError):
                pass
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendSeries(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup

        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }

        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }

        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeries_data)

        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')

        for card in cards:
            title_element = card.find('h2')
            title = title_element.text.strip() if title_element else 'Unknown Series Title'

            data_id_element = card.find('div', class_='options')
            data_id = int(data_id_element['data-id']) if data_id_element and 'data-id' in data_id_element.attrs else None

            link_slug_element = card.find('a', class_='image')
            link_slug = link_slug_element['href'] if link_slug_element else ''
            link_slug_id = ''
            if link_slug:
                match = re.findall(r'.*/(.*/\d+)', link_slug)
                link_slug_id = match[0].strip() if match else ''

            poster_link_element = card.find('img')
            poster_link = poster_link_element['src'] if poster_link_element else ''

            date_element = card.find('p')
            date = date_element.text.strip() if date_element else 'N/A'

            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})

        try:
            next_page_url_element = soup.find('p', class_='load_more')
            if next_page_url_element and next_page_url_element.find('a'):
                next_page_url = 'https://www.themoviedb.org' + next_page_url_element.find('a')['href']
                self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
            else:
                xbmc.log(f'{base_log_info}| getRecommendSeries | next_page_url | csak egy oldal található', xbmc.LOGINFO)
        except AttributeError:
            xbmc.log(f'{base_log_info}| getRecommendSeries | next_page_url | csak egy oldal található (AttributeError)', xbmc.LOGINFO)

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def ExtRecommendSeries(self, url, link_slug_id, imdb_id, description, poster_link):
        import requests

        url_x = f'https://api.themoviedb.org/3/{link_slug_id}'
        
        params = {
            'api_key': f'{bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}',
            'language': 'hu-HU',
            'append_to_response': 'external_ids'
        }

        response = nc_get(url_x, params=params)

        if response.status_code == 200:
            movie_info = response.json()
            
            title = movie_info.get('name', '')
            description = movie_info.get('overview', '')

            imdb_id = movie_info.get('external_ids', {}).get('imdb_id', '')
            
            if imdb_id and imdb_id != '':
                db_sync_data = self.db.get_indicators_for_list([imdb_id])

                indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, None, db_sync_data, [])

                add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={quote_plus(title)}&title_2={quote_plus(title)}")
                
                context_menu_items = [add_series_watching]
                
                self.addDirectoryItem(f"{indicator}[B]{title} (imdb: {imdb_id})[/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&link_slug_id={link_slug_id}&imdb_id={imdb_id}&description={quote_plus(description)}&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultFolder.png', context=context_menu_items, isFolder=True, meta={'plot': f'{plot_status_line}\n[B]{title}[/B]\n{description}'})

                self.addDirectoryItem(f"[B][COLOR lightgreen][I]--[/I] Szereplők (stáblista) [I]--[/I][/COLOR][/B]", f"get_cast_list&imdb_id={imdb_id}&media_type=tv&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{title}', "plot": f'{plot_status_line}\n{description}'})
                
                self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{title}', "plot": f'{plot_status_line}\n{description}'})
            else:
                try:
                    tmdb_id = re.findall(r'(\d+)', link_slug_id)[0].strip()
                    
                    response_1 = nc_get(f'{ab_t}.{kf_t}/search/id?tmdb={tmdb_id}&extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                    simkl_id = response_1[0]['ids']['simkl']
                    response_2 = nc_get(f'{a_d}{c_d}{i_d}{simkl_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                    imdb_id = response_2.get('ids', {}).get('imdb', '')
                    
                    if imdb_id:
                        db_sync_fb = self.db.get_indicators_for_list([imdb_id])
                        indicator_fb, plot_status_line_fb, is_already_played_fb = self._build_indicators(imdb_id, None, db_sync_fb, [])

                        add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={quote_plus(title)}&title_2={quote_plus(title)}")
                        
                        context_menu_items = [add_series_watching]                    

                        self.addDirectoryItem(f"{indicator_fb}[B]{title} (imdb: {imdb_id})[/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&link_slug_id={link_slug_id}&imdb_id={imdb_id}&description={quote_plus(description)}&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultFolder.png', context=context_menu_items, isFolder=True, meta={'plot': f'{plot_status_line_fb}\n[B]{title}[/B]\n{description}'})
                        
                        self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": f'{title}', "plot": f'{plot_status_line_fb}\n{description}'})
                    
                        if 'trailers' in response_2 and response_2['trailers']:
                            trailer_name = response_2['trailers'][0]['name']
                            trailer_id = response_2['trailers'][0]['youtube']
                            
                            if trailer_id:
                                self.addDirectoryItem(f"[B][COLOR lime][Bemutató][/COLOR] ({trailer_name}):[/B] {title}", f'plugin://plugin.video.youtube/play/?video_id={trailer_id}', poster_link, 'DefaultFolder.png', isFolder=False, isAction=False, meta={'plot': f'{plot_status_line_fb}\n[B]{title}[/B]\n{description}'})
                except (IndexError, TypeError, KeyError):
                    pass
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)


    def getRecommendSeriesAmazon(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup
        
        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/tv',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeriesAmazon_data)
        
        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')
        
        for card in cards:
            title = card.find('h2').text.strip()
            data_id = int(card.find('div', class_='options')['data-id'])
            link_slug = card.find('a', class_='image')['href']
            link_slug_id = re.findall(r'.*/(.*/\d+)', link_slug)[0].strip()
            
            poster_link = card.find('img')['src']
            date = card.find('p').text.strip()
        
            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})
        
        try:
            next_page_url = 'https://www.themoviedb.org' + soup.find('p', class_='load_more').find('a')['href']
            
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
        except AttributeError:
            xbmc.log(f'{base_log_info}| getOnlyMovies | next_page_url | csak egy oldal található', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendSeriesDisney(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup
        
        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeriesDisney_data)
        
        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')
        
        for card in cards:
            title = card.find('h2').text.strip()
            data_id = int(card.find('div', class_='options')['data-id'])
            link_slug = card.find('a', class_='image')['href']
            link_slug_id = re.findall(r'.*/(.*/\d+)', link_slug)[0].strip()
            
            poster_link = card.find('img')['src']
            date = card.find('p').text.strip()
        
            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})
        
        try:
            next_page_url = 'https://www.themoviedb.org' + soup.find('p', class_='load_more').find('a')['href']
            
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
        except AttributeError:
            xbmc.log(f'{base_log_info}| getOnlyMovies | next_page_url | csak egy oldal található', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendSeriesMAX(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup
        
        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeriesMAX_data)
        
        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')
        
        for card in cards:
            title = card.find('h2').text.strip()
            data_id = int(card.find('div', class_='options')['data-id'])
            link_slug = card.find('a', class_='image')['href']
            link_slug_id = re.findall(r'.*/(.*/\d+)', link_slug)[0].strip()
            
            poster_link = card.find('img')['src']
            date = card.find('p').text.strip()
        
            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})
        
        try:
            next_page_url = 'https://www.themoviedb.org' + soup.find('p', class_='load_more').find('a')['href']
            
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
        except AttributeError:
            xbmc.log(f'{base_log_info}| getOnlyMovies | next_page_url | csak egy oldal található', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendSeriesNetflix(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup
        
        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeriesNetflix_data)
        
        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')
        
        for card in cards:
            title = card.find('h2').text.strip()
            data_id = int(card.find('div', class_='options')['data-id'])
            link_slug = card.find('a', class_='image')['href']
            link_slug_id = re.findall(r'.*/(.*/\d+)', link_slug)[0].strip()
            
            poster_link = card.find('img')['src']
            date = card.find('p').text.strip()
        
            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})
        
        try:
            next_page_url = 'https://www.themoviedb.org' + soup.find('p', class_='load_more').find('a')['href']
            
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
        except AttributeError:
            xbmc.log(f'{base_log_info}| getOnlyMovies | next_page_url | csak egy oldal található', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendSeriesSkyshowtime(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup
        
        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeriesSkyshowtime_data)
        
        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')
        
        for card in cards:
            title = card.find('h2').text.strip()
            data_id = int(card.find('div', class_='options')['data-id'])
            link_slug = card.find('a', class_='image')['href']
            link_slug_id = re.findall(r'.*/(.*/\d+)', link_slug)[0].strip()
            
            poster_link = card.find('img')['src']
            date = card.find('p').text.strip()
        
            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})
        
        try:
            next_page_url = 'https://www.themoviedb.org' + soup.find('p', class_='load_more').find('a')['href']
            
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
        except AttributeError:
            xbmc.log(f'{base_log_info}| getOnlyMovies | next_page_url | csak egy oldal található', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getRecommendSeriesApple_plus(self, url, link_slug_id, poster_link):
        import requests
        from bs4 import BeautifulSoup
        
        cookies = {
            'tmdb.prefs': '%7B%22adult%22%3Afalse%2C%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
        }
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.themoviedb.org',
            'referer': 'https://www.themoviedb.org/movie',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        response = nc_post(url, cookies=cookies, headers=headers, data=getRecommendSeriesApple_plus_data)
        
        soup = BeautifulSoup(response.text, 'html.parser')

        cards = soup.find_all('div', class_='card style_1')
        
        for card in cards:
            title = card.find('h2').text.strip()
            data_id = int(card.find('div', class_='options')['data-id'])
            link_slug = card.find('a', class_='image')['href']
            link_slug_id = re.findall(r'.*/(.*/\d+)', link_slug)[0].strip()
            
            poster_link = card.find('img')['src']
            date = card.find('p').text.strip()
        
            self.addDirectoryItem(f'[B]{title} - {date}[/B]', f'ext_recommend_series&link_slug_id={link_slug_id}&poster_link={poster_link}', poster_link, 'DefaultFolder.png', meta={'plot': f'{title}\n{date}'})
        
        try:
            next_page_url = 'https://www.themoviedb.org' + soup.find('p', class_='load_more').find('a')['href']
            
            self.addDirectoryItem('[I]Következő oldal[/I]', f'get_recommend_series&url={quote_plus(next_page_url)}', '', 'DefaultFolder.png')
        except AttributeError:
            xbmc.log(f'{base_log_info}| getOnlyMovies | next_page_url | csak egy oldal található', xbmc.LOGINFO)


        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)


    def BookmarkDatabaseCheck(self):
        bookmark_name = self.params.get('bookmark_name')
        bookmark_group_id = self.params.get('bookmark_group_id')
        unique_key = f"{bookmark_name}::{bookmark_group_id}"
        
        report = []
        report.append("[B][COLOR gold]!!! KÖNYVJELZŐ ADATBÁZIS ELLENŐRZÉS !!![/COLOR][/B]")
        report.append("[COLOR grey]------------------------------------------------------------[/COLOR]")

        auto_add = addon.getSetting('auto_add_bookmark') == 'true'
        show_notif = addon.getSetting('show_notif_for_auto_bookmark') == 'true'
        
        report.append("\n[B][COLOR lightgreen]=== GLOBÁLIS BEÁLLÍTÁSOK (Settings) ===[/COLOR][/B]")
        
        status_color = "lime" if auto_add else "red"
        status_text = "AKTIVÁLVA" if auto_add else "KIKAPCSOLVA"
        report.append(f"[COLOR gold]AUTO HOZZÁADÁS LEJÁTSZÁSKOR:[/COLOR] [COLOR {status_color}][B]{status_text}[/B][/COLOR]")
        
        notif_text = "BEKAPCSOLVA" if show_notif else "KIKAPCSOLVA"
        report.append(f"[COLOR gold]ÉRTESÍTÉS MEGJELENÍTÉSE:[/COLOR] {notif_text}")
        
        if not auto_add:
            report.append("\n[COLOR orange][I]Figyelem: Mivel az auto hozzáadás ki van kapcsolva, a lenti[/I][/COLOR]")
            report.append("[COLOR orange][I]hozzárendelések jelenleg nem lépnek életbe lejátszáskor![/I][/COLOR]")

        try:
            with self.db._get_connection() as conn:
                row = conn.execute("SELECT * FROM bookmarks_mapping WHERE bookmark_key = ?", (unique_key,)).fetchone()
                
                if row:
                    report.append("\n[B][COLOR lightgreen]=== EGYEDI HOZZÁRENDELÉS (SQL) ===[/COLOR][/B]")
                    report.append(f"[COLOR gold]NÉV:[/COLOR] {row['name']}")
                    report.append(f"[COLOR gold]CSOPORT ID:[/COLOR] {row['group_id']}")
                    
                    report.append("\n[B][COLOR lightgreen]=== AKTÍV KATEGÓRIÁK EBBEN A CSOPORTBAN ===[/COLOR][/B]")
                    categories = json.loads(row['categories'])
                    
                    if 'all' in categories:
                        report.append("[COLOR lime]>>> MINDEN KATEGÓRIA (all) <<<[/COLOR]")
                    else:
                        for cat_key in categories:
                            readable = bookmark_map.get(cat_key, cat_key)
                            report.append(f"[COLOR cyan]- {readable}[/COLOR] [COLOR grey]({cat_key})[/COLOR]")
                else:
                    report.append("\n[B][COLOR lightgreen]=== EGYEDI HOZZÁRENDELÉS ===[/COLOR][/B]")
                    report.append("[COLOR red][-] Ehhez a könyvjelzőhöz nincs mentett szabály az adatbázisban.[/COLOR]")
        
        except Exception as e:
            report.append(f"\n[COLOR red]!!! HIBA AZ SQL LEKÉRDEZÉSNÉL: {str(e)} !!![/COLOR]")

        report.append("\n[COLOR grey]------------------------------------------------------------[/COLOR]")
        report.append("[I]Vége a jelentésnek.[/I]")
        
        xbmcgui.Dialog().textviewer(f"SQL Audit: {bookmark_name}", "\n".join(report))

    def forSetBookmark(self, bookmark_name, bookmark_group_id):
        plugin_next_action = f"plugin://{addon_str}/?action=setBookmarkCategories&bookmark_name={quote_plus(bookmark_name)}&bookmark_group_id={bookmark_group_id}"
        xbmc.executebuiltin(f'RunPlugin({plugin_next_action})')
    
    def setBookmarkCategories(self, bookmark_name, bookmark_group_id):
        unique_bookmark_key = f"{bookmark_name}::{bookmark_group_id}"
        bookmarks = self.db.get_all_bookmarks()
        
        used_categories_keys = set()
        current_bookmark_categories = []
        
        for key, value in bookmarks.items():
            if key == unique_bookmark_key:
                current_bookmark_categories = value.get('categories', [])
            else:
                used_categories_keys.update(value.get('categories', []))
        
        available_items_for_multiselect = []
        available_keys_list = []
        initial_selection_indices = []

        for i, (key, value) in enumerate(bookmark_map.items()):
            if key not in used_categories_keys or key in current_bookmark_categories:
                available_items_for_multiselect.append(value)
                available_keys_list.append(key)

                if key in current_bookmark_categories or 'all' in current_bookmark_categories:
                    initial_selection_indices.append(len(available_items_for_multiselect) - 1)
        
        selected_indices = xbmcgui.Dialog().multiselect(
            f"Válassz ebbe: '{bookmark_name}' (csak ami még elérhető)",
            available_items_for_multiselect,
            preselect=initial_selection_indices
        )
        
        if selected_indices is not None:
            pDialog = xbmcgui.DialogProgress()
            pDialog.create('nCore TV', 'Beállítások mentése...')
            pDialog.update(30)

            if not selected_indices:
                if unique_bookmark_key in bookmarks:
                    self.db.delete_bookmark(unique_bookmark_key)
            else:
                selected_keys = [available_keys_list[i] for i in selected_indices]
                selected_values = ['all'] if len(selected_keys) == len(bookmark_map.keys()) else selected_keys
                self.db.save_bookmark(unique_bookmark_key, bookmark_name, bookmark_group_id, selected_values)

            import time
            pDialog.update(60, 'Lista újratöltése...')
            time.sleep(0.3)

            xbmc.executebuiltin("Container.Refresh")

            pDialog.update(100, 'Kész!')
            time.sleep(0.2)
            pDialog.close()
    
    def getBookmarkCategories(self, url, bookmark_name, bookmark_num):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re

        cookies = { 'nick': user_name, 'pass': saved_pass_cookie }
        resp = nc_get(f'https://ncore.pro/bookmarks.php', cookies=cookies, headers=headers)
        soup = BeautifulSoup(resp.text, 'html.parser')
        if known_errors(str(soup)): return
        
        bookmarks = []
        for li in soup.find_all('li'):
            link = li.find('a')
            if link and 'href' in link.attrs:
                bookmark = {}
                bookmark['bookmark_name'] = link.text.strip()
                bookmark['bookmark_link'] = 'https://ncore.pro' + link['href']
                if '?group=' not in bookmark['bookmark_link']: bookmark['bookmark_link'] += '?group=0'
                li_text = li.text
                if '(' in li_text and ')' in li_text:
                    try:
                        start_index = li_text.rfind('('); end_index = li_text.rfind(')')
                        if start_index != -1 and end_index != -1 and start_index < end_index:
                            bookmark['bookmark_num'] = int(li_text[start_index + 1:end_index].strip())
                        else: bookmark['bookmark_num'] = 0
                    except ValueError: bookmark['bookmark_num'] = 0
                else: bookmark['bookmark_num'] = 0
                bookmarks.append(bookmark)

        live_bookmark_keys = set()
        for b in bookmarks:
            try:
                live_bookmark_group_id = int(re.findall(r'group=(\d+)', str(b['bookmark_link']))[0].strip())
                live_bookmark_keys.add(f"{b['bookmark_name']}::{live_bookmark_group_id}")
            except: pass

        saved_bookmarks = self.db.get_all_bookmarks()
        for saved_key in list(saved_bookmarks.keys()):
            if saved_key not in live_bookmark_keys:
                self.db.delete_bookmark(saved_key)
                del saved_bookmarks[saved_key]

        for stuffs in bookmarks:
            bookmark_name = stuffs['bookmark_name']
            bookmark_link = stuffs['bookmark_link']
            bookmark_group_id = int(re.findall(r'group=(\d+)', str(bookmark_link))[0].strip())
            bookmark_num = int(stuffs['bookmark_num'])
            unique_bookmark_key = f"{bookmark_name}::{bookmark_group_id}"

            saved_info = saved_bookmarks.get(unique_bookmark_key, None)
            title_text = f'[B]{bookmark_name}[/B]'

            if saved_info:
                saved_categories = saved_info.get('categories', [])
                if 'all' in saved_categories:
                    plot_text = f"\n\n[COLOR orange]Lejátszáskor [COLOR lime]MINDEN[/COLOR] kategória\nEbbe a könyvjelzőbe kerül:\n[COLOR cyan]{bookmark_name}[/COLOR]"
                else:
                    saved_category_names = [bookmark_map.get(cat, cat) for cat in saved_categories]
                    plot_text = f"\n\n[COLOR orange]Lejátszáskor ezek a kategóriák:\n[/COLOR][COLOR lime]{', '.join(saved_category_names)}[/COLOR]\nEbbe a könyvjelzőbe kerülnek:\n[COLOR cyan]{bookmark_name}[/COLOR]"
            else:
                plot_text = "\n\n[COLOR grey]Lejátszáskor ez a könyvjelző nem mentődik egy kategóriához se!\n\n[COLOR lime]-[/COLOR] Context menüvel vehetsz fel kategóriákat ehhez a könyvjelző csoporthoz\n\n[COLOR lime]-[/COLOR] A Beállításokba engedélyezni kell:\nLejátszásnál hozzáadás a Könyvjelzőhöz[/COLOR]"

            metadata = {'title': title_text, 'plot': title_text + plot_text}
            url_params = f'extr_book_mark&url={quote_plus(bookmark_link)}&bookmark_name={quote_plus(bookmark_name)}&bookmark_num={bookmark_num}'

            db_check_item = (f"[B][COLOR gold]Adatbázis bookmark check[/COLOR][/B]", f"bookmark_database_check&bookmark_name={quote_plus(bookmark_name)}&bookmark_group_id={bookmark_group_id}")
            new_context_menu_item = ("[B][COLOR orange]Lejátszáskor a kiválasztott kategóriák alapján auto ebbe a könyvjelzőbe kerül[/COLOR][/B]", f"forSetBookmark&bookmark_name={quote_plus(bookmark_name)}&bookmark_group_id={bookmark_group_id}")
            context_menu_items = [new_context_menu_item, db_check_item]
            
            self.addDirectoryItem(title_text, url_params, '', 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=metadata)
            
        self.endDirectory('plot' if custom_view_list == 'true' else user_change_view)

    def deleteBookmarkTorrentAction(self, torrent_id, bookmark_group_id, megerositve_value, div_konyvjelzo_nev_id):
        plugin_next_action = f"plugin://{addon_str}/?action=deleteBookmarkTorrentId&torrent_id={torrent_id}&bookmark_group_id={bookmark_group_id}&megerositve_value={megerositve_value}&div_konyvjelzo_nev_id={div_konyvjelzo_nev_id}"
        xbmc.executebuiltin(f'Container.Update({plugin_next_action})')

    def deleteBookmarkTorrentId(self, torrent_id, bookmark_group_id, megerositve_value, div_konyvjelzo_nev_id):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        data = {
            f'konyvjelzo_nev[{div_konyvjelzo_nev_id}]': '',
            'torlendo_konyvjelzok[]': f'{div_konyvjelzo_nev_id}',
            'muvelet': 'modositas',
            'group': f'{bookmark_group_id}',
            'megerositve': f'{megerositve_value}',
        }

        resp = nc_post(f'https://ncore.pro/bookmarks.php', cookies=cookies, headers=headers, data=data)
        soup = BeautifulSoup(resp.text, 'html.parser')
        if known_errors(str(soup)):
            return
    
    def extrBookmark(self, url, title_1, rev_upload_date, rev_seeders, rev_leechers, torrent_id):
        import requests
        from requests.adapters import HTTPAdapter
        from requests.packages.urllib3.util.retry import Retry
        import time
        import re
        from bs4 import BeautifulSoup
        from urllib.parse import quote_plus

        retry_attempts = 3
        backoff_factor = 2
        timeout = 30

        torrents = []
        bookmark_group_id = ''
        megerositve_value = ''

        for attempt in range(retry_attempts):
            try:
                cookies = { 'nick': user_name, 'pass': saved_pass_cookie }
                response = requests.get(url, cookies=cookies, headers=headers, timeout=timeout)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                group_input = soup.find("input", {"type": "hidden", "name": "group"})
                if group_input: bookmark_group_id = group_input.get("value", "")

                megerositve_input = soup.find("input", {"type": "hidden", "name": "megerositve"})
                if megerositve_input: megerositve_value = megerositve_input.get("value", "")

                rows = soup.select("table tr")
                if not rows: break

                for i, row in enumerate(rows):
                    cells = row.find_all("td")
                    if len(cells) == 4 and cells[1].find("input"):
                        title_div = cells[2].find("div", {"class": "bookmark_name_txt"})
                        if title_div:
                            div_konyvjelzo_nev_name = title_div.get("id", "")
                            div_konyvjelzo_nev_id = re.findall(r'_nev(\d+)', str(div_konyvjelzo_nev_name))[0].strip()
                            title_a_tag = title_div.find("a")
                            if title_a_tag: title = title_a_tag.get("title", "")
                            else: continue
                        else: continue

                        torrent_id_matches = re.findall(r'detail.*id=(\d+)', str(cells))
                        if torrent_id_matches: current_torrent_id = torrent_id_matches[0].strip()
                        else: continue

                        upload_date, seeders, leechers = '', '', ''
                        if i + 1 < len(rows):
                            extra_info_cells = rows[i + 1].find_all("td")
                            extra_info_matches = re.findall(r'(<td>\d+-\d+-\d+.*</td><td>.*</td>)', str(extra_info_cells))
                            if extra_info_matches:
                                upload_date_matches = re.findall(r'<td>(.*?)</td>', extra_info_matches[0].strip())
                                if len(upload_date_matches) >= 1: upload_date = upload_date_matches[0].strip()
                                if len(upload_date_matches) >= 2: seeders = upload_date_matches[1].strip()
                                if len(upload_date_matches) >= 3: leechers = upload_date_matches[2].strip()

                        torrents.append({
                            "title": title, "torrent_id": current_torrent_id,
                            "upload_date": upload_date, "seeders": seeders,
                            "leechers": leechers, "div_konyvjelzo_nev_id": div_konyvjelzo_nev_id
                        })

                db_sync_data = {}
                db_local_played = set()
                db_torrent_to_imdb = {}
                db_torrent_to_poster = {}
                
                temp_ids = [t['torrent_id'] for t in torrents]
                if temp_ids:
                    with self.db._get_connection() as conn:
                        placeholders = ', '.join(['?'] * len(temp_ids))
                        t_rows = conn.execute(f'SELECT torrent_id, imdb_id, full_url, poster_link FROM torrents WHERE torrent_id IN ({placeholders})', temp_ids).fetchall()
                        
                        found_imdb_ids = []
                        for r in t_rows:
                            tid = str(r['torrent_id'])
                            db_torrent_to_imdb[tid] = r['imdb_id']
                            db_torrent_to_poster[tid] = r['poster_link']
                            if r['imdb_id']: found_imdb_ids.append(r['imdb_id'])

                            has_url = r['full_url'] is not None and r['full_url'] != ""
                            has_pos = conn.execute('SELECT 1 FROM video_positions WHERE torrent_id = ? LIMIT 1', (tid,)).fetchone() is not None
                            if has_url or has_pos:
                                db_local_played.add(tid)
                        
                        if found_imdb_ids:
                            db_sync_data = self.db.get_indicators_for_list(found_imdb_ids)

                torrents_reversed = torrents[::-1]
                for rev_torrent in torrents_reversed:
                    title_1 = rev_torrent['title']
                    rev_upload_date = rev_torrent['upload_date']
                    t_id_str = str(rev_torrent['torrent_id'])
                    cur_imdb = db_torrent_to_imdb.get(t_id_str)

                    indicator, plot_status_line, is_already_played = self._build_indicators(cur_imdb, t_id_str, db_sync_data, db_local_played)

                    cur_poster = db_torrent_to_poster.get(t_id_str)
                    if (not cur_poster or cur_poster == "") and cur_imdb:
                        from resources.lib.indexers.trakt_parts import TraktInterface
                        cur_poster = TraktInterface.get_simkl_poster_for_imdb(cur_imdb)
                    final_poster = self.clean_base64_data(cur_poster) if cur_poster else 'DefaultMovies.png'

                    try: rs = int(rev_torrent['seeders'])
                    except: rs = 0
                    try: rl = int(rev_torrent['leechers'])
                    except: rl = 0
                    
                    feltoltve_formatted = f'[COLOR orange][B]Feltöltve:[/B] {rev_upload_date}[/COLOR]'
                    parsed_details = self.parse_and_format_torrent_details(title_1, feltoltve_formatted)
                    
                    metadata = {
                        'title': f'[B]{title_1}[/B]', 
                        'plot': f'{plot_status_line}[COLOR lightgreen][B]Seeder:[/B] {rs}[COLOR magenta] | [/COLOR][B]Leecher:[/B] {rl}[/COLOR]\n{parsed_details["plot"]}'
                    }
                    
                    url_params = f'extr_bookmark_torrent&title_1={quote_plus(title_1)}&rev_upload_date={rev_upload_date}&rev_seeders={rs}&rev_leechers={rl}&torrent_id={t_id_str}'
                    
                    context_menu_items = [
                        ("[B][COLOR FFF56C00]Törlés a könyvjelzők közül[/COLOR][/B]", f'deleteBookmarkTorrentAction&torrent_id={t_id_str}&bookmark_group_id={bookmark_group_id}&megerositve_value={megerositve_value}&div_konyvjelzo_nev_id={rev_torrent["div_konyvjelzo_nev_id"]}'),
                        ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={t_id_str}")
                    ]
                    
                    self.addDirectoryItem(f'{indicator}{title_1}', url_params, final_poster, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=metadata)
                break
            except Exception as e:
                xbmc.log(f"Hiba az extrBookmark-ban: {e}", xbmc.LOGERROR)
                break

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def extrBookmarkTorrent(self, url, title_1, rev_upload_date, rev_seeders, rev_leechers, torrent_id):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import base64
        import re

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = nc_get(f'{base_url}/torrents.php?action=details&id={torrent_id}', cookies=cookies, headers=headers)
        soup = BeautifulSoup(resp.text, 'html.parser')

        if known_errors(str(soup)):
            return

        description = ''
        poster_link = ''
        clear_logo = ''
        tmdb = ''
        type_for_tmdb = ''
        imdb_id = ''

        title = title_1

        if re.search(r'imdb.*?(tt\d+)', str(soup)):
            imdb_id_matches = re.findall(r'imdb.*?(tt\d+)', str(soup))
            if imdb_id_matches:
                imdb_id = imdb_id_matches[0].strip()
            else:
                imdb_id = ''

            if imdb_id != '':
                response_2 = {}
                try:
                    first_try = f'{k_h_n_o}/tv/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}'
                    second_try = f'{k_h_n_o}/movies/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}'

                    response_2_req = nc_get(first_try)
                    response_2_req.raise_for_status()
                    response_2 = response_2_req.json()

                    if not response_2.get('poster'):
                        response_2_req = nc_get(second_try)
                        response_2_req.raise_for_status()
                        response_2 = response_2_req.json()

                except requests.exceptions.RequestException as e:
                    xbmc.log(f"{base_log_info}| extrBookmarkTorrent | Failed to get API data for IMDb ID {imdb_id}: {e}", xbmc.LOGINFO)
                except ValueError as e:
                    xbmc.log(f"{base_log_info}| extrBookmarkTorrent | Failed to decode JSON for IMDb ID {imdb_id}: {e}", xbmc.LOGINFO)

                if response_2:
                    description = response_2.get('overview', '')
                    tmdb = response_2.get('ids', {}).get('tmdb', '')
                    if tmdb != '':
                        try:
                            tmdb = int(tmdb)
                        except ValueError:
                            tmdb = ''

                    poster_link = response_2.get('poster', '')
                    if poster_link:
                        poster_link = f'{a_d}{s_s}{s_g}{poster_link}_m.jpg'
                    else:
                        poster_link = ''

                    type_for_tmdb = response_2.get('type', '')
                    if type_for_tmdb != 'movie':
                        type_for_tmdb = 'tv'

                    if tmdb and type_for_tmdb:
                        cookies_tmdb = {
                            'tmdb.prefs': '%7B%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D',
                            '__e_inc': '1',
                        }
                        headers_tmdb = {
                            'authority': 'www.themoviedb.org',
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6287.198 Safari/537.36',
                        }

                        html_tmdb = None
                        try:
                            html_tmdb_req = nc_get(f'https://www.themoviedb.org/{type_for_tmdb}/{tmdb}', cookies=cookies_tmdb, headers=headers_tmdb)
                            html_tmdb_req.raise_for_status()
                            html_tmdb = html_tmdb_req.text
                        except requests.exceptions.RequestException as e:
                            xbmc.log(f"{base_log_info}| extrBookmarkTorrent | Failed to get TMDB page for {type_for_tmdb}/{tmdb}: {e}", xbmc.LOGINFO)

                        if html_tmdb:
                            soup_tmdb = BeautifulSoup(html_tmdb, 'html.parser')
                            title_tag = soup_tmdb.find('meta', property='og:title')
                            title = title_tag['content'] if title_tag and 'content' in title_tag.attrs else title_1
                            description_tag = soup_tmdb.find('meta', property='og:description')
                            description = description_tag['content'] if description_tag and 'content' in description_tag.attrs else description
                else:
                    description = ''; poster_link = ''; clear_logo = ''; tmdb = ''; type_for_tmdb = ''
            else:
                imdb_id = ''; description = ''; poster_link = ''; clear_logo = ''; tmdb = ''; type_for_tmdb = ''
        else:
            description = ''; title = title_1; borito_link = ''; poster_link = ''
            try:
                borito_link_matches = re.findall(r'inforbar_img.*img src=\"(.*?)\?.*Borító', str(soup))
                if borito_link_matches:
                    borito_link = borito_link_matches[0].strip()
                else:
                    borito_link_matches = re.findall(r'inforbar_img.*Borító.*(http.*img.*)\?', str(soup))
                    if borito_link_matches:
                        borito_link = borito_link_matches[0].strip()
                    else:
                        borito_link_matches = re.findall(r'(http.*img.*)\?', str(soup))
                        if borito_link_matches:
                            borito_link = borito_link_matches[0].strip()
                        else:
                            poster_link = ''; borito_link = ''
            except Exception:
                poster_link = ''; borito_link = ''

            if proxy_needed == 'true' and borito_link:
                poster_link = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(borito_link, safe='')}"
            else:
                poster_link = borito_link if borito_link else ""
            clear_logo = ''; imdb_id = ''

        db_sync_data = self.db.get_indicators_for_list([imdb_id]) if imdb_id else {}
        db_local_played = set()
        
        db_torrent = self.db.get_torrent_details(torrent_id) if _local_tracking_on() else None
        if db_torrent:
            has_url = db_torrent.get('full_url') is not None and db_torrent.get('full_url') != ""
            with self.db._get_connection() as conn:
                has_pos = conn.execute('SELECT 1 FROM video_positions WHERE torrent_id = ? LIMIT 1', (str(torrent_id),)).fetchone() is not None
            if has_url or has_pos:
                db_local_played.add(str(torrent_id))

        indicator, plot_status_line, _ = self._build_indicators(imdb_id, str(torrent_id), db_sync_data, db_local_played)
        full_description = f"{plot_status_line}{description}"
        
        if not type_for_tmdb or type_for_tmdb == '':
            if re.search(r'[sS]\d+[eExX]\d+|\d+\.\s*évad|Season\s*\d+', title_1):
                type_for_tmdb = 'tv'
            else:
                type_for_tmdb = 'movie'

        if (not poster_link or poster_link == "") and imdb_id:
            from resources.lib.indexers.trakt_parts import TraktInterface
            poster_link = TraktInterface.get_simkl_poster_for_imdb(imdb_id)
        
        final_poster = self.clean_base64_data(poster_link) if poster_link else 'DefaultMovies.png'

        img_title = ''; sample_i = ''; sample_link = ''
        download_link = f'{torrent_id}'

        url_params = f'single_item_folder&url={quote_plus(str(download_link))}&torrent_id={quote_plus(str(torrent_id))}&imdb_id={quote_plus(str(imdb_id))}&poster_link={quote_plus(str(final_poster))}&clear_logo={quote_plus(str(clear_logo))}&description={quote_plus(str(description))}&title_1={quote_plus(str(title_1))}&tmdb_id={quote_plus(str(tmdb))}'

        add_series_watching = (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{imdb_id}')}&imdb_id={imdb_id}&title_1={quote_plus(title)}&title_2={quote_plus(title)}")
        bookmark_context = ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={torrent_id}")
        torrent_to_seed = ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={torrent_id}")
        context_menu_items = [add_series_watching, bookmark_context, torrent_to_seed]
        
        is_series_bool = 'true' if type_for_tmdb == 'tv' else 'false'

        if self.is_trakt_active():
            context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={imdb_id}&is_series={is_series_bool}"))
        if self.is_simkl_active():
            context_menu_items.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={imdb_id}&is_series={is_series_bool}"))

        self.addDirectoryItem(f'[B][COLOR lime][Lejátszás][/COLOR] {indicator}{title_1}[/B]', url_params, final_poster, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})

        for a_tag in soup.find_all('a', class_='fancy_groups'):
            img_tag = a_tag.find('img')
            if img_tag:
                parent_td = a_tag.find_parent('td')
                if parent_td:
                    em_tag = parent_td.find_next('em')
                    if em_tag:
                        img_title = em_tag.text.strip()
                        sample_i = a_tag.get('href', '')
                        sample_i = re.sub(r'\?.*', r'', sample_i)
                        if sample_i:
                            sample_link = f"http://{proxy_host}:{proxy_port}/?url={urllib.parse.quote(sample_i, safe='')}" if proxy_needed == 'true' else sample_i
                            self.addDirectoryItem(f'[B]sample kép {img_title}[/B]', '', sample_link, 'DefaultMovies.png', isFolder=False, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})

        if imdb_id != '':
            self.addDirectoryItem(f"[B][COLOR yellow]Más verziók (imdb: {imdb_id})[/COLOR][/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", final_poster, '', 'DefaultFolder.png', meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})

            self.addDirectoryItem(f"[B][COLOR lightgreen][I]--[/I] Szereplők (stáblista) [I]--[/I][/COLOR][/B]", f"get_cast_list&imdb_id={imdb_id}&media_type={type_for_tmdb}&poster_link={quote_plus(str(final_poster))}", final_poster, 'DefaultActor.png', isFolder=True, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})

            self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", final_poster, 'DefaultMovies.png', isFolder=True, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})

            if type_for_tmdb == 'movie':
                self.addDirectoryItem(f'[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]', f"tmdb_get_collection&tmdb_id={tmdb}&imdb_id={imdb_id}&torrent_id={torrent_id}", final_poster, 'DefaultMovies.png', isFolder=True, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})

            try:
                import requests
                response_1_x = {}
                try:
                    response_1_x_req = nc_get(f'{ab_t}.{kf_t}/search/id?imdb={imdb_id}&extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}')
                    response_1_x_req.raise_for_status()
                    response_1_x = response_1_x_req.json()
                except: pass
                simkl_id = response_1_x[0]['ids'].get('simkl', '') if response_1_x and len(response_1_x) > 0 and 'ids' in response_1_x[0] else ''
                response_2_x = {}
                if simkl_id:
                    try:
                        response_2_x_req = nc_get(f'{a_d}{c_d}{i_d}{simkl_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}')
                        response_2_x_req.raise_for_status()
                        response_2_x = response_2_x_req.json()
                    except: pass
                trailer_name = ''; trailer_id = ''
                if response_2_x and 'trailers' in response_2_x and len(response_2_x['trailers']) > 0:
                    trailer_name = response_2_x['trailers'][0].get('name', '')
                    trailer_id = response_2_x['trailers'][0].get('youtube', '')
                if trailer_name and trailer_id:
                    self.addDirectoryItem(f"[B][COLOR lime][Bemutató][/COLOR] ({trailer_name}):[/B] {title_1}", f'plugin://plugin.video.youtube/play/?video_id={trailer_id}', final_poster, 'DefaultFolder.png', isFolder=False, isAction=False, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})
            except: pass

            if torrent_id and imdb_id:
                try:
                    from datetime import datetime
                    save_data = { 'torrent_id': str(torrent_id), 'imdb_id': str(imdb_id), 'title_1': title_1, 'title_2': title, 'poster_link': final_poster, 'description': description, 'timestamp': datetime.now().isoformat() }
                    self.db.save_torrent_metadata(save_data)
                except: pass

        url_params_2 = f'get_file_list&torrent_id={quote_plus(str(torrent_id))}&tmdb_id={quote_plus(str(tmdb))}&imdb_id={quote_plus(str(imdb_id))}&poster_link={quote_plus(str(final_poster))}&title_1={quote_plus(str(title_1))}&title_2={quote_plus(str(title))}&description={quote_plus(str(description))}'
        
        self.addDirectoryItem(f'[B][COLOR orange][FájlLista][/COLOR] (.torrent fájl tartalma)[/B]', url_params_2, final_poster, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta={"title": title_1, "plot": f'\n\n[B]{title_1}[/B]\n\n{full_description}'})
        
        self.endDirectory(user_change_view)


    def getSeededTorrents(self, url, title_1, torrent_id):
        from bs4 import BeautifulSoup
        import requests
        import datetime
        import urllib.parse

        current_page = int(self.params.get('page', 1))
        items_per_page = 20

        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        resp = requests.get(f'{base_url}/profile.php', cookies=cookies, headers=headers, timeout=30)

        soup = BeautifulSoup(resp.text, 'html.parser')
        
        if known_errors(str(soup)): return

        profile_divs = {div.get('id'): div for div in soup.find_all('div', id=True) if div.get('id')}

        if not profile_divs:
            self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
            return

        all_boxes = soup.find_all('div', class_='box_torrent_mini')

        valid_torrent_types = {"xvid_hun", "xvid", "hd_hun", "xvidser_hun", "xvidser", "hd", "hdser_hun", "hdser", "mp3_hun", "mp3", "lossless_hun", "lossless", "clip"}
        if xxx_contents == 'true': valid_torrent_types.update({"xxx_xvid", "xxx_hd"})
        
        valid_boxes = []
        for box in all_boxes:
            a_tag = box.find('a')
            if a_tag and a_tag.get('href'):
                t_type = a_tag['href'].split('=')[-1]
                if t_type in valid_torrent_types:
                    valid_boxes.append(box)

        total_items = len(valid_boxes)
        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paged_boxes = valid_boxes[start_idx:end_idx]
        remaining = total_items - end_idx

        temp_t_ids = []
        for b in paged_boxes:
            txt_div = b.find('div', class_='torrent_txt_mini')
            if txt_div and txt_div.find('a'):
                onc = str(txt_div.find('a').get('onclick', ''))
                if '(' in onc: temp_t_ids.append(onc.split('(')[1].split(')')[0])

        db_sync_data = {}      
        db_truly_played = set() 
        db_torrent_to_imdb = {} 
        db_torrent_to_poster = {}

        if temp_t_ids:
            with self.db._get_connection() as conn:
                placeholders = ', '.join(['?'] * len(temp_t_ids))
                t_rows = conn.execute(f'SELECT torrent_id, imdb_id, full_url, poster_link FROM torrents WHERE torrent_id IN ({placeholders})', temp_t_ids).fetchall()
                
                found_imdb_ids = []
                for r in t_rows:
                    tid, iid = r['torrent_id'], r['imdb_id']
                    db_torrent_to_imdb[tid] = iid
                    db_torrent_to_poster[tid] = r['poster_link']
                    if iid: found_imdb_ids.append(iid)
                    
                    has_url = r['full_url'] is not None and r['full_url'] != ""
                    has_pos = conn.execute('SELECT 1 FROM video_positions WHERE torrent_id = ? LIMIT 1', (tid,)).fetchone() is not None
                    if has_url or has_pos:
                        db_truly_played.add(tid)
                
                if found_imdb_ids:
                    db_sync_data = self.db.get_indicators_for_list(found_imdb_ids)

        torrents = []
        for box in paged_boxes:
            try:
                torrent_type = box.find('a')['href'].split('=')[-1]
                torrent_info_a_tag = box.find('div', class_='torrent_txt_mini').find('a')
                onclick_attr = torrent_info_a_tag.get('onclick')
                torrent_title = torrent_info_a_tag.get('title')
                current_t_id = onclick_attr.split('(')[1].split(')')[0]

                profile_div = profile_divs.get(current_t_id)
                if not profile_div: continue

                tables = profile_div.find_all('table')
                if len(tables) < 2 or not tables[1].find_all('td'): continue
                upload_time_str = tables[1].find_all('td')[0].text.strip()

                current_imdb = db_torrent_to_imdb.get(current_t_id)
                seeded_poster = db_torrent_to_poster.get(current_t_id)
                if (not seeded_poster or seeded_poster == "") and current_imdb:
                    from resources.lib.indexers.trakt_parts import TraktInterface
                    seeded_poster = TraktInterface.get_simkl_poster_for_imdb(current_imdb)
                
                final_poster = self.clean_base64_data(seeded_poster) if seeded_poster else 'DefaultMovies.png'

                indicator, plot_status_line, is_already_played = self._build_indicators(current_imdb, current_t_id, db_sync_data, db_truly_played)

                parsed_details = self.parse_and_format_torrent_details(torrent_title, f'[COLOR orange][B]Feltöltve:[/B] {upload_time_str}[/COLOR]')

                display_indicator = f"{indicator} " if indicator else ""

                torrents.append({
                    'torrent_id': current_t_id,
                    'torrent_title': torrent_title,
                    'display_title': f"{display_indicator}{torrent_title}",
                    'torrent_link': f'https://ncore.pro/torrents.php?action=details&id={current_t_id}',
                    'poster': final_poster,
                    'metadata': {'plot': f'{plot_status_line}[COLOR yellow][B]Kategória:[/B] {torrent_type}[/COLOR]\n{parsed_details["plot"]}'}
                })
            except: continue

        for t in torrents:
            url_params = f'extr_bookmark_torrent&url={urllib.parse.quote_plus(t["torrent_link"])}&title_1={urllib.parse.quote_plus(t["torrent_title"])}&torrent_id={t["torrent_id"]}'
            c_m = [
                ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f'getContextBookmark&torrent_id={t["torrent_id"]}'),
                ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={t['torrent_id']}")
            ]
            self.addDirectoryItem(t['display_title'], url_params, t.get('poster', 'DefaultMovies.png'), 'DefaultMovies.png', context=c_m, isFolder=True, meta=t['metadata'])

        if remaining > 0:
            u_next = f"seeded_torrents&page={current_page + 1}"
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal (Még {remaining} db) >>>[/COLOR][/B]", u_next, '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)


    def manage_saved_positions(self, torrent_id):
        player = xbmc.Player()
        if not player.isPlaying(): return

        current_file_name = self.clean_display_path(player.getPlayingFile())

        with self.db._get_connection() as conn:
            cursor = conn.execute('''
                SELECT * FROM video_positions 
                WHERE torrent_id = ? AND file_name = ? 
                ORDER BY timestamp DESC
            ''', (str(torrent_id), current_file_name))
            positions = [dict(row) for row in cursor.fetchall()]

        if not positions:
            xbmcgui.Dialog().notification("Infó", "Nincs mentett pozíció ehhez a részhez.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        labels = [f"[COLOR red]TÖRLÉS:[/COLOR] [B]{p['label']}[/B]" for p in positions]
        selection = xbmcgui.Dialog().select("Melyik mentett pozíciót töröljük?", labels)
        
        if selection != -1:
            target = positions[selection]
            self.db.delete_video_position(target['torrent_id'], target['file_name'], target['position'])
            xbmcgui.Dialog().notification("Törölve", f"Pozíció törölve: {target['label']}", xbmcgui.NOTIFICATION_INFO, 3000)

    def save_current_position(self, torrent_id):
        player = xbmc.Player()
        if not player.isPlaying(): return

        if not _local_tracking_on():
            xbmcgui.Dialog().notification("nCore TV", "Lokális követés kikapcsolva", xbmcgui.NOTIFICATION_INFO, 2500)
            return

        current_time = player.getTime()
        if current_time < 10: return 

        playing_file = player.getPlayingFile()
        clean_file_name = self.clean_display_path(playing_file)

        try:
            self.db.save_torrent_metadata({'torrent_id': str(torrent_id)})
        except: pass

        label = time.strftime('%H:%M:%S', time.gmtime(float(current_time)))
        self.db.add_video_position(str(torrent_id), clean_file_name, current_time, label)
        
        xbmcgui.Dialog().notification("Pozíció mentve", f"{clean_file_name[:20]}... @ {label}", xbmcgui.NOTIFICATION_INFO, 3000)

    def get_saved_positions(self, torrent_id):
        torrents = self.load_played_torrents()
        for torrent in torrents:
            if torrent.get('torrent_id') == torrent_id:
                return torrent.get('video_saved_position', [])
        return []

    def load_saved_position(self, torrent_id):
        player = xbmc.Player()
        if not player.isPlaying(): return

        current_file_name = self.clean_display_path(player.getPlayingFile())

        relevant_items = self.db.get_video_positions(str(torrent_id), current_file_name)
        
        if not relevant_items:
            xbmcgui.Dialog().notification("nCore TV", "Nincs mentett pozíció ehhez a részhez.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        labels = [f"Ugrás: [B]{i['label']}[/B]" for i in relevant_items]
        selection = xbmcgui.Dialog().select("Válassz pozíciót", labels)
        
        if selection != -1:
            seek_to = float(relevant_items[selection]['position'])
            player.seekTime(seek_to)
            xbmcgui.Dialog().notification("nCore TV", "Pozíció betöltve.", xbmcgui.NOTIFICATION_INFO, 2000)
    
    def get_storage_path(self):
        return self.local_played_torrents_file

    def load_played_torrents(self):
        torrents, _ = self.db.get_played_torrents(page=1, items_per_page=1000)

        if not torrents and os.path.exists(self.local_played_torrents_file):
            self.db.migrate_from_json(self.local_played_torrents_file)
            torrents, _ = self.db.get_played_torrents(page=1, items_per_page=1000)
            
        return torrents

    def save_data_automatically(self, file_path, data):
        target_file_path = translatePath(file_path)
        temporary_file = target_file_path + ".tmp"
        backup_file = target_file_path + ".bak"
        
        with global_write_lock:
            try:
                serialized_data = json.dumps(data, indent=2, ensure_ascii=False)

                with open(temporary_file, 'w', encoding='utf-8') as f:
                    f.write(serialized_data)
                    f.flush()
                    os.fsync(f.fileno())
     
                if os.path.exists(target_file_path):
                    if os.path.exists(backup_file): 
                        os.remove(backup_file)
                    os.rename(target_file_path, backup_file)

                if sys.platform == "win32" and os.path.exists(target_file_path):
                    os.remove(target_file_path)
                os.rename(temporary_file, target_file_path)
                
                return True
            except Exception as e:
                xbmc.log(f"[nCore_TV] KRITIKUS MENTÉSI HIBA: {str(e)}", xbmc.LOGERROR)
                if os.path.exists(temporary_file):
                    try: os.remove(temporary_file)
                    except: pass
                return False

    def save_played_torrents(self, data):
        # xbmc.log("[nCore_TV] Régi JSON mentés hívva - az adatok már az SQL-ben vannak.", xbmc.LOGDEBUG)
        return True


    def update_played_torrent_urls_migration(self):
        torrents_data = self.load_played_torrents()
        if not torrents_data or len(torrents_data) == 0:
            return

        url_pattern = r'plugin:\/\/plugin\.video\.elementum\/play\?uri=https?%3A%2F%2Fncore\.pro%2Ftorrents\.php%3Faction%3Ddownload%26id%3D(\d+)(%26key%3D)?'

        changes_made = False
        for entry in torrents_data:
            if "url" in entry and isinstance(entry["url"], str):
                match = re.search(url_pattern, entry["url"])
                if match:
                    new_url = f"{match.group(1)}{match.group(2) if match.group(2) else ''}"
                    if new_url != entry["url"]:
                        entry["url"] = new_url
                        changes_made = True

        if changes_made:
            self.save_played_torrents(torrents_data)

    def getContextBookmark(self, torrent_id):
        plugin_next_action = f"plugin://{addon_str}/?action=extContextBookmark&torrent_id={torrent_id}"
        xbmc.executebuiltin(f'Container.Update({plugin_next_action})')

    def extContextBookmark(self, torrent_id):
        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        try:
            resp = nc_get(f'{base_url}/ajax.php?action=bookmark_add&addlist=1', cookies=cookies, headers=headers).text
        except requests.exceptions.RequestException as e:
            xbmcgui.Dialog().ok("Hiba", f"Nem sikerült lekérni a könyvjelzőket: {e}")
            return

        regex_pattern = re.compile(r"new Option\('([^']*)', '([^']*)'")
        matches = regex_pattern.findall(resp)

        bookmark_names_for_dialog = []
        bookmark_data_map = []

        if not matches:
            xbmcgui.Dialog().ok("Információ", "Nincsenek elérhető könyvjelző csoportok.")
            return

        for bookmark_name, bookmark_group_id in matches:
            bookmark_names_for_dialog.append(f'[B]Hozzáadás ide: [COLOR lime]{bookmark_name}[/COLOR][/B]')
            bookmark_data_map.append({
                'bookmark_name': bookmark_name,
                'bookmark_group_id': bookmark_group_id,
                'torrent_id': torrent_id
            })

        dialog = xbmcgui.Dialog()
        selected_index = dialog.select("Válassz könyvjelző csoportot", bookmark_names_for_dialog)

        if selected_index >= 0:
            selected_bookmark_data = bookmark_data_map[selected_index]

            self.AddToContextBookmark(
                selected_bookmark_data['torrent_id'],
                selected_bookmark_data['bookmark_name'],
                selected_bookmark_data['bookmark_group_id']
            )
        else:
            xbmcgui.Dialog().notification("[COLOR FFF56C00]Mégse[/COLOR]", "Könyvjelző hozzáadása megszakítva.", time=2000)

    def AddToContextBookmark(self, torrent_id, bookmark_name, bookmark_group_id):
        dialog = xbmcgui.Dialog()
        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        try:
            resp = nc_get(f'{base_url}/ajax.php?action=bookmark_add&id={torrent_id}&group={bookmark_group_id}', cookies=cookies, headers=headers)
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            dialog.notification(
                "Hiba", f'Nem sikerült hozzáadni a könyvjelzőhöz: {e}")', time=3000
            )
            
            return

        soup = BeautifulSoup(resp.text, 'html.parser')
        
        div_element = soup.find('div', class_='bookmark_close_text')
        if div_element:
            extracted_text = div_element.get_text(strip=True)
            dialog.notification(
                f"{bookmark_name}", f'{extracted_text}', time=3000
            )

    def autoAddBookmark(self, torrent_id, bookmark_name, bookmark_group_id):
        dialog = xbmcgui.Dialog()
        cookies = {
            'nick': user_name,
            'pass': saved_pass_cookie,
        }

        try:
            resp = nc_get(f'{base_url}/ajax.php?action=bookmark_add&id={torrent_id}&group={bookmark_group_id}', cookies=cookies, headers=headers)
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            dialog.notification(
                "Hiba", f'Nem sikerült hozzáadni a könyvjelzőhöz: {e}")', time=3000
            )

    def context_torrent_to_seed(self, torrent_id):
        plugin_next_action = f"plugin://{addon_str}/?action=download_torrent_to_seed&torrent_id={torrent_id}"
        xbmc.executebuiltin(f'Container.Update({plugin_next_action})')

    def sanitize_filename(self, filename):
        illegal_chars = r'[<>:"/\\|?*\x00-\x1f]'
        sanitized_filename = re.sub(illegal_chars, '_', filename)
        sanitized_filename = sanitized_filename.strip()

        if len(sanitized_filename) > 250:
            sanitized_filename = sanitized_filename[:250]

        return sanitized_filename

    def clean_display_path(self, full_url):
        if not full_url:
            return ""

        decoded_url = unquote_plus(full_url)
        clean_path = decoded_url

        match = re.search(r'(?:[a-zA-Z]:[/\\]|/)?(?:.+?[/\\])?(?:https?:[/\\]+)?127\.0\.0\.1:\d+[/\\]+(files|temp_elementum_cache)[/\\]+(.+)', decoded_url, re.IGNORECASE)

        if match:
            clean_path = match.group(2)
            clean_path = clean_path.replace('\\', '/')
        else:
            clean_path = decoded_url

        return os.path.basename(clean_path)

    def get_target_download_path(self, torrent_filename, torrent_id):
        dialog = xbmcgui.Dialog()

        processed_filename_for_display = torrent_filename
        for old_tag, new_tag in CATEGORY_MAP.items():
            if old_tag in processed_filename_for_display:
                processed_filename_for_display = processed_filename_for_display.replace(old_tag, new_tag)
                break 

        chosen_path = dialog.browse(
            type=0, 
            heading=f'[B][COLOR lime]Válaszd ki a .torrent fájl letöltési helyét:[/COLOR][/B]\n[COLOR white]{processed_filename_for_display}[/COLOR]\n',
            shares='files', 
            mask='', 
            useThumbs=False, 
            treatAsFolder=True, 
            defaultt='' 
        )

        if not chosen_path:
            #xbmc.log("User cancelled path selection for torrent.", xbmc.LOGINFO)
            dialog.notification(
                '[B][COLOR FFF56C00]Mégsem[/COLOR][/B]', 
                'A .torrent fájl letöltése megszakítva.',
                xbmcgui.NOTIFICATION_WARNING,
                3000
            )
            return None

        #xbmc.log(f"User chose initial download path: {chosen_path}", xbmc.LOGINFO)
        final_download_path = chosen_path 
        
        while True:
            current_folder_display = os.path.basename(final_download_path)
            if not current_folder_display: 
                current_folder_display = final_download_path 
            
            response = dialog.yesno(
                '[B][COLOR yellow]Új mappa létrehozása?[/COLOR][/B]',
                f' Szeretne új mappát létrehozni?\n pl. egy adott sorozatnak főmappát?\n vagy almappát: S07',
                nolabel='Nem',
                yeslabel='Igen'
            )
            
            if response:
                suggested_folder_name = re.sub(r'\[nCore\]\[[^\]]+\]|\[nCore\]|\.torrent', '', torrent_filename).strip()
                suggested_folder_name = re.sub(r'[._\s]+', ' ', suggested_folder_name).strip() 
                suggested_folder_name = self.sanitize_filename(suggested_folder_name)
                
                if not suggested_folder_name:
                    suggested_folder_name = f"Torrent_{torrent_id}" 

                new_folder_name = dialog.input(
                    f'[B][COLOR lime]Add meg az új mappa nevét (a(z) \n"{current_folder_display}" mappában)[/COLOR][/B]',
                    type=xbmcgui.INPUT_ALPHANUM,
                    defaultt=suggested_folder_name
                )
                
                if new_folder_name is None or new_folder_name == "": 
                    #xbmc.log("User cancelled new folder name input (or empty).", xbmc.LOGINFO)
                    dialog.notification(
                        '[B][COLOR FFF56C00]Mégsem[/COLOR][/B]', 
                        'A .torrent fájl letöltése megszakítva.',
                        xbmcgui.NOTIFICATION_WARNING,
                        3000
                    )
                    return None 
                else: 
                    sanitized_folder_name = self.sanitize_filename(new_folder_name)
                    potential_new_path = os.path.join(final_download_path, sanitized_folder_name)
                    #xbmc.log(f"Attempting to create directory: {potential_new_path}", xbmc.LOGINFO)

                    if not xbmcvfs.exists(potential_new_path):
                        if xbmcvfs.mkdir(potential_new_path):
                            #xbmc.log(f"Successfully created new directory: {potential_new_path}", xbmc.LOGINFO)
                            dialog.notification(
                                '[B][COLOR lime]Mappa létrehozva![/COLOR][/B]', 
                                f'"{new_folder_name}" mappa létrehozva.', 
                                xbmcgui.NOTIFICATION_INFO, 
                                3000
                            )
                            final_download_path = potential_new_path 
                        else:
                            #xbmc.log(f"Failed to create directory '{potential_new_path}'. Permission or network issue?", xbmc.LOGERROR) 
                            dialog.notification(
                                '[B][COLOR FFF56C00]Hiba! (Engedélyek?)[/COLOR][/B]', 
                                f'Nem sikerült létrehozni a mappát: "{new_folder_name}". Ellenőrizze a jogosultságokat vagy a hálózati elérhetőséget!', 
                                xbmcgui.NOTIFICATION_ERROR, 
                                7000
                            )
                            return None 
                    else: 
                        #xbmc.log(f"Directory already exists: {potential_new_path}. Will use this path.", xbmc.LOGWARNING) 
                        dialog.notification(
                            '[B][COLOR orange]Mappa már létezik![/COLOR][/B]', 
                            f'"{new_folder_name}" mappa már létezik. Ide folytatjuk.', 
                            xbmcgui.NOTIFICATION_WARNING, 
                            3000
                        )
                        final_download_path = potential_new_path
            else: 
                #xbmc.log("A felhasználó úgy döntött, hogy nem hoz létre több alkönyvtárat...", xbmc.LOGINFO)
                break 
        
        #xbmc.log(f"Final determined download path: {final_download_path}", xbmc.LOGINFO)
        return final_download_path 

    def download_torrent_to_seed(self, torrent_id):
        dialog = xbmcgui.Dialog()

        torrent_download_url = f"https://ncore.pro/torrents.php?action=download&id={torrent_id}&key={pass_k}" 

        torrent_filename = None
        torrent_data = None 

        #xbmc.log(f"Attempting to download torrent file from: {torrent_download_url}", xbmc.LOGINFO)
        try:
            response = nc_get(torrent_download_url, stream=True)
            response.raise_for_status() 

            content_disposition = response.headers.get('Content-Disposition')
            if content_disposition:
                matches = re.findall(r'filename\*?=(?:UTF-8\'\')?\"?([^"]+)\"?', content_disposition)
                if matches:
                    torrent_filename = requests.utils.unquote(matches[-1]) 
                    #xbmc.log(f"Extracted actual torrent filename: {torrent_filename} from Content-Disposition", xbmc.LOGINFO)
            
            if not torrent_filename:
                torrent_filename = f"torrent_{torrent_id}.torrent"
            torrent_data = response.content

        except requests.exceptions.RequestException as e:
            #xbmc.log(f"Error downloading torrent (requests): {e}", xbmc.LOGERROR) 
            dialog.notification(
                '[B][COLOR FFF56C00]Letöltési hiba![/COLOR][/B]', 
                f'Hiba történt a .torrent fájl előzetes letöltésekor: {e}', 
                xbmcgui.NOTIFICATION_ERROR, 
                7000
            )
            return 

        final_download_path = self.get_target_download_path(torrent_filename, torrent_id)
        if final_download_path is None: 
            return 

        full_save_path = os.path.join(final_download_path, torrent_filename) 
        if xbmcvfs.exists(full_save_path):
            #xbmc.log(f"Torrent file already exists at: {full_save_path}. Prompting user for overwrite.", xbmc.LOGINFO)
            overwrite_response = dialog.yesno(
                '[B][COLOR orange]Fájl már létezik![/COLOR][/B]',
                f'[B]Szeretné felülírni?[/B]\n\nA .torrent fájl már létezik ezen a helyen:\n[COLOR white]{os.path.basename(full_save_path)}[/COLOR]\n',
                nolabel='Nem',
                yeslabel='Igen'
            )

            if not overwrite_response: 
                #xbmc.log(f"User chose NOT to overwrite existing torrent file: {full_save_path}. Skipping save.", xbmc.LOGINFO)
                dialog.notification(
                    '[B][COLOR orange]Mentés kihagyva![/COLOR][/B]', 
                    f'A .torrent fájl felülírása kihagyva.', 
                    xbmcgui.NOTIFICATION_INFO, 
                    3000
                )
                return
        
        try:
            with xbmcvfs.File(full_save_path, 'wb') as f:
                f.write(torrent_data)
            
            #xbmc.log(f"Successfully saved .torrent file to: {full_save_path}", xbmc.LOGINFO)
            dialog.notification(
                '[B][COLOR lime]Sikeres letöltés![/COLOR][/B]',
                f'.torrent fájl letöltve ide: [COLOR white]{full_save_path}[/COLOR]',
                xbmcgui.NOTIFICATION_INFO,
                5000
            )
        except IOError as e:
            #xbmc.log(f"Error saving torrent (xbmcvfs): {e}", xbmc.LOGERROR)
            dialog.notification(
                '[B][COLOR FFF56C00]Mentési hiba! (Jogosultság?)[/COLOR][/B]',
                f'Nem sikerült elmenteni a .torrent fájlt ide: [COLOR white]{final_download_path}[/COLOR]. Lehet, hogy nincs írási jogosultság.',
                xbmcgui.NOTIFICATION_ERROR,
                10000
            )
        except Exception as e:
            #xbmc.log(f"An unexpected error occurred during save: {e}", xbmc.LOGERROR)
            dialog.notification(
                '[B][COLOR FFF56C00]Ismeretlen hiba![/COLOR][/B]',
                f'Váratlan hiba történt: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                7000
            )
    
    
    def torrent_filename_and_category(self, torrent_id):
        dialog = xbmcgui.Dialog()
    
        torrent_download_url = f"https://ncore.pro/torrents.php?action=download&id={torrent_id}&key={pass_k}"
    
        torrent_filename = None
        torrent_category = None
    
        try:
            response = requests.head(torrent_download_url, allow_redirects=True)
            response.raise_for_status()
    
            content_disposition = response.headers.get('Content-Disposition')
            if content_disposition:
                matches = re.findall(r'filename\*?=(?:UTF-8\'\')?\"?([^"]+)\"?', content_disposition)
                if matches:
                    torrent_filename = requests.utils.unquote(matches[-1])
                    #xbmc.log(f"Extracted torrent filename: {torrent_filename}", xbmc.LOGINFO)
    
                    category_match = re.search(r'\[([^\]]+)\]', torrent_filename)
                    if category_match and '[' in category_match.group(0):
                        all_matches = re.findall(r'\[([^\]]+)\]', torrent_filename)
                        if len(all_matches) >= 2:
                            torrent_category = all_matches[1]
                            #xbmc.log(f"Extracted torrent category: {torrent_category}", xbmc.LOGINFO)
    
        except requests.exceptions.RequestException as e:
            xbmc.log(f"Error getting torrent data: {e}", xbmc.LOGERROR)
            dialog.notification(
                '[B][COLOR FFF56C00]Letöltési hiba![/COLOR][/B]',
                f'Hiba történt a .torrent adatok lekérésekor: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                7000
            )
            return None, None
    
        return torrent_filename, torrent_category

    def format_seconds(self, seconds):
        return time.strftime('%H:%M:%S', time.gmtime(float(seconds)))

    def sync_torrent_files_to_db(self, torrent_id):
        import requests
        from bs4 import BeautifulSoup
        import os

        params = {'action': 'files', 'id': str(torrent_id)}
        cookies = {'nick': user_name, 'pass': saved_pass_cookie}
        
        try:
            r = requests.get('https://ncore.pro/ajax.php', params=params, cookies=cookies, timeout=10)
            if r.status_code == 200:
                soup = BeautifulSoup(r.text, 'html.parser')
                rows = soup.find_all('tr', class_=['listrow_odd', 'listrow_even'])

                all_files = []
                for row in rows:
                    cols = row.find_all('td')
                    if len(cols) >= 2:
                        path = cols[1].get_text(strip=True)
                        all_files.append(os.path.basename(path.replace('\\', '/')))
                
                if all_files:
                    self.db.update_torrent_files(torrent_id, all_files)
        except Exception as e:
            xbmc.log(f"[nCore_SQL] Kritikus hiba a szinkron alatt: {str(e)}", xbmc.LOGERROR)
    
    @staticmethod
    def parse_plugin_url(url):
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)
        
        params = {}
        for k, v in query_params.items():
            params[k] = v[0] if len(v) == 1 else v
    
        return params

    def wait_for_playback(self, timeout=80000, poll_interval=1000):
        player = xbmc.Player()
        elapsed = 0
        
        #xbmc.log("Waiting for playback to start for file reference...", xbmc.LOGINFO)
        _wm = xbmc.Monitor()
        while not player.isPlaying() and elapsed < timeout:
            if _wm.waitForAbort(0.25): break
            elapsed += 250
        
        if player.isPlaying():
            #xbmc.log(f"Playback started, file: {player.getPlayingFile()}", xbmc.LOGINFO)
            return player.getPlayingFile()
        else:
            #xbmc.log("Playback did not start within timeout.", xbmc.LOGWARNING)
            return None

    def _run_cloud_sync_task(self, service_type, imdb_id, season, episode, tmdb_id, status_type, current_seconds, total_seconds, display_info, silent=False, is_cleanup=False):
        if xbmc.Monitor().abortRequested():
            return

        s_lbl = "utoljára:" if season is not None else ":"
        s_txt = f"S{season:02d}E{episode:02d}" if season is not None else "[COLOR lime]Láttam[/COLOR]"

        if service_type == 'trakt' and self.is_trakt_active():
            try:
                success = False
                if status_type == 'watched':
                    success = TraktInterface.trakt_scrobble(imdb_id, season, episode)
                    if success:
                        if is_cleanup:
                            TraktInterface.clear_trakt_playback(imdb_id)
                        else:
                            import threading
                            threading.Thread(target=TraktInterface.clear_trakt_playback, args=(imdb_id,)).start()
                else:
                    success = TraktInterface.trakt_scrobble_manager(imdb_id, status_type, (current_seconds/total_seconds)*100, season, episode)
                
                if success and status_type == 'watched':
                    self.db.update_single_service_status(imdb_id, 'trakt', f"[B][COLOR orange]Trakt {s_lbl}[/COLOR][/B] {s_txt}")
                    if not silent and addon.getSetting('trakt_notif_enabled') == 'true':
                        xbmcgui.Dialog().notification("Trakt", f"[B]{display_info}[/B]\nMegtekintve", trakt_notif_icon, 3000)
            except Exception as e:
                xbmc.log(f"[nCore_SYNC] Trakt hiba: {str(e)}", xbmc.LOGERROR)

        if service_type == 'simkl' and self.is_simkl_active():
            try:
                progress = 100 if status_type == 'watched' else (current_seconds/total_seconds)*100
                action = 'stop' if status_type == 'watched' else status_type
                
                res = SimklInterface.simkl_scrobble_manager(imdb_id, action, progress, season, episode, tmdb_id)
                if res and status_type == 'watched':
                    self.db.update_single_service_status(imdb_id, 'simkl', f"[B][COLOR cyan]Simkl {s_lbl}[/COLOR][/B] {s_txt}")

                    if not silent and addon.getSetting('simkl_notif_enabled') == 'true':
                        xbmc.sleep(500) 
                        xbmcgui.Dialog().notification("Simkl", f"[B]{display_info}[/B]\nMegtekintve", simkl_notif_icon, 3000)
            except Exception as e:
                xbmc.log(f"[nCore_SYNC] Simkl hiba: {str(e)}", xbmc.LOGERROR)

        if service_type == 'plex' and self.is_plex_active():
            try:
                action = 'watched' if status_type == 'watched' else status_type
                res = PlexInterface.plex_scrobble_manager(imdb_id, action, current_seconds, season, episode, total_seconds)
                
                if res and status_type == 'watched':
                    self.db.update_single_service_status(imdb_id, 'plex', f"[B][COLOR dodgerblue]Plex {s_lbl}[/COLOR][/B] {s_txt}")

                    if not silent and addon.getSetting('plex_notif_enabled') == 'true':
                        xbmc.sleep(500)
                        xbmcgui.Dialog().notification("Plex", f"[B]{display_info}[/B]\nMegtekintve", plex_notif_icon, 3000)
            except Exception as e:
                xbmc.log(f"[nCore_SYNC] Plex hiba: {str(e)}", xbmc.LOGERROR)


    def playMovie(self, url, poster_link, clear_logo, imdb_id, c_i):
        # --- BLOCK 1: IMPORTS & INITIAL SETUP ---
        from datetime import datetime
        import time, base64, json, os, urllib.parse, re, threading
        from resources.lib.indexers.trakt_parts import TraktInterface
        from resources.lib.indexers.simkl_tracks import SimklInterface
        from resources.lib.indexers.plex_tracks import PlexInterface
        from urllib.parse import unquote, unquote_plus
        
        def dlog(msg): xbmc.log(f"[nCore_DEBUG] {msg}", xbmc.LOGINFO)
        dlog("playMovie elindult.")

        # --- BLOCK 2: PLAYBACK SESSION TOKEN ---
        this_session_token = time.time()
        self.active_playback_token = this_session_token

        # --- BLOCK 3: KRITIKUS VÁLTOZÓK INICIALIZÁLÁSA ---
        full_duration = 0
        total_file_seconds = 0
        last_known_seconds = 0
        current_pct = 0
        playback_finished_flag = False
        sync_started_sent = False 
        last_pause_toggle_state = False
        notified_sync_threshold = False
        playback_dialog_interceptor = None
        file_ref = ""
        original_params = {}
        save_params = {}

        # --- BLOCK 4: SETTINGS CAPTURE ---
        trakt_notif_ok = addon.getSetting('trakt_notif_enabled') == 'true'
        simkl_notif_ok = addon.getSetting('simkl_notif_enabled') == 'true'
        plex_notif_ok = addon.getSetting('plex_notif_enabled') == 'true'
        
        extra_pause_menu_enabled = addon.getSetting('extra_pause_menu') == 'true'
        auto_add_bookmark_enabled = addon.getSetting('auto_add_bookmark') == 'true'
        show_notif_for_auto_bookmark = addon.getSetting('show_notif_for_auto_bookmark') == 'true'

        # --- BLOCK 5: LOCAL HELPER FUNCTIONS ---
        def local_format_label(prefix, full_name):
            if not full_name: return prefix

            clean_name = unquote_plus(full_name)
            
            match = re.search(r'[sS](\d{1,2})[eExX](\d{1,2})', clean_name)
            if match:
                s = int(match.group(1))
                e = int(match.group(2))
                tag = f"[B][COLOR white]S{s:02d}E{e:02d}[/COLOR][/B]"
                return f"{prefix} {tag}"
            else:
                return f"{prefix} {clean_name}"      
        
        def local_extract_season_episode(text):
            if not text: return None, None
            patterns = [
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
            ]
            for series_patt in patterns:
                match = re.search(series_patt, str(text))
                if match: return int(match.group('season')), int(match.group('episode'))
            return None, None

        def local_clean_display_path(path):
            if not path: return ''
            return os.path.basename(path)

        def encode_base64_local(data_to_encode):
            if data_to_encode is None: return ''
            return base64.b64encode(str(data_to_encode).encode()).decode()

        # --- BLOCK 6: ELEMENTUM CHECK & PARAMETER PARSING ---
        try:
            check_exist_elementum()
            
            plugin_arguments = sys.argv[2]
            original_params = self.parse_plugin_url(plugin_arguments)
            current_torrent_id = str(original_params.get('torrent_id', ''))
            tmdb_id_reference = original_params.get('tmdb_id')

            # --- BLOCK 7: DATA CLEANING (POSTER / C_I) ---
            cleaned_poster_url = self.clean_base64_data(poster_link)
            cleaned_c_i_url = self.clean_base64_data(c_i)
            
            save_params = original_params.copy()
            save_params['poster_link'] = cleaned_poster_url
            save_params['c_i'] = cleaned_c_i_url
            if str(save_params.get('clear_logo', '')).lower() == "none":
                save_params['clear_logo'] = ""

            # --- BLOCK 8: ELEMENTUM URL CONFIGURATION ---
            url_fixed = url.replace('&', '%26').replace('%2526', '%26')
            if '%26' not in url_fixed:
                url_fixed = f"{url_fixed}%26key%3D"

            trakt_is_active = self.is_trakt_active()
            simkl_is_active = self.is_simkl_active()
            plex_is_active = self.is_plex_active()
            is_cloud_sync_needed = trakt_is_active or simkl_is_active or plex_is_active

            ncore_uri_encoded = f"https%3A%2F%2Fncore.pro%2Ftorrents.php%3Faction%3Ddownload%26id%3D{url_fixed}{pass_k}"

            r_sec_val = self.params.get('resume_seconds', '0')
            r_pct_val = self.params.get('resume_percent', '')
            
            from urllib.parse import unquote
            r_time_label = unquote(self.params.get('resume_time', ''))

            f_name_val = unquote(self.params.get('f_name', ''))
            db_f_name = unquote(self.params.get('db_f_name', ''))
            target_ep = unquote(self.params.get('target_episode', ''))
            
            #xbmc.log(f"[nCore_PLAY_Debug] Bemenet: f_name='{f_name_val}' | db_f='{db_f_name}' | target_ep='{target_ep}'", xbmc.LOGINFO)

            is_music = self.params.get('is_music') == 'true'
            is_xxx = self.params.get('is_xxx') == 'true'

            target_file_match = f_name_val if f_name_val else target_ep

            advanced_ready = True
            is_browse_mode = self.params.get('select') == '1'

            all_real_files = []
            try:
                with self.db._get_connection() as conn:
                    rows = conn.execute("SELECT file_name FROM torrent_files WHERE torrent_id = ?", (str(current_torrent_id),)).fetchall()
                    all_real_files = [r['file_name'] for r in rows if not any(x in r['file_name'].lower() for x in ['sample', 'minta'])]
                    all_real_files.sort(key=lambda x: local_extract_season_episode(x))
                #xbmc.log(f"[nCore_PLAY_Debug] Torrent fájlok száma: {len(all_real_files)}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[nCore_DEBUG] DB Error -> Fájllista hiba: {str(e)}", xbmc.LOGERROR)

            source_db = self.db.get_torrent_details(current_torrent_id)
            last_full_url = source_db.get('full_url') if source_db else ""
            
            import os
            curr_file = target_file_match if target_file_match else db_f_name

            if not curr_file:
                raw_basename = os.path.basename(last_full_url.replace('\\', '/')) if last_full_url else ""
                curr_file = unquote(raw_basename)

            if not curr_file and len(all_real_files) == 1:
                curr_file = all_real_files[0]

            matched_index = -1
            if all_real_files and curr_file:
                target_s, target_e = local_extract_season_episode(curr_file)
                #xbmc.log(f"[nCore_PLAY_Debug] Keresett szál -> Név: '{curr_file}' | S:{target_s} E:{target_e}", xbmc.LOGINFO)

                def normalize_strict(s): 
                    decoded = unquote(str(s)).replace('+', ' ')
                    clean_name = decoded.replace('\\', '/').split('/')[-1]
                    return ''.join(e for e in clean_name.lower() if e.isalnum())
                
                target_norm = normalize_strict(curr_file)

                for idx, f in enumerate(all_real_files):
                    f_norm = normalize_strict(f)
                    f_s, f_e = local_extract_season_episode(f)

                    if target_norm == f_norm:
                        matched_index = idx
                        curr_file = f
                        break

                    if target_s is not None and target_s == f_s and target_e == f_e:
                        matched_index = idx
                        curr_file = f
                        break

                    if target_norm != "" and (target_norm in f_norm or f_norm in target_norm):
                        matched_index = idx
                        curr_file = f
                        break

            if matched_index == -1 and len(all_real_files) == 1:
                curr_file = all_real_files[0]
                matched_index = 0

            #xbmc.log(f"[nCore_PLAY_Debug] Beazonosítás eredménye -> Index: {matched_index} | Fájl: '{curr_file}'", xbmc.LOGINFO)

            xbmc.log(f"[DEBUG_file] all_real_files (első 5): {all_real_files[:5] if len(all_real_files) > 5 else all_real_files}", xbmc.LOGINFO)
            xbmc.log(f"[DEBUG_file] curr_file: '{curr_file}', matched_index: {matched_index}, total: {len(all_real_files)}", xbmc.LOGINFO)

            if matched_index == -1 and all_real_files:
                if not target_file_match and not db_f_name:
                    curr_file = all_real_files[0]
                    matched_index = 0

            db_res_found = False
            db_res_label = ""
            db_res_sec = 0
            db_res_file = ""
            db_res_dur = 0

            try:
                with self.db._get_connection() as conn:
                    res_row = conn.execute('''
                        SELECT file_name, label, position, duration FROM video_positions 
                        WHERE torrent_id = ? 
                        ORDER BY timestamp DESC LIMIT 1
                    ''', (str(current_torrent_id) if _local_tracking_on() else '',)).fetchone()
                    if res_row:
                        db_res_file = unquote(res_row['file_name']).replace('\\', '/').split('/')[-1]
                        db_res_label = res_row['label']
                        db_res_sec = int(float(res_row['position']))
                        db_res_dur = int(float(res_row['duration'] or 0))
                        db_res_found = True
            except Exception as e:
                xbmc.log(f"[nCore_RESUME_DEBUG] SQL HIBA: {str(e)}", xbmc.LOGERROR)

            # --- ÉVADPAKK KEZELŐ MENÜ ---
            if (advanced_ready and not target_file_match and len(all_real_files) > 1 and not is_browse_mode and _season_pack_menu_on()):
                
                prev_file_db = all_real_files[matched_index - 1] if matched_index > 0 else None
                next_file_db = all_real_files[matched_index + 1] if (matched_index != -1 and matched_index < len(all_real_files) - 1) else None
                
                unit_name = "szám" if is_music else ("klip" if is_xxx else "epizód")
                dialog_title = "nCore TV - Album kezelő" if is_music else ("nCore TV - XXX gyűjtemény" if is_xxx else "nCore TV - Évadpakk kezelő")
                
                menu_items = []
                index_to_action = {}
                is_finished = False

                if db_res_found and db_res_sec > 0:
                    if db_res_dur > 0:
                        remaining = db_res_dur - db_res_sec
                        if remaining < 7: is_finished = True
                    if not is_finished:
                        resume_prefix = local_format_label("[B][COLOR lightgreen]Folytatás:[/COLOR][/B]", db_res_file)
                        menu_items.append(f"{resume_prefix} [COLOR yellow]({db_res_label})[/COLOR]")
                        index_to_action[len(menu_items)-1] = {"file": db_res_file, "sec": db_res_sec}

                label_prefix = "[B][COLOR yellow]Lejátszás:[/COLOR][/B]" if not last_full_url else f"[B][COLOR yellow]Jelenlegi {unit_name}:[/COLOR][/B]"
                current_label = local_format_label(label_prefix, curr_file)
                if is_finished and curr_file == db_res_file:
                    current_label += " [B][COLOR lime][Megtekintve][/COLOR][/B]"

                menu_items.append(current_label)
                index_to_action[len(menu_items)-1] = {"file": curr_file, "sec": 0}

                if next_file_db:
                    menu_items.append(local_format_label(f"[B][COLOR orange]Következő {unit_name}:[/COLOR][/B]", next_file_db))
                    index_to_action[len(menu_items)-1] = {"file": next_file_db, "sec": 0}
                if prev_file_db:
                    menu_items.append(local_format_label(f"[B][COLOR grey]Előző {unit_name}:[/COLOR][/B]", prev_file_db))
                    index_to_action[len(menu_items)-1] = {"file": prev_file_db, "sec": 0}

                menu_items.append(f"[B][COLOR lime]Tallózás:[/COLOR][/B] Minden {unit_name} mutatása")
                browse_index = len(menu_items) - 1

                sel = xbmcgui.Dialog().select(dialog_title, menu_items)
                if sel == -1: return 
                
                if sel == browse_index:
                    is_browse_mode = True
                    target_file_match = ''
                elif sel in index_to_action:
                    target_file_match = index_to_action[sel]["file"]
                    r_sec_val = str(index_to_action[sel]["sec"])
                    curr_file = target_file_match

            elif not target_file_match and len(all_real_files) == 1:
                curr_file = all_real_files[0]
                target_file_match = curr_file

            # --- ELEMENTUM URL ÖSSZEÁLLÍTÁSA ---
            extra_elementum_params = "&size_at_start=true"
            if is_music or is_xxx: extra_elementum_params += "&min_size=0"
            else:
                f_size_raw = self.params.get('f_size', '0')
                try:
                    if 0 < int(f_size_raw) < 104857600: extra_elementum_params += "&min_size=10000000"
                except: pass
            
            url_pass = f'plugin://plugin.video.elementum/play?uri={ncore_uri_encoded}&doresume=false&position={r_sec_val}{extra_elementum_params}'
            if is_browse_mode:
                final_selection = ""
                r_sec_val = "0"
                #xbmc.log("[nCore_PLAY_Debug] TALLÓZÓ MÓD: final_selection ürítve.", xbmc.LOGINFO)
            else:
                if matched_index != -1:
                    final_selection = curr_file
                    #xbmc.log(f"[nCore_PLAY_Debug] NORMÁL MÓD: Beazonosított fájl használata: '{final_selection}'", xbmc.LOGINFO)
                else:
                    final_selection = target_file_match if ( 'target_file_match' in locals() and target_file_match) else curr_file
                    #xbmc.log(f"[nCore_PLAY_Debug] NORMÁL MÓD: Fallback fájl használata: '{final_selection}'", xbmc.LOGINFO)

            url_pass = f'plugin://plugin.video.elementum/play?uri={ncore_uri_encoded}&doresume=false&position={r_sec_val}{extra_elementum_params}'
            if is_browse_mode: 
                url_pass += '&select=1'
            
            if final_selection:
                clean_name = str(final_selection).replace('\\', '/').split('/')[-1]
                import re
                final_regex = r"(?i)(?:^|[\\/])" + re.escape(clean_name) + r"$"
                url_pass += f'&file_match={urllib.parse.quote(final_regex)}'
                #xbmc.log(f"[nCore_PLAY_Debug] Elementum parancs (STRICT): '{final_regex}'", xbmc.LOGINFO)
            else:
                exclusion_filter = r"(?i)^(?!.*sample).*$"
                url_pass += f'&file_match={urllib.parse.quote(exclusion_filter)}'
                #xbmc.log("[nCore_PLAY_Debug] Elementum parancs (SAMPLE FILTER ACTIVE)", xbmc.LOGINFO)

            #xbmc.log(f"[nCore_PLAY_Debug] FINAL URL -> {url_pass}", xbmc.LOGINFO)
            
            # --- ELEMENTUM URL ELLENŐRZÉSE ---
            parsed_url_elementum = urllib.parse.urlparse(url_pass)
            query_params_elementum = urllib.parse.parse_qs(parsed_url_elementum.query)
            
            url_ellenorzendo = None
            if 'uri' in query_params_elementum:
                url_ellenorzendo_encoded = query_params_elementum['uri'][0]
                url_ellenorzendo = urllib.parse.unquote(url_ellenorzendo_encoded)

                if not checkTorrentSource(url_ellenorzendo):
                    return 
            else:
                xbmcgui.Dialog().notification("Hiba", "Érvénytelen Elementum URL formátum.", time=5000)
                xbmcplugin.setResolvedUrl(syshandle, False, listitem=xbmcgui.ListItem())
                return

            # --- BLOCK 9: BASE64 RE-ENCODING FOR INTERCEPTOR ---
            original_params['poster_link'] = encode_base64_local(cleaned_poster_url)
            c_i_final_val = cleaned_c_i_url
            if c_i_final_val and "&t=image/png" not in c_i_final_val:
                c_i_final_val = f"{c_i_final_val}&t=image/png"
            if c_i_final_val:
                original_params['c_i'] = encode_base64_local(c_i_final_val)
            original_params['clear_logo'] = clear_logo

            # --- BLOCK 10: SQL ALAPÚ BOOKMARK LOGIC ---
            get_filename, get_category = self.torrent_filename_and_category(current_torrent_id)
            #xbmc.log(f"[nCore_DEBUG] get_filename: {get_filename}", xbmc.LOGINFO)
            #xbmc.log(f"[nCore_DEBUG] get_category: {get_category}", xbmc.LOGINFO)
            if auto_add_bookmark_enabled and get_category:
                all_bookmarks = self.db.get_all_bookmarks()
                target_bookmark_info = None
                for b_key, b_info in all_bookmarks.items():
                    if get_category in b_info.get('categories', []) or 'all' in b_info.get('categories', []):
                        target_bookmark_info = b_info
                        break
                if target_bookmark_info:
                    if show_notif_for_auto_bookmark:
                        xbmcgui.Dialog().notification("Könyvjelző", f"Hozzáadva: {target_bookmark_info.get('name')}", xbmcgui.NOTIFICATION_INFO)                        
                    plugin_action = f"plugin://{addon_str}/?action=autoAddBookmark&torrent_id={current_torrent_id}&bookmark_name={target_bookmark_info.get('name')}&bookmark_group_id={target_bookmark_info.get('group_id')}"
                    xbmc.executebuiltin(f'RunPlugin({plugin_action})')

            # --- BLOCK 11: SET RESOLVED URL & KODI FLAGS ---
            desc_for_player = original_params.get('description', '')
            if not desc_for_player and source_db:
                desc_for_player = source_db.get('description', '')
            is_selecting_mode = (original_params.get('select') == '1')
            play_media_url = url_pass + '&select=1' if is_selecting_mode else url_pass
            play_item = xbmcgui.ListItem(path=play_media_url)

            title = original_params.get('title_1', 'Video')
            try:
                info_tag = play_item.getVideoInfoTag()
                if hasattr(info_tag, 'setTitle'):
                    info_tag.setTitle(title)
                    if desc_for_player:
                        info_tag.setPlot(desc_for_player)
                else:
                    info_labels = {'title': title}
                    if desc_for_player:
                        info_labels['plot'] = desc_for_player
                    play_item.setInfo('video', info_labels)
            except:
                info_labels = {'title': title}
                if desc_for_player:
                    info_labels['plot'] = desc_for_player
                play_item.setInfo('video', info_labels)
            
            play_item.setArt({"poster": cleaned_poster_url, "thumb": cleaned_poster_url, "clearlogo": clear_logo})
            play_item.setProperty('ResumeTime', '0')
            play_item.setProperty('StartOffset', '0')
            play_item.setProperty('isFolder', 'false')
            play_item.setProperty('PlayMedia', 'true')
            play_item.setProperty('ReplaceParent', 'true')
            xbmcplugin.setResolvedUrl(syshandle, True, listitem=play_item)

            # --- BLOCK 12: WAIT FOR PLAYBACK & RESUME MENU ---
            file_ref = self.wait_for_playback(timeout=80000)
            if file_ref:
                xbmcgui.Window(10000).clearProperty('nCore_TV_Switching')
                #dlog(f"Lejátszás detektálva: {file_ref}")
                
                xbmc.Player().pause()
                season_val, episode_val = local_extract_season_episode(file_ref)
                current_file_name = local_clean_display_path(file_ref)

                if all_real_files and current_file_name:
                    from urllib.parse import unquote_plus
                    def normalize(s): 
                        return ''.join(e for e in unquote_plus(str(s)).lower() if e.isalnum())
                    
                    curr_norm = normalize(current_file_name)
                    matched_index = -1
                    for idx, f in enumerate(all_real_files):
                        if normalize(f) == curr_norm:
                            matched_index = idx
                            break
                    if matched_index == -1:
                        for idx, f in enumerate(all_real_files):
                            if curr_norm in normalize(f) or normalize(f) in curr_norm:
                                matched_index = idx
                                break                

                def local_sec_to_hms(seconds):
                    s = int(float(seconds))
                    hours = s // 3600
                    minutes = (s % 3600) // 60
                    seconds = s % 60
                    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

                if season_val is not None:
                    display_info = f"S{season_val:02d}E{episode_val:02d}"
                else:
                    clean_n = original_params.get('title_2', '').strip()
                    if not clean_n or clean_n.lower() == "none":
                        clean_n = original_params.get('title_1', '')
                    clean_n = re.split(r'\.\d{4}\.|\(\d{4}\)', clean_n)[0].replace('.', ' ').strip()
                    display_info = clean_n[:27] + "..." if len(clean_n) > 30 else clean_n

                seek_to_position = 0
                temp_dur = 0
                for i in range(25):
                    temp_dur = xbmc.Player().getTotalTime()
                    if temp_dur > 1: 
                        dlog(f"Időtartam beolvasva: {temp_dur} mp ({i*0.5} mp várakozás után)")
                        break
                    xbmc.sleep(500)

                trakt_resume_pct = self.params.get('resume_percent', '')
                is_sw_active = xbmcgui.Window(10000).getProperty('nCore_TV_Switching') == 'true'
                
                # --- [ PRIORITÁS ] ---
                if trakt_resume_pct and temp_dur > 0 and not is_browse_mode:
                    seek_to_position = (float(trakt_resume_pct) / 100) * temp_dur
                elif is_sw_active and r_sec_val and float(r_sec_val) > 10:
                    seek_to_position = float(r_sec_val)
                elif self.params.get('direct_resume') == 'true' and r_sec_val and float(r_sec_val) > 10:
                    seek_to_position = float(r_sec_val)
                else:
                    #xbmc.log("[nCore_PLAY_Debug] Választómenü összeállítása...", xbmc.LOGINFO)
                    resume_options = []
                    resume_options.append({"label": "Lejátszás az elejétől", "pos": 0})
                    seen_labels = set()

                    db_positions = self.db.get_video_positions(current_torrent_id, current_file_name)
                    safe_duration_fallback = float(temp_dur) if temp_dur > 0 else 0

                    for p_item in db_positions:
                        p_sec = float(p_item['position'])
                        p_dur = float(p_item.get('duration', 0))
                        if p_dur <= 0: p_dur = safe_duration_fallback

                        if p_dur > 0 and (p_dur - p_sec) < 15: continue

                        rem_text = ""
                        if p_dur > 0:
                            rem_sec = int(p_dur - p_sec)
                            m_rem, s_rem = divmod(rem_sec, 60); h_rem, m_rem = divmod(m_rem, 60)
                            rem_fmt = f"{h_rem:02d}:{m_rem:02d}:{s_rem:02d}" if h_rem > 0 else f"{m_rem:02d}:{s_rem:02d}"
                            rem_text = f" [COLOR orange](-{rem_fmt} hátra)[/COLOR]"

                        l_text = f"Folytatás (helyi): [{p_item['label']}]{rem_text}"
                        if l_text not in seen_labels:
                            resume_options.append({"label": l_text, "pos": p_sec})
                            seen_labels.add(l_text)

                    if is_cloud_sync_needed and temp_dur > 0:
                        if trakt_is_active:
                            t_p = TraktInterface.get_trakt_resume_progress(imdb_id, season_val, episode_val)
                            if t_p:
                                t_sec = (float(t_p) / 100) * temp_dur
                                r_s = int(temp_dur - t_sec); m_r, s_r = divmod(r_s, 60); h_r, m_r = divmod(m_r, 60)
                                r_f = f"{h_r:02d}:{m_r:02d}:{s_r:02d}" if h_r > 0 else f"{m_r:02d}:{s_r:02d}"
                                resume_options.append({"label": f"Folytatás (Trakt): [{local_sec_to_hms(t_sec)}] {int(float(t_p))}% [COLOR orange](-{r_f} hátra)[/COLOR]", "pos": t_sec})
                        
                        if simkl_is_active:
                            s_p = SimklInterface.get_simkl_resume_progress(imdb_id, season_val, episode_val, tmdb_id_reference)
                            if s_p: 
                                s_sec = (float(s_p) / 100) * temp_dur
                                r_s = int(temp_dur - s_sec); m_r, s_r = divmod(r_s, 60); h_r, m_r = divmod(m_r, 60)
                                r_f = f"{h_r:02d}:{m_r:02d}:{s_r:02d}" if h_r > 0 else f"{m_r:02d}:{s_r:02d}"
                                resume_options.append({"label": f"Folytatás (Simkl): [{local_sec_to_hms(s_sec)}] {int(float(s_p))}% [COLOR orange](-{r_f} hátra)[/COLOR]", "pos": s_sec})
                        
                        if plex_is_active:
                            p_p = PlexInterface.get_plex_resume_progress(imdb_id, season_val, episode_val)
                            if p_p: 
                                p_sec = (float(p_p) / 100) * temp_dur
                                r_s = int(temp_dur - p_sec); m_r, s_r = divmod(r_s, 60); h_r, m_r = divmod(m_r, 60)
                                r_f = f"{h_r:02d}:{m_r:02d}:{s_r:02d}" if h_r > 0 else f"{m_r:02d}:{s_r:02d}"
                                resume_options.append({"label": f"Folytatás (Plex): [{local_sec_to_hms(p_sec)}] {int(float(p_p))}% [COLOR orange](-{r_f} hátra)[/COLOR]", "pos": p_sec})

                    if len(resume_options) > 1:
                        selection = xbmcgui.Dialog().select(f"Folytatási pont: {display_info}", [opt['label'] for opt in resume_options])
                        if selection >= 0: 
                            seek_to_position = resume_options[selection]['pos']
                        else:
                            xbmc.Player().stop()
                            return

                # --- BLOCK 13: SEEK ---
                if seek_to_position > 0:
                    xbmc.Player().seekTime(seek_to_position)
                    xbmc.sleep(1000)

                clean_args = sys.argv[2].replace('&select=1', '').replace('select=1', '')
                raw_args_b64 = base64.b64encode(clean_args.encode('utf-8')).decode('utf-8')
                b64_url_pass = base64.b64encode(url_pass.encode('utf-8')).decode('utf-8')

                # --- FORK: film/lejatszas inditasakor NE maradjon pause-ban ---
                # A folytatasi pont meghatarozasahoz a lejatszas fentebb megallt.
                # Ha nem folytatas-menubol indult (pl. film az elejerol), a video
                # pause-ban ragadna. Itt visszainditjuk, ha meg szunetel.
                try:
                    if xbmc.getCondVisibility('Player.Paused'):
                        xbmc.Player().pause()  # toggle -> visszainditas
                except Exception:
                    pass

                # --- BLOCK 14: MAIN MONITORING LOOP ---
                player_instance = xbmc.Player()
                _mon = xbmc.Monitor()  # egyszer példányosítva (korábban 500 ms-onként új Monitor jött létre)
                while player_instance.isPlaying():
                    if _mon.abortRequested() or getattr(self, 'active_playback_token', None) != this_session_token:
                        break
                    try:
                        if not player_instance.isPlaying(): break
                        curr_s = player_instance.getTime()
                        if total_file_seconds <= 0: total_file_seconds = player_instance.getTotalTime()

                        if total_file_seconds > 0:
                            last_known_seconds = curr_s
                            current_pct = round((curr_s / total_file_seconds) * 100, 2)
                            if current_pct < 1.0 and is_cloud_sync_needed and not notified_sync_threshold:
                                if imdb_id and player_instance.isPlaying():
                                    xbmcgui.Dialog().notification("nCore TV", "Felhő Sync csak 1% felett", "", 2500)
                                notified_sync_threshold = True

                            if current_pct >= 1.0:
                                if current_pct >= 85 and not playback_finished_flag:
                                    playback_finished_flag = True
                                    sync_started_sent = True 
                                    threading.Thread(target=lambda: [self._run_cloud_sync_task(s, imdb_id, season_val, episode_val, tmdb_id_reference, 'watched', curr_s, total_file_seconds, display_info) for s in ['trakt', 'simkl', 'plex'] if not xbmc.Monitor().abortRequested()]).start()
                                elif not sync_started_sent:
                                    sync_started_sent = True
                                    threading.Thread(target=lambda: [self._run_cloud_sync_task(s, imdb_id, season_val, episode_val, tmdb_id_reference, 'start', curr_s, total_file_seconds, display_info) for s in ['trakt', 'simkl', 'plex'] if addon.getSetting(f'{s}_scrobble_start') == 'true']).start()

                            is_pnow = xbmc.getCondVisibility('Player.Paused')
                            if is_pnow and not last_pause_toggle_state and not playback_finished_flag:    
                                last_pause_toggle_state = True
                                if current_pct >= 1.0:
                                    threading.Thread(target=lambda: [self._run_cloud_sync_task(s, imdb_id, season_val, episode_val, tmdb_id_reference, 'pause', curr_s, total_file_seconds, display_info) for s in ['trakt', 'simkl', 'plex'] if addon.getSetting(f'{s}_scrobble_pause') == 'true']).start()

                                    if player_instance.isPlaying():
                                        xbmcgui.Dialog().notification("Sync", f"Pozíció mentve: {int(current_pct)}%", "", 1500)
                             
                                if last_known_seconds > 5:
                                    self.db.add_video_position(current_torrent_id, current_file_name, last_known_seconds, time.strftime('%H:%M:%S', time.gmtime(last_known_seconds)), total_file_seconds)
                            elif not is_pnow: last_pause_toggle_state = False

                            if is_pnow and extra_pause_menu_enabled and current_pct > 0.1:
                                if playback_dialog_interceptor is None:
                                    from urllib.parse import unquote_plus
                                    display_name_interceptor = unquote_plus(current_file_name)
                                    
                                    f_count = len(all_real_files)
                                    f_pos = matched_index + 1 if matched_index != -1 else 0                                    
                                    
                                    playback_dialog_interceptor = PlaybackInterceptor(
                                        current_torrent_id,
                                        display_name_interceptor,
                                        b64_url_pass, 
                                        raw_args_b64,
                                        xbmc.getInfoLabel('Player.Process(videofps)'),
                                        xbmc.getInfoLabel('System.FPS'),
                                        xbmc.getInfoLabel('VideoPlayer.VideoResolution'),
                                        f_pos, f_count
                                    )
                                    
                                    playback_dialog_interceptor.show()
                            
                            
                            elif playback_dialog_interceptor:
                                playback_dialog_interceptor.close()
                                playback_dialog_interceptor = None
                    except: break
                    if _mon.waitForAbort(0.5): break

                if getattr(self, 'active_playback_token', None) == this_session_token:
                    xbmc.sleep(200)
                    try:
                        if last_known_seconds > 10:
                            self.db.add_video_position(current_torrent_id, current_file_name, last_known_seconds, time.strftime('%H:%M:%S', time.gmtime(last_known_seconds)), total_file_seconds)

                        if file_ref: 
                            save_params['full_url'] = urllib.parse.unquote_plus(os.path.abspath(file_ref))
                        save_params['timestamp'] = datetime.now().isoformat()
                        self.db.save_torrent_metadata(save_params)
                    except: pass

                    if not playback_finished_flag and sync_started_sent and total_file_seconds > 0:
                        f_pct = round((last_known_seconds / total_file_seconds) * 100, 2)
                        if f_pct >= 1.0:
                            f_stat = 'watched' if f_pct >= 85 else 'pause'
                            
                            for s in ['trakt', 'simkl', 'plex']:
                                if xbmc.Monitor().abortRequested(): break
                                self._run_cloud_sync_task(s, imdb_id, season_val, episode_val, tmdb_id_reference, f_stat, last_known_seconds, total_file_seconds, display_info, silent=True, is_cleanup=True)
                    xbmc.sleep(300)
        finally:
            if getattr(self, 'active_playback_token', None) == this_session_token:
                self.active_playback_token = None 
                if playback_dialog_interceptor:
                    try: playback_dialog_interceptor.close()
                    except: pass
                player_instance = None
                xbmc.sleep(100)
        return


    def SingleItemFolder(self):
        picked_torrent_id = str(self.params.get('torrent_id', ''))

        if picked_torrent_id:
            if not self.db.has_torrent_structure(picked_torrent_id):
                self.sync_torrent_files_to_db(picked_torrent_id)

        source_db = self.db.get_torrent_details(picked_torrent_id)
        source = self.params.copy()
        if source_db:
            db_dict = dict(source_db)
            for key, value in db_dict.items():
                if value and (key not in source or not source[key] or str(source[key]).lower() == "none"):
                    source[key] = value
        
        if not source.get('url'):
            source['url'] = picked_torrent_id

        picked_tmdb_id = self.params.get('tmdb_id', '')
        if picked_tmdb_id and not source.get('tmdb_id'):
            source['tmdb_id'] = picked_tmdb_id

        if source.get('poster_link'):
            source['poster_link'] = self.clean_base64_data(source['poster_link'])
        if source.get('c_i'):
            source['c_i'] = self.clean_base64_data(source['c_i'])

        picked_poster_link = source.get('poster_link') or ""
        raw_f_url = source.get('full_url') or ""
        picked_full_url = unquote_plus(raw_f_url)

        picked_description = source.get('description', '')
        if str(picked_description) == "None": picked_description = ""

        def extract_season_episode(text):
            if not text: return None, None
            patterns = [
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
            ]
            for series_patt in patterns:
                match = re.search(series_patt, str(text))
                if match: return int(match.group('season')), int(match.group('episode'))
            return None, None

        search_target = picked_full_url if picked_full_url else (source.get('title_1') or "")
        season, episode = extract_season_episode(search_target)

        series_episode = ""
        if season is not None and episode is not None:
            series_episode = f'[COLOR orange]Utoljára nézett:[/COLOR] [COLOR yellow]S{season:02d}E{episode:02d}[/COLOR]'
        elif picked_full_url:
            series_episode = f'[COLOR lightgreen]{self.clean_display_path(picked_full_url)}[/COLOR]'

        valid_title_2 = source.get('title_2') and str(source.get('title_2')).strip().lower() not in ["none", ""]
        pick_title = source.get('title_1') if source.get('title_1') else (f'Alcím: {source.get("title_2")}' if valid_title_2 else '')

        manual_keys = [
            'action', 'url', 'torrent_id', 'video_saved_position', 
            'target_episode', 'resume_percent', 'f_name', 'db_f_name',
            'resume_time', 'resume_seconds', 'f_size', 'is_music', 'is_xxx',
            'description', 'full_url'
        ]

        passed_params = []
        for key, value in source.items():
            if key not in manual_keys:
                clean_val = "" if (value is None or str(value).lower() == "none") else str(value)
                passed_params.append(f"{key}={quote_plus(clean_val)}")
        
        play_params = f"playmovie&url={quote_plus(str(source['url']))}&torrent_id={quote_plus(picked_torrent_id)}"
        if passed_params:
            play_params += "&" + "&".join(passed_params)

        t_ep = source.get('target_episode', '')
        r_pct = source.get('resume_percent', '')
        f_name = source.get('f_name', '')
        db_f = source.get('db_f_name', '')
        r_time = source.get('resume_time', '')
        r_sec = source.get('resume_seconds', '')
        f_size = source.get('f_size', '')
        i_music = source.get('is_music', '')
        i_xxx = source.get('is_xxx', '')
        d_res = source.get('direct_resume', '')

        if t_ep: play_params += f"&target_episode={t_ep}"
        if r_pct: play_params += f"&resume_percent={r_pct}"
        if f_name: play_params += f"&f_name={quote_plus(str(f_name))}"
        if db_f: play_params += f"&db_f_name={quote_plus(str(db_f))}"
        if r_time: play_params += f"&resume_time={r_time}"
        if r_sec: play_params += f"&resume_seconds={r_sec}"
        if f_size: play_params += f"&f_size={f_size}"
        if i_music: play_params += f"&is_music={i_music}"
        if i_xxx: play_params += f"&is_xxx={i_xxx}"
        if d_res: play_params += f"&direct_resume={d_res}"

        final_name = f'[B]{series_episode} | {pick_title}[/B]' if picked_full_url else f'[B][COLOR lime][Lejátszás][/COLOR] {pick_title}[/B]'
        meta_plot = {"mediatype": "movie", "plot": f'{(series_episode) if series_episode else ""}\n\n{picked_description}', "title": pick_title}
        
        self.addDirectoryItem(final_name, play_params, picked_poster_link, 'DefaultMovies.png', isFolder=False, meta=meta_plot)
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view, cache=False, update=True)
    
    def PlayedTorrents(self):
        current_page = int(self.params.get('page', 1))
        
        if current_page == 1:
            self.addDirectoryItem(f"[B][COLOR lime]Megnézettek (Archívum)[/COLOR][/B]{ncore_coloring}", "finished_torrents", '', 'DefaultFolder.png')
            
            github_sync_enabled = addon.getSetting('github_sync_enabled')
            if github_sync_enabled == 'true':
                self.addDirectoryItem(f"[B]Utoljára nézettek ([COLOR yellow]GitHub-on lévő teljes lista[/COLOR])[/B]{ncore_coloring}", f"view_github_list_action", '', 'DefaultFolder.png')
                self.addDirectoryItem(f"[B]Az itt látható 'Utoljára nézettek' [COLOR orange]Szinkronizálása GitHub-ra[/COLOR][/B]{ncore_coloring}", f"github_sync_action", '', 'DefaultFolder.png')
            else:
                if addon.getSetting('github_owner'):
                    self.addDirectoryItem(f"[B]Utoljára nézettek ([COLOR yellow]GitHub-on lévő teljes lista[/COLOR])[/B]{ncore_coloring}", f"view_github_list_action", '', 'DefaultFolder.png')

        db_max = self.db.get_total_played_groups_count()
        if db_max > 0:
            torrents, _ = self.db.get_grouped_played_torrents(page=1, items_per_page=db_max)
            self._render_played_list(torrents, mode='active', current_page=current_page, base_action='played_torrents')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view, cache=False)

    def FinishedTorrents(self):
        current_page = int(self.params.get('page', 1))
        db_max = self.db.get_total_played_groups_count()
        if db_max > 0:
            torrents, _ = self.db.get_grouped_played_torrents(page=1, items_per_page=db_max)
            self._render_played_list(torrents, mode='finished', current_page=current_page, base_action='finished_torrents')
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view, cache=False)

    def ViewPlayedGroup(self):
        picked_imdb_id = self.params.get('imdb_id', '')
        if not picked_imdb_id: return

        torrents = self.db.get_torrents_by_imdb(picked_imdb_id)

        self._render_played_list(torrents, is_subgroup=True, mode='all')
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view, cache=False)

    def _render_played_list(self, torrents, is_subgroup=False, mode='active', current_page=1, base_action='played_torrents'):    
        def extract_season_episode(full_url_str):
            if not full_url_str: return None, None
            patterns = [
                r'[sS](?P<season>\d{1,2})[.\s-]*[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
            ]
            for series_patt in patterns:
                match = re.search(series_patt, str(full_url_str))
                if match: 
                    return int(match.group('season')), int(match.group('episode'))
            return None, None

        imdb_ids_to_query = [t.get('imdb_id') for t in torrents if t.get('imdb_id')]
        db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)

        filtered_list = []
        for torrent in torrents:
            picked_torrent_id = torrent['torrent_id']
            is_finished_val = False
            r_pos = 0
            r_dur = 0
            try:
                with self.db._get_connection() as conn:
                    row = conn.execute('SELECT position, duration FROM video_positions WHERE torrent_id = ? ORDER BY timestamp DESC LIMIT 1', (str(picked_torrent_id) if _local_tracking_on() else '',)).fetchone()
                    if row:
                        r_pos = row['position']
                        r_dur = row['duration'] or 0
            except: pass

            if r_dur > 10 and r_pos > 0:
                p_pct = int((r_pos / r_dur) * 100)
                p_rem = max(0, r_dur - r_pos)
                if (p_pct > 89 or p_rem < 45):
                    curr, total = self.db.get_torrent_pack_progress_raw(picked_torrent_id)
                    if total <= 1 or curr == total:
                        is_finished_val = True

            if mode == 'active' and is_finished_val: continue
            if mode == 'finished' and not is_finished_val: continue
            filtered_list.append(torrent)

        items_per_page = 20
        total_filtered = len(filtered_list)
        start_idx = (current_page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        page_items = filtered_list[start_idx:end_idx]
        remaining_count = total_filtered - end_idx

        imdb_ids_to_query_page = [t.get('imdb_id') for t in page_items if t.get('imdb_id')]
        db_sync_data_page = self.db.get_indicators_for_list(imdb_ids_to_query_page)

        for torrent in page_items:
            picked_torrent_id = torrent['torrent_id']
            picked_imdb_id = torrent.get('imdb_id') or ""
            picked_tmdb_id = torrent.get('tmdb_id') or ""
            raw_full_url = torrent.get('full_url') or ""
            picked_full_url = unquote_plus(raw_full_url)
            group_count = torrent.get('group_count', 1)

            season, episode = extract_season_episode(picked_full_url if picked_full_url else (torrent.get('title_1') or ""))

            show_rating_info = ""
            if picked_imdb_id:
                local_r_type = 'show' if any(x in picked_full_url.lower() for x in ['s0', 's1', 's2', 'évad']) else 'movie'
                main_rating = self.db.get_trakt_rating(picked_imdb_id, local_r_type, 0, 0)
                if main_rating:
                    show_rating_info = f"[B][COLOR gold]Értékelésed: {main_rating}/10 ★[/COLOR][/B]\n"

            pack_stat = self.db.get_torrent_pack_progress(picked_torrent_id)
            pack_stat_label = f" [COLOR cyan]({pack_stat})[/COLOR]" if pack_stat else ""
            
            cleaned_poster = self.clean_base64_data(torrent.get('poster_link') or "")
            cleaned_c_i = self.clean_base64_data(torrent.get('c_i') or "")
            picked_poster_link = cleaned_poster if cleaned_poster else (cleaned_c_i if cleaned_c_i else 'DefaultMovies.png')

            is_music_item = "true" if any(picked_full_url.lower().endswith(ext) for ext in ['.mp3', '.flac', '.wav', '.m4a', '.aac']) else "false"
            is_xxx_item = "true" if not picked_imdb_id and any(x in picked_full_url.lower() for x in ['xxx', 'adult', 'porn']) else "false"

            show_sync_indicator = addon.getSetting('show_sync_indicator') == 'true'
            indicator, plot_status_line = ("", "")
            if show_sync_indicator:
                indicator, plot_status_line, _ = self._build_indicators(picked_imdb_id, picked_torrent_id, db_sync_data_page, [])
            
            local_status_text = ""
            res_seconds = 0
            res_label = ""
            res_pos = 0
            res_dur = 0
            res_file = ""

            try:
                with self.db._get_connection() as conn:
                    row = conn.execute('''
                        SELECT file_name, label, position, duration FROM video_positions 
                        WHERE torrent_id = ? 
                        ORDER BY timestamp DESC LIMIT 1
                    ''', (str(picked_torrent_id) if _local_tracking_on() else '',)).fetchone()
                    
                    if row:
                        res_file = row['file_name']
                        res_label = row['label']
                        res_pos = row['position']
                        res_seconds = int(float(res_pos))
                        res_dur = row['duration'] if row['duration'] else 0
                        
                        if res_dur > 0:
                            rem_sec = max(0, res_dur - res_pos)
                            percent = int((res_pos / res_dur) * 100)
                            if percent > 89 or rem_sec < 45:
                                local_status_text = f"\n\n[COLOR lime]Állapot: Megtekintve[/COLOR]"
                            else:
                                m, s = divmod(int(rem_sec), 60); h, m = divmod(m, 60)
                                rem_fmt = f"{h:02d}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"
                                tm, ts = divmod(int(res_dur), 60); th, tm = divmod(tm, 60)
                                total_fmt = f"{th:02d}:{tm:02d}:{ts:02d}" if th > 0 else f"{tm:02d}:{ts:02d}"
                                pm, ps = divmod(int(res_pos), 60); ph, pm = divmod(pm, 60)
                                pos_fmt = f"{ph:02d}:{pm:02d}:{ps:02d}" if th > 0 else f"{pm:02d}:{ps:02d}"
                                local_status_text = f"\n[COLOR yellow][ {percent}% ]  {pos_fmt} / {total_fmt}  [COLOR orange](-{rem_fmt})[/COLOR][/COLOR]"
                        else:
                            local_status_text = f"\n[COLOR yellow]Utolsó (helyi) időpont: {res_label}[/COLOR]"
            except: pass

            series_episode = f'[COLOR orange]Utoljára nézett:[/COLOR] [COLOR yellow]S{season:02d}E{episode:02d}[/COLOR]' if (season is not None) else f'[COLOR lightgreen]{self.clean_display_path(picked_full_url)}[/COLOR]' if picked_full_url else ""

            valid_title_2 = torrent.get('title_2') and str(torrent.get('title_2')).strip().lower() not in ["none", ""]
            pick_title = torrent.get('title_1') if torrent.get('title_1') else (f'[COLOR FFF56C00]Alcím:[/COLOR] {torrent.get("title_2")}' if valid_title_2 else '')

            if not is_subgroup and group_count > 1 and picked_imdb_id:
                group_prefix = f'[COLOR gold][{group_count}x][/COLOR] '
                final_display_name = f'[B]{group_prefix}[/B]{indicator}[B]{series_episode}{pack_stat_label} | {pick_title}[/B]'
                url_params = f"view_played_group&imdb_id={picked_imdb_id}"
            else:
                final_display_name = f'{indicator}[B]{series_episode}{pack_stat_label} | {pick_title}[/B]'
                url_params = (f"single_item_folder&torrent_id={picked_torrent_id}"
                             f"&imdb_id={picked_imdb_id}"
                             f"&poster_link={quote_plus(cleaned_poster)}"
                             f"&c_i={quote_plus(cleaned_c_i)}"
                             f"&is_music={is_music_item}"
                             f"&is_xxx={is_xxx_item}"
                             f"&resume_seconds={res_seconds}"
                             f"&resume_time={quote_plus(res_label or '')}"
                             f"&db_f_name={quote_plus(res_file or '')}")

            meta_plot = {
                "mediatype": "movie",
                "plot": (f'{show_rating_info}{plot_status_line}{series_episode}{pack_stat_label}{local_status_text}\n\n{torrent.get("title_1") or ""}\n\n{torrent.get("description") or ""}'),
                "title": pick_title
            }

            context_menu_items = [
                ("[B][COLOR FFF56C00]Eltávolítás a listából[/COLOR][/B]", f"remove_torrent&torrent_id={picked_torrent_id}"),
                ("[B][COLOR orange][FájlLista][/COLOR] (.torrent tartalma)[/B]", 
                 f"get_file_list_context&torrent_id={picked_torrent_id}&imdb_id={picked_imdb_id}&poster_link={quote_plus(cleaned_poster)}&title_1={quote_plus(torrent.get('title_1') or '')}&description={quote_plus(torrent.get('description') or '')}"),
                ("[B][COLOR gold]Trakt Értékelő Rendszer[/COLOR][/B]", f"open_rating_manager&torrent_id={picked_torrent_id}&imdb_id={picked_imdb_id}&title_1={quote_plus(pick_title)}"),                
                (f"[B][COLOR yellow]Más verziók: {picked_imdb_id}[/COLOR][/B]", f"search_with_imdb&imdb_id={picked_imdb_id}"),
                ("[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]", f"more_like_this_imdb&imdb_id={picked_imdb_id}"),                
                ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={picked_torrent_id}"),               
                (f"[B][COLOR gold]Adatbázis check: {picked_torrent_id}[/COLOR][/B]", f"torrent_database_audit&torrent_id={picked_torrent_id}")
            ]

            if picked_imdb_id:
                m_type = 'tv' if season else 'movie'
                if m_type == 'movie' and picked_tmdb_id:
                    context_menu_items.append(("[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", f"tmdb_get_collection_context&tmdb_id={picked_tmdb_id}&imdb_id={picked_imdb_id}&torrent_id={picked_torrent_id}"))
                if m_type == 'tv':
                    context_menu_items.append((f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({picked_imdb_id})[/COLOR][/B]", f"get_watching_series&imdb_id={picked_imdb_id}"))
                context_menu_items.append(("[B]Stáblista és Színészek[/B]", f"get_cast_list&imdb_id={picked_imdb_id}&media_type={m_type}&poster_link={quote_plus(str(picked_poster_link))}"))
                if self.is_trakt_active(): context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={picked_imdb_id}&is_series={'true' if season else 'false'}"))
                if self.is_simkl_active(): context_menu_items.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={picked_imdb_id}&is_series={'true' if season else 'false'}"))
                if self.is_plex_active(): context_menu_items.append(("[B][COLOR yellow]Plex => Watchlist[/COLOR][/B]", f"add_plex_watchlist_action&imdb_id={picked_imdb_id}&is_series={'true' if season else 'false'}"))

            self.addDirectoryItem(final_display_name, url_params, picked_poster_link, 'DefaultMovies.png', context=context_menu_items, isFolder=True, meta=meta_plot)

        if remaining_count > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) - ({remaining_count} maradt) >>>[/COLOR][/B]", f"{base_action}&page={current_page + 1}", '', 'DefaultFolder.png')

    def all_merged_played_torrents(self):
        current_page = int(self.params.get('page', 1))
        items_per_page = 20

        def extract_season_episode(picked_full_url):
            patterns = [
                r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
                r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
                r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
            ]
            for series_patt in patterns:
                match = re.search(series_patt, str(picked_full_url))
                if match:
                    return int(match.group('season')), int(match.group('episode'))
            return None, None

        all_merged_data = self.load_merged_played_torrents_from_github()
        if not all_merged_data:
            self.addDirectoryItem("[B]Nincs megjeleníthető adat a mergelt listában.[/B]", '', '', 'DefaultFolder.png')
            return

        all_merged_data.sort(key=lambda torrent: str(torrent.get('timestamp', '')), reverse=True)

        start_index = (current_page - 1) * items_per_page
        end_index = start_index + items_per_page
        torrents = all_merged_data[start_index:end_index]
        remaining_count = len(all_merged_data) - end_index

        imdb_ids_to_query = [t.get('imdb_id') for t in torrents if t.get('imdb_id')]
        db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)

        for torrent in torrents:
            picked_imdb_id = str(torrent.get('imdb_id') or "")
            picked_tmdb_id = str(torrent.get('tmdb_id') or "")
            picked_torrent_id = str(torrent.get('torrent_id') or "")

            cleaned_poster = self.clean_base64_data(torrent.get('poster_link') or "")
            cleaned_c_i = self.clean_base64_data(torrent.get('c_i') or "")
            
            if (not cleaned_poster or "DefaultMovies" in cleaned_poster) and picked_imdb_id:
                from resources.lib.indexers.trakt_parts import TraktInterface
                cleaned_poster = TraktInterface.get_simkl_poster_for_imdb(picked_imdb_id)

            picked_poster_link = cleaned_poster if cleaned_poster else (cleaned_c_i if cleaned_c_i else 'DefaultMovies.png')

            picked_title_1 = torrent.get('title_1') or ""
            picked_title_2 = torrent.get('title_2') or ""
            raw_full_url = torrent.get('full_url') or ""
            picked_full_url = unquote_plus(raw_full_url)
            picked_timestamp = torrent.get('timestamp') or ""

            show_sync_indicator = addon.getSetting('show_sync_indicator') == 'true'
            if show_sync_indicator:
                indicator, plot_status_line, _ = self._build_indicators(picked_imdb_id, picked_torrent_id, db_sync_data, [])
            else:
                indicator = ""
                plot_status_line = ""

            season, episode = extract_season_episode(picked_full_url if picked_full_url else picked_title_1)
            series_episode = ""
            if season is not None and episode is not None:
                series_episode = f'[COLOR orange]Utoljára nézett:[/COLOR] [COLOR yellow]S{season:02d}E{episode:02d}[/COLOR]'
            else:
                display_filename = self.clean_display_path(picked_full_url)
                if display_filename:
                    series_episode = f'[COLOR lightgreen]{display_filename}[/COLOR]'

            valid_title_2 = picked_title_2 and picked_title_2.strip().lower() not in ["none", ""]
            pick_title = picked_title_1 if picked_title_1 else (f'[COLOR FFF56C00]Alcím:[/COLOR] {picked_title_2}' if valid_title_2 else '')

            if series_episode:
                color = "lightblue" if (season is not None) else "lightgreen"
                final_display_name = f'{indicator}[B][COLOR {color}]{series_episode} | {pick_title}[/COLOR][/B]'
            else:
                final_display_name = f'{indicator}[B][COLOR lightgreen]{pick_title}[/COLOR][/B]'

            download_link = f'{picked_torrent_id}%26key%3D'

            url_params = (
                f'single_item_folder&url={quote_plus(download_link)}&title_1={quote_plus(str(picked_title_1))}'
                f'&title_2={quote_plus(str(picked_title_2))}&torrent_id={picked_torrent_id}'
                f'&imdb_id={picked_imdb_id}&poster_link={quote_plus(str(cleaned_poster))}&c_i={quote_plus(str(cleaned_c_i))}'
                f'&feltoltve={torrent.get("feltoltve", "")}&seeder={torrent.get("seeder", "")}&leecher={torrent.get("leecher", "")}'
                f'&description={quote_plus(str(torrent.get("description") or ""))}&full_url={quote_plus(picked_full_url)}&timestamp={picked_timestamp}'
            )

            context_menu_items = [
                (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({picked_imdb_id})[/COLOR][/B]", f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{picked_imdb_id}')}&imdb_id={picked_imdb_id}&title_1={quote_plus(str(picked_title_1))}&title_2={quote_plus(str(picked_title_2))}"),
                (f"[B][COLOR yellow]Más verziók: {picked_imdb_id}[/COLOR][/B]", f"search_with_imdb&imdb_id={picked_imdb_id}"),
                ("[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]", f"more_like_this_imdb&imdb_id={picked_imdb_id}"),
                ("[B][COLOR orange]Hozzáadás egy könyvjelzőbe[/COLOR][/B]", f"getContextBookmark&torrent_id={picked_torrent_id}"),
                ("[B][COLOR lime].torrent letöltése (HDD/Hálózat)[/COLOR][/B]", f"context_torrent_to_seed&torrent_id={picked_torrent_id}")
            ]

            if picked_imdb_id:
                m_type = 'tv' if season else 'movie'

                if m_type == 'movie' and (picked_tmdb_id or picked_imdb_id):
                    franchise_query = f"tmdb_get_collection_context&tmdb_id={picked_tmdb_id}&imdb_id={picked_imdb_id}&torrent_id={picked_torrent_id}"
                    context_menu_items.append(
                        ("[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]", franchise_query)
                    )

                if m_type == 'tv':
                    context_menu_items.append(
                        (f"[B][COLOR cyan]Hozzáadás a SorozatFigyelőbe ({picked_imdb_id})[/COLOR][/B]", 
                         f"get_watching_series&url={quote_plus(f'{base_url}{imdb_kereso}{picked_imdb_id}')}&imdb_id={picked_imdb_id}&title_1={quote_plus(str(picked_title_1))}&title_2={quote_plus(str(picked_title_2))}")
                    )

                context_menu_items.append(("[B]Stáblista és Színészek[/B]", f"get_cast_list&imdb_id={picked_imdb_id}&media_type={m_type}&poster_link={quote_plus(str(picked_poster_link))}"))      

                if self.is_trakt_active(): context_menu_items.append(("[B][COLOR yellow]Trakt => Watchlist[/COLOR][/B]", f"add_trakt_watchlist_action&imdb_id={picked_imdb_id}&is_series={'true' if season else 'false'}"))
                if self.is_simkl_active(): context_menu_items.append(("[B][COLOR yellow]Simkl => Plan to Watch[/COLOR][/B]", f"add_simkl_plan_action&imdb_id={picked_imdb_id}&is_series={'true' if season else 'false'}"))
                if self.is_plex_active(): context_menu_items.append(("[B][COLOR yellow]Plex => Watchlist[/COLOR][/B]", f"add_plex_watchlist_action&imdb_id={picked_imdb_id}&is_series={'true' if season else 'false'}"))

            meta_plot = {
                "mediatype": "movie",
                "plot": (f'{plot_status_line}'
                         f'{series_episode if series_episode else ""}\n\n{picked_title_1}' + 
                         (f'\n\n[COLOR FFF56C00]Alcím:[/COLOR] {picked_title_2}' if valid_title_2 else '') + 
                         f'\n\n{torrent.get("description") or ""}'),
                "title": pick_title
            }

            self.addDirectoryItem(final_display_name, url_params, picked_poster_link, 'DefaultMovies.png',
                                  context=context_menu_items, isFolder=True, meta=meta_plot)

        if remaining_count > 0:
            self.addDirectoryItem(f"[B][COLOR yellow]>>> Következő oldal ({current_page + 1}) - ({remaining_count} maradt) >>>[/COLOR][/B]", f"all_merged_played_torrents_action&page={current_page + 1}", '', 'DefaultFolder.png')

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
    
    def clean_base64_data(self, data):
        if not data or data is None: return ""
        text_data = str(data)
        if text_data.lower() in ["none", "null", ""]: return ""
        
        try:
            import base64
            import re
            current = text_data

            for _ in range(5):
                if not isinstance(current, str) or len(current) < 4: break
                try:
                    decoded = base64.b64decode(current).decode('utf-8')
                    if str(decoded).lower() == "none": return ""
                    current = decoded
                    if "http" in current: break
                except: break

            if "127.0.0.1" in current or "localhost" in current:
                current_port = addon.getSetting('proxy_port')
                if not current_port: current_port = "8081"
                current = re.sub(r'127\.0\.0\.1:\d+', f'127.0.0.1:{current_port}', current)
                current = re.sub(r'localhost:\d+', f'127.0.0.1:{current_port}', current)

            if "http" in current and "&t=image/png" in current:
                current = current.split("&t=image/png")[0] + "&t=image/png"
                
            return current
        except:
            return text_data
    
    def remove_torrent(self, torrent_id):
        if xbmcgui.Dialog().yesno("nCore TV - Törlés megerősítése", "Biztosan el akarod távolítani ezt a tételt az előzményekből?"):

            self.db.delete_torrent(torrent_id)

            try:
                h_d = self.load_played_torrents()
                h_d = [t for t in h_d if str(t.get('torrent_id')) != str(torrent_id)]
            except: 
                pass

            xbmc.executebuiltin('Container.Refresh')
            # xbmc.log(f"[nCore_TV] Torrent törölve az előzményekből: {torrent_id}", xbmc.LOGINFO)
        
        else:
            pass

    def removeSearchHistoryItem(self, query):
        self.db.delete_search_item(query)
        xbmc.executebuiltin('Container.Refresh')

    def search_with_imdb(self, imdb_id):
        full_ncore_search_url = f"{base_url}{imdb_kereso}{imdb_id}"
        plugin_next_action = f"plugin://{addon_str}/?action=newsearch_3&url={quote_plus(full_ncore_search_url)}&imdb_id={imdb_id}"

        xbmc.executebuiltin(f'Container.Update({plugin_next_action})')

    def more_like_this_imdb(self, imdb_id):
        plugin_next_action = f"plugin://{addon_str}/?action=more_like_this&imdb_id={imdb_id}"
        xbmc.executebuiltin(f'Container.Update({plugin_next_action})')

    def saveSearch(self, full_url, context, mire_text):
        if not full_url.strip(): return
    
        imdb_name = ""
        if context == 'newsearch_2':
            import requests
            if not re.search(r'tt', mire_text): mire_text = f'tt{mire_text}'
            try:
                res = nc_get(f'{a_d}{c_d}{i_d}{mire_text}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                if isinstance(res, list): res = res[0] if res else {}
                alt_titles = res.get("alt_titles", [])
                imdb_name = next((alt["name"] for alt in alt_titles if alt.get("lang") == 19), res.get("title") or "")
            except: pass

        base_name = determineDisplayName(context, full_url)
        display_name = f"{base_name}: [COLOR lime]{mire_text}[/COLOR]"
    
        new_entry = {
            "query": full_url,
            "type": context,
            "display_name": display_name,
            "mire_text": mire_text,
            "timestamp": datetime.now().isoformat(),
            "imdb_name": imdb_name
        }

        self.db.add_search_item(new_entry)

    def listStaticSearches(self):
        for item in static_search_json:
            display_name = item.get("addDirectoryItemName", "")
            action_type = item.get("type", "newsearch")
            query_url = item.get("query", "")

            action_string = f"{action_type}&saved_url={quote_plus(query_url)}"
            
            self.addDirectoryItem(f'[B]{display_name}', action_string, "", "DefaultFolder.png", isFolder=True)
        
        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getHistorySearches(self):
        self.addDirectoryItem("[COLOR FFF56C00][B]Keresési előzmények törlése[/B][/COLOR]", "clearSearchHistory", "", "DefaultAddonUpdates.png")

        searches = self.db.get_search_history()
        
        if not searches:
            pass
        
        for entry in searches:
            query = entry.get("query", "")
            context_val = entry.get("type", "newsearch")
            display_name = entry.get("display_name", query)
            imdb_name = entry.get("imdb_name", "")

            if xxx_contents == 'false' and re.search(r'XXX:', display_name, re.IGNORECASE):
                continue
            
            final_display = f'{display_name} ({imdb_name})' if imdb_name else display_name

            removal_context = [("[B][COLOR FFF56C00]Eltávolítás a listából[/COLOR][/B]", f"remove_search_item&query={quote_plus(query)}")]
            main_item_action = f"{context_val}&saved_url={quote_plus(query)}"
            
            self.addDirectoryItem(final_display, main_item_action, "", "DefaultFolder.png", context=removal_context)
            
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
    
    def alreadySearched(self):
        self.getHistorySearches()
    
    def doSearch(self, url, saved_url=None):
        is_refresh = xbmcgui.Window(10000).getProperty('nCore_Rating_Refreshing') == 'true'
        last_url = xbmcgui.Window(10000).getProperty('nCore_LastSearchUrl')

        if is_refresh and last_url:
            xbmcgui.Window(10000).clearProperty('nCore_Rating_Refreshing')
            self.getItems(last_url)
            return

        if saved_url:
            full_link = saved_url
        else:
            if not url: return
            search_text = self.getSearchText()
            if not search_text.strip(): return
            full_link = f"{url}{search_text}"
            self.saveSearch(full_link, "newsearch", search_text)

        xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', full_link)
        self.getItems(full_link)

    def doSearch_2(self, url, saved_url=None):
        is_refresh = xbmcgui.Window(10000).getProperty('nCore_Rating_Refreshing') == 'true'
        last_url = xbmcgui.Window(10000).getProperty('nCore_LastSearchUrl')

        if is_refresh and last_url:
            xbmcgui.Window(10000).clearProperty('nCore_Rating_Refreshing')
            self.getItems(last_url)
            return

        if saved_url:
            full_link = saved_url
        else:
            if not url: return
            search_text = self.getSearchText_2()
            if not search_text.strip(): return
            full_link = f"{url}{search_text}"
            self.saveSearch(full_link, "newsearch_2", search_text)

        xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', full_link)
        self.getItems(full_link)

    def doSearch_3(self, url, imdb_id):
        if not url: return
        if imdb_id != '':
            full_link = f"{url}{imdb_id}"
            xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', full_link)
            self.getItems(full_link)
        else:
            xbmc.log("doSearch_3: IMDb ID empty", xbmc.LOGINFO)

    def doSearch_4_text(self, url):
        if not url: return
        full_link = f"{url}"
        xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', full_link)
        self.getItems(full_link)

    def doSearch_Name(self, url):
        is_refresh = xbmcgui.Window(10000).getProperty('nCore_Rating_Refreshing') == 'true'
        last_url = xbmcgui.Window(10000).getProperty('nCore_LastSearchUrl')

        if is_refresh and last_url:
            xbmcgui.Window(10000).clearProperty('nCore_Rating_Refreshing')
            self.getActors(last_url)
            return

        if not url: return
        search_text = self.getSearchTextName()
        if not search_text.strip(): return
        full_link = f"{url}{search_text}.json"
        
        xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', full_link)
        self.getActors(full_link)

    def getSearchTextName(self, preloaded_text=None):
        if preloaded_text:
            return preloaded_text.strip()
        keyb = xbmc.Keyboard('', 'Add meg a keresendő színész nevét')
        keyb.doModal()
        if keyb.isConfirmed():
            text = keyb.getText().strip()
            return text
        return ''

    def getCastList(self, imdb_id, media_type, movie_poster):
        import requests, sys
        from urllib.parse import quote_plus

        if int(sys.argv[1]) < 0 and not self.params.get('is_ui_nav'):
            safe_poster = quote_plus(str(movie_poster or ""))
            url = f"plugin://plugin.video.nCore_TV/?action=get_cast_list&imdb_id={imdb_id}&media_type={media_type}&poster_link={safe_poster}&is_ui_nav=true"
            xbmc.executebuiltin(f"Container.Update({url})")
            return

        trakt_type = "movies" if media_type == 'movie' else "shows"
        trakt_client_id = f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': trakt_client_id}
        url = f"https://api.trakt.tv/{trakt_type}/{imdb_id}/people?extended=full"
        
        try:
            response = requests.get(url, headers=headers, timeout=15)
            if response.status_code != 200: return
            people_data = response.json()

            cast_list = people_data.get('cast', [])
            crew_data = people_data.get('crew', {})
            directors = [p for p in crew_data.get('directing', []) if p.get('job') == 'Director']

            if not cast_list and not directors:
                xbmcgui.Dialog().notification("Infó", "Nem található stáblista.", xbmcgui.NOTIFICATION_INFO, 3000)
                return

            for director in directors:
                person = director.get('person', {})
                name = person.get('name', 'Ismeretlen Rendező')
                biography = person.get('biography', '')
                nm_id = person.get('ids', {}).get('imdb')
                
                if nm_id:
                    images = person.get('images', {})
                    headshots = images.get('headshot', [])
                    actor_thumb = f"https://{headshots[0]}" if headshots else movie_poster

                    m_label = "|  RENDEZŐ  |"
                    display_name = f"[COLOR gold]{m_label}[/COLOR] [B]{name}[/B]"
                    
                    meta = {"title": name, "plot": f"[B]RENDEZŐ[/B]\n\n{biography}" if biography else f"Rendező: {name}"}
                    u_params = f"ext_actors&actor_id={nm_id}&actor_name={quote_plus(str(name))}&poster_link={quote_plus(str(actor_thumb))}"
                    
                    self.addDirectoryItem(display_name, u_params, actor_thumb, 'DefaultActor.png', isFolder=True, meta=meta)

            for actor in cast_list:
                person = actor.get('person', {})
                name = person.get('name', 'Ismeretlen')
                character = actor.get('character', '')
                biography = person.get('biography', '')
                nm_id = person.get('ids', {}).get('imdb')

                if nm_id:
                    images = person.get('images', {})
                    headshots = images.get('headshot', [])
                    actor_thumb = f"https://{headshots[0]}" if headshots else movie_poster

                    m_label = "|  SZÍNÉSZ  |"
                    display_name = f"[COLOR lightgreen]{m_label}[/COLOR] [B]{name}[/B]"
                    if character: display_name += f" [COLOR gray]as {character}[/COLOR]"
                    
                    ep_total = actor.get('episode_count')
                    if ep_total: display_name += f" [COLOR gray]({ep_total} ep.)[/COLOR]"

                    meta = {"title": name, "plot": biography if biography else f"{name} as {character}"}
                    u_params = f"ext_actors&actor_id={nm_id}&actor_name={quote_plus(str(name))}&poster_link={quote_plus(str(actor_thumb))}"
                    
                    self.addDirectoryItem(display_name, u_params, actor_thumb, 'DefaultActor.png', isFolder=True, meta=meta)

        except Exception as e:
            xbmc.log(f"getCastList Error: {e}", xbmc.LOGERROR)

        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)

    def getActors(self, full_link):
        import requests
        import json
        
        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'hu',
            'origin': 'https://www.imdb.com',
            'referer': 'https://www.imdb.com/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        }
        
        resp = nc_get(full_link, headers=headers).json()
        
        output_list = []
        if 'd' in resp and isinstance(resp['d'], list):
            for entry in resp['d']:
                if 'id' in entry and entry['id'].startswith('nm'):
                    poster_link = ''
                    if 'i' in entry and entry['i'] is not None and 'imageUrl' in entry['i']:
                        poster_link = entry['i']['imageUrl']
        
                    actor_id = entry.get('id', '')
                    actor_name = entry.get('l', '')
                    
                    metadata = {'title': f'[B]{actor_name}[/B]'}
                    
                    url_params = f'ext_actors&actor_id={actor_id}&actor_name={actor_name}&poster_link={poster_link}'
                    
                    self.addDirectoryItem(actor_name, url_params, poster_link, 'DefaultMovies.png', isFolder=True, meta=metadata)

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def extActors(self, full_link, actor_id, actor_name, poster_link, title):
        resp_data = []

        headers = {
            'accept': 'application/graphql+json, application/json',
            'accept-language': 'hu',
            'content-type': 'application/json',
            'origin': 'https://www.imdb.com',
            'referer': f'https://www.imdb.com/name/{actor_id}/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
            'x-imdb-user-country': 'HU',
            'x-imdb-user-language': 'en-US',
        }

        possible_targets = [
            'amzn1.imdb.concept.name_credit_category.a9ab2a8b-9153-4edb-a27a-7c2346830d77',
            'amzn1.imdb.concept.name_credit_category.7f6d81aa-23aa-4503-844d-38201eb08761',
            'actor',
            'actress'
        ]

        for test_target in possible_targets:
            if resp_data:
                break
                
            for current_sha256_hash in ext_actors_hashes:
                params = {
                    'operationName': 'FilmographyV2Pagination',
                    'variables': f'{{"after":"","category":"{test_target}","includeUserRating":false,"isProPage":false,"locale":"en-US","nameId":"{actor_id}","order":"DESC","projectStatus":["PREVIOUS"]}}',
                    'extensions': f'{{"persistedQuery":{{"sha256Hash":"{current_sha256_hash}","version":1}}}}',
                }
                
                try:
                    response = requests.get('https://caching.graphql.imdb.com/', params=params, headers=headers, timeout=10)
                    if response.status_code == 200:
                        resp_json = response.json()
                        data = resp_json.get('data')
                        
                        if data:
                            name_data = data.get('name')
                            if name_data:
                                credit_keys_to_check = ['CreditV2Edge', 'creditsV2', 'credit_category', 'actor_credits', 'actress_credits', 'writer_credits', 'director_credits']
                                
                                found_credits = None
                                for key in credit_keys_to_check:
                                    credits_container = name_data.get(key)
                                    if credits_container and isinstance(credits_container, dict) and 'edges' in credits_container:
                                        found_credits = credits_container
                                        break 
                                
                                if found_credits:
                                    temp_resp_data = found_credits.get('edges', [])
                                    if temp_resp_data: 
                                        resp_data = temp_resp_data
                                        break
                except Exception as e:
                    xbmc.log(f"extActors GraphQL API hiba ({current_sha256_hash}): {e}", xbmc.LOGERROR)
                    continue
            
            if resp_data:
                break

        if not resp_data:
            xbmcgui.Dialog().notification("Infó", "Nem tölthető be a színész adatlapja (Nincs adat).", xbmcgui.NOTIFICATION_INFO, 3000)
            if custom_view_list == 'true':
                self.endDirectory(fixed_wide_view)
            else:    
                self.endDirectory(user_change_view)
            return

        tv_series = []
        movies = []
        imdb_ids_to_query = []
        
        for item in resp_data:
            if not isinstance(item, dict) or not item:
                continue 

            node = item.get('node', {}) 
            if not isinstance(node, dict) or not node:
                continue

            title_data_raw = node.get('title', {}) 
            if not isinstance(title_data_raw, dict) or not title_data_raw:
                continue
            
            extracted_data = {}
            extracted_data['imdb_id'] = title_data_raw.get('id', '')
            
            extracted_data['title_text'] = (title_data_raw.get('titleText') or {}).get('text', '')
            extracted_data['original_title_text'] = (title_data_raw.get('originalTitleText') or {}).get('text', '')
            
            primary_image = title_data_raw.get('primaryImage') 
            extracted_data['poster_link'] = primary_image.get('url', '') if isinstance(primary_image, dict) else ''

            extracted_data['aggregate_rating'] = (title_data_raw.get('ratingsSummary') or {}).get('aggregateRating', None)

            extracted_data['vote_count'] = (title_data_raw.get('ratingsSummary') or {}).get('voteCount', 0)
            
            release_year_obj = title_data_raw.get('releaseYear') or {}
            extracted_data['release_year'] = release_year_obj.get('year', None)
            extracted_data['end_year'] = release_year_obj.get('endYear', None)
            
            extracted_data['runtime_secs'] = (title_data_raw.get('runtime') or {}).get('seconds', 0)
            
            ep_credits = node.get('episodeCredits') or {}
            extracted_data['ep_total'] = ep_credits.get('total', 0)
            
            seasons_list = []
            seasons_data = ep_credits.get('displayableSeasons') or {}
            for s_edge in seasons_data.get('edges', []):
                s_val = s_edge.get('node', {}).get('season')
                if s_val: seasons_list.append(str(s_val))
            extracted_data['seasons'] = ", ".join(seasons_list)

            genres_list_raw = []
            title_genres_container = title_data_raw.get('titleGenres')
            if isinstance(title_genres_container, dict):
                genres_list_raw = title_genres_container.get('genres', [])
            
            extracted_data['genres'] = ", ".join([
                g.get('genre', {}).get('text', '') 
                for g in genres_list_raw 
                if isinstance(g, dict) and isinstance(g.get('genre'), dict) and g.get('genre', {}).get('text')
            ])

            formatted_character_names = ""
            is_voice_actor = False

            credited_roles_edges = node.get('creditedRoles', {}).get('edges', [])
            character_names_list = []
            
            if credited_roles_edges:
                for role_edge in credited_roles_edges:
                    role_node = role_edge.get('node', {})

                    chars_edges = role_node.get('characters', {}).get('edges', [])
                    for c_edge in chars_edges:
                        c_name = c_edge.get('node', {}).get('name')
                        if c_name: character_names_list.append(c_name)

                    attrs = role_node.get('attributes')
                    if attrs and any(a.get('text') == 'voice' for a in attrs if isinstance(a, dict)):
                        is_voice_actor = True

            if not character_names_list:
                chars_raw = node.get('characters')
                if isinstance(chars_raw, list):
                    for char_item in chars_raw:
                        if isinstance(char_item, dict) and char_item.get('name'):
                            character_names_list.append(char_item['name'])

                attrs_raw = node.get('attributes')
                if attrs_raw and any(a.get('text') == 'voice' for a in attrs_raw if isinstance(a, dict)):
                    is_voice_actor = True

            if character_names_list:
                all_chars = ", ".join(list(set(character_names_list)))
                formatted_character_names = f"{all_chars} (voice)" if is_voice_actor else all_chars
            
            extracted_data['formatted_character_names'] = formatted_character_names

            extracted_data['pegi'] = ''
            if isinstance(title_data_raw, dict):
                certificate_data = title_data_raw.get('certificate')
                if isinstance(certificate_data, dict):
                    extracted_data['pegi'] = certificate_data.get('rating', '')

            title_type_id = (title_data_raw.get('titleType') or {}).get('id')
            
            if title_type_id == 'tvSeries':
                extracted_data['type'] = 'Sorozat'
                tv_series.append(extracted_data)
            elif title_type_id == 'movie':
                extracted_data['type'] = 'Film'
                movies.append(extracted_data)
            
            if extracted_data['imdb_id']:
                imdb_ids_to_query.append(extracted_data['imdb_id'])

        db_sync_data = self.db.get_indicators_for_list(imdb_ids_to_query)

        all_titles = tv_series + movies
        all_titles.sort(key=lambda x: x.get('release_year') if x.get('release_year') is not None else float('-inf'), reverse=True)

        for title_data in all_titles:
            imdb_id = title_data.get('imdb_id', '')

            indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, None, db_sync_data, [])

            title_text = title_data.get('title_text', '')
            poster_link = title_data.get('poster_link', '')
            original_title_text = title_data.get('original_title_text', '')
            release_year = title_data.get('release_year', '')
            end_year = title_data.get('end_year', '')
            aggregate_rating = title_data.get('aggregate_rating', None)
            vote_count = title_data.get('vote_count', 0)
            runtime_secs = title_data.get('runtime_secs', 0)
            ep_total = title_data.get('ep_total', 0)
            seasons = title_data.get('seasons', '')
            genres_str = title_data.get('genres', '') 
            item_type = title_data.get('type', '')
            formatted_character_names = title_data.get('formatted_character_names', '')
            rated = title_data.get('pegi', '')
            
            title = title_text or original_title_text or 'Ismeretlen Cím'

            full_plot_text = []
            if original_title_text:
                year_info = f"{release_year}-{end_year}" if end_year else f"{release_year}"
                year_display = f" ([COLOR gold]{year_info}[/COLOR])" if release_year else ""
                full_plot_text.append(f"\n[B]Eredeti cím:[/B] {original_title_text}{year_display}")

            if formatted_character_names:
                ep_info = f" ({ep_total} epizód - Szezon: {seasons})" if ep_total > 0 else ""
                full_plot_text.append(f"[B]Szerep:[/B] {formatted_character_names}{ep_info}")
            
            if rated:
                full_plot_text.append(f"[B]Korhatár:[/B] {rated}")

            if aggregate_rating is not None:
                f_votes = "{:,}".format(vote_count).replace(",", ".") if vote_count else ""
                full_plot_text.append(f"[B]IMDb:[/B] {float(aggregate_rating):.1f} ({f_votes} szavazat)")
            
            if runtime_secs:
                full_plot_text.append(f"[B]Hossz:[/B] {runtime_secs // 60} perc")

            if genres_str:
                full_plot_text.append(f"[B]Műfaj:[/B] {genres_str}")

            metadata = {
                'title': title,
                'plot': f'{plot_status_line}' + "\n".join(full_plot_text)
            }

            display_name = ""
            type_inner_width = 10
            if item_type == 'Sorozat':
                first_part = f"| {item_type} | "
            else:
                first_part = f"| {item_type:^{type_inner_width}} | "

            display_name = f"{first_part}{indicator}[B]{title}[/B]"

            if release_year:
                display_name += f" | ([COLOR gold]{release_year}[/COLOR])"

            if imdb_id:
                query_string = f"get_info_from_imdb&imdb_id={imdb_id}&poster_link={poster_link}&title={quote_plus(title)}"
                self.addDirectoryItem(display_name, query_string, poster_link, 'DefaultFolder.png', isFolder=True, meta=metadata)

        if custom_view_list == 'true':
            self.endDirectory(fixed_wide_view)
        else:    
            self.endDirectory(user_change_view)

    def getInfoImdb(self, imdb_id, poster_link, title=''):
        from bs4 import BeautifulSoup
        import urllib.parse
        import requests
        import re

        title = urllib.parse.unquote(title) if title else ''
        
        description = ''
        tmdb = ''
        type_for_tmdb = ''
        trailer_name = ''
        trailer_id = ''

        response_2 = {}
        try:
            first_try = f'{k_h_n_o}/tv/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}'
            second_try = f'{k_h_n_o}/movies/{imdb_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}'

            response_2_req = nc_get(first_try)
            response_2_req.raise_for_status()
            response_2 = response_2_req.json()
            
            if not response_2 or not response_2.get('poster'):
                response_2_req = nc_get(second_try)
                response_2_req.raise_for_status()
                response_2 = response_2_req.json()
        except:
            pass

        if response_2:
            description = response_2.get('overview', '')
            tmdb_val = response_2.get('ids', {}).get('tmdb', '')
            if tmdb_val:
                try: tmdb = int(tmdb_val)
                except: tmdb = ''

            p_path = response_2.get('poster', '')
            if p_path:
                poster_link = f'{a_d}{s_s}{s_g}{p_path}_m.jpg'
            
            type_for_tmdb = response_2.get('type', '')

        if not type_for_tmdb or type_for_tmdb == '':
            if re.search(r'[sS]\d+[eExX]\d+|\d+\.\s*évad|Season\s*\d+', title):
                type_for_tmdb = 'tv'
            else:
                type_for_tmdb = 'movie'
        else:
            if type_for_tmdb != 'movie':
                type_for_tmdb = 'tv'

        if tmdb and type_for_tmdb:
            try:
                cookies_tmdb = {'tmdb.prefs': '%7B%22i18n_fallback_language%22%3A%22en-US%22%2C%22locale%22%3A%22hu-HU%22%2C%22country_code%22%3A%22HU%22%2C%22timezone%22%3A%22Europe%2FBudapest%22%7D', '__e_inc': '1'}
                headers_tmdb = {'authority': 'www.themoviedb.org', 'accept': 'text/html,application/xhtml+xml', 'user-agent': 'Mozilla/5.0'}
                html_tmdb = nc_get(f'https://www.themoviedb.org/{type_for_tmdb}/{tmdb}', cookies=cookies_tmdb, headers=headers_tmdb)
                if html_tmdb.status_code == 200:
                    soup_tmdb = BeautifulSoup(html_tmdb.text, 'html.parser')
                    d_meta = soup_tmdb.find('meta', property='og:description')
                    if d_meta: description = d_meta.get('content', description)
                    t_meta = soup_tmdb.find('meta', property='og:title')
                    if t_meta: title = t_meta.get('content', title)
            except:
                pass

        if not title:
            title = f"Ismeretlen cím ({imdb_id})"

        db_sync_data = self.db.get_indicators_for_list([imdb_id])
        indicator, plot_status_line, is_already_played = self._build_indicators(imdb_id, None, db_sync_data, [])
        metadata = {'plot': f'{plot_status_line}\n{description.strip()}'}
        
        if imdb_id and title:
            self.addDirectoryItem(f"{indicator}[B]{title} (imdb: {imdb_id})[/B]", f"newsearch_3&url={quote_plus(f'{base_url}{imdb_kereso}')}&imdb_id={imdb_id}", poster_link, '', 'DefaultFolder.png', meta=metadata)

            self.addDirectoryItem(f"[B][COLOR lightgreen][I]--[/I] Szereplők (stáblista) [I]--[/I][/COLOR][/B]", f"get_cast_list&imdb_id={imdb_id}&media_type={type_for_tmdb}&poster_link={quote_plus(str(poster_link))}", poster_link, 'DefaultActor.png', isFolder=True, meta={"title": title, "plot": f'{plot_status_line}\n{description}'})

            if type_for_tmdb == 'movie':
                self.addDirectoryItem(f'[B][COLOR gold]A Film többi része (Franchise)[/COLOR][/B]', f"tmdb_get_collection&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": title, "plot": f'{plot_status_line}\n{description}'})

            self.addDirectoryItem(f'[B][COLOR gold]Hasonló tartalmak mutatása[/COLOR][/B]', f"more_like_this&imdb_id={imdb_id}", poster_link, 'DefaultMovies.png', isFolder=True, meta={"title": title, "plot": f'{plot_status_line}\n{description}'})

            try:
                r1 = nc_get(f'{ab_t}.{kf_t}/search/id?imdb={imdb_id}&extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                if r1 and isinstance(r1, list) and len(r1) > 0 and 'ids' in r1[0]:
                    s_id = r1[0]['ids'].get('simkl')
                    if s_id:
                        r2 = nc_get(f'{a_d}{c_d}{i_d}{s_id}?extended=full&client_id={atb_td}{kzf_td}{frt_td}{qwe_td}{cde_td}{otg_td}{cvb_td}{tdz_td}').json()
                        if r2 and 'trailers' in r2 and r2['trailers'] and len(r2['trailers']) > 0:
                            tr_n = r2['trailers'][0].get('name', '')
                            tr_id = r2['trailers'][0].get('youtube', '')
                            if tr_id:
                                self.addDirectoryItem(f"[B][COLOR lime][Bemutató][/COLOR] ({tr_n})[/B]", f'plugin://plugin.video.youtube/play/?video_id={tr_id}', poster_link, 'DefaultFolder.png', isFolder=False, isAction=False, meta={'plot': f'{plot_status_line}\n{description.strip()}'})
            except:
                pass
        
        self.endDirectory(fixed_wide_view if custom_view_list == 'true' else user_change_view)
    
    def getSearchText(self, preloaded_text=None):
        if preloaded_text:
            return preloaded_text.strip()
        keyb = xbmc.Keyboard('', 'Add meg a keresendő film címet')
        keyb.doModal()
        if keyb.isConfirmed():
            text = keyb.getText().strip()
            return text
        return ''
    
    def getSearchText_2(self, preloaded_text=None):
        if preloaded_text:
            return preloaded_text.strip()
        keyb = xbmc.Keyboard('', 'imdb azonosító (tt vagy anélkül)')
        keyb.doModal()
        if keyb.isConfirmed():
            text = keyb.getText().strip()
            return text
        return ''
    
    def clearSearchHistory(self):
        if xbmcgui.Dialog().yesno("Törlés", "Biztosan törlöd az összes keresési előzményt?"):
            self.db.clear_all_search_history()
            xbmc.executebuiltin('Container.Refresh')

    def addDirectoryItem(self, name, query, thumb=None, icon=None, context=None, queue=False, isAction=True, isFolder=True, Fanart=None, meta=None, banner=None):
        url = f'{sysaddon}?action={query}' if isAction else query
        _lite = _lite_on() and not self._is_widget()
        if _lite and thumb and str(thumb).startswith('http'):
            # gyors mód: a távoli borítót nem töltjük/dekódoljuk (gyenge boxon ez okozza a görgetési akadást)
            thumb = icon if (icon and not str(icon).startswith('http')) else 'DefaultMovies.png'
            Fanart = None
        if not thumb:
            thumb = icon if icon else ''
        cm = []
        if queue and 'queueMenu' in globals():
            cm.append((queueMenu, f'RunPlugin({sysaddon}?action=queueItem)'))
    
        if isinstance(context, list):
            for context_item in context:
                if isinstance(context_item, (list, tuple)) and len(context_item) >= 2:
                    try:
                        label = str(context_item[0])
                        action_url = f'RunPlugin({sysaddon}?action={context_item[1]})'    
                        cm.append((label, action_url))
                    except Exception as e:
                        xbmc.log(f"Error processing context item: {context_item} - {e}", xbmc.LOGERROR)
        elif isinstance(context, (list, tuple)) and len(context) >= 2:
            try:
                label = str(context[0])
                action_url = f'RunPlugin({sysaddon}?action={context[1]})'
                cm.append((label, action_url))
            except Exception as e:
                xbmc.log(f"Error processing single context tuple: {context} - {e}", xbmc.LOGERROR)
    
        item = xbmcgui.ListItem(label=name)
        item.addContextMenuItems(cm)

        art = {'icon': thumb, 'thumb': thumb}
        if thumb and str(thumb).startswith('http'):
            art['poster'] = thumb  # skin-widgetek a poster art-ot keresik
        if banner:
            art['banner'] = banner
        if Fanart:
            art['fanart'] = Fanart
        elif addonFanart and not _lite:
            art['fanart'] = addonFanart
        item.setArt(art)

        if Fanart:
            item.setProperty('Fanart_Image', Fanart)
        elif addonFanart and not _lite:
            item.setProperty('Fanart_Image', addonFanart)
        
        if not isFolder:
            item.setProperty('IsPlayable', 'true')

        if isinstance(meta, dict):
            try:
                if hasattr(item, 'getVideoInfoTag'):
                    info_tag = item.getVideoInfoTag()
                    if info_tag is not None:
                        if 'title' in meta:
                            info_tag.setTitle(meta['title'])
                        _mt = meta.get('mediatype') or self._widget_mediatype()
                        if _mt and hasattr(info_tag, 'setMediaType'):
                            info_tag.setMediaType(_mt)
                        if 'plot' in meta:
                            info_tag.setPlot(meta['plot'])
                        if 'genre' in meta:
                            info_tag.setGenre(meta['genre'])
                        if 'year' in meta:
                            try:
                                info_tag.setYear(int(meta['year']))
                            except:
                                info_tag.setYear(meta['year'])
                        if 'rating' in meta:
                            info_tag.setRating(float(meta['rating']))
                        if 'director' in meta:
                            info_tag.setDirector(meta['director'])
                        if 'cast' in meta:
                            info_tag.setCast(meta['cast'])
                        xbmcplugin.addDirectoryItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
                        return
            except:
                pass

            info_labels = {}
            if 'title' in meta:
                info_labels['title'] = meta['title']
            if 'plot' in meta:
                info_labels['plot'] = meta['plot']
            if 'genre' in meta:
                info_labels['genre'] = meta['genre']
            if 'year' in meta:
                info_labels['year'] = meta['year']
            if 'rating' in meta:
                info_labels['rating'] = meta['rating']
            if 'director' in meta:
                info_labels['director'] = meta['director']
            if 'cast' in meta:
                if isinstance(meta['cast'], list):
                    info_labels['cast'] = ', '.join(meta['cast'])
                else:
                    info_labels['cast'] = meta['cast']
            if 'plotoutline' in meta:
                info_labels['plotoutline'] = meta['plotoutline']
            if 'tagline' in meta:
                info_labels['tagline'] = meta['tagline']
            
            if info_labels:
                item.setInfo('video', info_labels)
        
        xbmcplugin.addDirectoryItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
    
    def _is_widget(self):
        return str(getattr(self, 'params', {}).get('widget', '')) in ('1', 'true')

    def _widget_mediatype(self):
        if not self._is_widget(): return None
        return 'tvshow' if self.params.get('content') == 'tvshows' else 'movie'

    def endDirectory(self, type='addons', cache=True, update=False):
        if self._is_widget():
            # Widget: érvényes tartalomtípus (a 'series' nem létezik Kodiban), cache be, nincs frissítés
            type = self.params.get('content') or 'movies'
            cache, update = True, False
        xbmcplugin.setContent(syshandle, type)
        xbmcplugin.endOfDirectory(syshandle, succeeded=True, updateListing=update, cacheToDisc=cache)
