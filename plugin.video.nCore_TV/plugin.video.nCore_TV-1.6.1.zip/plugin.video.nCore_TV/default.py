# -*- coding: utf-8 -*-

'''
    nCore TV Addon
    Copyright (C) 2026 heg
    Módosítások (fork): Copyright (C) 2026 TomSzo, módosítva: 2026-09-20 (lásd CHANGELOG.md)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
import xbmc
import xbmcaddon

from resources.lib.indexers.navigator import navigator
from urllib.parse import parse_qsl

addon = xbmcaddon.Addon('plugin.video.nCore_TV')

proxy_needed = addon.getSetting('proxy_enable')
if proxy_needed == 'true':
    from resources.lib.indexers.local_proxy import LocalProxyServer
    from resources.lib.indexers.local_proxy import get_proxy_server
    proxy_server = get_proxy_server()
    #xbmc.log(f"default py: LocalProxyServer használata: {proxy_server.host}:{proxy_server.port}", xbmc.LOGINFO)

query_string = sys.argv[2][1:] if sys.argv[2].startswith('?') else sys.argv[2]
params = dict(parse_qsl(query_string))

action = params.get('action')
url = params.get('url')
title_1 = params.get('title_1')
title_2 = params.get('title_2')
title_3 = params.get('title_3')
imdb_id = params.get('imdb_id')
imdb_rate = params.get('imdb_rate')
c_i = params.get('c_i')
feltoltve = params.get('feltoltve')
seeder = params.get('seeder')
leecher = params.get('leecher')
description = params.get('description')
torrent_id = params.get('torrent_id')
poster_link = params.get('poster_link')
clear_logo = params.get('clear_logo')
link_slug_id = params.get('link_slug_id')
bookmark_name = params.get('bookmark_name')
bookmark_num = params.get('bookmark_num')
rev_upload_date = params.get('rev_upload_date')
rev_seeders = params.get('rev_seeders')
rev_leechers = params.get('rev_leechers')
hnr_tstart = params.get('hnr_tstart')
saved_url = params.get('saved_url')
target_episode = params.get('target_episode')

get_justwatch = params.get('get_justwatch')
ext_justwatch = params.get('ext_justwatch')
real_slug_url = params.get('real_slug_url')
selected_date = params.get('selected_date')

popularTitlesSortBy_title = params.get('popularTitlesSortBy_title')
popularTitlesSortBy_id = params.get('popularTitlesSortBy_id')
objectTypes_title = params.get('objectTypes_title')
objectTypes_id = params.get('objectTypes_id')
genres_title = params.get('genres_title')
genres_id = params.get('genres_id')
after_cursor = params.get('after_cursor')

actor_id = params.get('actor_id')
actor_name = params.get('actor_name')
full_link = params.get('full_link')

year = params.get('year')
title = params.get('title')

bookmark_group_id = params.get('bookmark_group_id')
megerositve_value = params.get('megerositve_value')
div_konyvjelzo_nev_id = params.get('div_konyvjelzo_nev_id')

user_name = params.get('user_name')
watching_user_name = params.get('watching_user_name')

ignore_filter = params.get('ignore_filter', 'false')

tmdb_id = params.get('tmdb_id')
media_type = params.get('media_type')

nav = navigator()
nav.params = params

if action == 'remove_torrent':
    nav.remove_torrent(torrent_id)
    sys.exit(0)

elif action == 'clean_files':
    nav.clean_files_action()

elif action == 'remove_search_item':
    query = params.get('query')
    nav.removeSearchHistoryItem(query)
    sys.exit(0)
    
elif action == 'search_with_imdb':
    nav.search_with_imdb(imdb_id)
    sys.exit(0)

elif action == 'more_like_this_imdb':
    nav.more_like_this_imdb(imdb_id)
    sys.exit(0)


elif action == 'played_torrents':
    nav.PlayedTorrents()

elif action == 'view_played_group':
    nav.ViewPlayedGroup()

elif action == 'finished_torrents':
    nav.FinishedTorrents()

elif action == 'single_item_folder':
    nav.SingleItemFolder()

elif action == 'github_sync_options':
    nav.GithubSyncOptions()

elif action == 'github_sync_watching_series_action':
    nav.github_sync_watching_series_action()
    sys.exit(0)


elif action == 'github_download_and_merge_watching_series_action':
    nav.github_download_and_merge_watching_series_action()
    sys.exit(0)

elif action == 'local_played_torrents':
    nav.list_local_played_torrents()

elif action == 'github_sync_action':
    nav.GithubPlayedList()

elif action == 'all_merged_played_torrents_action':
    nav.all_merged_played_torrents()

elif action == 'view_github_list_action':
    nav.view_github_played_list()   


elif action == 'get_watching_series':
    nav.getWatchingSeries(url, imdb_id, title_1, title_2, poster_link)
    sys.exit(0)

elif action == 'ext_watching_series':
    nav.extWatchingSeries(url, imdb_id, title_1, title_2, title_3, poster_link)

elif action == 'show_watching_series':
    nav.ShowWatchingSeries()

elif action == 'delete_watching_series':
    nav.delete_watching_series(full_link, imdb_id, watching_user_name)


elif action == 'listStaticSearches':
    nav.listStaticSearches()

elif action == 'more_like_this':
    nav.MoreLikeThis(imdb_id)

elif action == 'get_info_from_tmdb':
    tmdb_id = params.get('tmdb_id')
    media_type = params.get('media_type')
    poster_link = params.get('poster_link')
    title = params.get('title')
    
    nav.get_info_from_tmdb(tmdb_id, media_type, poster_link, title)

elif action == 'tmdb_to_ncore':
    nav.TMDBToNcore()

elif action == 'tmdb_discovery_menu':
    nav.TMDBDiscoveryMenu()

elif action == 'tmdb_streaming_menu':
    nav.TMDBStreamingMenu()

elif action == 'tmdb_streaming_type':
    nav.TMDBStreamingTypeSelect()

elif action == 'tmdb_list':
    nav.TMDBList()

elif action == 'tmdb_themes_menu':
    nav.TMDBThemesMenu()

elif action == 'tmdb_streaming_news_menu':
    nav.TMDBStreamingNewsMenu()

elif action == 'tmdb_get_collection':
    nav.TMDBGetCollection()

elif action == 'tmdb_get_collection_context':
    nav.TMDBGetCollectionContext()

elif action == 'tmdb_streaming_news_select':
    nav.TMDBStreamingNewsSelect()

elif action == 'getContextBookmark':
    nav.getContextBookmark(torrent_id)

elif action == 'extContextBookmark':
    nav.extContextBookmark(torrent_id)

elif action == 'AddToContextBookmark':
    nav.AddToContextBookmark(torrent_id, bookmark_name, bookmark_group_id)

elif action == 'cloud_auth_diagnostic':
    nav.CloudAuthDiagnostic()


elif action == 'bookmark_database_check':
    nav.BookmarkDatabaseCheck()

elif action == 'deleteBookmarkTorrentAction':
    nav.deleteBookmarkTorrentAction(torrent_id, bookmark_group_id, megerositve_value, div_konyvjelzo_nev_id)

elif action == 'deleteBookmarkTorrentId':
    nav.deleteBookmarkTorrentId(torrent_id, bookmark_group_id, megerositve_value, div_konyvjelzo_nev_id)


elif action == 'context_torrent_to_seed':
    nav.context_torrent_to_seed(torrent_id)

elif action == 'download_torrent_to_seed':
    nav.download_torrent_to_seed(torrent_id)

elif action == 'torrent_filename_and_category':
    nav.torrent_filename_and_category(torrent_id)

##
elif action == 'setBookmarkCategories':
    nav.setBookmarkCategories(bookmark_name, bookmark_group_id)

elif action == 'forSetBookmark':
    nav.forSetBookmark(bookmark_name, bookmark_group_id)

elif action == 'autoAddBookmark':
    nav.autoAddBookmark(torrent_id, bookmark_name, bookmark_group_id)

##movie##
elif action == 'movie_categories':
    nav.getMovieCategories()

elif action == 'extr_movie':
    nav.extrMovie(url, title_1, title_2, torrent_id, imdb_id, imdb_rate, poster_link, clear_logo, feltoltve, seeder, leecher, description)

elif action == 'pick_version':
    nav.PickVersion(params.get('gid'))

elif action == 'sort_pick':
    nav.SortPick(params.get('target'), url)

elif action == 'movie_items':
    nav.getMovieItems(url, title_1, title_2, torrent_id, imdb_id, imdb_rate, c_i, feltoltve, seeder, leecher)

##series##
elif action == 'series_categories':
    nav.getSeriesCategories()

elif action == 'extr_series':
    nav.extrSeries(url, title_1, title_2, torrent_id, imdb_id, imdb_rate, poster_link, clear_logo, c_i, feltoltve, seeder, leecher, description)

elif action == 'series_items':
    nav.getSeriesItems(url, title_1, title_2, torrent_id, imdb_id, imdb_rate, c_i, feltoltve, seeder, leecher)

##zene##
elif action == 'zene_categories':
    nav.getZeneCategories()

elif action == 'extr_zene':
    nav.extrZene(url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher, description)

elif action == 'zene_items':
    nav.getZeneItems(url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher)

##xxx##
elif action == 'xxx_categories':
    nav.getXXXCategories()

elif action == 'extr_xxx':
    nav.extrXXX(url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher, description)

elif action == 'xxx_items':
    nav.getXXXItems(url, title_1, title_2, torrent_id, c_i, feltoltve, seeder, leecher)

##könyvjelzők##
elif action == 'book_mark':
    nav.getBookmarkCategories(url, bookmark_name, bookmark_num)

elif action == 'extr_book_mark':
    nav.extrBookmark(url, title_1, rev_upload_date, rev_seeders, rev_leechers, torrent_id)

elif action == 'extr_bookmark_torrent':
    nav.extrBookmarkTorrent(url, title_1, rev_upload_date, rev_seeders, rev_leechers, torrent_id)

##egyéb##
elif action == 'extend_searches':
    nav.getExtendSearches()

elif action == 'playback_settings_menu':
    torrent_id = params.get('torrent_id')
    elementum_url = params.get('elementum_url')
    original_args = params.get('original_args')

    nav.show_playback_menu(torrent_id, elementum_url, original_args)
    sys.exit(0)

elif action == 'save_video_position':
    torrent_id = params.get('torrent_id')
    nav.save_current_position(torrent_id)
    sys.exit(0)

elif action == 'manage_saved_positions':
    torrent_id = params.get('torrent_id')
    nav.manage_saved_positions(torrent_id)
    sys.exit(0)

elif action == 'load_video_position':
    torrent_id = params.get('torrent_id')
    nav.load_saved_position(torrent_id)
    sys.exit(0)

#trakt
elif action == 'trakt_setup_menu':
    nav.TraktMenu()

elif action == 'show_trakt_categories':
    nav.ShowTraktCategories()

elif action == 'watched_trakt_movies':
    nav.WatchedTraktMovies()

elif action == 'watched_trakt_series':
    nav.WatchedTraktSeries()

elif action == 'trakt_watchlist_movies':
    nav.TraktWatchlistMovies()

elif action == 'trakt_watchlist_series':
    nav.TraktWatchlistSeries()

elif action == 'trakt_watchlist_combined':
    nav.TraktWatchlistCombined()

elif action == 'trakt_up_next':
    nav.TraktUpNext()

elif action == 'trakt_history':
    nav.TraktHistory()

elif action == 'add_trakt_watchlist_action':
    imdb_id = params.get('imdb_id')
    is_series = params.get('is_series')
    nav.add_trakt_watchlist_action(imdb_id, is_series)

elif action == 'trakt_full_sync_action':
    nav.TraktFullSync()

elif action == 'trakt_calendar':
    nav.TraktCalendar()

elif action == 'trakt_continue':
    nav.TraktContinueWatching()

elif action == 'manual_metadata_cloud_sync':
    nav.ManualMetadataCloudSync()

#trakt dinamikus böngészés
elif action == 'trakt_genres_menu':
    nav.TraktGenresMenu()

elif action == 'trakt_years_menu':
    nav.TraktYearsMenu()

elif action == 'trakt_filtered_items':
    nav.TraktFilteredItems()

elif action == 'trakt_discovery_select':
    nav.TraktDiscoveryTypeSelect()

elif action == 'trakt_trending_lists':
    nav.TraktTrendingLists()

elif action == 'trakt_list_items':
    nav.TraktListItems()

#simkl
elif action == 'simkl_setup_menu':
    nav.SimklMenu()

elif action == 'show_simkl_categories':
    nav.ShowSimklCategories()

elif action == 'watched_simkl_movies':
    nav.WatchedSimklMovies()

elif action == 'watched_simkl_series':
    nav.WatchedSimklSeries()

elif action == 'simkl_plan_to_watch':
    nav.SimklPlanToWatch()

elif action == 'simkl_favorites':
    nav.SimklFavorites()

elif action == 'simkl_history':
    nav.SimklHistory()

elif action == 'add_simkl_plan_action':
    imdb_id = params.get('imdb_id')
    is_series = params.get('is_series')
    nav.add_simkl_plan_action(imdb_id, is_series)

elif action == 'simkl_full_sync_action':
    nav.SimklFullSync()

elif action == 'simkl_calendar':
    nav.SimklCalendar()

elif action == 'simkl_continue':
    nav.SimklContinueWatching()


elif action == 'simkl_up_next':
    nav.SimklUpNext()

#simkl böngészés
elif action == 'simkl_genres_menu':
    nav.SimklGenresMenu()

elif action == 'simkl_years_menu':
    nav.SimklYearsMenu()

elif action == 'simkl_filtered_items':
    nav.SimklFilteredItems()

elif action == 'simkl_to_ncore':
    nav.SimklToNcore()

elif action == 'simkl_discovery_select':
    nav.SimklDiscoveryTypeSelect()

elif action == 'simkl_weekly_discovery':
    nav.SimklWeeklyDiscoveryMenu()

elif action == 'simkl_streaming_networks':
    nav.SimklStreamingNetworks()

elif action == 'simkl_streaming_items':
    nav.SimklStreamingItems()

elif action == 'simkl_trending_menu':
    nav.SimklTrendingMenu()

elif action == 'simkl_mixed_items':
    nav.SimklMixedItems()

elif action == 'simkl_discovery_menu':
    nav.SimkldiscoveryMenu()

#plex
elif action == 'plex_setup_menu':
    nav.PlexMenu()

elif action == 'show_plex_categories':
    nav.ShowPlexCategories()

elif action == 'plex_continue':
    nav.PlexContinueWatching()

elif action == 'watched_plex_movies':
    nav.WatchedPlexMovies()

elif action == 'watched_plex_series':
    nav.WatchedPlexSeries()

elif action == 'plex_watchlist_movies':
    nav.PlexWatchlistMovies()

elif action == 'plex_watchlist_series':
    nav.PlexWatchlistSeries()

elif action == 'plex_watchlist_combined':
    nav.PlexWatchlistCombined()

elif action == 'all_merged_watchlist':
    nav.allMergedWatchlist()

elif action == 'plex_history':
    nav.PlexHistory()

elif action == 'plex_full_sync_action':
    nav.PlexFullSync()

elif action == 'add_plex_watchlist_action':
    imdb_id = params.get('imdb_id')
    is_series = params.get('is_series')
    nav.add_plex_watchlist_action(imdb_id, is_series)


elif action == 'torrent_database_audit':
    nav.TorrentDatabaseAudit()

elif action == 'db_summary':
    nav.getDatabaseSummary()
    sys.exit(0)

elif action == 'id_database_audit':
    nav.IDDatabaseAudit()

elif action == 'items':
    nav.getItems(url, ignore_filter)

elif action == 'search':
    nav.getSearches()

elif action == 'elementum_part':
    nav.getElementum()
    
elif action == 'stats':
    nav.getStats()

elif action == 'custom_filter_menu':
    nav.custom_filter_menu()

elif action == 'disable_filter_and_refresh':
    nav.disable_filter_and_refresh()

elif action == 'already_searched':
    nav.alreadySearched()

elif action == 'get_hnr':
    nav.getHNR(url, title_1, torrent_id, hnr_tstart)

elif action == 'seeded_torrents':
    nav.getSeededTorrents(url, title_1, torrent_id)

elif action == 'search_window':
    nav.SearchWindow()

elif action == 'open_rating_window': 
    nav.OpenRatingWindow()

elif action == 'open_rating_manager':
    nav.OpenRatingManager()

##recommend##
elif action == 'reco_open':
    nav.RecoOpen(params.get('imdb_id'))

elif action == 'container_go':
    nav.ContainerGo(params.get('q'))

elif action == 'ajanlo_more':
    nav.AjanloMore()

elif action == 'tmdb_hu_streaming':
    nav.TMDBHuStreamingMenu()

elif action == 'tmdb_hu_provider':
    nav.TMDBHuProvider()

elif action == 'get_ajanlo_categs':
    nav.getAjanloCategs(url)

elif action == 'get_recommend_both':
    nav.getRecommendBoth(url)

elif action == 'get_lists':
    nav.getLists(url)

elif action == 'get_file_list':
    nav.getFileList(torrent_id)

elif action == 'list_file_positions':
    nav.listFilePositions()

elif action == 'get_file_list_context':
    nav.getFileListContext()

elif action == 'set_trakt_rating_action':
    nav.setTraktRatingAction()


elif action == 'play_next_episode_action':
    nav.playNextEpisodeAction()
    sys.exit(0)

elif action == 'play_prev_episode_action':
    nav.playPrevEpisodeAction()
    sys.exit(0)

elif action == 'ext_lists':
    nav.extLists(url, poster_link, year)

elif action == 'ext_tvdb':
    nav.extTvdb(url, poster_link, year)

elif action == 'get_recommend_movie':
    nav.getRecommendMovie(url, link_slug_id, poster_link)

elif action == 'ext_recommend_movie':
    nav.ExtRecommendMovie(url, link_slug_id, imdb_id, description, poster_link)

elif action == 'get_recommend_series':
    nav.getRecommendSeries(url, link_slug_id, poster_link)

elif action == 'ext_recommend_series':
    nav.ExtRecommendSeries(url, link_slug_id, imdb_id, description, poster_link)

##
elif action == 'get_recommend_series_amazon':
    nav.getRecommendSeriesAmazon(url, link_slug_id, poster_link)

elif action == 'get_recommend_series_disney':
    nav.getRecommendSeriesDisney(url, link_slug_id, poster_link)

elif action == 'get_recommend_series_max':
    nav.getRecommendSeriesMAX(url, link_slug_id, poster_link)    

elif action == 'get_recommend_series_netflix':
    nav.getRecommendSeriesNetflix(url, link_slug_id, poster_link)

elif action == 'get_recommend_series_skyshowtime':
    nav.getRecommendSeriesSkyshowtime(url, link_slug_id, poster_link)

elif action == 'get_recommend_series_apple':
    nav.getRecommendSeriesApple_plus(url, link_slug_id, poster_link)
##


elif action == 'get_justwatch_date':
    nav.getJustWatchDate(real_slug_url, poster_link, description, title_1, selected_date)

elif action == 'get_justwatch_categories':
    nav.getJustWatchCategories()

elif action == 'pick_justwatch_categorys':
    nav.PickJustWatchCategories(popularTitlesSortBy_title, popularTitlesSortBy_id, objectTypes_title, objectTypes_id, genres_title, genres_id)

elif action == 'extr_justwatch_categorys':
    nav.ExtJustWatchCategories(popularTitlesSortBy_title, popularTitlesSortBy_id, objectTypes_title, objectTypes_id, genres_title, genres_id, after_cursor)

elif action == 'get_info_from_imdb':
    nav.getInfoImdb(imdb_id, poster_link, title)

###
elif action == 'playmovie':
    nav.playMovie(url, poster_link, clear_logo, imdb_id, c_i)

elif action == 'tmdbh':
    nav.TmdbHelper()

elif action == 'install_tmdbh_player':
    nav.install_tmdbh_player()

elif action == 'widget_menu':
    nav.WidgetMenu()

##kereső
elif action == 'newsearch':
    nav.doSearch(url, saved_url)

elif action == 'newsearch_2':
    nav.doSearch_2(url, saved_url)

elif action == 'newsearch_3':
    nav.doSearch_3(url, imdb_id)

elif action == 'newsearch_4':
    nav.doSearch_4_text(url)
    
elif action == 'newsearch_5':
    nav.doSearch_5_text(url)

elif action == 'search_name':
    nav.doSearch_Name(url)

elif action == 'get_actors':
    nav.getActors(full_link)

elif action == 'ext_actors':
    if addon.getSetting('person_roles') == 'false':
        nav.extActors(full_link, actor_id, actor_name, poster_link, title)
    else:
        nav.PersonRoles(actor_id, actor_name, poster_link)

elif action == 'ext_actors_imdb':
    nav.extActors(full_link, actor_id, actor_name, poster_link, title)

elif action == 'person_credits':
    nav.PersonCredits()

elif action == 'get_cast_list':
    nav.getCastList(imdb_id, media_type, poster_link)

elif action == 'clearSearchHistory':
    nav.clearSearchHistory()

elif action == 'imdb_search':
    nav.doSearchImdb_Name(url)

elif action is None:
    nav.root()    