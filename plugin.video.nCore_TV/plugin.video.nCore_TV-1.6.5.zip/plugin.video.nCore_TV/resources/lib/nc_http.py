# -*- coding: utf-8 -*-
# nCore TV (fork) - új fájl. Copyright (C) 2026 TomSzo, GPL-3.0-or-later (lásd LICENSE.txt).
"""
Vékony requests-wrapper: alapértelmezett timeout minden hívásnak.

Miért: a navigator.py-ban a requests.get/post hívások többsége timeout nélkül fut, így egy
elakadt hálózati kapcsolat (pl. gyenge wifi a boxon) végtelen ideig lefagyasztja a listát.
A kapcsolat-újrahasználat (Session) itt nem ad sokat: Kodi minden plugin-hívást új
interpreterben futtat, így a session úgyis elveszne két lista között.
"""
import requests

# (connect, read) másodperc
DEFAULT_TIMEOUT = (6, 25)


def nc_get(url, **kwargs):
    kwargs.setdefault('timeout', DEFAULT_TIMEOUT)
    return requests.get(url, **kwargs)


def nc_post(url, **kwargs):
    kwargs.setdefault('timeout', DEFAULT_TIMEOUT)
    return requests.post(url, **kwargs)
