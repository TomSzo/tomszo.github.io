# -*- coding: utf-8 -*-
import os, sys, re, xbmc, xbmcgui, xbmcvfs, xbmcplugin, xbmcaddon, locale, base64, json, time, threading
import requests, html
import pyxbmct
from pyxbmct import AddonDialogWindow, Label, Button
from .static_data import *

import traceback

addon_id = 'plugin.video.nCore_TV'
profile_path = xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile'))
simkl_status_cache = os.path.join(profile_path, 'simkl_status_list.json')
imdb_poster_map_file = os.path.join(profile_path, 'imdb_poster_map.json')
simkl_id_map_file = os.path.join(profile_path, 'simkl_id_map.json')

def get_simkl_stealth_headers(token):
    addon_version = "3.2.4"
    kodi_version = xbmc.getInfoLabel("System.BuildVersion")
    user_agent = "script.simkl/v{} / Kodi/{}".format(addon_version, kodi_version)
    
    return {
        "Authorization": f"Bearer {token}",
        "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}",
        "Content-Type": "application/json",
        "User-Agent": user_agent
    }

class SimklInterface(AddonDialogWindow):
    def __init__(self, title='[B]Simkl.com Hitelesítés[/B]'):
        super(SimklInterface, self).__init__(title)
        self.setGeometry(550, 400, 10, 4)
        
        self.setup_ui()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def setup_ui(self):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        simkl_user = myself.getSetting('simkl_username')
        
        is_auth = token and token.strip() != "" and token != "None"
        status_color = 'lime' if is_auth else 'red'
        
        if is_auth and simkl_user:
            status_text = f'Hitelesített ([B]{simkl_user}[/B])'
        elif is_auth:
            status_text = 'Hitelesített'
        else:
            status_text = 'Nem hitelesített'
        
        self.status_label = Label(f'Állapot: [COLOR {status_color}]{status_text}[/COLOR]')
        self.placeControl(self.status_label, 0, 0, 1, 4)
        
        self.auth_btn = Button('Engedélyezés [Simkl.com] (eszközkód)')
        self.placeControl(self.auth_btn, 2, 0, 1, 4)
        self.connect(self.auth_btn, self.start_auth)
        
        self.revoke_btn = Button('Engedély visszavonása')
        self.placeControl(self.revoke_btn, 4, 0, 1, 4)
        self.connect(self.revoke_btn, self.revoke_access)
        
        self.close_btn = Button('Vissza')
        self.placeControl(self.close_btn, 9, 0, 1, 4)
        self.connect(self.close_btn, self.close)
        
        self.buttons = [self.auth_btn, self.revoke_btn, self.close_btn]
        for i in range(len(self.buttons)):
            self.buttons[i].controlUp(self.buttons[(i - 1) % len(self.buttons)])
            self.buttons[i].controlDown(self.buttons[(i + 1) % len(self.buttons)])
        self.setFocus(self.auth_btn)

    def start_auth(self):
        try:
            r = requests.get(f"https://api.simkl.com/oauth/pin?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}", timeout=15)
            if r.status_code != 200: return
            data = r.json()
            user_code = data.get('user_code')
            msg = f"Böngészőben: [B]simkl.com/pin[/B]\nKód: [COLOR yellow][B]{user_code}[/B][/COLOR]\nVárakozás a felhasználó visszaigazolására..."
            prog = xbmcgui.DialogProgress()
            prog.create("Simkl.com Hitelesítés", msg)

            token_url = f"https://api.simkl.com/oauth/pin_status/{user_code}?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}&client_secret={ayb_3h}{kyf_3h}{fyt_3h}{qye_3h}"
            start = time.time()
            while time.time() - start < 900:
                if prog.iscanceled(): break
                prog.update(int(((time.time() - start) / 900) * 100), msg)
                res = requests.get(token_url, timeout=15)
                if res.status_code == 200:
                    d = res.json()
                    access_token = d.get('access_token')
                    refresh_token = d.get('refresh_token')
                    if access_token:
                        user_name = ""
                        u_url = f"https://api.simkl.com/users/settings?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
                        u_headers = {"Authorization": f"Bearer {access_token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}", "Content-Type": "application/json"}
                        try:
                            user_res = requests.get(u_url, headers=u_headers, timeout=15)
                            if user_res.status_code == 200:
                                user_name = user_res.json().get('user', {}).get('name', '')
                        except: pass

                        track_event("logins", "Auth: Simkl", "Simkl service authorized for watch history tracking.", icon="🎬️")

                        myself = xbmcaddon.Addon(addon_id)
                        myself.setSetting('simkl_access_token', str(access_token))
                        myself.setSetting('simkl_refresh_token', str(refresh_token))
                        myself.setSetting('simkl_username', str(user_name))
                        myself.setSetting('simkl_enabled', 'true')
                        
                        prog.close()
                        xbmcgui.Dialog().ok("Simkl.com", f"Sikeres párosítás!\nFelhasználó: [B]{user_name}\nA beállítások menüben végzett módosítások csak az OK gomb megnyomásával kerülnek mentésre. Ez a fő beállítások menüre is érvényes.[/B]")
                        self.status_label.setLabel(f'Állapot: [COLOR lime]Hitelesített ([B]{user_name}[/B])[/COLOR]')
                        return
                xbmc.sleep(5000)
            prog.close()
        except: pass

    def revoke_access(self):
        if xbmcgui.Dialog().yesno("Simkl.com", "Biztos vagy benne?"):
            myself = xbmcaddon.Addon(addon_id)
            myself.setSetting('simkl_access_token', '')
            myself.setSetting('simkl_username', '')
            myself.setSetting('simkl_enabled', 'false')
            self.status_label.setLabel('Állapot: [COLOR red]Nem hitelesített[/COLOR]')

    @staticmethod
    def _quick_cache_save(imdb_id, val):
        with global_write_lock: 
            try:
                current_cache = {}
                if os.path.exists(simkl_status_cache):
                    try:
                        with open(simkl_status_cache, 'r', encoding='utf-8') as f:
                            current_cache = json.load(f)
                    except: pass
                
                current_cache[imdb_id] = val

                temporary_file = simkl_status_cache + ".tmp"
                with open(temporary_file, 'w', encoding='utf-8') as f:
                    json.dump(current_cache, f, indent=2, ensure_ascii=False)
                    f.flush()
                    os.fsync(f.fileno())
                
                if sys.platform == "win32" and os.path.exists(simkl_status_cache):
                    os.remove(simkl_status_cache)
                os.rename(temporary_file, simkl_status_cache)
            except Exception as e:
                xbmc.log(f"[nCore_TV Simkl Cache] Hiba: {e}", xbmc.LOGERROR)

    @staticmethod
    def simkl_scrobble_manager(imdb_id, action, progress, season=None, episode=None, tmdb_id=None):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        
        if not token or token in ["", "None"]:
            return False

        from resources.lib.indexers.database import DatabaseManager
        db_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile')), 'ncore_tv.db')
        db = DatabaseManager(db_path)

        simkl_id = db.get_sync_id(imdb_id, 'simkl')

        addon_version_stealth = "3.2.3"
        kodi_version_stealth = xbmc.getInfoLabel("System.BuildVersion")
        user_agent_stealth = "script.simkl/v{} / Kodi/{}".format(addon_version_stealth, kodi_version_stealth)
        app_info = {"name": "Simkl TV Tracker", "version": "3.2.3"}

        url = f"https://api.simkl.com/scrobble/{action}?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
        headers = {
            "Content-Type": "application/json", 
            "Authorization": f"Bearer {token}", 
            "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}",
            "User-Agent": user_agent_stealth
        }

        ids = {}
        if simkl_id:
            ids["simkl"] = int(simkl_id)
        else:
            ids["imdb"] = str(imdb_id)

        if tmdb_id and str(tmdb_id).lower() not in ["none", ""]:
            try:
                ids["tmdb"] = int(tmdb_id)
            except:
                pass

        if season and episode:
            data = {
                "show": {"ids": ids}, 
                "episode": {"season": int(season), "number": int(episode)}, 
                "progress": float(progress),
                "app": app_info
            }
        else:
            data = {
                "movie": {"ids": ids}, 
                "progress": float(progress),
                "app": app_info
            }

        try:
            r = requests.post(url, json=data, headers=headers, timeout=15)
            if r.status_code in [200, 201, 409]:
                status_msg = "SIKERES SCROBBLE" if r.status_code != 409 else "MÁR MEGNÉZVE (409)"
                return True
            else:
                return False
                
        except Exception as e:
            return False

    @staticmethod
    def get_simkl_info(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        if not token or token in ["", "None"] or not imdb_id or str(imdb_id).lower() == "none": return None

        if os.path.exists(simkl_status_cache):
            try:
                with open(simkl_status_cache, 'r', encoding='utf-8') as f:
                    c = json.load(f)
                    if imdb_id in c: return c[imdb_id]
            except: pass

        headers = {"Authorization": f"Bearer {token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"}
        try:
            r = requests.get(f"https://api.simkl.com/sync/all-items?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}", headers=headers, timeout=15)
            if r.status_code == 200:
                data, res = r.json(), None
                # Shows és Anime
                for item in data.get('shows', []) + data.get('anime', []):
                    if item.get('show', {}).get('ids', {}).get('imdb') == imdb_id:
                        status = item.get('status')
                        last = item.get('last_watched')

                        if status == 'completed':
                            res = "[B][COLOR cyan]Simkl:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                        elif status == 'watching' and last and str(last).lower() != "none":
                            res = f"[B][COLOR cyan]Simkl utoljára:[/COLOR][/B] {last}"
                        elif status == 'plantowatch':
                            res = "[B][COLOR cyan]Simkl:[/COLOR] [COLOR yellow]Listán[/COLOR][/B]"
                        break
                
                # Movie
                if not res:
                    for item in data.get('movies', []):
                        if item.get('movie', {}).get('ids', {}).get('imdb') == imdb_id:
                            status = item.get('status')
                            if status == 'completed':
                                res = "[B][COLOR cyan]Simkl:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                            elif status == 'plantowatch':
                                res = "[B][COLOR cyan]Simkl:[/COLOR] [COLOR yellow]Listán[/COLOR][/B]"
                            break
                if res:
                    SimklInterface._quick_cache_save(imdb_id, res)
                    return res
        except: pass
        return None

    @staticmethod
    def get_simkl_watched_items():
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        if not token: return None
        url = f"https://api.simkl.com/sync/all-items?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
        headers = {"Authorization": f"Bearer {token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"}
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()

                new_posters = {}
                for cat in ['movies', 'shows', 'anime']:
                    for item in data.get(cat, []):
                        inner = item.get('movie') or item.get('show')
                        if inner:
                            imdb = inner.get('ids', {}).get('imdb')
                            pid = inner.get('poster')
                            if imdb and pid:
                                new_posters[imdb] = pid

                            item['poster_link'] = f"https://simkl.in/posters/{pid}_m.jpg" if pid else 'DefaultMovies.png'

                if new_posters:
                    SimklInterface._update_global_poster_map(new_posters)
                return data
        except: pass
        return None

    @staticmethod
    def _update_global_poster_map(new_data):
        try:
            from resources.lib.indexers.database import DatabaseManager
            db_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile')), 'ncore_tv.db')
            db = DatabaseManager(db_path)

            db.update_bulk_sync_status(new_data, 'simkl_poster')
        except Exception as e:
            xbmc.log(f"[nCore_TV Simkl SQL] Poster mentési hiba: {e}", xbmc.LOGERROR)

    @staticmethod
    def simkl_add_plan(imdb_id, is_series=False):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        if not token or not imdb_id: return False

        url = f"https://api.simkl.com/sync/add-to-list?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
        headers = {
            "Content-Type": "application/json", 
            "Authorization": f"Bearer {token}", 
            "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
        }
        
        key = "shows" if is_series else "movies"
        data = {key: [{"ids": {"imdb": str(imdb_id)}, "to": "plantowatch"}]}

        try:
            r = requests.post(url, json=data, headers=headers, timeout=15)
            if r.status_code in [200, 201]:
                res_data = r.json()
                added_list = res_data.get('added', {}).get(key, [])
                
                if len(added_list) > 0:
                    return True
                else:
                    xbmcgui.Dialog().notification("Simkl Hiba", "Nem található az adatbázisban", xbmcgui.NOTIFICATION_WARNING, 3000)
                    return False
            else:
                return False
        except Exception as e:
            xbmc.log(f"Simkl Error: {e}", xbmc.LOGERROR)
        return False

    @staticmethod
    def sync_full_simkl_history(return_data=False):
        if hasattr(SimklInterface, '_is_syncing') and SimklInterface._is_syncing: return False
        SimklInterface._is_syncing = True
        
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')

        if not token or token == "" or token == "None":
            SimklInterface._is_syncing = False
            return False

        headers = {"Authorization": f"Bearer {token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"}
        try:
            r_test = requests.get(f"https://api.simkl.com/users/settings?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}", headers=headers, timeout=15)
            if r_test.status_code == 401:
                SimklInterface._is_syncing = False
                return False
        except: pass        
        
        data = SimklInterface.get_simkl_watched_items()
        if not data:
            SimklInterface._is_syncing = False
            return False

        new_watched = {}
        new_id_map = {} 

        for cat in ['movies', 'shows', 'anime']:
            for item in data.get(cat, []):
                inner = item.get('movie') or item.get('show', {})
                imdb = inner.get('ids', {}).get('imdb')
                if not imdb: continue
                
                new_id_map[imdb] = {
                    "simkl_id": inner.get('ids', {}).get('simkl'),
                    "poster": inner.get('poster')
                }

                status = item.get('status')
                last = item.get('last_watched')

                if status == 'plantowatch':
                    new_watched[imdb] = "[B][COLOR cyan]Simkl:[/COLOR] [COLOR yellow]Listán[/COLOR][/B]"
                else:
                    watched_cnt = item.get('watched_episodes_count', 0)
                    total_cnt = item.get('total_episodes_count', 0)
                    if status == 'completed' or (watched_cnt >= total_cnt and total_cnt > 0):
                        new_watched[imdb] = "[B][COLOR cyan]Simkl:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                    elif last and str(last).lower() != "none":
                        new_watched[imdb] = f"[B][COLOR cyan]Simkl utoljára:[/COLOR][/B] {last}"
        
        SimklInterface._is_syncing = False

        if return_data:
            return new_watched, new_id_map
        
        return True

    @staticmethod
    def get_simkl_global_calendar():
        url = "https://data.simkl.in/calendar/tv.json"
        try:
            r = requests.get(url, timeout=20)
            if r.status_code == 200:
                return r.json()
        except Exception as e:
            xbmc.log(f"[DEBUG] Network error on CDN: {e}", xbmc.LOGERROR)
        return None

    @staticmethod
    def get_simkl_playback():
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        if not token or token in ["", "None"]: return None

        url = f"https://api.simkl.com/sync/playback?all=1&client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"

        headers = get_simkl_stealth_headers(token)

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 530:
                xbmcgui.Dialog().notification("Simkl Hiba", "A Simkl szervere átmenetileg nem elérhető (DNS hiba).", xbmcgui.NOTIFICATION_WARNING, 4000)
                return None

            if r.status_code == 200:
                return r.json()
        except Exception as e:
            xbmc.log(f"[Simkl DEBUG] Error: {e}", xbmc.LOGERROR)
        return None

    @staticmethod
    def force_refresh_poster_map(imdb_id):
        data = SimklInterface.get_simkl_watched_items()
        if data:
            return True
        return False

    @staticmethod
    def harvest_poster_by_imdb(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        if not token or not imdb_id: return None

        url = f"https://api.simkl.com/search/id?imdb={imdb_id}&client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
        headers = {"Authorization": f"Bearer {token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"}
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()
                if data and isinstance(data, list):
                    item = data[0]
                    inner = item.get('movie') or item.get('show')
                    if inner:
                        pid = inner.get('poster')
                        if pid:
                            SimklInterface._update_global_poster_map({imdb_id: pid})
                            return pid
        except: pass
        return None

    @staticmethod
    def get_simkl_resume_progress(imdb_id, season=None, episode=None, tmdb_id=None):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        if not token or token in ["", "None"]: return None

        url = f"https://api.simkl.com/sync/playback?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
        headers = {"Authorization": f"Bearer {token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}", "Content-Type": "application/json"}

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                playback_list = r.json()
                
                t_imdb = str(imdb_id).lower() if imdb_id else ""

                for item in playback_list:
                    media = item.get('movie') or item.get('show') or item.get('anime')
                    if not media: continue
                    
                    s_imdb = str(media.get('ids', {}).get('imdb', '')).lower()
                    m_type = item.get('type', '')

                    if t_imdb and s_imdb and (t_imdb == s_imdb or t_imdb.endswith(s_imdb) or s_imdb.endswith(t_imdb)):
                        if m_type in ['movie', 'anime']:
                            return float(item.get('progress', 0))
                        else:
                            ep = item.get('episode', {})
                            if int(ep.get('season', -1)) == int(season) and int(ep.get('number', -1)) == int(episode):
                                return float(item.get('progress', 0))
        except: pass
        return None

    @staticmethod
    def get_simkl_up_next(page=1, progress_callback=None):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        headers = {"Authorization": f"Bearer {token}", "simkl-api-client": f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}", "Content-Type": "application/json"}
        img_proxy = "https://wsrv.nl/?url=https://simkl.in"

        try:
            url = f"https://api.simkl.com/sync/all-items/shows/watching?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}"
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code != 200: return None, 0
            
            shows_data = r.json().get('shows', [])
            shows_data.sort(key=lambda x: str(x.get('last_watched_at') or '0000-00-00'), reverse=True)

            filtered_shows = [s for s in shows_data if s.get('next_to_watch') and str(s.get('next_to_watch')).upper() != "S01E01"]

            items_per_page = 15
            start_idx = (page - 1) * items_per_page
            end_idx = start_idx + items_per_page
            
            target_slice = filtered_shows[start_idx:end_idx]
            remaining_count = len(filtered_shows) - end_idx
            
            up_next_results = []
            total_on_page = len(target_slice)

            for idx, item in enumerate(target_slice):
                s_title = item['show']['title']
                nxt_str = item['next_to_watch']
                
                if progress_callback:
                    progress_callback(int((idx / total_on_page) * 100), s_title)

                match = re.search(r'[sS](\d+)[eE](\d+)', nxt_str)
                if match:
                    target_s, target_e = int(match.group(1)), int(match.group(2))
                    s_id = item['show']['ids']['simkl']

                    ep_list_url = f"https://api.simkl.com/tv/episodes/{s_id}?client_id={aob_zn}{kof_zn}{fot_zn}{qoe_zn}&extended=full"
                    try:
                        reps = requests.get(ep_list_url, headers=headers, timeout=15)
                        if reps.status_code == 200:
                            all_episodes = reps.json()
                            found_ep = next((ep for ep in all_episodes if ep.get('season') == target_s and ep.get('episode') == target_e), None)
                            
                            if found_ep:
                                img_id = found_ep.get('img')
                                up_next_results.append({
                                    'imdb_id': item['show']['ids']['imdb'],
                                    'show_title': s_title,
                                    'ep_title': found_ep.get('title', 'Következő rész'),
                                    'season': target_s,
                                    'episode': target_e,
                                    'plot': found_ep.get('description') or found_ep.get('overview', 'Nincs leírás.'),
                                    'thumb': f"{img_proxy}/episodes/{img_id}_w.jpg" if img_id else "",
                                    'poster': item['show'].get('poster'),
                                    'progress': f"{item.get('watched_episodes_count')}/{item.get('total_episodes_count')}"
                                })
                    except: continue

            return up_next_results, remaining_count
        except Exception as e:
            xbmc.log(f"SIMKL-UPNEXT-ERROR: {e}", xbmc.LOGERROR)
            return None, 0

    @staticmethod
    def get_simkl_genres(media_type):
        if media_type == 'movies':
            return [
                ("Action", "action"), ("Adventure", "adventure"), ("Animation", "animation"),
                ("Comedy", "comedy"), ("Crime", "crime"), ("Documentary", "documentary"),
                ("Drama", "drama"), ("Family", "family"), ("Fantasy", "fantasy"),
                ("History", "history"), ("Horror", "horror"), ("Music", "music"),
                ("Mystery", "mystery"), ("Romance", "romance"), ("Science Fiction", "science-fiction"),
                ("Thriller", "thriller"), ("TV Movie", "tv-movie"), ("War", "war"), ("Western", "western")
            ]
        else:
            return [
                ("Action", "action"), ("Adventure", "adventure"), ("Animation", "animation"),
                ("Awards Show", "awards-show"), ("Children", "children"), ("Comedy", "comedy"),
                ("Crime", "crime"), ("Documentary", "documentary"), ("Drama", "drama"),
                ("Family", "family"), ("Fantasy", "fantasy"), ("Food", "food"),
                ("Game Show", "game-show"), ("History", "history"), ("Home and Garden", "home-and-garden"),
                ("Horror", "horror"), ("Indie", "indie"), ("Martial Arts", "martial-arts"),
                ("Mini-Series", "mini-series"), ("Musical", "musical"), ("Mystery", "mystery"),
                ("News", "news"), ("Podcast", "podcast"), ("Reality", "reality"),
                ("Romance", "romance"), ("Science-Fiction", "science-fiction"), ("Soap", "soap"),
                ("Special Interest", "special-interest"), ("Sport", "sport"), ("Suspense", "suspense"),
                ("Talk Show", "talk-show"), ("Thriller", "thriller"), ("Travel", "travel"),
                ("Video Game Play", "video-game-play"), ("War", "war"), ("Western", "western")
            ]

    @staticmethod
    def get_simkl_filtered_content(media_type, genre_slug, year, page=1):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')

        stype = 'tv' if media_type == 'shows' else 'movies'
        client_id = f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"

        url = f"https://api.simkl.com/{stype}/genres/{genre_slug}/{year}?page={page}&limit=20&client_id={client_id}&extended=full"
        
        headers = get_simkl_stealth_headers(token)

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()
                return data, len(data) >= 20
            else:
                xbmc.log(f"[nCore_TV DEBUG] Simkl API hiba: {r.status_code} - {r.text}", xbmc.LOGERROR)
                return [], False
        except Exception as e:
            xbmc.log(f"[nCore_TV DEBUG] Simkl hálózati hiba: {str(e)}", xbmc.LOGERROR)
            return [], False

    @staticmethod
    def get_simkl_summary(media_type, simkl_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')

        stype = 'tv' if media_type == 'shows' else media_type
        client_id = f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"

        url = f"https://api.simkl.com/{stype}/{simkl_id}?extended=full&client_id={client_id}"
        
        headers = get_simkl_stealth_headers(token)
        if not token or token == "" or token == "None":
            if "Authorization" in headers:
                del headers["Authorization"]

        try:
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code == 200:
                return r.json()
            else:
                xbmc.log(f"[nCore_TV DEBUG] API Hiba: {r.status_code} - {r.text}", xbmc.LOGERROR)
                return None
        except Exception as e:
            xbmc.log(f"[nCore_TV DEBUG] Halozati hiba: {str(e)}", xbmc.LOGERROR)
            return None

    @staticmethod
    def get_simkl_static_trending(media_type, timeframe='week', limit=500):
        import os, time, json
        profile_path = xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile'))

        if media_type == 'dvd':
            url = f"https://data.simkl.in/discover/dvd/releases_{limit}.json"
            cache_file = os.path.join(profile_path, f"simkl_dvd_releases_{limit}.json")
        elif media_type == 'mixed':
            url = f"https://data.simkl.in/discover/trending/{timeframe}_{limit}.json"
            cache_file = os.path.join(profile_path, f"simkl_mixed_{timeframe}_{limit}.json")
        else:
            # movies, tv, anime
            url = f"https://data.simkl.in/discover/trending/{media_type}/{timeframe}_{limit}.json"
            cache_file = os.path.join(profile_path, f"simkl_{media_type}_{timeframe}_{limit}.json")

        cache_time = 43200 if timeframe == 'today' else 86400
        
        if os.path.exists(cache_file) and (time.time() - os.path.getmtime(cache_file) < cache_time):
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        headers = {'User-Agent': 'script.simkl/v3.2.4'}
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                with open(cache_file, 'w', encoding='utf-8') as f:
                    f.write(r.text)
                return r.json()
        except:
            if os.path.exists(cache_file):
                with open(cache_file, 'r', encoding='utf-8') as f: return json.load(f)
        return []

    @staticmethod
    def get_simkl_summary_by_imdb(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('simkl_access_token')
        client_id = f"{aob_zn}{kof_zn}{fot_zn}{qoe_zn}"

        url = f"https://api.simkl.com/search/id?imdb={imdb_id}&client_id={client_id}"
        
        headers = get_simkl_stealth_headers(token)
        try:
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code == 200:
                data = r.json()
                if data and isinstance(data, list):
                    return data[0]
            return None
        except:
            return None