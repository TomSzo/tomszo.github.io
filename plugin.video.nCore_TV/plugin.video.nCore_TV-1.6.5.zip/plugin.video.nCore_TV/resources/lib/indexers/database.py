# -*- coding: utf-8 -*-
# Módosított fájl (fork). Eredeti: nCore TV Addon, Copyright (C) heg, GPL-3.0-or-later (lásd LICENSE.txt).
# Módosítások: Copyright (C) 2026 TomSzo, módosítva: 2026-09-20 (lásd CHANGELOG.md).
import os
import re
import json
import sqlite3
import time
import threading
import xbmc
import xbmcaddon
from xbmcvfs import translatePath
from datetime import datetime

try:
    from .static_data import global_write_lock
except ImportError:
    from resources.lib.indexers.static_data import global_write_lock

def _local_tracking_enabled():
    """Lokális lejátszás-követés (video_positions, full_url) ki/be. Alap: be. A felhő-szinket nem érinti."""
    try:
        return xbmcaddon.Addon('plugin.video.nCore_TV').getSetting('local_tracking_enabled') != 'false'
    except Exception:
        return True

# Ha a séma (táblák/indexek) változik, növeld ezt: az átlépéskor egyszer lefut a teljes inicializálás.
SCHEMA_VERSION = 1

class DatabaseManager:
    _wal_done = False  # a WAL mód a DB-fájlban tartós, folyamatonként elég egyszer beállítani

    def __init__(self, db_path):
        self.db_path = translatePath(db_path)
        # Minden plugin-hívás (minden lista, minden kattintás) új DatabaseManager-t hoz létre.
        # A ~12 CREATE TABLE + ALTER próbálkozás ezért csak sémaverzió-váltáskor fut.
        if self._get_schema_version() < SCHEMA_VERSION:
            self._initialize_db()
            self.force_create_search_table()
            self.force_create_torrent_files_table()
            self._set_schema_version(SCHEMA_VERSION)

    def _get_schema_version(self):
        try:
            conn = self._get_connection()
            try:
                return conn.execute('PRAGMA user_version').fetchone()[0]
            finally:
                conn.close()
        except Exception:
            return 0

    def _set_schema_version(self, version):
        conn = self._get_connection()
        try:
            conn.execute('PRAGMA user_version = %d' % int(version))
            conn.commit()
        finally:
            conn.close()

    def _get_connection(self):
        # Szálanként egy újrahasznált kapcsolat: a lista-építés elemenként hív DB-t (értékelés, státusz),
        # korábban minden hívás új kapcsolatot nyitott + PRAGMA-kat futtatott. A kód a kapcsolatokat
        # eddig sem zárta le (a `with` csak commitol), tehát a viselkedés azonos.
        tl = self.__dict__.setdefault('_tl', threading.local())
        conn = getattr(tl, 'conn', None)
        if conn is not None:
            try:
                conn.execute('SELECT 1')
                return conn
            except sqlite3.Error:
                tl.conn = None
        conn = sqlite3.connect(self.db_path, timeout=20)
        if not DatabaseManager._wal_done:
            conn.execute("PRAGMA journal_mode=WAL")
            DatabaseManager._wal_done = True
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        tl.conn = conn
        return conn

    def _initialize_db(self):
        with self._get_connection() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS torrents (
                    torrent_id TEXT PRIMARY KEY,
                    imdb_id TEXT,
                    tmdb_id TEXT,
                    imdb_rate TEXT,
                    title_1 TEXT,
                    title_2 TEXT,
                    poster_link TEXT,
                    c_i TEXT,
                    clear_logo TEXT,
                    description TEXT,
                    feltoltve TEXT,
                    seeder TEXT,
                    leecher TEXT,
                    url TEXT,
                    full_url TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            conn.execute('''
                CREATE TABLE IF NOT EXISTS video_positions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    torrent_id TEXT,
                    file_name TEXT,
                    position REAL,
                    duration REAL,  -- ÚJ OSZLOP (Új telepítéshez)
                    label TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(torrent_id) REFERENCES torrents(torrent_id) ON DELETE CASCADE
                )
            ''')

            try:
                conn.execute('ALTER TABLE video_positions ADD COLUMN duration REAL DEFAULT 0')
                conn.commit()
            except:
                pass

            conn.execute('''
                CREATE TABLE IF NOT EXISTS sync_status (
                    imdb_id TEXT PRIMARY KEY,
                    trakt_status TEXT, 
                    trakt_id INTEGER,
                    simkl_status TEXT, 
                    simkl_id INTEGER, 
                    simkl_poster TEXT,
                    plex_status TEXT, 
                    plex_rk TEXT,
                    last_updated INTEGER
                )
            ''')
            conn.commit()

            conn.execute('''
                CREATE TABLE IF NOT EXISTS search_history (
                    query TEXT PRIMARY KEY,
                    type TEXT,
                    display_name TEXT,
                    mire_text TEXT,
                    imdb_name TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            conn.commit()

            conn.execute('''
                CREATE TABLE IF NOT EXISTS watching_series (
                    imdb_id TEXT,
                    user_name TEXT,
                    title_1 TEXT,
                    title_2 TEXT,
                    title_3 TEXT,
                    poster_link TEXT,
                    full_link TEXT,
                    rogzitett_timestamp REAL,
                    rogzitett_date_and_time TEXT,
                    PRIMARY KEY (imdb_id, user_name)
                )
            ''')

            try:
                conn.execute('ALTER TABLE watching_series ADD COLUMN rogzitett_timestamp REAL')
            except: pass
            try:
                conn.execute('ALTER TABLE watching_series ADD COLUMN rogzitett_date_and_time TEXT')
            except: pass
            
            conn.commit()

            conn.execute('CREATE TABLE IF NOT EXISTS device_names (name TEXT PRIMARY KEY)')
            conn.commit()

            self._get_connection().execute('''
                CREATE TABLE IF NOT EXISTS bookmarks_mapping (
                    bookmark_key TEXT PRIMARY KEY,
                    name TEXT,
                    group_id TEXT,
                    categories TEXT  -- JSON stringként tároljuk a listát
                )
            ''')
            self._get_connection().commit()

            conn.execute('''
                CREATE TABLE IF NOT EXISTS torrent_file_structure (
                    torrent_id TEXT,
                    file_name TEXT,
                    PRIMARY KEY (torrent_id, file_name)
                )
            ''')

            try:
                conn.execute('''
                    CREATE TABLE IF NOT EXISTS trakt_ratings (
                        imdb_id TEXT,
                        rating_type TEXT, -- 'movie', 'show', 'season', 'episode'
                        season INTEGER DEFAULT 0,
                        episode INTEGER DEFAULT 0,
                        rating INTEGER,
                        last_updated INTEGER,
                        PRIMARY KEY (imdb_id, rating_type, season, episode)
                    )
                ''')
                conn.commit()
            except Exception as e:
                xbmc.log(f"[nCore_SQL_Error] Nem sikerült létrehozni a trakt_ratings táblát: {e}", xbmc.LOGERROR)

    def force_create_search_table(self):
        with self._get_connection() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS search_history (
                    query TEXT PRIMARY KEY,
                    type TEXT,
                    display_name TEXT,
                    mire_text TEXT,
                    imdb_name TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            conn.commit()

    def force_create_torrent_files_table(self):
        try:
            with self._get_connection() as conn:
                conn.execute('''
                    CREATE TABLE IF NOT EXISTS torrent_files (
                        torrent_id TEXT,
                        file_name TEXT,
                        last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (torrent_id, file_name)
                    )
                ''')

                conn.execute('CREATE INDEX IF NOT EXISTS idx_tf_last_used ON torrent_files (last_used)')
                conn.commit()
        except Exception as e:
            xbmc.log(f"[nCore_DB] HIBA a torrent_files kenyszeritesekor: {str(e)}", xbmc.LOGERROR)

    def update_full_service_sync(self, service, watched_data, id_map):
        if not watched_data and not id_map: return
        
        status_col = f"{service}_status"
        id_col = "plex_rk" if service == "plex" else f"{service}_id"
        timestamp = int(time.time())

        all_ids = set(list(watched_data.keys()) + list(id_map.keys()))

        with self._get_connection() as conn:
            for imdb_id in all_ids:
                status = watched_data.get(imdb_id)
                m_id = id_map.get(imdb_id)

                s_poster = None
                if service == 'simkl' and isinstance(m_id, dict):
                    s_poster = m_id.get('poster')
                    m_id = m_id.get('simkl_id')

                if service == 'simkl':
                    conn.execute(f'''
                        INSERT INTO sync_status (imdb_id, {status_col}, {id_col}, simkl_poster, last_updated)
                        VALUES (?, ?, ?, ?, ?)
                        ON CONFLICT(imdb_id) DO UPDATE SET 
                            {status_col}=COALESCE(excluded.{status_col}, {status_col}),
                            {id_col}=COALESCE(excluded.{id_col}, {id_col}),
                            simkl_poster=COALESCE(excluded.simkl_poster, simkl_poster),
                            last_updated=excluded.last_updated
                    ''', (imdb_id, status, m_id, s_poster, timestamp))
                else:
                    conn.execute(f'''
                        INSERT INTO sync_status (imdb_id, {status_col}, {id_col}, last_updated)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(imdb_id) DO UPDATE SET 
                            {status_col}=COALESCE(excluded.{status_col}, {status_col}),
                            {id_col}=COALESCE(excluded.{id_col}, {id_col}),
                            last_updated=excluded.last_updated
                    ''', (imdb_id, status, m_id, timestamp))
            conn.commit()

    def migrate_from_json(self, json_path):
        source_path = translatePath(json_path)
        bak_path = source_path + ".bak"

        final_source = None
        if os.path.exists(source_path):
            final_source = source_path
        elif os.path.exists(bak_path):
            final_source = bak_path

        if not final_source:
            return

        with global_write_lock:
            try:
                with open(final_source, 'r', encoding='utf-8') as f:
                    old_data = json.load(f)
                
                if not old_data or not isinstance(old_data, list):
                    return

                inserted_count = 0
                with self._get_connection() as conn:
                    for item in old_data:
                        t_id = item.get('torrent_id')
                        if not t_id: continue

                        conn.execute('''
                            INSERT OR REPLACE INTO torrents 
                            (torrent_id, imdb_id, tmdb_id, imdb_rate, title_1, title_2, poster_link, c_i, clear_logo, description, feltoltve, seeder, leecher, url, full_url, timestamp)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            t_id, item.get('imdb_id'), item.get('tmdb_id'), item.get('imdb_rate'),
                            item.get('title_1'), item.get('title_2'), item.get('poster_link'), item.get('c_i'),
                            item.get('clear_logo'), item.get('description'), item.get('feltoltve'), item.get('seeder'),
                            item.get('leecher'), item.get('url'), item.get('full_url'), 
                            item.get('timestamp') or datetime.now().isoformat()
                        ))

                        positions = item.get('video_saved_position', [])
                        if isinstance(positions, list):
                            for pos in positions:
                                if isinstance(pos, dict):
                                    conn.execute('''
                                        INSERT OR IGNORE INTO video_positions (torrent_id, file_name, position, label)
                                        VALUES (?, ?, ?, ?)
                                    ''', (t_id, pos.get('file'), pos.get('pos'), pos.get('t') or pos.get('label')))
                        
                        inserted_count += 1
                    conn.commit()

                if inserted_count > 0:
                    for f_to_retire in [source_path, bak_path]:
                        if os.path.exists(f_to_retire):
                            migrated_path = f_to_retire + ".migrated"
                            if os.path.exists(migrated_path): os.remove(migrated_path)
                            os.rename(f_to_retire, migrated_path)
            except Exception as e:
                xbmc.log(f"[nCore_TV] Migrációs hiba: {e}", xbmc.LOGERROR)

    def get_indicators_for_list(self, imdb_ids):
        if not imdb_ids: return {}
        placeholders = ', '.join(['?'] * len(imdb_ids))
        
        with self._get_connection() as conn:
            cursor = conn.execute(f'SELECT * FROM sync_status WHERE imdb_id IN ({placeholders})', imdb_ids)
            return {row['imdb_id']: row for row in cursor.fetchall()}

    def update_sync_status(self, imdb_id, service, status_text):
        column = f"{service}_status"
        with self._get_connection() as conn:
            conn.execute(f'''
                INSERT INTO sync_status (imdb_id, {column}, last_updated)
                VALUES (?, ?, ?)
                ON CONFLICT(imdb_id) DO UPDATE SET {column}=excluded.{column}, last_updated=excluded.last_updated
            ''', (imdb_id, status_text, int(time.time())))
            conn.commit()

    def get_all_statuses_for_page(self, imdb_ids, torrent_ids):
        if not imdb_ids and not torrent_ids: return {}, set()
        
        sync_results = {}
        local_played_set = set()

        with self._get_connection() as conn:
            if imdb_ids:
                imdb_placeholders = ', '.join(['?'] * len(imdb_ids))
                cursor = conn.execute(f'SELECT * FROM sync_status WHERE imdb_id IN ({imdb_placeholders})', imdb_ids)
                for row in cursor:
                    sync_results[row['imdb_id']] = dict(row)

            if torrent_ids:
                torrent_placeholders = ', '.join(['?'] * len(torrent_ids))
                cursor = conn.execute(f'''
                    SELECT DISTINCT t.torrent_id FROM torrents t
                    LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                    WHERE t.torrent_id IN ({torrent_placeholders})
                    AND ( (t.full_url IS NOT NULL AND t.full_url != '') OR (v.id IS NOT NULL) )
                ''', torrent_ids)
                for row in cursor:
                    local_played_set.add(row['torrent_id'])

        return sync_results, local_played_set

    def migrate_statuses(self, trakt_path, simkl_path, plex_path):
        with global_write_lock:
            status_maps = [
                (trakt_path, 'trakt'),
                (simkl_path, 'simkl'),
                (plex_path, 'plex')
            ]
            
            with self._get_connection() as conn:
                for path, service in status_maps:
                    if os.path.exists(path):
                        try:
                            with open(path, 'r', encoding='utf-8') as f:
                                data = json.load(f)
                            
                            status_col = f"{service}_status"
                            
                            for imdb_id, status_text in data.items():
                                conn.execute(f'''
                                    INSERT INTO sync_status (imdb_id, {status_col}, last_updated)
                                    VALUES (?, ?, ?)
                                    ON CONFLICT(imdb_id) DO UPDATE SET {status_col}=excluded.{status_col}, last_updated=excluded.last_updated
                                ''', (imdb_id, status_text, int(time.time())))
                            
                            conn.commit()

                            migrated = path + ".migrated"
                            if os.path.exists(migrated):
                                os.remove(migrated)
                            os.rename(path, migrated)
                            xbmc.log(f"[nCore_TV] {service} státuszok migrációja kész, fájl nyugdíjazva.", xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log(f"[nCore_TV] Hiba a {service} migrációnál: {e}", xbmc.LOGERROR)

    def update_single_service_status(self, imdb_id, service, status_text):
        if not imdb_id: return
        column = f"{service}_status"
        with self._get_connection() as conn:
            conn.execute(f'''
                INSERT INTO sync_status (imdb_id, {column}, last_updated)
                VALUES (?, ?, ?)
                ON CONFLICT(imdb_id) DO UPDATE SET {column}=excluded.{column}, last_updated=excluded.last_updated
            ''', (imdb_id, status_text, int(time.time())))
            conn.commit()

    def get_played_torrents(self, page=1, items_per_page=20):
        offset = (page - 1) * items_per_page
        with self._get_connection() as conn:
            cursor = conn.execute(f'''
                SELECT DISTINCT t.* FROM torrents t
                LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                WHERE (t.full_url IS NOT NULL AND t.full_url != '') 
                   OR (v.id IS NOT NULL)
                ORDER BY t.timestamp DESC 
                LIMIT ? OFFSET ?
            ''', (items_per_page, offset))
            
            rows = [dict(row) for row in cursor.fetchall()]
            
            total = conn.execute('''
                SELECT COUNT(DISTINCT t.torrent_id) FROM torrents t
                LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                WHERE (t.full_url IS NOT NULL AND t.full_url != '') OR (v.id IS NOT NULL)
            ''').fetchone()[0]
            
            remaining = total - (page * items_per_page)
            return rows, max(0, remaining)

    def get_grouped_played_torrents(self, page=1, items_per_page=20):
        offset = (page - 1) * items_per_page
        with self._get_connection() as conn:
            query = f'''
                SELECT *, MAX(timestamp) as latest_activity, COUNT(DISTINCT torrent_id) as group_count 
                FROM (
                    SELECT t.* FROM torrents t
                    LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                    WHERE (t.full_url IS NOT NULL AND t.full_url != '') 
                       OR (v.id IS NOT NULL)
                    ORDER BY t.timestamp DESC
                )
                GROUP BY CASE 
                    WHEN (imdb_id IS NOT NULL AND imdb_id != '') THEN imdb_id 
                    ELSE torrent_id 
                END
                ORDER BY latest_activity DESC 
                LIMIT ? OFFSET ?
            '''
            cursor = conn.execute(query, (items_per_page, offset))
            rows = [dict(row) for row in cursor.fetchall()]
            
            total_groups_query = '''
                SELECT COUNT(*) FROM (
                    SELECT 1 FROM torrents t
                    LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                    WHERE (t.full_url IS NOT NULL AND t.full_url != '') OR (v.id IS NOT NULL)
                    GROUP BY CASE 
                        WHEN (t.imdb_id IS NOT NULL AND t.imdb_id != '') THEN t.imdb_id 
                        ELSE t.torrent_id 
                    END
                )
            '''
            total_groups = conn.execute(total_groups_query).fetchone()[0]
            
            remaining = total_groups - (page * items_per_page)
            return rows, max(0, remaining)

    def extract_season_episode(self, text):
        if not text: return (None, None)
        patterns = [
            r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
            r'[sS](?P<season>\d{1,2})[eE](?P<episode>\d{1,2})',
            r'(?P<season>\d{1,2})\.\s*évad\s*(?P<episode>\d{1,2})\.\s*rész',
        ]
        for series_patt in patterns:
            match = re.search(series_patt, str(text))
            if match: 
                return int(match.group('season')), int(match.group('episode'))
        return (None, None)

    def get_torrent_pack_progress(self, torrent_id):
        from urllib.parse import unquote_plus
        try:
            with self._get_connection() as conn:
                all_files = conn.execute('''
                    SELECT file_name FROM torrent_files 
                    WHERE torrent_id = ? 
                ''', (str(torrent_id),)).fetchall()
                
                if not all_files: return None
                total_files = len(all_files)
                if total_files <= 1: return None
    
                file_list = [row['file_name'] for row in all_files]
                file_list.sort(key=lambda x: self.extract_season_episode(x) or (999, 999))
                
                last_played = conn.execute('''
                    SELECT file_name FROM video_positions 
                    WHERE torrent_id = ? 
                    ORDER BY timestamp DESC LIMIT 1
                ''', (str(torrent_id),)).fetchone()
    
                if not last_played: return f"0/{total_files}"
    
                def normalize_filename(f):
                    if not f: return ""
                    decoded = unquote_plus(f)
                    clean_name = decoded.replace('\\', '/').split('/')[-1]
                    return clean_name.strip().lower()
    
                target_file = normalize_filename(last_played['file_name'])
                
                found_index = -1
                for i, f in enumerate(file_list):
                    if normalize_filename(f) == target_file:
                        found_index = i
                        break
                
                if found_index == -1:
                    for i, f in enumerate(file_list):
                        if target_file in normalize_filename(f) or normalize_filename(f) in target_file:
                            found_index = i
                            break
                
                if found_index != -1:
                    return f"{found_index + 1}/{total_files}"
                else:
                    return f"?/{total_files}"
        except Exception as e:
            xbmc.log(f"[ERROR] get_torrent_pack_progress: {e}", xbmc.LOGERROR)
            return None

    def get_torrents_by_imdb(self, imdb_id):
        with self._get_connection() as conn:
            cursor = conn.execute('''
                SELECT DISTINCT t.* FROM torrents t
                LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                WHERE t.imdb_id = ?
                AND ((t.full_url IS NOT NULL AND t.full_url != '') OR (v.id IS NOT NULL))
                ORDER BY t.timestamp DESC
            ''', (imdb_id,))
            return [dict(row) for row in cursor.fetchall()]

    def get_torrent_details(self, torrent_id):
        with self._get_connection() as conn:
            cursor = conn.execute('SELECT * FROM torrents WHERE torrent_id = ?', (torrent_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def save_torrent_metadata(self, data):
        t_id = data.get('torrent_id')
        if not t_id: return

        f_url = data.get('full_url') or ""
        i_id = data.get('imdb_id') or ""
        t1 = data.get('title_1') or ""
        t2 = data.get('title_2') or ""
        post = data.get('poster_link') or ""
        desc = data.get('description') or ""
        ts = data.get('timestamp') or datetime.now().isoformat()

        with self._get_connection() as conn:
            conn.execute('''
                INSERT OR IGNORE INTO torrents (torrent_id, timestamp) VALUES (?, ?)
            ''', (t_id, ts))

            if f_url and _local_tracking_enabled():
                conn.execute('UPDATE torrents SET full_url = ?, timestamp = ? WHERE torrent_id = ?', (f_url, ts, t_id))

            updates = [
                ('imdb_id', i_id), ('title_1', t1), ('title_2', t2), 
                ('poster_link', post), ('description', desc)
            ]
            
            for column, value in updates:
                if value:
                    conn.execute(f'''
                        UPDATE torrents SET {column} = ? 
                        WHERE torrent_id = ? AND ({column} IS NULL OR {column} = '')
                    ''', (value, t_id))

            for col in ['imdb_rate', 'feltoltve', 'seeder', 'leecher', 'url', 'tmdb_id', 'c_i']:
                val = data.get(col)
                if val:
                    conn.execute(f'UPDATE torrents SET {col} = ? WHERE torrent_id = ?', (val, t_id))

            conn.commit()

    def add_video_position(self, torrent_id, file_name, position, label, duration=0):
        if not torrent_id or position < 10: return
        if not _local_tracking_enabled(): return
        with self._get_connection() as conn:
            conn.execute('''
                INSERT INTO video_positions (torrent_id, file_name, position, label, duration)
                VALUES (?, ?, ?, ?, ?)
            ''', (torrent_id, file_name, position, label, duration))
            conn.commit()

    def update_bulk_sync_status(self, data_map, column):
        with self._get_connection() as conn:
            for imdb_id, value in data_map.items():
                conn.execute(f'''
                    INSERT INTO sync_status (imdb_id, {column}) VALUES (?, ?)
                    ON CONFLICT(imdb_id) DO UPDATE SET {column}=excluded.{column}
                ''', (imdb_id, value))
            conn.commit()

    def get_sync_id(self, imdb_id, service):
        id_col = "plex_rk" if service == "plex" else f"{service}_id"
        
        with self._get_connection() as conn:
            row = conn.execute(f'SELECT {id_col} FROM sync_status WHERE imdb_id = ?', (imdb_id,)).fetchone()
            if row and row[0]:
                return row[0]
        return None

    def get_video_positions(self, torrent_id, file_name):
        if not _local_tracking_enabled(): return []
        with self._get_connection() as conn:
            cursor = conn.execute('''
                SELECT position, duration, label, file_name FROM video_positions 
                WHERE torrent_id = ? AND file_name = ?
                ORDER BY timestamp DESC
            ''', (torrent_id, file_name))
            return [dict(row) for row in cursor.fetchall()]

    def migrate_search_history(self, json_path):
        with self._get_connection() as conn:
            exists = conn.execute('SELECT COUNT(*) FROM search_history').fetchone()[0]
            if exists > 0: return

        source_path = translatePath(json_path)
        sources = [source_path, source_path + ".bak", source_path.replace(".json", "_original.json")]
        
        final_source = None
        for s in sources:
            if os.path.exists(s):
                final_source = s
                break
        
        if not final_source: return

        with global_write_lock:
            try:
                with open(final_source, 'r', encoding='utf-8') as f:
                    old_data = json.load(f)
                if not old_data: return

                with self._get_connection() as conn:
                    for item in old_data:
                        conn.execute('''
                            INSERT OR IGNORE INTO search_history 
                            (query, type, display_name, mire_text, imdb_name, timestamp)
                            VALUES (?, ?, ?, ?, ?, ?)
                        ''', (
                            item.get('query'), item.get('type'), 
                            item.get('addDirectoryItemName') or item.get('display_name'), 
                            item.get('mire_text'), item.get('imdb_name'), item.get('timestamp')
                        ))
                    conn.commit()

                if "_original" not in final_source:
                    os.rename(final_source, final_source + ".migrated")
                
                xbmc.log(f"[nCore_TV SQL] Egyszeri migráció kész forrásból: {os.path.basename(final_source)}", xbmc.LOGINFO)
            except: pass

    def cleanup_orphans(self):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM video_positions WHERE torrent_id NOT IN (SELECT torrent_id FROM torrents)')
            conn.commit()

    def add_search_item(self, data):
        with self._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO search_history 
                (query, type, display_name, mire_text, imdb_name, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                data['query'], data['type'], data['display_name'],
                data['mire_text'], data['imdb_name'], data['timestamp']
            ))
            conn.commit()

    def get_search_history(self):
        with self._get_connection() as conn:
            cursor = conn.execute('SELECT * FROM search_history ORDER BY timestamp DESC')
            return [dict(row) for row in cursor.fetchall()]

    def delete_search_item(self, query):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM search_history WHERE query = ?', (query,))
            conn.commit()

    def clear_all_search_history(self):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM search_history')
            conn.commit()


    def delete_torrent(self, torrent_id):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM torrents WHERE torrent_id = ?', (torrent_id,))
            conn.commit()

    def delete_video_position(self, torrent_id, file_name, position):
        with self._get_connection() as conn:
            conn.execute('''
                DELETE FROM video_positions 
                WHERE torrent_id = ? AND file_name = ? AND position = ?
            ''', (torrent_id, file_name, position))
            conn.commit()

    def migrate_id_maps(self, trakt_map, simkl_map, plex_map, poster_map):
        map_configs = [
            (trakt_map, 'trakt_id'),
            (simkl_map, 'simkl_id'),
            (plex_map, 'plex_rk'),
            (poster_map, 'simkl_poster')
        ]
        
        with global_write_lock:
            with self._get_connection() as conn:
                for path, column in map_configs:
                    if os.path.exists(path):
                        try:
                            with open(path, 'r', encoding='utf-8') as f:
                                data = json.load(f)
                            
                            for imdb_id, value in data.items():
                                final_val = value.get('simkl_id') if isinstance(value, dict) else value
                                
                                conn.execute(f'''
                                    INSERT INTO sync_status (imdb_id, {column}) VALUES (?, ?)
                                    ON CONFLICT(imdb_id) DO UPDATE SET {column}=excluded.{column}
                                ''', (imdb_id, final_val))
                            conn.commit()

                            migrated = path + ".migrated"
                            if os.path.exists(migrated): os.remove(migrated)
                            os.rename(path, migrated)
                            xbmc.log(f"[nCore_TV SQL] Migráció kész: {column}", xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log(f"[nCore_TV SQL] Hiba a(z) {column} migrációnál: {e}", xbmc.LOGERROR)

    def add_watching_series(self, data):
        u_name = data.get('user_name') or data.get('egyedi_eszkoz_name')
        
        with self._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO watching_series 
                (imdb_id, user_name, title_1, title_2, title_3, poster_link, full_link, rogzitett_timestamp, rogzitett_date_and_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data.get('imdb_id'), u_name,
                data.get('title_1'), data.get('title_2'), data.get('title_3'),
                data.get('poster_link'), data.get('full_link'),
                data.get('rogzitett_timestamp'), data.get('rogzitett_date_and_time')
            ))
            conn.commit()

    def get_watching_series(self, filter_user=None):
        query = 'SELECT * FROM watching_series'
        params = ()
        if filter_user:
            query += ' WHERE user_name = ?'
            params = (filter_user,)

        query += ' ORDER BY rogzitett_timestamp DESC'
        
        with self._get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def delete_watching_series(self, imdb_id, user_name):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM watching_series WHERE imdb_id = ? AND user_name = ?', (imdb_id, user_name))
            conn.commit()

    def add_device_name(self, name):
        with self._get_connection() as conn:
            conn.execute('INSERT OR IGNORE INTO device_names (name) VALUES (?)', (name.strip(),))
            conn.commit()

    def get_device_names(self):
        with self._get_connection() as conn:
            cursor = conn.execute('SELECT name FROM device_names ORDER BY name ASC')
            return [row['name'] for row in cursor.fetchall()]

    def migrate_watching_series_legacy(self, history_json, devices_json):
        import os

        if os.path.exists(devices_json):
            try:
                with open(devices_json, 'r', encoding='utf-8') as f:
                    names = json.load(f)
                if names:
                    for n in names:
                        self.add_device_name(n)

                    migrated_dev = devices_json + ".migrated"
                    if os.path.exists(migrated_dev): os.remove(migrated_dev)
                    os.rename(devices_json, migrated_dev)
                    xbmc.log(f"[nCore_TV SQL] Eszköznevek migrációja kész.", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[nCore_TV SQL] Hiba az eszköznevek migrációjánál: {e}", xbmc.LOGERROR)

        if os.path.exists(history_json):
            try:
                with open(history_json, 'r', encoding='utf-8') as f:
                    history = json.load(f)
                
                if history:
                    inserted_count = 0
                    for item in history:
                        sql_data = {
                            "imdb_id": item.get('imdb_id'),
                            "egyedi_eszkoz_name": item.get('egyedi_eszkoz_name'),
                            "title_1": item.get('title_1'),
                            "title_2": item.get('title_2'),
                            "title_3": item.get('title_3'),
                            "poster_link": item.get('poster_link'),
                            "full_link": item.get('full_link'),
                            "rogzitett_timestamp": float(item.get('rogzitett_timestamp', 0)),
                            "rogzitett_date_and_time": item.get('rogzitett_date_and_time')
                        }
                        self.add_watching_series(sql_data)
                        inserted_count += 1

                    if inserted_count > 0:
                        migrated_hist = history_json + ".migrated"
                        if os.path.exists(migrated_hist): os.remove(migrated_hist)
                        os.rename(history_json, migrated_hist)
                        xbmc.log(f"[nCore_TV SQL] SorozatFigyelő migráció kész ({inserted_count} elem).", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[nCore_TV SQL] Hiba a SorozatFigyelő migrációjánál: {e}", xbmc.LOGERROR)

    def export_to_json(self, history_path, devices_path):
        with global_write_lock:
            devices = self.get_device_names()
            with open(devices_path, 'w', encoding='utf-8') as f:
                json.dump(devices, f, indent=4, ensure_ascii=False)

            series = self.get_watching_series()
            export_list = []
            for s in series:
                export_list.append({
                    "full_link": s['full_link'],
                    "title_1": s['title_1'],
                    "title_2": s['title_2'],
                    "title_3": s['title_3'],
                    "poster_link": s['poster_link'],
                    "imdb_id": s['imdb_id'],
                    "rogzitett_timestamp": str(s['rogzitett_timestamp']),
                    "rogzitett_date_and_time": s['rogzitett_date_and_time'],
                    "egyedi_eszkoz_name": s['user_name']
                })
            with open(history_path, 'w', encoding='utf-8') as f:
                json.dump(export_list, f, indent=4, ensure_ascii=False)

    def get_all_played_data_for_export(self):
        final_list = []
        with self._get_connection() as conn:
            query = '''
                SELECT DISTINCT t.* FROM torrents t
                LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                WHERE (t.full_url IS NOT NULL AND t.full_url != '') 
                   OR (v.id IS NOT NULL)
                ORDER BY t.timestamp DESC
            '''
            cursor = conn.execute(query)
            torrents = [dict(row) for row in cursor.fetchall()]
            
            for t in torrents:
                pos_cursor = conn.execute('''
                    SELECT position as pos, label as t, file_name as file 
                    FROM video_positions WHERE torrent_id = ?
                ''', (t['torrent_id'],))
                t['video_saved_position'] = [dict(r) for r in pos_cursor.fetchall()]

                if t['timestamp'] and ' ' in t['timestamp']:
                    t['timestamp'] = t['timestamp'].replace(' ', 'T')
                
                final_list.append(t)
        return final_list

    def get_all_bookmarks(self):
        with self._get_connection() as conn:
            cursor = conn.execute('SELECT * FROM bookmarks_mapping')
            results = {}
            for row in cursor.fetchall():
                results[row['bookmark_key']] = {
                    "name": row['name'],
                    "group_id": row['group_id'],
                    "categories": json.loads(row['categories'])
                }
            return results

    def save_bookmark(self, key, name, group_id, categories_list):
        with self._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO bookmarks_mapping (bookmark_key, name, group_id, categories)
                VALUES (?, ?, ?, ?)
            ''', (key, name, group_id, json.dumps(categories_list)))
            conn.commit()

    def delete_bookmark(self, key):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM bookmarks_mapping WHERE bookmark_key = ?', (key,))
            conn.commit()

    def migrate_bookmarks_from_settings(self, json_str):
        if not json_str or json_str == "{}" or json_str == "": return
        try:
            data = json.loads(json_str)
            for key, info in data.items():
                self.save_bookmark(key, info['name'], info['group_id'], info['categories'])
            xbmc.log("[nCore_TV SQL] Könyvjelző migráció sikeresen lezajlott.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[nCore_TV SQL] Hiba a könyvjelzők migrációjakor: {e}", xbmc.LOGERROR)

    def initialize_file_map_table(self):
        with self._get_connection() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS torrent_files (
                    torrent_id TEXT,
                    file_name TEXT,
                    last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (torrent_id, file_name)
                )
            ''')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_tf_last_used ON torrent_files (last_used)')
            conn.commit()

    def update_torrent_files(self, torrent_id, files):
        video_ext = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.mp3', '.flac')
        valid_files = [
            (str(torrent_id), f) for f in files 
            if f.lower().endswith(video_ext) and 'sample' not in f.lower()
        ]
        
        try:
            with self._get_connection() as conn:
                conn.execute("DELETE FROM torrent_files WHERE torrent_id = ?", (str(torrent_id),))

                if valid_files:
                    conn.executemany("INSERT INTO torrent_files (torrent_id, file_name) VALUES (?, ?)", valid_files)
                    conn.execute("UPDATE torrent_files SET last_used = CURRENT_TIMESTAMP WHERE torrent_id = ?", (str(torrent_id),))

                conn.execute("DELETE FROM torrent_files WHERE last_used < date('now', '-30 days')")
                conn.commit()
                #xbmc.log(f"[nCore_DB] Adatbazis frissitve: {torrent_id} ({len(valid_files)} video fajl)", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[nCore_DB] HIBA az update_torrent_files soran: {str(e)}", xbmc.LOGERROR)

    def get_next_file_in_torrent(self, torrent_id, current_file):
        try:
            with self._get_connection() as conn:
                rows = conn.execute('''
                    SELECT file_name FROM torrent_files 
                    WHERE torrent_id = ?
                ''', (str(torrent_id),)).fetchall()
                
                if not rows: return None
    
                file_list = [r['file_name'] for r in rows]
                file_list.sort(key=lambda x: self.extract_season_episode(x) or (999, 999))
                
                try:
                    current_index = file_list.index(current_file)
                    if current_index + 1 < len(file_list):
                        return file_list[current_index + 1]
                    return None
                except ValueError:
                    return None
        except:
            return None

    def save_torrent_file_list(self, torrent_id, file_list):
        with self._get_connection() as conn:
            conn.execute('DELETE FROM torrent_files WHERE torrent_id = ?', (torrent_id,))
            for file_path in file_list:
                conn.execute('''
                    INSERT INTO torrent_files (torrent_id, file_path) 
                    VALUES (?, ?)
                ''', (torrent_id, file_path))
            conn.commit()

    def has_torrent_structure(self, torrent_id):
        try:
            with self._get_connection() as conn:
                cur = conn.execute('SELECT 1 FROM torrent_files WHERE torrent_id = ? LIMIT 1', (str(torrent_id),))
                return cur.fetchone() is not None
        except:
            return False

    def save_trakt_rating(self, imdb_id, rating_type, rating, season=0, episode=0):
        if not imdb_id: return
        import time
        try:
            with self._get_connection() as conn:
                conn.execute('''
                    INSERT OR REPLACE INTO trakt_ratings 
                    (imdb_id, rating_type, season, episode, rating, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (imdb_id, rating_type, int(season or 0), int(episode or 0), int(rating), int(time.time())))
                conn.commit()
        except Exception as e:
            xbmc.log(f"[nCore_SQL_Error] save_trakt_rating hiba: {e}", xbmc.LOGERROR)

    def get_trakt_rating(self, imdb_id, rating_type, season=0, episode=0):
        if not imdb_id: return None
        try:
            with self._get_connection() as conn:
                row = conn.execute('''
                    SELECT rating FROM trakt_ratings 
                    WHERE imdb_id = ? AND rating_type = ? AND season = ? AND episode = ?
                ''', (imdb_id, rating_type, int(season or 0), int(episode or 0))).fetchone()
                return row['rating'] if row else None
        except:
            return None

    def sync_bulk_trakt_ratings(self, ratings_list):
        if not ratings_list: return
        import time
        timestamp = int(time.time())
        try:
            with self._get_connection() as conn:
                for r in ratings_list:
                    conn.execute('''
                        INSERT OR REPLACE INTO trakt_ratings 
                        (imdb_id, rating_type, season, episode, rating, last_updated)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (r['imdb_id'], r['type'], int(r.get('s') or 0), int(r.get('e') or 0), int(r['rating']), timestamp))
                conn.commit()
            #xbmc.log(f"[nCore_Sync] {len(ratings_list)} db Trakt értékelés elmentve az SQL-be.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[nCore_SQL_Error] sync_bulk_trakt_ratings hiba: {e}", xbmc.LOGERROR)

    def get_total_played_groups_count(self):
        try:
            query = '''
                SELECT COUNT(*) FROM (
                    SELECT 1 FROM torrents t
                    LEFT JOIN video_positions v ON t.torrent_id = v.torrent_id
                    WHERE (t.full_url IS NOT NULL AND t.full_url != '') OR (v.id IS NOT NULL)
                    GROUP BY CASE 
                        WHEN (t.imdb_id IS NOT NULL AND t.imdb_id != '') THEN t.imdb_id 
                        ELSE t.torrent_id 
                    END
                )
            '''
            with self._get_connection() as conn:
                return conn.execute(query).fetchone()[0]
        except Exception as e:
            #xbmc.log(f"[nCore_DB_Error] get_total_played_groups_count: {e}", xbmc.LOGERROR)
            return 0

    def get_torrent_pack_progress_raw(self, torrent_id):
        try:
            video_exts = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.mp3', '.flac')
            
            with self._get_connection() as conn:
                all_rows = conn.execute('SELECT file_name FROM torrent_files WHERE torrent_id = ?', (str(torrent_id),)).fetchall()
    
                relevant_files = [r['file_name'] for r in all_rows 
                                 if r['file_name'].lower().endswith(video_exts) 
                                 and 'sample' not in r['file_name'].lower() 
                                 and 'minta' not in r['file_name'].lower()]
                
                total_count = len(relevant_files)
                if total_count == 0: 
                    return 0, 0
    
                relevant_files.sort(key=lambda x: self.extract_season_episode(x) or (999, 999))
    
                last_row = conn.execute('SELECT file_name FROM video_positions WHERE torrent_id = ? ORDER BY timestamp DESC LIMIT 1', (str(torrent_id),)).fetchone()
                if not last_row: 
                    return 0, total_count
    
                from urllib.parse import unquote_plus
                def norm(f): 
                    return unquote_plus(f).replace('\\', '/').split('/')[-1].strip().lower()
                
                target_name = norm(last_row['file_name'])
                norm_list = [norm(f) for f in relevant_files]
                
                try:
                    curr_index = norm_list.index(target_name) + 1
                    return curr_index, total_count
                except:
                    return 0, total_count
        except Exception as e:
            return 0, 0
