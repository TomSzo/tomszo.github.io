# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import requests
import json
import os
import time
import base64
from datetime import datetime

addon_id = 'plugin.video.nCore_TV'
addon = xbmcaddon.Addon(addon_id)
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
local_played_torrents_file = os.path.join(profile_path, "played_torrents.json")
merged_played_torrents_filename = "all_merged_played_torrents.json"

github_saved_device_names_filename = "saved_device_names_github.json"
github_series_watch_history_filename = "series_watch_history_github.json"

version = xbmcaddon.Addon().getAddonInfo('version')
kodi_version = xbmc.getInfoLabel('System.BuildVersion')
base_log_info = f'nCore TV | v{version} | Kodi: {kodi_version[:5]}'

def log_message(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{addon_id}] {message}", level)

def show_notification(heading, message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=5000):
    xbmcgui.Dialog().notification(heading, message, icon=icon, time=time_ms)

class GitHubSyncManager:
    def __init__(self):
        self.github_owner = addon.getSetting('github_owner')
        self.github_pat = addon.getSetting('github_pat')
        self.github_repo = addon.getSetting('github_repo')
        self.github_folder = 'torrent_stuffs'
        self.github_branch = "main"
        self.github_api_root = f"https://api.github.com/repos/{self.github_owner}/{self.github_repo}/"

        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdirs(profile_path)

    def get_github_config(self):
        github_owner = addon.getSetting('github_owner')
        github_pat = addon.getSetting('github_pat')

        github_repo = self.github_repo
        github_folder = self.github_folder
        github_branch = self.github_branch

        if not github_owner or github_pat in ["github_pat_...", ""]:
            log_message("GitHub sync configuration is incomplete or invalid.", xbmc.LOGWARNING)
            return None, None, None, None, None, None

        github_api_root = f"https://api.github.com/repos/{github_owner}/{github_repo}/"
        return github_owner, github_pat, github_repo, github_folder, github_branch, github_api_root

    def github_request(self, method, url_path, data=None, params=None, headers=None):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            show_notification("GitHub Szinkronizálás", "Hiányzó vagy érvénytelen GitHub beállítások!", xbmcgui.NOTIFICATION_ERROR)
            return None

        full_url = f"{api_root}{url_path}"
        default_headers = {
            "Authorization": f"token {pat}",
            "Accept": "application/vnd.github.v3+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if headers:
            default_headers.update(headers)

        try:
            response = None
            if method == 'GET':
                response = requests.get(full_url, headers=default_headers, params=params)
            elif method == 'PUT':
                response = requests.put(full_url, headers=default_headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            show_notification("GitHub Szinkronizálás Hiba", f"API hiba: {e.response.status_code}", xbmcgui.NOTIFICATION_ERROR)
            return None
        except requests.exceptions.ConnectionError as e:
            log_message(f"ERROR: GitHub API connection error: {e}", xbmc.LOGERROR)
            show_notification("GitHub Szinkronizálás Hiba", "Kapcsolódási hiba a GitHubhoz.", xbmcgui.NOTIFICATION_ERROR)
            return None
        except requests.exceptions.Timeout as e:
            log_message(f"ERROR: GitHub API timeout error: {e}", xbmc.LOGERROR)
            show_notification("GitHub Szinkronizálás Hiba", "Időtúllépés a GitHub API hívásakor.", xbmcgui.NOTIFICATION_ERROR)
            return None
        except Exception as e:
            log_message(f"ERROR: An unexpected error occurred during GitHub API request: {e}", xbmc.LOGERROR)
            show_notification("GitHub Szinkronizálás Hiba", f"Váratlan hiba: {e}", xbmcgui.NOTIFICATION_ERROR)
            return None

    def get_file_sha(self, file_path):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat: return None

        full_github_path = f"contents/{folder}/{file_path}"
        try:
            response = self.github_request('GET', full_github_path, params={'ref': branch})
            return response.get('sha') if response else None
        except Exception as e:
            log_message(f"ERROR: Could not get SHA for {file_path}: {e}", xbmc.LOGERROR)
            return None

    def create_or_update_file(self, file_path, content, message, sha=None):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            log_message("HIBA: GitHub tulajdonos vagy PAT hiányzik, nem lehet fájlt létrehozni/frissíteni.", xbmc.LOGERROR)
            return False

        full_github_path = f"contents/{folder}/{file_path}"
        encoded_content = base64.b64encode(content.encode('utf-8')).decode('utf-8')
        data = {
            "message": message,
            "content": encoded_content,
            "branch": branch
        }
        if sha:
            data["sha"] = sha

        try:
            response = self.github_request('PUT', full_github_path, data=data)

            if response is not None:
                return True
            else:
                log_message(f"HIBA: GitHub API válasz 'None' volt a(z) {file_path} feltöltésekor.", xbmc.LOGERROR)
                return False
        except Exception as e:
            log_message(f"HIBA: Váratlan hiba a create/update fájl művelet során {file_path}: {e}", xbmc.LOGERROR)
            return False

    def get_github_file_content(self, file_path):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat: return None

        full_github_path = f"contents/{folder}/{file_path}"
        try:
            response = self.github_request('GET', full_github_path, params={'ref': branch})
            if response and 'content' in response:
                return base64.b64decode(response['content']).decode('utf-8')
            return None
        except Exception as e:
            log_message(f"ERROR: Could not get content for {file_path}: {e}", xbmc.LOGERROR)
            return None

    def load_local_data(self, file_path):
        if xbmcvfs.exists(file_path):
            try:
                with xbmcvfs.File(file_path, 'r') as f:
                    content = f.read()
                    if content.strip():
                        return json.loads(content)
            except json.JSONDecodeError as e:
                log_message(f"ERROR: JSON decode error in local file {file_path}: {e}. Attempting recovery.", xbmc.LOGERROR)
                show_notification("Hiba", f"Helyi adatfájl sérült: {os.path.basename(file_path)}. Biztonsági mentés...", xbmcgui.NOTIFICATION_ERROR)
                timestamp = int(time.time())
                corrupted_path = f"{file_path}.corrupted_{timestamp}"
                try:
                    if xbmcvfs.rename(file_path, corrupted_path):
                        log_message(f"Corrupted file renamed to: {corrupted_path}", xbmc.LOGWARNING)
                    else:
                        log_message(f"xbmcvfs.rename failed for {file_path} to {corrupted_path}.", xbmc.LOGERROR)
                except Exception as rename_e:
                    log_message(f"Error renaming corrupted file {file_path}: {rename_e}", xbmc.LOGERROR)
                return []
            except Exception as e:
                log_message(f"ERROR: Error reading local file {file_path}: {e}", xbmc.LOGERROR)
        return []

    def sync_single_json_file(self, local_file_path, github_target_filename, commit_message_prefix, navigator_instance=None):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            xbmcgui.Dialog().notification("GitHub Szinkronizálás", "Ellenőrizze a GitHub beállításokat!", xbmcgui.NOTIFICATION_ERROR)
            return False

        local_data = self.load_local_data(local_file_path)
        if not local_data and xbmcvfs.exists(local_file_path):
            local_data = []

        github_content = self.get_github_file_content(github_target_filename)
        github_data = []
        if github_content:
            try:
                github_data = json.loads(github_content)
            except json.JSONDecodeError as e:
                xbmcgui.Dialog().notification("Hiba", f"GitHub {os.path.basename(github_target_filename)} adatfájl sérült!", xbmcgui.NOTIFICATION_ERROR)
                return False
            except Exception as e:
                xbmcgui.Dialog().notification("Hiba", f"Váratlan hiba a GitHub adatokkal: {e}", xbmcgui.NOTIFICATION_ERROR)
                return False

        if github_target_filename == github_series_watch_history_filename:
            final_merged_list = local_data
            #xbmc.log(f'{base_log_info}| GitHubSyncManager | DEBUG: {github_target_filename} fájlhoz a lokális adatok kerülnek feltöltésre (teljes felülírás).', xbmc.LOGINFO)
        elif github_target_filename == github_saved_device_names_filename:
            combined_set = set(github_data).union(set(local_data))
            final_merged_list = sorted(list(combined_set))
            #xbmc.log(f'{base_log_info}| GitHubSyncManager | DEBUG: {github_target_filename} fájlhoz az egyesített adatok kerülnek feltöltésre.', xbmc.LOGINFO)
        else:
            final_merged_list = local_data
            #xbmc.log(f'{base_log_info}| GitHubSyncManager | DEBUG: {github_target_filename} fájlhoz a lokális adatok kerülnek feltöltésre.', xbmc.LOGINFO)

        sha = self.get_file_sha(github_target_filename)
        commit_message = f"{commit_message_prefix} szinkronizálása"

        if github_content:
            try:
                current_github_json_string = json.dumps(json.loads(github_content), indent=2, ensure_ascii=False)
                new_upload_json_string = json.dumps(final_merged_list, indent=2, ensure_ascii=False)

                if current_github_json_string == new_upload_json_string:
                    return True
            except Exception as e:
                xbmc.log(f'{base_log_info}| GitHubSyncManager | WARNING: Hiba a GitHub tartalom összehasonlításakor: {e}. Folytatjuk a feltöltéssel.', xbmc.LOGWARNING)

        upload_success = self.create_or_update_file(
            github_target_filename,
            json.dumps(final_merged_list, indent=2, ensure_ascii=False),
            commit_message,
            sha
        )

        if not upload_success:
            xbmc.log(f'{base_log_info}| GitHubSyncManager | ERROR: Nem sikerült feltölteni a(z) {os.path.basename(local_file_path)} adatokat a GitHubra.', xbmc.LOGERROR)
            return False
        return True

    def download_and_merge_saved_device_names(self, local_file_path):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            show_notification("GitHub Letöltés Hiba", "Ellenőrizze a GitHub beállításokat!", xbmcgui.NOTIFICATION_ERROR)
            return False

        github_content = self.get_github_file_content(github_saved_device_names_filename)
        github_data = []
        if github_content:
            try:
                github_data = json.loads(github_content)
            except json.JSONDecodeError as e:
                log_message(f"ERROR: JSON decode error in GitHub device names file: {e}", xbmc.LOGERROR)
                show_notification("Hiba", "GitHub eszköznevek fájl sérült!", xbmcgui.NOTIFICATION_ERROR)
                return False
            except Exception as e:
                log_message(f"ERROR: An unexpected error occurred loading GitHub device names file: {e}", xbmc.LOGERROR)
                show_notification("Hiba", f"Váratlan hiba a GitHub eszköznevekkel: {e}", xbmcgui.NOTIFICATION_ERROR)
                return False
        else:
            log_message("DEBUG: Nincs meglévő eszköznév fájl a GitHubon vagy üres.", xbmc.LOGDEBUG)

        local_data = self.load_local_data(local_file_path)

        combined_set = set(github_data).union(set(local_data))
        merged_data_list = sorted(list(combined_set))

        try:
            with xbmcvfs.File(local_file_path, 'w') as f:
                f.write(json.dumps(merged_data_list, indent=2, ensure_ascii=False))
        except Exception as e:
            show_notification("Hiba", "Nem sikerült menteni a lokális eszköznevek fájlt!", xbmcgui.NOTIFICATION_ERROR)
            return False

        sha = self.get_file_sha(github_saved_device_names_filename)
        commit_message = "Szinkronizált eszköznevek adatok (merge)"
        upload_success = self.create_or_update_file(
            github_saved_device_names_filename,
            json.dumps(merged_data_list, indent=2, ensure_ascii=False),
            commit_message,
            sha
        )
        if not upload_success:
            show_notification("Szinkronizálás Hiba", "Nem sikerült feltölteni az egyesített eszközneveket a GitHubra.", xbmcgui.NOTIFICATION_ERROR)
            return False

        show_notification("GitHub Szinkronizálás", "Eszköznevek szinkronizálása sikeres!", xbmcgui.NOTIFICATION_INFO, 3000)
        return True


    def download_and_merge_series_watch_history(self, local_file_path):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            show_notification("GitHub Letöltés Hiba", "Ellenőrizze a GitHub beállításokat!", xbmcgui.NOTIFICATION_ERROR)
            return False

        github_content = self.get_github_file_content(github_series_watch_history_filename)
        github_data = []
        if github_content:
            try:
                github_data = json.loads(github_content)
            except json.JSONDecodeError as e:
                show_notification("Hiba", "GitHub sorozat előzmények fájl sérült!", xbmcgui.NOTIFICATION_ERROR)
                return False
            except Exception as e:
                show_notification("Hiba", f"Váratlan hiba a GitHub sorozat előzményekkel: {e}", xbmcgui.NOTIFICATION_ERROR)
                return False

        local_data = self.load_local_data(local_file_path)

        merged_data_dict = {
            (item.get('egyedi_eszkoz_name'), item.get('imdb_id')): item
            for item in github_data
        }
        for item in local_data:
            key = (item.get('egyedi_eszkoz_name'), item.get('imdb_id'))
            if key in merged_data_dict:
                github_ts_str = merged_data_dict[key].get('rogzitett_timestamp')
                local_ts_str = item.get('rogzitett_timestamp')
                if github_ts_str and local_ts_str:
                    try:
                        github_ts = float(github_ts_str)
                        local_ts = float(local_ts_str)
                        if local_ts > github_ts:
                            merged_data_dict[key] = item
                    except ValueError:
                        merged_data_dict[key] = item
                else:
                    merged_data_dict[key] = item
            else:
                merged_data_dict[key] = item

        merged_data_list = list(merged_data_dict.values())
        merged_data_list.sort(key=lambda x: float(x.get("rogzitett_timestamp", 0)), reverse=True)

        try:
            with xbmcvfs.File(local_file_path, 'w') as f:
                f.write(json.dumps(merged_data_list, indent=2, ensure_ascii=False))
        except Exception as e:
            show_notification("Hiba", "Nem sikerült menteni a lokális sorozat előzmények fájlt!", xbmcgui.NOTIFICATION_ERROR)
            return False

        sha = self.get_file_sha(github_series_watch_history_filename)
        commit_message = "Szinkronizált sorozat figyelési előzmények (összefésülve)"
        upload_success = self.create_or_update_file(
            github_series_watch_history_filename,
            json.dumps(merged_data_list, indent=2, ensure_ascii=False),
            commit_message,
            sha
        )
        if not upload_success:
            show_notification("Szinkronizálás Hiba", "Nem sikerült feltölteni az egyesített sorozat előzményeket a GitHubra.", xbmcgui.NOTIFICATION_ERROR)
            return False

        show_notification("GitHub Szinkronizálás", "Sorozat figyelő előzmények szinkronizálása sikeres!", xbmcgui.NOTIFICATION_INFO, 3000)
        return True

    def github_download_and_merge_watching_series_action(self):
        success_devices = self.github_sync_manager.download_and_merge_saved_device_names(self.saved_device_names_file)
        success_history = self.github_sync_manager.download_and_merge_series_watch_history(self.seriesWatchFileName)

        if success_devices and success_history:
            try:
                with open(self.saved_device_names_file, 'r', encoding='utf-8') as f:
                    names = json.load(f)
                    for n in names: self.db.add_device_name(n)
                
                with open(self.seriesWatchFileName, 'r', encoding='utf-8') as f:
                    history = json.load(f)
                    for item in history:
                        item['user_name'] = item.get('egyedi_eszkoz_name')
                        self.db.add_watching_series(item)
                
                xbmcgui.Dialog().notification("GitHub Letöltés", "Adatbázis frissítve!", xbmcgui.NOTIFICATION_INFO, 3000)
            except Exception as e:
                xbmc.log(f"Hiba az SQL frissítésekor letöltés után: {e}", xbmc.LOGERROR)
        
        xbmc.executebuiltin(f'Container.Update("plugin://{addon_str}/?action=show_watching_series")')

    def sync_played_torrents_and_view(self, navigator_instance):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            show_notification("GitHub Szinkronizálás", "Ellenőrizze a GitHub beállításokat!", xbmcgui.NOTIFICATION_ERROR)
            return False

        show_notification("GitHub Szinkronizálás", "Utoljára nézettek szinkronizálása...", xbmcgui.NOTIFICATION_INFO, 3000)

        local_data = self.load_local_data(local_played_torrents_file)

        github_merged_filename_current = merged_played_torrents_filename
        github_merged_content = self.get_github_file_content(github_merged_filename_current)
        github_merged_data = []
        
        if github_merged_content:
            try:
                github_merged_data = json.loads(github_merged_content)
            except Exception as e:
                xbmc.log(f"[nCore_TV GitHub] JSON hiba a tavoli adatoknal: {e}", xbmc.LOGERROR)

        merged_data = {item['torrent_id']: item for item in github_merged_data if 'torrent_id' in item}
        
        for item in local_data:
            tid = item.get('torrent_id')
            if not tid: continue
            
            if tid in merged_data:
                try:
                    github_ts = datetime.fromisoformat(merged_data[tid]['timestamp'])
                    local_ts = datetime.fromisoformat(item['timestamp'])
                    if local_ts > github_ts:
                        merged_data[tid] = item
                except:
                    merged_data[tid] = item
            else:
                merged_data[tid] = item

        final_merged_list = list(merged_data.values())
        try:
            final_merged_list.sort(key=lambda x: datetime.fromisoformat(x['timestamp']), reverse=True)
        except:
            pass

        if not final_merged_list and (local_data or github_merged_data):
            show_notification("Hiba", "Adatvesztés veszélye miatt a mentés megszakadt!", xbmcgui.NOTIFICATION_ERROR)
            return False

        local_merged_file_path = os.path.join(profile_path, github_merged_filename_current)
        if not navigator_instance.save_data_automatically(local_merged_file_path, final_merged_list):
            show_notification("Szinkronizálás Hiba", "Nem sikerült írni a helyi tárolóra.", xbmcgui.NOTIFICATION_ERROR)
            return False

        sha = self.get_file_sha(github_merged_filename_current)
        commit_message = " 'utoljára nézettek' Szinkronizálása..."
        json_payload = json.dumps(final_merged_list, indent=2, ensure_ascii=False)
        
        upload_success = self.create_or_update_file(
            github_merged_filename_current,
            json_payload,
            commit_message,
            sha
        )

        if not upload_success:
            show_notification("Szinkronizálás Hiba", "Nem sikerült a GitHub feltöltés.", xbmcgui.NOTIFICATION_ERROR)
            return False

        show_notification("GitHub Szinkronizálás", "Szinkronizálás sikeres!", xbmcgui.NOTIFICATION_INFO, 3000)
        return True

    def sync_watching_series_files(self, local_device_names_path, local_series_watch_path):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            xbmcgui.Dialog().notification("GitHub Szinkronizálás", "Ellenőrizze a GitHub beállításokat!", xbmcgui.NOTIFICATION_ERROR)
            return False
    
        overall_success = True
        
        success_device_names = self.sync_single_json_file(
            local_device_names_path,
            github_saved_device_names_filename,
            "Eszköznevek"
        )
        if not success_device_names:
            overall_success = False
            
        success_series_history = self.sync_single_json_file(
            local_series_watch_path,
            github_series_watch_history_filename,
            "Sorozat figyelési előzmények"
        )
        if not success_series_history:
            overall_success = False

        if overall_success:
            return True
        else:
            return False

    def download_github_merged_list(self, navigator_instance):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat:
            show_notification("GitHub Letöltés Hiba", "Ellenőrizze a GitHub beállításokat!", xbmcgui.NOTIFICATION_ERROR)
            return False

        github_merged_filename_current = merged_played_torrents_filename
        github_merged_content = self.get_github_file_content(github_merged_filename_current)
        
        if not github_merged_content:
            show_notification("GitHub Letöltés", "Nincs elérhető GitHub lista a szerveren.", xbmcgui.NOTIFICATION_INFO)
            local_merged_file_path = os.path.join(profile_path, github_merged_filename_current)
            navigator_instance.save_data_automatically(local_merged_file_path, [])
            return False

        try:
            github_merged_data = json.loads(github_merged_content)
        except json.JSONDecodeError as e:
            show_notification("Hiba", "GitHub merge-elt adatfájl sérült!", xbmcgui.NOTIFICATION_ERROR)
            return False
        except Exception as e:
            show_notification("Hiba", f"Váratlan hiba a GitHub adatokkal: {e}", xbmcgui.NOTIFICATION_ERROR)
            return False

        local_merged_file_path = os.path.join(profile_path, github_merged_filename_current)
        if not navigator_instance.save_data_automatically(local_merged_file_path, github_merged_data):
            show_notification("GitHub Letöltés Hiba", "Nem sikerült menteni a letöltött GitHub lista fájlt.", xbmcgui.NOTIFICATION_ERROR)
            return False

        return True

    def get_all_github_files_list(self):
        owner, pat, repo, folder, branch, api_root = self.get_github_config()
        if not owner or not pat: return []

        try:
            response = self.github_request('GET', f"contents/{folder}", params={'ref': branch})
            if response:
                return [item['name'] for item in response if item['type'] == 'file']
            return []
        except Exception as e:
            show_notification("GitHub Szinkronizálás Hiba", "Nem sikerült lekérni a GitHub fájllistát.", xbmcgui.NOTIFICATION_ERROR)
            return []