# -*- coding: utf-8 -*-
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import urllib.parse
import requests
import socket
import xbmc
import xbmcaddon
import time

addon = xbmcaddon.Addon('plugin.video.nCore_TV')
session = requests.Session()

def is_port_in_use(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.settimeout(0.5)
        s.connect((host, port))
        s.close()
        return True
    except:
        return False

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class ProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if '?url=' in self.path:
            remote_url = self.path.split('?url=')[1]
            remote_url = urllib.parse.unquote(remote_url)
        else:
            remote_url = None

        if remote_url:
            try:
                h = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://ncore.pro/'
                }
                
                r = session.get(remote_url, headers=h, stream=True, timeout=8, verify=False)
                
                if r.status_code == 200:
                    self.send_response(200)
                    self.send_header("Content-Type", "image/jpeg")
                    self.send_header("Cache-Control", "public, max-age=86400")
                    self.end_headers()

                    for chunk in r.iter_content(chunk_size=16384):
                        if chunk:
                            try: self.wfile.write(chunk)
                            except: break
                else:
                    self.send_response(204)
                    self.end_headers()

            except Exception as e:
                try:
                    self.send_response(204)
                    self.end_headers()
                except: pass
        else:
            self.send_error(400, "Missing url")
    
    def log_message(self, format, *args):
        return

class LocalProxyServer(threading.Thread):
    def __init__(self, host='127.0.0.1', default_port=8081, end_port=8100):
        super(LocalProxyServer, self).__init__()
        self.host = host
        self.httpd = None

        try:
            desired_port = int(addon.getSetting('proxy_port'))
        except:
            desired_port = default_port

        if is_port_in_use(self.host, desired_port):
            self.port = desired_port
            self.httpd = None
        else:
            try:
                self.httpd = ThreadedHTTPServer((self.host, desired_port), ProxyHandler)
                self.port = desired_port
            except OSError:
                for candidate in range(desired_port + 1, end_port):
                    if not is_port_in_use(self.host, candidate):
                        try:
                            self.httpd = ThreadedHTTPServer((self.host, candidate), ProxyHandler)
                            self.port = candidate
                            addon.setSetting('proxy_port', str(candidate))
                            break
                        except OSError:
                            continue
        self.daemon = True

    def run(self):
        if self.httpd:
            try:
                self.httpd.serve_forever()
            except:
                pass

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()

SERVER_INSTANCE = None

def get_proxy_server():
    global SERVER_INSTANCE
    if SERVER_INSTANCE is None:
        SERVER_INSTANCE = LocalProxyServer()
        SERVER_INSTANCE.start()
    return SERVER_INSTANCE