# -*- coding: utf-8 -*-
# Módosított fájl (fork). Eredeti: nCore TV Addon, Copyright (C) heg, GPL-3.0-or-later (lásd LICENSE.txt).
# Módosítások: Copyright (C) 2026 TomSzo, módosítva: 2026-09-20 (lásd CHANGELOG.md).
import sys, xbmc, xbmcaddon, xbmcgui, base64
from datetime import datetime
import urllib3
import requests
import hashlib

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
    pass

import json
import threading
global_write_lock = threading.Lock()

sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])
addonFanart = xbmcaddon.Addon().getAddonInfo('fanart')

version = xbmcaddon.Addon().getAddonInfo('version')
kodi_version = xbmc.getInfoLabel('System.BuildVersion')
base_log_info = f'nCore TV | v{version} | Kodi: {kodi_version[:5]}'
#xbmc.log(f'{base_log_info}', xbmc.LOGINFO)

addon = xbmcaddon.Addon('plugin.video.nCore_TV')
addon_str = addon.getAddonInfo('id')
user_name = addon.getSetting('username')
pass_word = addon.getSetting('password')
for_both_sub = addon.getSetting('for_both_sub')
just_for_eng_sub = addon.getSetting('just_for_eng_sub')
xxx_contents = addon.getSetting('show_xxx')
add_ncore_tag = addon.getSetting('ncore_tag')

auto_add_bookmark = addon.getSetting('auto_add_bookmark')
show_notif_for_auto_bookmark = addon.getSetting('show_notif_for_auto_bookmark')

file_test = addon.getSetting("test")

proxy_needed = addon.getSetting('proxy_enable')
if proxy_needed == 'true':
    proxy_port = addon.getSetting('proxy_port')
    proxy_host = "127.0.0.1"

extra_play_nav_menu_enabled = addon.getSetting('extra_play_nav_menu') == 'true'

### Kodi colors:
#[COLOR ]
# red #green #blue #yellow #orange #pink #purple #cyan #gray #white #black #gold 
# silver #brown #lime #magenta #lightblue #lightgreen #lightgray #lightpink #lightyellow
#[/COLOR]

forum_roviditett_link = "https://v.gd/Fma6hQ"
forum_link = "https://prohardver.hu/tema/kodi_xbmc_kiegeszito_magyar_nyelvu_online_filmekhe/friss.html"
forum_szoveg = f"[B][COLOR FFfc1303]Ha hibát találsz, ne az nCore oldalára írj, hanem a prohardver fórumra![/COLOR][/B]"

if add_ncore_tag == 'true':
    ncore_coloring = ' - [B][COLOR lime]n[COLOR ffff0000]C[/COLOR][COLOR lime]ore[/COLOR][/B]'
else:
    ncore_coloring = ''
    
base_url = 'https://ncore.pro'
headers = {
    'authority': 'ncore.pro',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36',
}

mire_dovi = '/torrents.php?miszerint=ctime&hogyan=DESC&mire=dolby%7Cdovi%7C.DV.+2160'
mire_hd = '/torrents.php?miszerint=ctime&hogyan=DESC&mire'
mire_hd_seed = '/torrents.php?miszerint=seeders&hogyan=DESC&mire'   # seed szerint csökkenő
mire_sd = '/torrents.php?miszerint=ctime&hogyan=DESC&tipus'

for_name = '&miben=name&tipus=kivalasztottak_kozott&mire='
for_imdb = '&miben=imdb&tipus=kivalasztottak_kozott&mire=tt'

if xxx_contents == 'true':
    xxx_kereso = f'/torrents.php?nyit_xxx_resz=true&kivalasztott_tipus%5B%5D=xxx_xvid&kivalasztott_tipus%5B%5D=xxx_hd{for_name}'

e_r = base64.b64decode
e_f = lambda x: x.decode('utf-8')
a_d = e_f(e_r('aHR0cHM6Ly8='))
c_d = e_f(e_r('YXBpLnNp'))
i_d = e_f(e_r('bWtsLmNvbS90di8='))
s_s = e_f(e_r('c2lt'))
s_g = e_f(e_r('a2wuaW4vcG9zdGVycy8='))
k_h_n_o = e_f(e_r('aHR0cHM6Ly9hcGkuc2lta2wuY29t'))

movie_ser_hu_kereso = f'/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvid_hun&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=xvidser_hun&kivalasztott_tipus%5B%5D=hdser_hun{for_name}'

movie_ser_en_kereso = f'/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvid&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=xvidser&kivalasztott_tipus%5B%5D=hdser{for_name}'

movie_ser_en_hu_kereso =f'/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvid_hun&kivalasztott_tipus%5B%5D=xvid&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=xvidser_hun&kivalasztott_tipus%5B%5D=xvidser&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser{for_name}'

u_s = base64.b64decode
kr_g = lambda cy: cy.decode('utf-8')
ab_t = kr_g(u_s('aHR0cHM6Ly9hcGk='))
kf_t = kr_g(u_s('c2lta2wuY29t'))

movie_hu_kereso = f'/torrents.php?nyit_filmek_resz=true&kivalasztott_tipus%5B%5D=xvid_hun&kivalasztott_tipus%5B%5D=hd_hun{for_name}'
movie_en_kereso = f'/torrents.php?nyit_filmek_resz=true&kivalasztott_tipus%5B%5D=xvid&kivalasztott_tipus%5B%5D=hd{for_name}'

series_hu_kereso = f'/torrents.php?nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvidser_hun&kivalasztott_tipus%5B%5D=hdser_hun{for_name}'
series_en_kereso = f'/torrents.php?nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvidser&kivalasztott_tipus%5B%5D=hdser{for_name}'

ad_t = base64.b64decode
tn_k = lambda kx: kx.decode('utf-8')
tk_rlt = tn_k(ad_t('YmU1ZA=='))
bd_cnd = tn_k(ad_t('YTEzY2Q='))
kt_ufg = tn_k(ad_t('MDJiNzc='))
ak_tdk = tn_k(ad_t('MDlmMjY1'))
cd_bdc = tn_k(ad_t('YzgwNWE='))
tn_knk = tn_k(ad_t('YmNjNTgzNw=='))

zene_hu_kereso = f'/torrents.php?nyit_zene_resz=true&kivalasztott_tipus%5B%5D=mp3_hun&kivalasztott_tipus%5B%5D=lossless_hun&kivalasztott_tipus%5B%5D=clip{for_name}'
zene_en_kereso = f'/torrents.php?nyit_zene_resz=true&kivalasztott_tipus%5B%5D=mp3&kivalasztott_tipus%5B%5D=lossless&kivalasztott_tipus%5B%5D=clip{for_name}'

imdb_hu_kereso = f'/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvid_hun&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=xvidser_hun&kivalasztott_tipus%5B%5D=hdser_hun{for_imdb}'

ot_ts = base64.b64decode
kk_g = lambda cy: cy.decode('utf-8')
atb_td = kk_g(ot_ts('NjJhNTg3ZWM='))
kzf_td = kk_g(ot_ts('MmE4MmRiZQ=='))
frt_td = kk_g(ot_ts('ZDAyYzZhYjQ4'))
qwe_td = kk_g(ot_ts('YjkyM2Q3MmU3'))
cde_td = kk_g(ot_ts('NzVjYjEw'))
otg_td = kk_g(ot_ts('OTZkMmRlNjBkMA=='))
cvb_td = kk_g(ot_ts('NDUwMjQxM2U='))
tdz_td = kk_g(ot_ts('MzZlZjEwMA=='))

o3_2s = base64.b64decode
x6_f = lambda uv: uv.decode('utf-8')
qje_9n = x6_f(o3_2s('NTg3ZDgxYWY1YWE5Nzhh'))
kjf_9n = x6_f(o3_2s('ZjZmYTk0OGMxNzQ1MGQ='))
ajb_9n = x6_f(o3_2s('YzUzZWNmNjE4NDZkMTlk'))
fjt_9n = x6_f(o3_2s('ZjJhMmMwMmU4NDI0YTI3ZGRhMjM='))

n5_fk = base64.b64decode
x7_o = lambda o3: o3.decode('utf-8')
qwi_t4 = x7_o(n5_fk('YjlhZGQxMGNkNDk1M2U4YTQ='))
kzi_t4 = x7_o(n5_fk('MGJkYTk2NzhkZmQy'))
ati_t4 = x7_o(n5_fk('MWVhNGRhMDUzNjYzZTc='))
fri_t4 = x7_o(n5_fk('MGZjMTcyZTc5NTM1M2RkYjc0Mjcx'))

hungarian_day_names = {
    'Monday': 'Hétfő',
    'Tuesday': 'Kedd',
    'Wednesday': 'Szerda',
    'Thursday': 'Csütörtök',
    'Friday': 'Péntek',
    'Saturday': 'Szombat',
    'Sunday': 'Vasárnap'
}

imdb_en_kereso = f'/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvid&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=xvidser&kivalasztott_tipus%5B%5D=hdser{for_imdb}'

a1_o3 = base64.b64decode
n9_2 = lambda c3: c3.decode('utf-8')
a2b_t4 = n9_2(a1_o3('MGQ1MTA0NWYzMDA3'))
f2t_t4 = n9_2(a1_o3('ZjI1Njc0MjI5'))
k2f_t4 = n9_2(a1_o3('ZjljMWIxNjcyZWM='))

a5_y3 = base64.b64decode
v4_t = lambda q3: q3.decode('utf-8')
qfv_x2 = v4_t(a5_y3('bmMtdHY='))

imdb_kereso = f'/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=xvid_hun&kivalasztott_tipus%5B%5D=xvid&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=xvidser_hun&kivalasztott_tipus%5B%5D=xvidser&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser{for_imdb}'

qv_ah = base64.b64decode
tn_u = lambda cx: cx.decode('utf-8')
qoe_zn = tn_u(qv_ah('MTA5NmQyZGU2MGQwNDUwMjQxM2UzNmVmMTAw'))
kof_zn = tn_u(qv_ah('ZWQwMmM2YWI0OGI5MjM='))
aob_zn = tn_u(qv_ah('NjJhNTg3ZWMyYTgyZGI='))
fot_zn = tn_u(qv_ah('ZDcyZTc3NWNi'))

un_zq = base64.b64decode
lb_f = lambda sx: sx.decode('utf-8')
qye_3h = lb_f(un_zq('ZmYxZmY2ZjEzZDliNzMyZQ=='))
kyf_3h = lb_f(un_zq('YTk0YTkzMGMyODJkM2QzOGNjMA=='))
ayb_3h = lb_f(un_zq('M2U5ZDE1NjM2NTk='))
fyt_3h = lb_f(un_zq('MWVjZTJhYjVkNzY5YWU0NDlj'))

def checkTorrentSource(url_to_check):
    try:
        valasz = requests.head(url_to_check, allow_redirects=False, timeout=(6, 12))
        if valasz.status_code == 200:
            #xbmc.log(f"A torrent URL sikeresen elérhető (200 OK): {url_to_check}", xbmc.LOGINFO)
            return True
        elif valasz.status_code == 302:
            #xbmc.log(f"302 Nem található a szerverünkön ez a torrent!", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("nCore TV", "Nem található a szerverünkön ez a torrent!", time=3000)
            return False
        else:
            #xbmc.log(f"A torrent URL hibás státuszkódot adott vissza: {valasz.status_code}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("nCore TV", f"A torrent URL hibás státuszkódot adott vissza: {valasz.status_code}", time=3000)
            return False
    except requests.exceptions.RequestException as e:
        #xbmc.log(f"Hiba a torrent URL ellenőrzésekor: {e} - {url_to_check}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("nCore TV", "Nem sikerült ellenőrizni a torrent forrást. Lehet, hogy nem elérhető (Hálózati hiba).", time=3000)
        return False

getJustWatchDate_extend_with_this = '''
externalIds {
  imdbId 
  wikidataId 
  __typename
}
originalReleaseYear
'''

getJustWatchDate_original_query = '''query GetNewTitles($country: Country!, $date: Date!, $language: Language!, $filter: TitleFilter, $after: String, $first: Int! = 10, $profile: PosterProfile, $format: ImageFormat, $backdropProfile: BackdropProfile, $priceDrops: Boolean!, $platform: Platform!, $bucketType: NewDateRangeBucket, $pageType: NewPageType! = NEW, $showDateBadge: Boolean!, $availableToPackages: [String!], $allowSponsoredRecommendations: SponsoredRecommendationsInput) {\n  newTitles(\n    country: $country\n    date: $date\n    filter: $filter\n    after: $after\n    first: $first\n    priceDrops: $priceDrops\n    bucketType: $bucketType\n    pageType: $pageType\n    allowSponsoredRecommendations: $allowSponsoredRecommendations\n  ) {\n    totalCount\n    edges {\n      ...NewTitleGraphql\n      __typename\n    }\n    sponsoredAd {\n      ...SponsoredAd\n      __typename\n    }\n    pageInfo {\n      endCursor\n      hasPreviousPage\n      hasNextPage\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment NewTitleGraphql on NewTitlesEdge {\n  cursor\n  newOffer(platform: $platform) {\n    ...NewWatchNowOffer\n    __typename\n  }\n  node {\n    __typename\n    ... on MovieOrSeason {\n      id\n      objectId\n      objectType\n      content(country: $country, language: $language) {\n        title\n        shortDescription\n        fullPath\n        scoring {\n          imdbVotes\n          imdbScore\n          tmdbPopularity\n          tmdbScore\n          tomatoMeter\n          certifiedFresh\n          __typename\n        }\n        posterUrl(profile: $profile, format: $format)\n        runtime\n        genres {\n          translation(language: $language)\n          __typename\n        }\n        ... on SeasonContent {\n          seasonNumber\n          __typename\n        }\n        upcomingReleases @include(if: $showDateBadge) {\n          releaseDate\n          package {\n            id\n            shortName\n            __typename\n          }\n          releaseCountDown(country: $country)\n          __typename\n        }\n        isReleased\n        __typename\n      }\n      availableTo(\n        country: $country\n        platform: $platform\n        packages: $availableToPackages\n      ) @include(if: $showDateBadge) {\n        availableCountDown(country: $country)\n        package {\n          id\n          shortName\n          __typename\n        }\n        availableToDate\n        __typename\n      }\n      ... on Movie {\n        likelistEntry {\n          createdAt\n          __typename\n        }\n        dislikelistEntry {\n          createdAt\n          __typename\n        }\n        seenlistEntry {\n          createdAt\n          __typename\n        }\n        watchlistEntryV2 {\n          createdAt\n          __typename\n        }\n        __typename\n      }\n      ... on Season {\n        likelistEntry {\n          createdAt\n          __typename\n        }\n        dislikelistEntry {\n          createdAt\n          __typename\n        }\n        show {\n          __typename\n          id\n          objectId\n          objectType\n          content(country: $country, language: $language) {\n            title\n            shortDescription\n            fullPath\n            scoring {\n              imdbVotes\n              imdbScore\n              tmdbPopularity\n              tmdbScore\n              __typename\n            }\n            posterUrl(profile: $profile, format: $format)\n            runtime\n            genres {\n              translation(language: $language)\n              __typename\n            }\n            __typename\n          }\n          likelistEntry {\n            createdAt\n            __typename\n          }\n          dislikelistEntry {\n            createdAt\n            __typename\n          }\n          watchlistEntryV2 {\n            createdAt\n            __typename\n          }\n          seenState(country: $country) {\n            progress\n            __typename\n          }\n        }\n        __typename\n      }\n      __typename\n    }\n  }\n  __typename\n}\n\nfragment NewWatchNowOffer on Offer {\n  ...WatchNowOffer\n  lastChangeRetailPrice(language: $language)\n  lastChangePercent\n  __typename\n}\n\nfragment WatchNowOffer on Offer {\n  __typename\n  id\n  standardWebURL\n  preAffiliatedStandardWebURL\n  streamUrl\n  package {\n    id\n    icon\n    packageId\n    clearName\n    shortName\n    technicalName\n    iconWide(profile: S160)\n    hasRectangularIcon(country: $country, platform: WEB)\n    __typename\n  }\n  retailPrice(language: $language)\n  retailPriceValue\n  lastChangeRetailPriceValue\n  currency\n  presentationType\n  monetizationType\n  availableTo\n  dateCreated\n  newElementCount\n}\n\nfragment SponsoredAd on SponsoredRecommendationAd {\n  bidId\n  holdoutGroup\n  campaign {\n    name\n    backgroundImages {\n      imageURL\n      size\n      __typename\n    }\n    countdownTimer\n    creativeType\n    disclaimerText\n    externalTrackers {\n      type\n      data\n      __typename\n    }\n    hideDetailPageButton\n    hideImdbScore\n    hideJwScore\n    hideRatings\n    hideContent\n    posterOverride\n    promotionalImageUrl\n    promotionalVideo {\n      url\n      __typename\n    }\n    promotionalTitle\n    promotionalText\n    promotionalProviderLogo\n    promotionalProviderWideLogo\n    watchNowLabel\n    watchNowOffer {\n      ...WatchNowOffer\n      __typename\n    }\n    nodeOverrides {\n      nodeId\n      promotionalImageUrl\n      watchNowOffer {\n        standardWebURL\n        __typename\n      }\n      __typename\n    }\n    node {\n      nodeId: id\n      __typename\n      ... on MovieOrShowOrSeason {\n        content(country: $country, language: $language) {\n          fullPath\n          posterUrl\n          title\n          originalReleaseYear\n          scoring {\n            imdbScore\n            jwRating\n            __typename\n          }\n          genres {\n            shortName\n            translation(language: $language)\n            __typename\n          }\n          externalIds {\n            imdbId\n            __typename\n          }\n          backdrops(format: $format, profile: $backdropProfile) {\n            backdropUrl\n            __typename\n          }\n          isReleased\n          __typename\n        }\n        objectId\n        objectType\n        offers(country: $country, platform: $platform, filter: {preAffiliate: true}) {\n          monetizationType\n          presentationType\n          package {\n            id\n            packageId\n            __typename\n          }\n          id\n          __typename\n        }\n        __typename\n      }\n      ... on MovieOrShow {\n        watchlistEntryV2 {\n          createdAt\n          __typename\n        }\n        __typename\n      }\n      ... on Show {\n        seenState(country: $country) {\n          seenEpisodeCount\n          __typename\n        }\n        __typename\n      }\n      ... on Season {\n        content(country: $country, language: $language) {\n          seasonNumber\n          __typename\n        }\n        show {\n          __typename\n          id\n          objectId\n          objectType\n          content(country: $country, language: $language) {\n            originalTitle\n            __typename\n          }\n          watchlistEntryV2 {\n            createdAt\n            __typename\n          }\n        }\n        __typename\n      }\n      ... on GenericTitleList {\n        followedlistEntry {\n          createdAt\n          name\n          __typename\n        }\n        id\n        type\n        content(country: $country, language: $language) {\n          name\n          visibility\n          __typename\n        }\n        titles(country: $country, first: 40) {\n          totalCount\n          edges {\n            cursor\n            node: nodeV2 {\n              content(country: $country, language: $language) {\n                fullPath\n                posterUrl\n                title\n                originalReleaseYear\n                scoring {\n                  imdbVotes\n                  imdbScore\n                  tomatoMeter\n                  certifiedFresh\n                  jwRating\n                  __typename\n                }\n                isReleased\n                __typename\n              }\n              id\n              objectId\n              objectType\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n    }\n    __typename\n  }\n  __typename\n}\n'''

ExtJustWatchCategories_extend_with_this = '''
externalIds {
  imdbId 
  wikidataId 
  __typename
}
originalReleaseYear
shortDescription
originalTitle
'''

ExtJustWatchCategories_original_query = '''query GetPopularTitles($backdropProfile: BackdropProfile, $country: Country!, $first: Int! = 99, $format: ImageFormat, $language: Language!, $after: String, $popularTitlesFilter: TitleFilter, $popularTitlesSortBy: PopularTitlesSorting! = POPULAR, $profile: PosterProfile, $sortRandomSeed: Int! = 0, $watchNowFilter: WatchNowOfferFilter!, $offset: Int = 0, $creditsRole: CreditRole! = DIRECTOR) {\n  popularTitles(\n    country: $country\n    filter: $popularTitlesFilter\n    first: $first\n    sortBy: $popularTitlesSortBy\n    sortRandomSeed: $sortRandomSeed\n    offset: $offset\n    after: $after\n  ) {\n    __typename\n    edges {\n      cursor\n      node {\n        ...PopularTitleGraphql\n        __typename\n      }\n      __typename\n    }\n    pageInfo {\n      startCursor\n      endCursor\n      hasPreviousPage\n      hasNextPage\n      __typename\n    }\n    totalCount\n  }\n}\n\nfragment PopularTitleGraphql on MovieOrShow {\n  __typename\n  id\n  objectId\n  objectType\n  content(country: $country, language: $language) {\n    title\n    fullPath\n    interactions {\n      likelistAdditions\n      dislikelistAdditions\n      __typename\n    }\n    scoring {\n      imdbVotes\n      imdbScore\n      tmdbPopularity\n      tmdbScore\n      tomatoMeter\n      certifiedFresh\n      jwRating\n      __typename\n    }\n    interactions {\n      votesNumber\n      __typename\n    }\n    dailymotionClips: clips(providers: [DAILYMOTION]) {\n      sourceUrl\n      externalId\n      provider\n      streamUrl\n      __typename\n    }\n    posterUrl(profile: $profile, format: $format)\n    ... on MovieOrShowOrSeasonContent {\n      backdrops(profile: $backdropProfile, format: $format) {\n        backdropUrl\n        __typename\n      }\n      __typename\n    }\n    isReleased\n    credits(role: $creditsRole) {\n      name\n      personId\n      __typename\n    }\n    runtime\n    genres {\n      translation(language: $language)\n      shortName\n      __typename\n    }\n    __typename\n  }\n  likelistEntry {\n    createdAt\n    __typename\n  }\n  dislikelistEntry {\n    createdAt\n    __typename\n  }\n  watchlistEntryV2 {\n    createdAt\n    __typename\n  }\n  customlistEntries {\n    createdAt\n    __typename\n  }\n  freeOffersCount: offerCount(\n    country: $country\n    platform: WEB\n    filter: {monetizationTypes: [FREE, ADS]}\n  )\n  watchNowOffer(country: $country, platform: WEB, filter: $watchNowFilter) {\n    ...WatchNowOffer\n    __typename\n  }\n  ... on Movie {\n    seenlistEntry {\n      createdAt\n      __typename\n    }\n    __typename\n  }\n  ... on Show {\n    tvShowTrackingEntry {\n      createdAt\n      __typename\n    }\n    seenState(country: $country) {\n      seenEpisodeCount\n      progress\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment WatchNowOffer on Offer {\n  __typename\n  id\n  standardWebURL\n  preAffiliatedStandardWebURL\n  streamUrl\n  package {\n    id\n    icon\n    packageId\n    clearName\n    shortName\n    technicalName\n    iconWide(profile: S160)\n    hasRectangularIcon(country: $country, platform: WEB)\n    __typename\n  }\n  retailPrice(language: $language)\n  retailPriceValue\n  lastChangeRetailPriceValue\n  currency\n  presentationType\n  monetizationType\n  availableTo\n  dateCreated\n  newElementCount\n}\n'''

vote_count_gte = '3'

getRecommendMovie_data = {
    'air_date.gte': '',
    'air_date.lte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    #'page': '1',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': '',
    'release_date.gte': '',
    #'release_date.lte': '2011',
    'show_me': '0',
    'sort_by': 'primary_release_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeries_data = {
    'air_date.gte': '',
    #'air_date.lte': '2024-11-09',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    #'page': '1',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': '0',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeriesAmazon_data = {
    'air_date.gte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': 'everything',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '119',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeriesDisney_data = {
    'air_date.gte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': 'everything',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '337',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeriesMAX_data = {
    'air_date.gte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': 'everything',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '1899',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeriesNetflix_data = {
    'air_date.gte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': 'everything',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '8',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeriesSkyshowtime_data = {
    'air_date.gte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': 'everything',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '1773',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

getRecommendSeriesApple_plus_data = {
    'air_date.gte': '',
    'certification': '',
    'certification_country': 'HU',
    'debug': '',
    'first_air_date.gte': '',
    'first_air_date.lte': '',
    'primary_release_date.gte': '',
    'primary_release_date.lte': '',
    'region': 'HU|XX',
    'release_date.gte': '',
    'release_date.lte': '',
    'show_me': 'everything',
    'sort_by': 'first_air_date.desc',
    'vote_average.gte': '0',
    'vote_average.lte': '10',
    'vote_count.gte': vote_count_gte,
    'watch_region': 'HU',
    'with_genres': '',
    'with_keywords': '',
    'with_networks': '',
    'with_origin_country': '',
    'with_original_language': '',
    'with_watch_monetization_types': '',
    'with_watch_providers': '350',
    'with_release_type': '',
    'with_runtime.gte': '0',
    'with_runtime.lte': '400',
}

this_year = datetime.now().year
years_in_query = "|".join([str(year) for year in range(2020, this_year + 1)]) + "+1080"
years_in_query_encoded = years_in_query.replace("+", "%2B")

ox_r1 = base64.b64decode
h4_1 = lambda xb2: xb2.decode('utf-8')
f7t_t8 = h4_1(ox_r1('Z3NuYWcuYw=='))
a7b_t8 = h4_1(ox_r1('aHR0cHM6Ly9hcGkubG8='))
k7f_t8 = h4_1(ox_r1('b20vdjEvbG9n'))

o3x_rn1 = base64.b64decode
h74_2 = lambda xt2: xt2.decode('utf-8')
q8t_t2 = h74_2(o3x_rn1('ZGJkNWZkNzQ='))
x8b_t2 = h74_2(o3x_rn1('MTNiNQ=='))
u8f_t2 = h74_2(o3x_rn1('NDIyOQ=='))
j8f_t2 = h74_2(o3x_rn1('ODEwYQ=='))
k8f_t2 = h74_2(o3x_rn1('ZTkzYThkODQ2MDI3'))

def get_anon_user_id():
    if not user_name or user_name == "":
        return None
    stat_uuid = f"{q8t_t2}-{x8b_t2}-{u8f_t2}-{j8f_t2}-{k8f_t2}"
    n_user = user_name.strip().lower()
    anon_user = f"{n_user}{stat_uuid}"
    return hashlib.sha256(anon_user.encode('utf-8')).hexdigest()[:12]
def s_t_l(channel_name, event_name, description, icon):
    anon_id = get_anon_user_id()
    if anon_id is None:
        return
    log_time = datetime.now().strftime("%Y.%m.%d. %H:%M")
    headers = {"Authorization": f"Bearer {a2b_t4}{k2f_t4}{f2t_t4}", "Content-Type": "application/json"}
    payload = {"project": qfv_x2, "channel": channel_name, "event": event_name, "description": f"{description}\n\n🕒 Time: {log_time} | User: {anon_id}", "user_id": anon_id, "icon": icon, "notify": False}
    try:
        requests.post(f'{a7b_t8}{f7t_t8}{k7f_t8}', json=payload, headers=headers, timeout=3)
    except:
        pass
def track_event(channel, event, message="", icon="🛡️"):
    if not addon.getSetting("pass_k"):
        return
    event_thread = threading.Thread(target=s_t_l, args=(channel, event, message, icon))
    event_thread.daemon = True
    event_thread.start()

years_in_name = f"2020-{this_year}"

static_search_json = [
    {
        "addDirectoryItemName": f"Kereső [B][COLOR lime]HU[/COLOR][/B] > Film: [COLOR lime]{years_in_name} 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&kivalasztott_tipus%5B%5D=hd_hun&mire={years_in_query_encoded}&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR][/B] > Sorozat & Film: [COLOR lime]Legtöbbet seedelt 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?miszerint=seeders&hogyan=DESC&tipus=kivalasztottak_kozott&kivalasztott_tipus=hd_hun,hdser_hun&mire=1080p&miben=name",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Netflix 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.nf.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Amazon Prime 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.amzn.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Disney+ 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.dsnp.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]MAX 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.MAX.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]HBOMAX 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.HMAX.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Apple TV+ 2160p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.2160p.ATVP.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },    
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Skyshowtime 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.SKST.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },        
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Telekom TVGO 720p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.720p.TVGO.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]BBC Iplayer (IP) 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.IP.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR] & [COLOR FFF56C00]EN[/COLOR][/B] > Sorozat & Film: [COLOR lime]Movies Anywhere (MA) 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hd&kivalasztott_tipus%5B%5D=hdser_hun&kivalasztott_tipus%5B%5D=hdser&mire=.1080p.MA.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR][/B] > Sorozat & Film: [COLOR lime]RTL+ 720p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hdser_hun&mire=.720p.RTLP.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },    
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR][/B] > Sorozat & Film: [COLOR lime]TV2 720p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hdser_hun&mire=.720p.TV2.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    },    
    {
        "addDirectoryItemName": "Kereső [B][COLOR lime]HU[/COLOR][/B] > Sorozat & Film: [COLOR lime]FILMIO 1080p[/COLOR]",
        "query": f"{base_url}/torrents.php?nyit_filmek_resz=true&nyit_sorozat_resz=true&kivalasztott_tipus%5B%5D=hd_hun&kivalasztott_tipus%5B%5D=hdser_hun&mire=.1080p.FMIO.&miben=name&tipus=kivalasztottak_kozott&tags=",
        "type": "newsearch"
    }    
]

ext_actors_headers = {
    'accept': 'application/graphql+json, application/json',
    'accept-language': 'hu',
    'content-type': 'application/json',
    'origin': 'https://www.imdb.com',
    'referer': 'https://www.imdb.com/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
    'x-amzn-sessionid': '',
    'x-imdb-client-name': 'imdb-web-next',
    'x-imdb-client-rid': '',
    'x-imdb-user-country': 'HU',
    'x-imdb-user-language': 'en-US',
    'x-imdb-weblab-treatment-overrides': '{}',
}

class _LazyRemote(object):
    """Távoli (GitHub) adat lusta, gyorsítótárazott betöltése.
    Korábban a static_data importálásakor, azaz MINDEN plugin-hívásnál (minden lista/kattintás) két
    blokkoló HTTPS-kérés futott (egyenként 15 mp timeouttal). Most csak első használatkor tölt le,
    és az eredményt TTL-ig lemezen tartja; hiba esetén a régi értéket (vagy az alapértéket) adja."""
    TTL = 12 * 3600

    def __init__(self, url, key, kind, default):
        self._url, self._key, self._kind, self._default = url, key, kind, default
        self._loaded = False
        self._value = default

    def _cache_path(self):
        import os, xbmcvfs
        return os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'remote_cache.json')

    def _load(self):
        if self._loaded:
            return self._value
        import os, time
        self._loaded = True
        cache, entry = {}, None
        path = self._cache_path()
        try:
            with open(path, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            entry = cache.get(self._key)
        except Exception:
            cache = {}
        now = time.time()
        if entry and (now - float(entry.get('ts', 0))) < self.TTL:
            self._value = entry.get('val', self._default)
            return self._value
        try:
            r = requests.get(self._url, headers=headers, timeout=(4, 8))
            val = json.loads(r.text) if self._kind == 'json' else r.text
            self._value = val
            cache[self._key] = {'ts': now, 'val': val}
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump(cache, f, ensure_ascii=False)
            except Exception:
                pass
        except Exception:
            self._value = entry.get('val', self._default) if entry else self._default
        return self._value

    # lista-szerű (json) használat
    def __iter__(self):
        return iter(self._load())
    def __len__(self):
        return len(self._load())
    # szöveg-szerű (text) használat: h_w_n.strip()
    def strip(self, *a):
        return str(self._load()).strip(*a)

ext_actors_hashes = []
d_f_b = base64.b16decode('68747470733A2F2F7261772E67697468756275736572636F6E74656E742E636F6D2F736B386F726469332F7570646174652F726566732F68656164732F6D61696E2F686173686573'.encode('utf-8'))
g_v_u = d_f_b.decode('utf-8')
headers = {'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8','upgrade-insecure-requests':'1','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'}
ext_actors_hashes = _LazyRemote(g_v_u, 'ext_actors_hashes', 'json', [])
k_d_v = base64.b16decode('68747470733A2F2F7261772E67697468756275736572636F6E74656E742E636F6D2F736B386F726469332F7570646174652F726566732F68656164732F6D61696E2F666F725F6F6666'.encode('utf-8'))
u_n_y = k_d_v.decode('utf-8')
headers = {'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8','upgrade-insecure-requests':'1','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'}
h_w_n = _LazyRemote(u_n_y, 'for_off', 'text', "")
o_r_s = base64.b16decode('68747470733A2F2F63646E2E6A7364656C6976722E6E65742F67682F736B386F726469332F757064617465406C61746573742F636865636B65642E6A736F6E'.encode('utf-8'))
t_k_d = o_r_s.decode('utf-8')

CATEGORY_MAP = {
    '[nCore][hd_hun]': '[Film HD HU]',
    '[nCore][hd]': '[Film HD EN]',
    '[nCore][xvid_hun]': '[Film SD HU]',
    '[nCore][xvid]': '[Film SD EN]',
    
    '[nCore][hdser_hun]': '[Sorozat HD HU]',
    '[nCore][hdser]': '[Sorozat HD EN]',
    '[nCore][xvidser_hun]': '[Sorozat SD HU]',
    '[nCore][xvidser]': '[Sorozat SD EN]',
    
    '[nCore][mp3_hun]': '[Zene MP3 HU]',
    '[nCore][mp3]': '[Zene MP3 EN]',
    '[nCore][lossless_hun]': '[Zene LOSSL HU]',
    '[nCore][lossless]': '[Zene LOSSL EN]',
    '[nCore][clip]': '[Zene CLIP]',
    
    '[nCore][xxx_xvid]': '[XXX SD]',
    '[nCore][xxx_hd]': '[XXX HD]'
}

bookmark_map = {
    'hd_hun': 'Film HD HU',
    'hd': 'Film HD EN',
    'xvid_hun': 'Film SD HU',
    'xvid': 'Film SD EN',
    
    'hdser_hun': 'Sorozat HD HU',
    'hdser': 'Sorozat HD EN',
    'xvidser_hun': 'Sorozat SD HU',
    'xvidser': 'Sorozat SD EN',
    
    'mp3_hun': 'Zene MP3 HU',
    'mp3': 'Zene MP3 EN',
    'lossless_hun': 'Zene LOSSL HU',
    'lossless': 'Zene LOSSL EN',
    'clip': 'Zene CLIP',
    
    'xxx_xvid': 'XXX SD',
    'xxx_hd': 'XXX HD'
}

import socket
original_getaddrinfo = socket.getaddrinfo
def ipv4_only_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if 'ncore.pro' in str(host).lower():
        family = socket.AF_INET
    return original_getaddrinfo(host, port, family, type, proto, flags)
socket.getaddrinfo = ipv4_only_getaddrinfo