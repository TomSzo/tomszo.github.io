# -*- coding: utf-8 -*-
import os, sys, re, xbmc, xbmcgui, xbmcvfs, xbmcplugin, xbmcaddon, locale, base64, json, time
from urllib.parse import urlparse, quote, unquote, unquote_plus, quote_plus, parse_qs
from bs4 import BeautifulSoup
import requests, time, html
import urllib.parse
from datetime import datetime, timedelta
from xbmcvfs import translatePath
import xml.etree.ElementTree as ET
import pyxbmct
from pyxbmct import AddonDialogWindow, Label, List, Button, RadioButton

from .static_data import *
from resources.lib.indexers.github_sync import GitHubSyncManager

addon_id = 'plugin.video.nCore_TV'
addon = xbmcaddon.Addon(addon_id)
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

xxx_contents = addon.getSetting('show_xxx')

class ExtendedSearchWindow(AddonDialogWindow):
    def __init__(self, title="[B]Bővített Kereső:[/B]"):
        super(ExtendedSearchWindow, self).__init__(title)
        self.setGeometry(850, 600, 15, 12)
        self.setup_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def setup_controls(self):
        self.input_box_label = Label("  [B]Írd ide a szöveget, ha kell: [/B]")
        self.placeControl(self.input_box_label, row=0, column=0, columnspan=12)
        
        self.input_box = Button("")
        self.placeControl(self.input_box, row=0, column=0, columnspan=12)
        self.connect(self.input_box, self.on_input)

        self.instruction_label = Label("[COLOR gold]Navigálás: ↓ ↑ ← → | Ok/Enter = kiválasztás[/COLOR]")
        self.placeControl(self.instruction_label, row=1, column=0, columnspan=12)

        self.radio_options = {
            'Sorozat:': 'nyit_sorozat_resz=true',
            'Film:': 'nyit_filmek_resz=true',
            'Zene:': 'nyit_zene_resz=true',
        }
        if xxx_contents == 'true':
            self.radio_options['XXX:'] = 'nyit_xxx_resz=true'
        
        col = 0
        for option in self.radio_options.keys():
            lbl = Label(option)
            self.placeControl(lbl, row=2, column=col, columnspan=3)
            col += 3

        self.radio_buttons = []
        self.radio_state = {}
        col = 0
        for option, value in self.radio_options.items():
            rb = RadioButton("Ki")
            self.placeControl(rb, row=3, column=col, columnspan=2)
            self.connect(rb, lambda r=rb: self.radio_changed(r))
            self.radio_buttons.append((rb, option, value))
            self.radio_state[id(rb)] = False
            col += 3
        self.selected_radio_values = []

        self.left_title = Label("[B][COLOR lightblue]'Miben' keresés:[/COLOR][/B]")
        self.placeControl(self.left_title, row=4, column=0, columnspan=4)
        self.cat_title = Label("[B][COLOR lightyellow]Kategóriák: (opcionális)[/COLOR][/B]")
        self.placeControl(self.cat_title, row=4, column=4, columnspan=4)
        self.right_title = Label("[B][COLOR lightgreen]     Típusok:[/COLOR][/B]")
        self.placeControl(self.right_title, row=4, column=8, columnspan=4)

        self.left_list = List()
        self.placeControl(self.left_list, row=5, column=0, rowspan=6, columnspan=4)
        self.left_items = {
            'Címben': 'name',
            'Leírásban': 'leiras',
            'IMDb': 'imdb',
            'Feltöltő nevére': 'uploaded_by_nev',
            'Címke': 'cimke'
        }
        self.left_keys = list(self.left_items.keys())
        self.left_list.addItems(self.left_keys)
        self.left_locked_index = None
        self.connect(self.left_list, self.lock_left)

        self.category_list = List()
        self.placeControl(self.category_list, row=5, column=4, rowspan=6, columnspan=4)
        self.categories = ["vígjáték", "dráma", "életrajz", "akció", "romantikus", "dokumentumfilm", "kaland", 
                            "animáció", "thriller", "családi", "bűnügyi", "rövidfilm", "musical", "sci-fi",
                            "misztikus", "háborús", "western", "horror", "történelmi", "sport", "zene",
                            "ismeretterjesztő", "valóságshow", "3D", "fantasy"]
        self.category_list.addItems(self.categories)
        self.selected_categories = []
        self.connect(self.category_list, self.toggle_category)

        self.right_list = List()
        self.placeControl(self.right_list, row=5, column=8, rowspan=6, columnspan=4)
        self.right_items = {
            'Film (HUN SD)': 'xvid_hun',
            'Film (ENG SD)': 'xvid',
            'Film (HUN HD)': 'hd_hun',
            'Film (ENG HD)': 'hd',
            'Sorozat (HUN SD)': 'xvidser_hun',
            'Sorozat (ENG SD)': 'xvidser',
            'Sorozat (HUN HD)': 'hdser_hun',
            'Sorozat (ENG HD)': 'hdser',
            'Mp3 (HUN)': 'mp3_hun',
            'Mp3 (ENG)': 'mp3',
            'Lossless (HUN)': 'lossless_hun',
            'Lossless (ENG)': 'lossless',
            'Klip': 'clip',
        }
        
        if xxx_contents == 'true':
            self.right_items['XXX (SD)'] = 'xxx_xvid'
            self.right_items['XXX (HD)'] = 'xxx_hd'
        
        self.right_keys = list(self.right_items.keys())
        self.right_list.addItems(self.right_keys)
        self.selected_right = []
        self.connect(self.right_list, self.toggle_right)

        self.ok_button = Button("[B]OK[/B]")
        self.placeControl(self.ok_button, row=11, column=4, columnspan=4)
        self.connect(self.ok_button, self.on_ok)

        self.status_label = Label("")
        self.placeControl(self.status_label, row=12, column=0, columnspan=12)

    def set_navigation(self):
        self.input_box.controlDown(self.radio_buttons[0][0])
        for i, (rb, option, value) in enumerate(self.radio_buttons):
            if i > 0:
                rb.controlLeft(self.radio_buttons[i-1][0])
            if i < len(self.radio_buttons)-1:
                rb.controlRight(self.radio_buttons[i+1][0])
            rb.controlUp(self.input_box)
            rb.controlDown(self.left_list)
        self.left_list.controlUp(self.radio_buttons[0][0])
        self.left_list.controlRight(self.category_list)
        self.left_list.controlDown(self.ok_button)
        self.category_list.controlUp(self.radio_buttons[0][0])
        self.category_list.controlLeft(self.left_list)
        self.category_list.controlRight(self.right_list)
        self.category_list.controlDown(self.ok_button)
        self.right_list.controlUp(self.radio_buttons[0][0])
        self.right_list.controlLeft(self.category_list)
        self.right_list.controlDown(self.ok_button)
        self.ok_button.controlUp(self.left_list)
        self.ok_button.controlDown(self.input_box)
        self.setFocus(self.input_box)

    def on_input(self):
        kb = xbmc.Keyboard('', '')
        kb.doModal()
        if kb.isConfirmed():
            text = kb.getText()
            self.input_box.setLabel(text)
            self.status_label.setLabel(f"keresés: {text}")
            #xbmc.log(f"keresés: {text}", xbmc.LOGINFO)
        self.setFocus(self.input_box)

    def lock_left(self):
        pos = self.left_list.getSelectedPosition()
        item = self.left_list.getListItem(pos)
        new_label = f"[COLOR FFF56C00]{self.strip_color_tags(item.getLabel())}[/COLOR]"
        item.setLabel(new_label)
        self.left_locked_index = pos
        self.status_label.setLabel(f"Kiválasztva: {self.strip_color_tags(item.getLabel())}")
        #xbmc.log(f"Left locked: {self.strip_color_tags(item.getLabel())} -> {self.left_items.get(self.strip_color_tags(item.getLabel()))}", xbmc.LOGINFO)

    def toggle_right(self):
        pos = self.right_list.getSelectedPosition()
        item = self.right_list.getListItem(pos)
        label = self.strip_color_tags(item.getLabel())
        if label in self.selected_right:
            item.setLabel(label)
            self.selected_right.remove(label)
            self.status_label.setLabel(f"Típus Leválasztva: {label}")
        else:
            item.setLabel(f"[COLOR FFF56C00]{label}[/COLOR]")
            self.selected_right.append(label)
            self.status_label.setLabel(f"Típus Kiválasztva: {label}")
        #xbmc.log(f"Toggled right list: {label}", xbmc.LOGINFO)

    def radio_changed(self, rb):
        state = self.radio_state[id(rb)]
        self.radio_state[id(rb)] = not state
        if self.radio_state[id(rb)]:
            rb.setLabel("Be")
        else:
            rb.setLabel("Ki")
        self.selected_radio_values = []
        for r, option, value in self.radio_buttons:
            if self.radio_state[id(r)]:
                self.selected_radio_values.append(value)
        #xbmc.log(f"Radio selection: {self.selected_radio_values}", xbmc.LOGINFO)

    def toggle_category(self):
        pos = self.category_list.getSelectedPosition()
        item = self.category_list.getListItem(pos)
        label = self.strip_color_tags(item.getLabel())
        if label in self.selected_categories:
            item.setLabel(label)
            self.selected_categories.remove(label)
            self.status_label.setLabel(f"Kategória Leválasztva: {label}")
        else:
            item.setLabel(f"[COLOR FFF56C00]{label}[/COLOR]")
            self.selected_categories.append(label)
            self.status_label.setLabel(f"Kategória Kiválasztva: {label}")
        #xbmc.log(f"Toggled category: {label}", xbmc.LOGINFO)

    def strip_color_tags(self, text):
        return re.sub(r'\[/?COLOR.*?\]', '', text)

    def on_ok(self):
        from resources.lib.indexers.navigator import navigator 

        if self.left_locked_index is not None:
            left_index = self.left_locked_index
        else:
            left_index = self.left_list.getSelectedPosition()
        left_item = self.left_list.getListItem(left_index)
        left_label = self.strip_color_tags(left_item.getLabel())
        left_value = self.left_items.get(left_label)

        if self.selected_right:
            right_labels = []
            right_values = []
            for label in self.selected_right:
                right_labels.append(label)
                right_values.append(self.right_items.get(label))
            right_params = "".join(f"&kivalasztott_tipus%5B%5D={value}" for value in right_values)
        else:
            pos = self.right_list.getSelectedPosition()
            item = self.right_list.getListItem(pos)
            right_label = self.strip_color_tags(item.getLabel())
            right_value = self.right_items.get(right_label)
            right_params = f"&kivalasztott_tipus%5B%5D={right_value}"

        if self.selected_categories:
            tags = "%2C+".join(self.selected_categories) if len(self.selected_categories) > 1 else self.selected_categories[0]
            tags_param = f"tags={tags}"
        else:
            tags_param = ""

        input_text = self.input_box.getLabel()
        input_text_url = input_text.replace(" ", "+")

        radio_params = "&".join(self.selected_radio_values) if self.selected_radio_values else ""

        final_link = (f"https://ncore.pro/torrents.php?"
                            f"{radio_params}{right_params}&mire={input_text_url}&miben={left_value}")
        if radio_params:
            final_link += "&tipus=kivalasztottak_kozott"
        if tags_param:
            final_link += f"&{tags_param}"

        xbmcgui.Window(10000).setProperty('nCore_LastSearchUrl', final_link)

        self.close()

        xbmc.sleep(300)

        nav_instance = navigator()
        nav_instance.params = {}
        nav_instance.getItems(final_link)