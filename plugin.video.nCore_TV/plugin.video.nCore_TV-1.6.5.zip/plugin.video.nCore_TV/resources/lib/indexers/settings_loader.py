# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import sys
import os
import xbmcvfs

addon_id = 'plugin.video.nCore_TV'
addon = xbmcaddon.Addon(id=addon_id)
addon_name = addon.getAddonInfo('name')

def log(msg):
    xbmc.log(f"[{addon_name}] settings_loader: {msg}", xbmc.LOGINFO)

def get_params():
    try:
        params_string = sys.argv[1]
        params = dict(param.split('=') for param in params_string.split('&'))
        return params
    except IndexError:
        #log("No parameters provided to settings_loader.py (IndexError).", xbmc.LOGERROR)
        return {}
    except Exception as e:
        #log(f"Error parsing parameters in get_params(): {e}", xbmc.LOGERROR)
        return {}

def load_settings_from_file(load_type):
    dialog = xbmcgui.Dialog()

    if load_type == "login":
        heading_msg = "Válaszd ki a bejelentkezési adatok fájlt (.txt)"
        mask_filter = ".txt"
        expected_settings = ["username", "password"]
    elif load_type == "github":
        heading_msg = "Válaszd ki a GitHub adatok fájlt (.txt)"
        mask_filter = ".txt"
        expected_settings = ["github_owner", "github_pat", "github_repo"]
    elif load_type == "test_file":
        heading_msg = "Válaszd ki a Teszt fájlt (.txt)"
        mask_filter = ".txt"
        expected_settings = "test"
    else:
        #log(f"Unknown load_type: {load_type}")
        dialog.notification(addon_name, "Ismeretlen beállítás típus.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    file_path = dialog.browse(
        type=1,
        heading=heading_msg,
        shares="files",
        mask=mask_filter,
        defaultt=""
    )

    if not file_path:
        #log("No file selected.")
        dialog.notification(addon_name, "Nincs fájl kiválasztva.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    if not os.path.exists(file_path):
        #log(f"File does not exist: {file_path}")
        dialog.notification(addon_name, "A fájl nem létezik.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        settings_to_update = {}
        skipped_lines_count = 0

        for line in lines:
            line = line.strip()
            if not line:
                continue
            if '=' not in line:
                skipped_lines_count += 1
                continue

            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip()

            if key in expected_settings:
                settings_to_update[key] = value
            else:
                #log(f"Skipping unexpected setting in file: {key}")
                skipped_lines_count += 1

        if not settings_to_update:
            dialog.notification(addon_name, "Nem található érvényes beállítás a fájlban.", xbmcgui.NOTIFICATION_WARNING, 4000)
            return

        for setting_id, setting_value in settings_to_update.items():
            addon.setSetting(setting_id, setting_value)
            #log(f"Set setting: {setting_id} = {setting_value}")

        if skipped_lines_count > 0:
            dialog.notification(addon_name, f"{load_type.capitalize()} beállítások betöltve.", xbmcgui.NOTIFICATION_INFO, 7000)
        else:
            dialog.notification(addon_name, f"{load_type.capitalize()} beállítások sikeresen betöltve!", xbmcgui.NOTIFICATION_INFO, 5000)

    except Exception as e:
        #log(f"Error loading settings file: {e}", xbmc.LOGERROR)
        dialog.notification(addon_name, f"Hiba a beállítások betöltésekor: {e}", xbmcgui.NOTIFICATION_ERROR, 7000)

if __name__ == '__main__':
    params = get_params()
    load_type = params.get('load_type')
    if load_type:
        load_settings_from_file(load_type)
    else:
        #log("No 'load_type' parameter provided when settings_loader.py was called.", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(addon_name, "Hiányzó 'load_type' paraméter.", xbmcgui.NOTIFICATION_ERROR, 3000)