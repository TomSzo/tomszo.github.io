# -*- coding: utf-8 -*-
import os, sys, re, xbmc, xbmcgui, xbmcvfs, xbmcplugin, xbmcaddon, json, time, threading, uuid
import requests
import pyxbmct
from pyxbmct import AddonDialogWindow, Label, Button
from .static_data import *

import traceback
import xml.etree.ElementTree as ET

addon_id = 'plugin.video.nCore_TV'
profile_path = xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile'))
plex_status_cache = os.path.join(profile_path, 'plex_status_list.json')
plex_id_map_file = os.path.join(profile_path, 'plex_id_map.json')

try:
    from .static_data import global_write_lock
except:
    global_write_lock = threading.Lock()

class PlexInterface(AddonDialogWindow):
    def __init__(self, title='[B]Plex.tv Hitelesítés[/B]'):
        super(PlexInterface, self).__init__(title)
        self.setGeometry(550, 400, 10, 4)

        myself = xbmcaddon.Addon(addon_id)
        self.client_id = myself.getSetting('plex_client_id')
        if not self.client_id or self.client_id == "":
            self.client_id = str(uuid.uuid4())
            myself.setSetting('plex_client_id', self.client_id)

        self.setup_ui()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    _cached_server_uri = None
    _cached_section_map = None


    def get_generic_headers(self):
        return {
            'X-Plex-Product': 'MediaCenter_Kodi',
            'X-Plex-Version': '1.0.0',
            'X-Plex-Client-Identifier': self.client_id,
            'X-Plex-Device': 'Kodi_Box',
            'X-Plex-Platform': 'Kodi',
            'Accept': 'application/json'
        }

    def setup_ui(self):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('plex_token')
        plex_user = myself.getSetting('plex_username')
        
        is_auth = token and token.strip() != "" and token != "None"
        status_color = 'lime' if is_auth else 'red'
        status_text = f'Hitelesített ([B]{plex_user}[/B])' if (is_auth and plex_user) else 'Hitelesített' if is_auth else 'Nem hitelesített'
        
        self.status_label = Label(f'Állapot: [COLOR {status_color}]{status_text}[/COLOR]')
        self.placeControl(self.status_label, 0, 0, 1, 4)
        
        self.auth_btn = Button('Engedélyezés [Plex.tv] (eszközkód)')
        self.placeControl(self.auth_btn, 2, 0, 1, 4)
        self.connect(self.auth_btn, self.start_auth)
        
        self.revoke_btn = Button('Engedély visszavonása')
        self.placeControl(self.revoke_btn, 4, 0, 1, 4)
        self.connect(self.revoke_btn, self.revoke_access)
        
        self.close_btn = Button('Vissza')
        self.placeControl(self.close_btn, 9, 0, 1, 4)
        self.connect(self.close_btn, self.close)
        
        self.buttons = [self.auth_btn, self.revoke_btn, self.close_btn]
        for i in range(len(self.buttons)):
            self.buttons[i].controlUp(self.buttons[(i - 1) % len(self.buttons)])
            self.buttons[i].controlDown(self.buttons[(i + 1) % len(self.buttons)])
        self.setFocus(self.auth_btn)

    def start_auth(self):
        xbmc.log("[Plex_DEBUG] PIN keres inditasa (auth_token fix)...", xbmc.LOGINFO)
        
        url = "https://plex.tv/pins.json"
        headers = self.get_generic_headers()
        
        try:
            r = requests.post(url, headers=headers, timeout=15)
            if r.status_code not in [200, 201]:
                xbmc.log(f"[Plex_DEBUG] POST hiba: {r.status_code}", xbmc.LOGERROR)
                return

            data = r.json()
            pin_data = data.get('pin', data)
            pin_id = pin_data.get('id')
            user_code = pin_data.get('code')

            if not user_code:
                xbmc.log("[Plex_DEBUG] Nincs 'code' a valaszban!", xbmc.LOGERROR)
                return

            msg = (f"Böngészőben: [B]plex.tv/link[/B]\n"
                   f"Kód: [COLOR yellow][B]{user_code}[/B][/COLOR]\n"
                   "Várakozás a visszaigazolásra...")
            
            prog = xbmcgui.DialogProgress()
            prog.create("Plex.tv Hitelesítés", msg)

            check_url = f"https://plex.tv/pins/{pin_id}.json"
            start = time.time()
            while time.time() - start < 600:
                if prog.iscanceled(): break
                prog.update(int(((time.time() - start) / 600) * 100), msg)
                
                res = requests.get(check_url, headers=headers, timeout=15)
                if res.status_code == 200:
                    auth_data = res.json()
                    pin_info = auth_data.get('pin', auth_data)

                    token = pin_info.get('auth_token') or pin_info.get('authToken')
                    
                    if token:
                        #xbmc.log(f"[Plex_DEBUG] Token megerkezett: {token[:5]}...", xbmc.LOGINFO)

                        u_headers = self.get_generic_headers()
                        u_headers['X-Plex-Token'] = token
                        u_res = requests.get("https://plex.tv/api/v2/user", headers=u_headers, timeout=10)
                        
                        user_name = "Plex Felhasználó"
                        if u_res.status_code == 200:
                            user_name = u_res.json().get('username', 'Plex User')

                        track_event("logins", "Auth: Plex", "Plex service authorized for watch history tracking.", icon="🎬")

                        myself = xbmcaddon.Addon(addon_id)
                        myself.setSetting('plex_token', str(token))
                        myself.setSetting('plex_username', str(user_name))
                        myself.setSetting('plex_enabled', 'true')
                        
                        prog.close()
                        xbmcgui.Dialog().ok("Plex.tv", f"Sikeres párosítás!\nFelhasználó: [B]{user_name}[/B]")
                        self.status_label.setLabel(f'Állapot: [COLOR lime]Hitelesített ([B]{user_name}[/B])[/COLOR]')
                        return
                
                xbmc.sleep(5000)
            prog.close()
            
        except Exception as e:
            xbmc.log(f"[Plex_DEBUG] Hiba: {str(e)}", xbmc.LOGERROR)

    def revoke_access(self):
        if xbmcgui.Dialog().yesno("Plex.tv", "Biztos vagy benne?"):
            myself = xbmcaddon.Addon(addon_id)
            myself.setSetting('plex_token', '')
            myself.setSetting('plex_username', '')
            myself.setSetting('plex_enabled', 'false')
            self.status_label.setLabel('Állapot: [COLOR red]Nem hitelesített[/COLOR]')

    @staticmethod
    def _log(msg, level=xbmc.LOGINFO):
        xbmc.log(f"[nCore_Plex_DEBUG] {msg}", level)

    @staticmethod
    def _quick_cache_save(imdb_id, val):
        with global_write_lock: 
            try:
                current_cache = {}
                if os.path.exists(plex_status_cache):
                    try:
                        with open(plex_status_cache, 'r', encoding='utf-8') as f:
                            current_cache = json.load(f)
                    except: pass
                
                current_cache[imdb_id] = val
                
                temporary_file = plex_status_cache + ".tmp"
                with open(temporary_file, 'w', encoding='utf-8') as f:
                    json.dump(current_cache, f, indent=2, ensure_ascii=False)
                    f.flush()
                    os.fsync(f.fileno())
                
                if sys.platform == "win32" and os.path.exists(plex_status_cache):
                    os.remove(plex_status_cache)
                os.rename(temporary_file, plex_status_cache)
            except Exception as e:
                xbmc.log(f"[nCore_TV Plex Cache] Hiba: {e}", xbmc.LOGERROR)

    @staticmethod
    def get_plex_playback():
        #PlexInterface._log("==== PLEX_PLAYBACK_DEBUG_START ====")
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('plex_token')
        client_id = myself.getSetting('plex_client_id')
        
        if not token: return None

        headers = {'X-Plex-Token': token, 'X-Plex-Client-Identifier': client_id, 'Accept': 'application/json'}
        server_uri, _ = PlexInterface.get_plex_connection_info()
        if not server_uri: return None

        show_id_cache = {}
        raw_results = []
        seen_imdb = set()

        endpoints = ["/library/onDeck", "/hubs/home/continueWatching"]
        
        for ep in endpoints:
            try:
                full_url = f"{server_uri}{ep}?includeGuids=1&X-Plex-Token={token}"
                #PlexInterface._log(f"API_CALL: {full_url}")
                
                r = requests.get(full_url, headers=headers, timeout=10, verify=False)
                #PlexInterface._log(f"API_RESPONSE_CODE: {r.status_code}")
                
                if r.status_code == 200:
                    data = r.json()

                    container = data.get('MediaContainer', {})
                    metadata = container.get('Metadata', [])
                    
                    if not metadata and 'Hub' in container:
                        for h in container['Hub']:
                            if h.get('type') == 'continueWatching':
                                metadata = h.get('Metadata', [])
                                break

                    if metadata:
                        #PlexInterface._log(f"DEBUG: Talált tételek száma: {len(metadata)}")
                        for item in metadata:
                            m_type = item.get('type')
                            rk = item.get('ratingKey')
                            title = item.get('title')
                            final_imdb_id = None
                            
                            if m_type == 'movie':
                                final_imdb_id = PlexInterface._get_id_from_guid(item.get('Guid', []), 'imdb')
                            elif m_type == 'episode':
                                gp_key = item.get('grandparentRatingKey')
                                if gp_key in show_id_cache:
                                    final_imdb_id = show_id_cache[gp_key]
                                else:
                                    show_url = f"{server_uri}/library/metadata/{gp_key}?includeGuids=1&X-Plex-Token={token}"
                                    rs = requests.get(show_url, headers=headers, timeout=5, verify=False)
                                    if rs.status_code == 200:
                                        s_data = rs.json().get('MediaContainer', {}).get('Metadata', [{}])[0]
                                        final_imdb_id = PlexInterface._get_id_from_guid(s_data.get('Guid', []), 'imdb')
                                        if final_imdb_id: show_id_cache[gp_key] = final_imdb_id

                            if final_imdb_id and final_imdb_id not in seen_imdb:
                                seen_imdb.add(final_imdb_id)
                                offset = float(item.get('viewOffset', 0))
                                duration = float(item.get('duration', 1))
                                pct = (offset / duration) * 100
                                
                                #PlexInterface._log(f"ITEM_ADD: '{title}' | IMDb: {final_imdb_id} | Progress: {int(pct)}%")
                                
                                raw_results.append({
                                    'imdb_id': final_imdb_id,
                                    'title': title,
                                    'type': m_type,
                                    'year': item.get('year'),
                                    'summary': item.get('summary', ''),
                                    'progress': pct,
                                    'thumb': item.get('thumb'),
                                    'grandparentTitle': item.get('grandparentTitle'),
                                    'parentIndex': item.get('parentIndex'),
                                    'index': item.get('index'),
                                    'server_uri': server_uri
                                })
                        
                        if raw_results:
                            #PlexInterface._log(f"KÉSZ: {len(raw_results)} tétel visszaadva.")
                            return raw_results
            except:
                #PlexInterface._log(f"HIBA az endpoint ({ep}) hívásakor.")
                continue

        #PlexInterface._log("VÉGE: Nem találtam félbehagyott tartalmat.")
        return None

    @staticmethod
    def _extract_imdb_id(guid_list):
        if not guid_list: return None
        for g in guid_list:
            id_str = g.get('id', '')
            if 'imdb://' in id_str:
                return id_str.split('imdb://')[1].split('?')[0]
        return None

    @staticmethod
    def _format_plex_items(metadata_list):
        formatted_list = []
        for item in metadata_list:
            imdb_id = PlexInterface._extract_imdb_id(item.get('Guid'))

            if not imdb_id:
                g_str = item.get('guid', '')
                if 'imdb://' in g_str:
                    imdb_id = g_str.split('imdb://')[1].split('?')[0]

            if imdb_id:
                formatted_list.append({
                    'type': 'movie' if item.get('type') == 'movie' else 'episode',
                    'progress': (float(item.get('viewOffset', 0)) / float(item.get('duration', 1))) * 100 if item.get('duration') else 0,
                    'movie': {'title': item.get('title'), 'year': item.get('year'), 'ids': {'imdb': imdb_id}},
                    'show': {'title': item.get('grandparentTitle') or item.get('title'), 'ids': {'imdb': imdb_id}},
                    'episode': {'season': item.get('parentIndex'), 'number': item.get('index'), 'title': item.get('title')}
                })
        return formatted_list

    @staticmethod
    def _extract_imdb_id(guid_list):
        for g in guid_list:
            id_str = g.get('id', '')
            if id_str.startswith('imdb://'):
                return id_str.replace('imdb://', '')
        return None

    @staticmethod
    def get_plex_watchlist(media_type='movie'):
        token = addon.getSetting('plex_token')
        client_id = addon.getSetting('plex_client_id')
        if not token: return None
    
        url = "https://discover.provider.plex.tv/library/sections/watchlist/all"

        if media_type == 'all':
            p_type = "99"
        elif media_type == 'movie':
            p_type = "1"
        else:
            p_type = "2"
        
        params = {
            "type": p_type,
            "includeGuids": "1",
            "includeAdvanced": "1",
            "includeMeta": "1",
            "X-Plex-Token": token,
            "X-Plex-Client-Identifier": client_id,
            "X-Plex-Container-Start": 0,
            "X-Plex-Container-Size": 50
        }
    
        headers = {
            "Accept": "application/json",
            "X-Plex-Product": "Plex for Kodi",
            "X-Plex-Platform": "Kodi",
            "X-Plex-Version": "1.0.0",
            "X-Plex-Device": "Kodi_Box",
            "X-Plex-Language": "hu",
            "Accept-Language": "hu"
        }
    
        all_items = []
    
        try:
            r = requests.get(url, params=params, headers=headers, timeout=15)
            if r.status_code == 200 and r.text.strip():
                data = r.json().get('MediaContainer', {})
                metadata = data.get('Metadata', [])
                
                for item in metadata:
                    imdb_id = PlexInterface._get_id_from_guid(item.get('Guid', []), 'imdb')
                    if not imdb_id:
                        main_g = item.get('guid', '')
                        if 'imdb://' in main_g: 
                            imdb_id = main_g.split('imdb://')[1].split('?')[0]
    
                    if imdb_id:
                        item_type = item.get('type', media_type)
                        
                        all_items.append({
                            'imdb_id': imdb_id,
                            'title': item.get('title'),
                            'type': item_type,
                            'year': item.get('year'),
                            'summary': item.get('summary', ''),
                            'tagline': item.get('tagline', ''),
                            'last_ep': "[COLOR yellow]Listán[/COLOR]",
                            'server_uri': "", 
                            'thumb': item.get('thumb', '')
                        })
                
                PlexInterface._log(f"SIKER: {len(all_items)} elem beolvasva (type={p_type}).")
    
        except Exception as e:
            PlexInterface._log(f"ERROR: {str(e)}", xbmc.LOGERROR)
    
        return all_items

    @staticmethod
    def get_plex_info(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('plex_token')
        if not token or token in ["", "None"] or not imdb_id: return None

        if os.path.exists(plex_status_cache):
            try:
                with open(plex_status_cache, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                    if imdb_id in cache: return cache[imdb_id]
            except: pass

        try:
            items = PlexInterface.get_plex_library_items(filter_watched=True)
            if items:
                for item in items:
                    if item['imdb_id'] == imdb_id:
                        if item['type'] == 'movie':
                            res = "[B][COLOR dodgerblue]Plex:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                        else:
                            res = f"[B][COLOR dodgerblue]Plex utoljára:[/COLOR][/B] {item.get('last_ep')}"
                        
                        PlexInterface._quick_cache_save(imdb_id, res)
                        return res
        except: pass
        return None

    @staticmethod
    def _fetch_deep_imdb_id(server_uri, rating_key, token):
        try:
            url = f"{server_uri}/library/metadata/{rating_key}?includeGuids=1&X-Plex-Token={token}"
            r = requests.get(url, timeout=5, verify=False)
            if r.status_code == 200:
                meta = r.json().get('MediaContainer', {}).get('Metadata', [{}])[0]
                return PlexInterface._get_id_from_guid(meta.get('Guid', []), 'imdb')
        except: pass
        return None

    @staticmethod
    def get_plex_connection_info(force_refresh=False):
        if not force_refresh and hasattr(PlexInterface, '_cached_server_uri') and PlexInterface._cached_server_uri:
            return PlexInterface._cached_server_uri, PlexInterface._cached_section_map

        #PlexInterface._log("DEBUG: get_plex_connection_info indítása (Univerzális verzió)")
        try:
            token = addon.getSetting('plex_token')
            client_id = addon.getSetting('plex_client_id')
            headers = {'X-Plex-Token': token, 'X-Plex-Client-Identifier': client_id, 'Accept': 'application/json'}

            res_url = f"https://plex.tv/api/resources?includeHttps=1&X-Plex-Token={token}"
            #PlexInterface._log(f"DEBUG: Szerver lista lekérése -> {res_url}")
            r_res = requests.get(res_url, timeout=10)
            
            if r_res.status_code != 200:
                #PlexInterface._log(f"HIBA: Plex.tv válasz kód: {r_res.status_code}")
                return None, {}

            import xml.etree.ElementTree as ET
            root = ET.fromstring(r_res.text)
            server_uri = None
            
            devices = root.findall('Device')
            PlexInterface._log(f"DEBUG: {len(devices)} eszközt találtam a fiókodban.")

            for device in devices:
                provides = device.get('provides', '')
                if "server" in provides:
                    s_name = device.get('name')
                    pub_ip = device.get('publicAddress')
                    #PlexInterface._log(f"DEBUG: Szerver vizsgálata: '{s_name}' (Publikus IP: {pub_ip})")
                    
                    connections = device.findall('Connection')
                    for conn in connections:
                        uri = conn.get('uri')
                        address = conn.get('address')
                        port = conn.get('port')
                        is_local = conn.get('local') == '1'
                        type_label = "HELYI" if is_local else "TÁVOLI/RELAY"
                        
                        #PlexInterface._log(f"DEBUG: Kapcsolat próbálása ({type_label}): {address}:{port}")

                        #PlexInterface._log(f" -> Próba 1 (Secure URI): {uri}")
                        try:
                            check = requests.get(f"{uri}/", headers=headers, timeout=3, verify=False)
                            if check.status_code == 200:
                                server_uri = uri
                                #PlexInterface._log(f" -> SIKER: Kapcsolódva ezen: {uri}")
                                break
                        except:
                            PlexInterface._log(" -> INFO: Secure URI nem elérhető (DNS hiba vagy tűzfal).")

                        fallback_url = f"http://{address}:{port}"
                        #PlexInterface._log(f" -> Próba 2 (IP Fallback): {fallback_url}")
                        try:
                            check = requests.get(f"{fallback_url}/", headers=headers, timeout=3, verify=False)
                            if check.status_code == 200:
                                server_uri = fallback_url
                                #PlexInterface._log(f" -> SIKER: Kapcsolódva nyers IP-vel!")
                                break
                        except:
                            PlexInterface._log(" -> INFO: IP Fallback is sikertelen.")
                            
                    if server_uri: break
            
            if not server_uri:
                PlexInterface._log("HIBA: Egyetlen kapcsolati útvonal sem működött!", xbmc.LOGERROR)
                return None, {}

            #PlexInterface._log(f"DEBUG: Szekciók beolvasása innen: {server_uri}")
            r_sec = requests.get(f"{server_uri}/library/sections?X-Plex-Token={token}", headers=headers, timeout=5, verify=False)
            section_map = {'movie': [], 'show': []}
            if r_sec.status_code == 200:
                data = r_sec.json()
                for s in data.get('MediaContainer', {}).get('Directory', []):
                    stype = s.get('type')
                    if stype in section_map:
                        section_map[stype].append(s.get('key'))
                        #PlexInterface._log(f" -> Szekció regisztrálva: {s.get('title')} (ID:{s.get('key')})")

            PlexInterface._cached_server_uri = server_uri
            PlexInterface._cached_section_map = section_map
            return server_uri, section_map

        except Exception:
            import traceback
            PlexInterface._log(f"EXC: {traceback.format_exc()}", xbmc.LOGERROR)
            return None, {}


    @staticmethod
    def sync_full_plex_history(return_data=False):
        if hasattr(PlexInterface, '_is_syncing') and PlexInterface._is_syncing: return False
        PlexInterface._is_syncing = True
        
        try:
            server_uri, section_map = PlexInterface.get_plex_connection_info(force_refresh=True)
            if not server_uri: 
                PlexInterface._is_syncing = False
                return False

            new_watched_data = {}
            new_id_map = {}

            for w_type in ['movie', 'show']:
                w_items = PlexInterface.get_plex_watchlist(media_type=w_type)
                if w_items:
                    for item in w_items:
                        imdb = item['imdb_id']
                        new_watched_data[imdb] = "[B][COLOR dodgerblue]Plex:[/COLOR] [COLOR yellow]Listán[/COLOR][/B]"

            for m_type in ['movie', 'show']:
                items = PlexInterface.get_plex_library_items(media_type=m_type, filter_watched=False)
                if items:
                    for item in items:
                        imdb = item.get('imdb_id')
                        rk = item.get('rk')
                        if imdb and rk:
                            new_id_map[imdb] = rk
                            if item.get('last_viewed', 0) > 0 or item.get('last_ep'):
                                if m_type == 'movie':
                                    new_watched_data[imdb] = "[B][COLOR dodgerblue]Plex:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                                else:
                                    new_watched_data[imdb] = f"[B][COLOR dodgerblue]Plex utoljára:[/COLOR][/B] {item.get('last_ep')}"

            PlexInterface._is_syncing = False
            
            if return_data:
                return new_watched_data, new_id_map
            
            return True
        except:
            PlexInterface._is_syncing = False
            return False

    @staticmethod
    def get_plex_library_items(media_type='movie', filter_watched=True):
        token = addon.getSetting('plex_token')
        client_id = addon.getSetting('plex_client_id')
        server_uri, section_map = PlexInterface.get_plex_connection_info()
        
        if not server_uri or not section_map.get(media_type): return None

        session = requests.Session()
        session.verify = False
        session.headers.update({'X-Plex-Token': token, 'X-Plex-Client-Identifier': client_id, 'Accept': 'application/json'})

        all_items = []
        seen_imdb = set()
        last_ep_map = {} 
        p_type = "2" if media_type == 'show' else "1"

        for s_id in section_map[media_type]:
            if media_type == 'show':
                try:
                    e_url = f"{server_uri}/library/sections/{s_id}/all?type=4&viewCount>=1&includeGuids=1&X-Plex-Container-Start=0&X-Plex-Container-Size=4000"
                    r_eps = session.get(e_url, timeout=15)
                    if r_eps.status_code == 200:
                        eps_data = r_eps.json().get('MediaContainer', {}).get('Metadata', [])
                        for ep in eps_data:
                            g_rk = ep.get('grandparentRatingKey')
                            if not g_rk: continue
                            s_num, e_num = int(ep.get('parentIndex', 0)), int(ep.get('index', 0))
                            if g_rk not in last_ep_map:
                                last_ep_map[g_rk] = (s_num, e_num)
                            else:
                                old_s, old_e = last_ep_map[g_rk]
                                if (s_num > old_s) or (s_num == old_s and e_num > old_e):
                                    last_ep_map[g_rk] = (s_num, e_num)
                except: pass

            start, size = 0, 150
            while True:
                url = f"{server_uri}/library/sections/{s_id}/all?type={p_type}&X-Plex-Container-Start={start}&X-Plex-Container-Size={size}&includeGuids=1"
                try:
                    r = session.get(url, timeout=15)
                    if r.status_code != 200: break
                    data = r.json().get('MediaContainer', {})
                    metadata = data.get('Metadata', [])
                    if not metadata: break

                    for item in metadata:
                        rk = item.get('ratingKey')
                        last_v = item.get('lastViewedAt')
                        v_count = int(item.get('viewedLeafCount', 0)) if media_type == 'show' else int(item.get('viewCount', 0))

                        if filter_watched and v_count == 0 and last_v is None: continue

                        imdb_id = PlexInterface._get_id_from_guid(item.get('Guid', []), 'imdb')
                        if not imdb_id:
                            main_g = item.get('guid', '')
                            if 'imdb://' in main_g: imdb_id = main_g.split('imdb://')[1].split('?')[0]
                        
                        if imdb_id and imdb_id not in seen_imdb:
                            seen_imdb.add(imdb_id)
                            display_ep = ""
                            if media_type == 'show' and rk in last_ep_map:
                                s, e = last_ep_map[rk]
                                display_ep = f"S{s:02d}E{e:02d}"

                            all_items.append({
                                'imdb_id': imdb_id,
                                'rk': rk,
                                'title': item.get('title'),
                                'type': media_type,
                                'year': item.get('year'),
                                'summary': item.get('summary', ''),
                                'last_ep': display_ep,
                                'last_viewed': last_v if last_v else 0,
                                'server_uri': server_uri,
                                'thumb': item.get('thumb')
                            })
                    start += size
                    if start >= int(data.get('totalSize', 0)): break
                except: break

        all_items.sort(key=lambda x: x.get('last_viewed', 0), reverse=True)
        return all_items

    @staticmethod
    def _get_id_from_guid(guid_list, prefix):
        if not guid_list: return None
        for g in guid_list:
            val = g.get('id', '')
            if f"{prefix}://" in val:
                extracted = val.split(f"{prefix}://")[1].split('?')[0]
                return extracted
        return None

    @staticmethod
    def get_plex_history(page=1):
        buffer_size = 500 
        #PlexInterface._log(f"--- PLEX_HISTORY_WITH_HANNA_FIX (Oldal: {page}) ---")
        
        token = addon.getSetting('plex_token')
        client_id = addon.getSetting('plex_client_id')
        server_uri, section_map = PlexInterface.get_plex_connection_info()
        if not server_uri: return None

        session = requests.Session()
        session.verify = False
        headers = {'X-Plex-Token': token, 'X-Plex-Client-Identifier': client_id, 'Accept': 'application/json', 'X-Plex-Language': 'hu'}

        last_ep_map = {}
        if section_map.get('show'):
            for s_id in section_map['show']:
                try:
                    e_url = f"{server_uri}/library/sections/{s_id}/all?type=4&viewCount>=1&X-Plex-Container-Size=3000"
                    r_eps = session.get(e_url, headers=headers, timeout=15)
                    if r_eps.status_code == 200:
                        eps_data = r_eps.json().get('MediaContainer', {}).get('Metadata', [])
                        for ep in eps_data:
                            g_rk = ep.get('grandparentRatingKey')
                            if not g_rk: continue
                            s_num, e_num = int(ep.get('parentIndex', 0)), int(ep.get('index', 0))

                            if g_rk not in last_ep_map:
                                last_ep_map[g_rk] = (s_num, e_num)
                            else:
                                old_s, old_e = last_ep_map[g_rk]
                                if (s_num > old_s) or (s_num == old_s and e_num > old_e):
                                    last_ep_map[g_rk] = (s_num, e_num)
                except: pass

        start_offset = (page - 1) * buffer_size
        url = f"{server_uri}/library/all"
        params = {
            "sort": "lastViewedAt:desc",
            "X-Plex-Container-Start": start_offset,
            "X-Plex-Container-Size": buffer_size,
            "includeGuids": "1"
        }

        all_items = []
        seen_imdb = set()
        show_id_map = {}

        try:
            r = session.get(url, params=params, headers=headers, timeout=15)
            if r.status_code == 200:
                metadata = r.json().get('MediaContainer', {}).get('Metadata', [])
                
                for item in metadata:
                    m_type = item.get('type')
                    if m_type == 'season': continue 

                    rk = item.get('ratingKey')
                    last_v = item.get('lastViewedAt')
                    if last_v is None: continue

                    show_rk = rk if m_type in ['movie', 'show'] else item.get('grandparentRatingKey')
                    if not show_rk: continue

                    final_imdb_id = None
                    if show_rk in show_id_map:
                        final_imdb_id = show_id_map[show_rk]
                    else:
                        try:
                            s_url = f"{server_uri}/library/metadata/{show_rk}?includeGuids=1"
                            sr = session.get(s_url, headers=headers, timeout=3)
                            if sr.status_code == 200:
                                s_meta = sr.json().get('MediaContainer', {}).get('Metadata', [{}])[0]
                                final_imdb_id = PlexInterface._get_id_from_guid(s_meta.get('Guid', []), 'imdb')
                                if final_imdb_id: show_id_map[show_rk] = final_imdb_id
                        except: pass

                    if final_imdb_id:
                        if final_imdb_id in seen_imdb: continue
                        seen_imdb.add(final_imdb_id)

                        display_ep = ""
                        if show_rk in last_ep_map:
                            s, e = last_ep_map[show_rk]
                            display_ep = f"S{s:02d}E{e:02d}"
                        
                        try: year = int(item.get('year') or item.get('parentYear') or 0)
                        except: year = 0

                        all_items.append({
                            'imdb_id': final_imdb_id,
                            'title': item.get('grandparentTitle') or item.get('title') or "Ismeretlen",
                            'type': 'show' if m_type != 'movie' else 'movie',
                            'year': year,
                            'summary': item.get('summary', ''),
                            'last_ep': display_ep,
                            'last_viewed': last_v,
                            'server_uri': server_uri,
                            'thumb': item.get('thumb')
                        })

            #PlexInterface._log(f"HISTORY_HANNA_FIX_READY: {len(all_items)} egyedi elem.")
        except Exception:
            PlexInterface._log(f"HISTORY_FATAL:\n{traceback.format_exc()}", xbmc.LOGERROR)

        return all_items

    @staticmethod
    def _find_plex_rating_key(imdb_id, media_type='movie', season=None, episode=None):
        #PlexInterface._log(f"RK keresés indítása IMDb ID-ra: {imdb_id}")
        
        from resources.lib.indexers.database import DatabaseManager
        db_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile')), 'ncore_tv.db')
        db = DatabaseManager(db_path)
        
        rk = db.get_sync_id(imdb_id, 'plex')

        server_uri, _ = PlexInterface.get_plex_connection_info()
        token = xbmcaddon.Addon(addon_id).getSetting('plex_token')

        if not server_uri:
            #PlexInterface._log("HIBA: Nincs server_uri a Rating Key kereséshez.")
            return None

        if rk:
            #PlexInterface._log(f"SQL találat ellenőrzése a szerveren (RK: {rk})...")
            try:
                url = f"{server_uri}/library/metadata/{rk}?X-Plex-Token={token}"
                r = requests.get(url, timeout=3, verify=False)
                if r.status_code == 200:
                    #PlexInterface._log("RK érvényes.")
                    return PlexInterface._resolve_episode_if_needed(rk, season, episode, server_uri, token)
                else:
                    PlexInterface._log(f"Az SQL-ben lévő RK elavult (Kód: {r.status_code}).")
            except: 
                PlexInterface._log("Időtúllépés az RK ellenőrzésekor.")

        try:
            search_url = f"{server_uri}/search?query={imdb_id}&X-Plex-Token={token}"
            #PlexInterface._log(f"Fallback keresés indítása: {search_url.replace(token, 'TOKEN_HIDDEN')}")
            
            r = requests.get(search_url, headers={'Accept': 'application/json'}, timeout=5, verify=False)
            if r.status_code == 200:
                meta = r.json().get('MediaContainer', {}).get('Metadata', [])
                if meta:
                    new_rk = meta[0].get('ratingKey')
                    #PlexInterface._log(f"Új RK találva: {new_rk}")
                    return PlexInterface._resolve_episode_if_needed(new_rk, season, episode, server_uri, token)
                else:
                    PlexInterface._log(f"A Plex szerver nem találja ezt az IMDb ID-t: {imdb_id}")
        except Exception as e:
            PlexInterface._log(f"Fallback keresési hiba: {str(e)}")

        return None

    @staticmethod
    def _resolve_episode_if_needed(rk, season, episode, server_uri, token):
        if season is None or episode is None: return rk
        try:
            url = f"{server_uri}/library/metadata/{rk}/allLeaves?X-Plex-Token={token}"
            r = requests.get(url, headers={'Accept': 'application/json'}, timeout=5, verify=False)
            if r.status_code == 200:
                for ep in r.json().get('MediaContainer', {}).get('Metadata', []):
                    if int(ep.get('parentIndex', 0)) == int(season) and int(ep.get('index', 0)) == int(episode):
                        return ep.get('ratingKey')
        except: pass
        return rk

    @staticmethod
    def plex_scrobble_manager(imdb_id, action, current_time_secs, season=None, episode=None, total_time_secs=0):
        #PlexInterface._log(f"--- PLEX_SCROBBLE START --- Akció: {action} | IMDb: {imdb_id} | S/E: {season}/{episode}")
        
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('plex_token')
        client_id = myself.getSetting('plex_client_id')
        server_uri, _ = PlexInterface.get_plex_connection_info()
        
        if not server_uri: 
            #PlexInterface._log("HIBA: Nincs server_uri! A Plex szerver nem érhető el.")
            return False

        from resources.lib.indexers.database import DatabaseManager
        db_path = os.path.join(xbmcvfs.translatePath(myself.getAddonInfo('profile')), 'ncore_tv.db')
        db = DatabaseManager(db_path)

        rk = db.get_sync_id(imdb_id, 'plex')
        
        if rk:
            PlexInterface._log(f"RK találat az SQL-ben: {rk}")
        else: 
            #PlexInterface._log("Nincs RK az SQL-ben, indítás: _find_plex_rating_key...")
            rk = PlexInterface._find_plex_rating_key(imdb_id, 'show' if season else 'movie', season, episode)
        
        if not rk: 
            #PlexInterface._log(f"KRITIKUS HIBA: Nem sikerült RK-t feloldani az IMDb ID-hoz: {imdb_id}")
            return False

        if season is not None and episode is not None:
            old_rk = rk
            rk = PlexInterface._resolve_episode_if_needed(rk, season, episode, server_uri, token)
            #PlexInterface._log(f"Epizód RK feloldás: {old_rk} -> {rk}")

        curr_ms = int(float(current_time_secs) * 1000)
        total_ms = int(float(total_time_secs) * 1000)

        if action == 'watched':
            url = f"{server_uri}/:/scrobble?key={rk}&identifier=com.plexapp.plugins.library&X-Plex-Token={token}"
        else:
            state = 'playing' if action == 'start' else 'paused' if action == 'pause' else 'stopped'
            url = (f"{server_uri}/:/timeline?ratingKey={rk}&key=%2Flibrary%2Fmetadata%2F{rk}"
                   f"&state={state}&time={curr_ms}&duration={total_ms}"
                   f"&X-Plex-Token={token}&X-Plex-Client-Identifier={client_id}")

        #PlexInterface._log(f"Plex API hívás: {url.replace(token, 'REDACTED_TOKEN')}")

        try:
            r = requests.get(url, timeout=8, verify=False)
            #PlexInterface._log(f"Szerver válaszkód: {r.status_code}")
            
            if r.status_code in [200, 201]:
                return True
            else:
                #PlexInterface._log(f"Plex szerver hibaüzenet: {r.text[:200]}")
                return False
        except Exception as e:
            #PlexInterface._log(f"Hálózati hiba a Plex hívásnál: {str(e)}")
            return False

    @staticmethod
    def get_plex_resume_progress(imdb_id, season=None, episode=None):
        rk = PlexInterface._find_plex_rating_key(imdb_id, 'show' if season else 'movie', season, episode)
        if not rk: return None

        server_uri, _ = PlexInterface.get_plex_connection_info()
        token = addon.getSetting('plex_token')
        url = f"{server_uri}/library/metadata/{rk}?X-Plex-Token={token}"

        try:
            r = requests.get(url, headers={'Accept': 'application/json'}, timeout=5, verify=False)
            if r.status_code == 200:
                item = r.json().get('MediaContainer', {}).get('Metadata', [{}])[0]
                offset, duration = float(item.get('viewOffset', 0)), float(item.get('duration', 1))
                if offset > 0: return (offset / duration) * 100
        except: pass
        return None

    @staticmethod
    def plex_add_watchlist(imdb_id, is_series=False):
        #PlexInterface._log(f"--- PLEX_ADD_WATCHLIST: IMDb:{imdb_id} ---")
        
        token = addon.getSetting('plex_token')
        client_id = addon.getSetting('plex_client_id')
        if not token: return False

        headers = {
            'X-Plex-Token': token,
            'X-Plex-Client-Identifier': client_id,
            'Accept': 'application/json',
            'X-Plex-Product': 'Plex for Kodi',
            'X-Plex-Language': 'hu'
        }

        search_urls = [
            f"https://discover.provider.plex.tv/library/search?query={imdb_id}&limit=5",
            f"https://metadata.provider.plex.tv/library/search?query=imdb://{imdb_id}&limit=5"
        ]

        try:
            global_rk = None
            
            for url in search_urls:
                #PlexInterface._log(f"DEBUG: Keresés indítása: {url}")
                r = requests.get(url, headers=headers, timeout=10)
                
                if r.status_code == 200:
                    data = r.json().get('MediaContainer', {})
                    metadata = data.get('Metadata', [])
                    if not metadata and 'Hub' in data:
                        for hub in data['Hub']:
                            if 'Metadata' in hub:
                                metadata.extend(hub['Metadata'])

                    for item in metadata:
                        all_guids = str(item.get('Guid', [])) + item.get('guid', '')
                        if imdb_id in all_guids:
                            global_rk = item.get('ratingKey')
                            #PlexInterface._log(f"DEBUG: Találat megvan! RK: {global_rk}")
                            break
                
                if global_rk: break

            if global_rk:
                add_url = f"https://metadata.provider.plex.tv/actions/addToWatchlist?ratingKey={global_rk}"
                r_add = requests.put(add_url, headers=headers, timeout=10)
                
                #PlexInterface._log(f"DEBUG: Watchlist PUT válasz: {r_add.status_code}")
                return r_add.status_code in [200, 201]
            
            xbmcgui.Dialog().notification("Plex", f"'{imdb_id}' nem található a Plex adatbázisában.", xbmcgui.NOTIFICATION_WARNING, 3000)
            #PlexInterface._log(f"ERROR: '{imdb_id}' nem található a Plex adatbázisában.")
            
        except Exception as e:
            PlexInterface._log(f"CRITICAL_ADD_ERROR: {str(e)}")
        
        return False
