# -*- coding: utf-8 -*-
import os, sys, re, xbmc, xbmcgui, xbmcvfs, xbmcplugin, xbmcaddon, locale, base64, json, time, threading
from urllib.parse import urlparse, quote, unquote, unquote_plus, quote_plus, parse_qs
import requests, html
import pyxbmct
from pyxbmct import AddonDialogWindow, Label, Button
from .static_data import *

addon_id = 'plugin.video.nCore_TV'
addon = xbmcaddon.Addon(addon_id)
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
trakt_status_cache = os.path.join(profile_path, 'trakt_status_list.json')
trakt_id_map_file = os.path.join(profile_path, 'trakt_id_map.json')

class TraktInterface(AddonDialogWindow):
    def __init__(self, title='[B]Trakt.tv Hitelesítés[/B]'):
        super(TraktInterface, self).__init__(title)

        self.setGeometry(550, 400, 10, 4)

        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        trakt_user = myself.getSetting('trakt_username')
        
        is_auth = token and token.strip() != "" and token != "None"
        status_color = 'lime' if is_auth else 'red'

        if is_auth and trakt_user:
            status_text = f'Hitelesített ([B]{trakt_user}[/B])'
        elif is_auth:
            status_text = 'Hitelesített'
        else:
            status_text = 'Nem hitelesített'
        
        self.status_label = Label(f'Állapot: [COLOR {status_color}]{status_text}[/COLOR]')
        self.placeControl(self.status_label, 0, 0, 1, 4)

        self.auth_btn = Button('Engedélyezés [Trakt.tv] (eszközkód)')
        self.placeControl(self.auth_btn, 2, 0, 1, 4)
        self.connect(self.auth_btn, self.start_device_auth)

        self.revoke_btn = Button('Engedély visszavonása')
        self.placeControl(self.revoke_btn, 4, 0, 1, 4)
        self.connect(self.revoke_btn, self.revoke_access)

        self.close_btn = Button('Vissza')
        self.placeControl(self.close_btn, 9, 0, 1, 4)
        self.connect(self.close_btn, self.close)

        self.buttons = [self.auth_btn, self.revoke_btn, self.close_btn]
        for i in range(len(self.buttons)):
            up_target = self.buttons[(i - 1) % len(self.buttons)]
            down_target = self.buttons[(i + 1) % len(self.buttons)]
            self.buttons[i].controlUp(up_target)
            self.buttons[i].controlDown(down_target)

        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.setFocus(self.auth_btn)

    def start_device_auth(self):
        url = "https://api.trakt.tv/oauth/device/code"
        
        try:
            payload = {"client_id": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
            response = requests.post(url, json=payload, timeout=15)
            if response.status_code != 200: return

            data = response.json()
            device_code = data.get('device_code')
            user_code = data.get('user_code')
            
            progress_msg = (f"Böngészőben: [B]trakt.tv/activate[/B]\n"
                           f"Kód: [COLOR yellow][B]{user_code}[/B][/COLOR]\n"
                           "Várakozás a felhasználó visszaigazolására...")
            
            prog = xbmcgui.DialogProgress()
            prog.create("Trakt.tv Hitelesítés", progress_msg)

            token_url = "https://api.trakt.tv/oauth/device/token"
            token_payload = {"code":device_code,"client_id":f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}","client_secret":f"{ati_t4}{kzi_t4}{fri_t4}{qwi_t4}"}
            
            start_time = time.time()
            while time.time() - start_time < 600:
                if prog.iscanceled(): break
                prog.update(int(((time.time() - start_time) / 600) * 100), progress_msg)

                res = requests.post(token_url, json=token_payload, timeout=15)
                if res.status_code == 200:
                    t_data = res.json()
                    access_token = t_data.get('access_token')
                    trakt_user = ""
                    try:
                        u_url = "https://api.trakt.tv/users/settings"
                        u_headers = {
                            "Content-Type": "application/json", 
                            "Authorization": f"Bearer {access_token}", 
                            "trakt-api-version": "2", 
                            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
                        }
                        u_res = requests.get(u_url, headers=u_headers, timeout=15)
                        if u_res.status_code == 200:
                            trakt_user = u_res.json().get('user', {}).get('username', '')
                    except: pass

                    track_event("logins", "Auth: Trakt", "Trakt service authorized for watch history tracking.", icon="️🎬")

                    myself = xbmcaddon.Addon(addon_id)
                    myself.setSetting('trakt_access_token', str(access_token))
                    myself.setSetting('trakt_refresh_token', str(t_data.get('refresh_token')))
                    myself.setSetting('trakt_username', str(trakt_user))
                    exp_at = int(time.time()) + t_data.get('expires_in', 7776000)
                    myself.setSetting('trakt_expires_at', str(exp_at))
                    myself.setSetting('trakt_enabled', 'true')
                    
                    prog.close()
                    xbmcgui.Dialog().ok("Trakt.tv", f"Sikeres párosítás!\nFelhasználó: [B]{trakt_user}[/B]\nA beállítások menüben végzett módosítások csak az OK gomb megnyomásával kerülnek mentésre. Ez a fő beállítások menüre is érvényes.")
                    self.status_label.setLabel(f'Állapot: [COLOR lime]Hitelesített ([B]{trakt_user}[/B])[/COLOR]')
                    return
                
                xbmc.sleep(5000)
            prog.close()
        except: pass

    def revoke_access(self):
        if xbmcgui.Dialog().yesno("Trakt.tv", "Biztos vagy benne?"):
            myself = xbmcaddon.Addon(addon_id)
            myself.setSetting('trakt_access_token', '')
            myself.setSetting('trakt_refresh_token', '')
            myself.setSetting('trakt_username', '')
            myself.setSetting('trakt_expires_at', '')
            myself.setSetting('trakt_enabled', 'false')
            self.status_label.setLabel('Állapot: [COLOR red]Nem Hitelesített[/COLOR]')

    @staticmethod
    def _save_cache_internal(imdb_id, val):
        with global_write_lock: 
            try:
                current_cache = {}
                if os.path.exists(trakt_status_cache):
                    try:
                        with open(trakt_status_cache, 'r', encoding='utf-8') as f:
                            current_cache = json.load(f)
                    except: pass
                
                current_cache[imdb_id] = val

                temporary_file = trakt_status_cache + ".tmp"
                with open(temporary_file, 'w', encoding='utf-8') as f:
                    json.dump(current_cache, f, indent=2, ensure_ascii=False)
                    f.flush()
                    os.fsync(f.fileno())
                
                if sys.platform == "win32" and os.path.exists(trakt_status_cache):
                    os.remove(trakt_status_cache)
                os.rename(temporary_file, trakt_status_cache)
            except Exception as e:
                xbmc.log(f"[nCore_TV Trakt Cache] Hiba: {e}", xbmc.LOGERROR)

    @staticmethod
    def refresh_trakt_token():
        myself = xbmcaddon.Addon(addon_id)
        refresh_token = myself.getSetting('trakt_refresh_token')
        
        if not refresh_token or refresh_token in ["", "None"]:
            return False

        url = "https://api.trakt.tv/oauth/token"

        payload = {
            "refresh_token": refresh_token,
            "client_id": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}",
            "client_secret": f"{ati_t4}{kzi_t4}{fri_t4}{qwi_t4}",
            "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
            "grant_type": "refresh_token"
        }

        try:
            r = requests.post(url, data=payload, timeout=15)
            if r.status_code == 200:
                data = r.json()
                new_access = data.get('access_token')
                new_refresh = data.get('refresh_token')
                expires_in = data.get('expires_in', 7776000)

                if new_access and new_refresh:
                    myself.setSetting('trakt_access_token', str(new_access))
                    myself.setSetting('trakt_refresh_token', str(new_refresh))
                    exp_at = int(time.time()) + expires_in
                    myself.setSetting('trakt_expires_at', str(exp_at))
                    return True
        except Exception as e:
            xbmc.log(f"[TRAKT-REFRESH] KRITIKUS HIBA: {str(e)}", xbmc.LOGERROR)
        
        return False

    @staticmethod
    def trakt_scrobble(imdb_id, season=None, episode=None):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"] or not imdb_id: return False

        url = "https://api.trakt.tv/sync/history"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}

        if season and episode:
            data = {"shows": [{"ids": {"imdb": imdb_id}, "seasons": [{"number": int(season), "episodes": [{"number": int(episode)}]}]}]}
        else:
            data = {"movies": [{"ids": {"imdb": imdb_id}}]}

        try:
            r = requests.post(url, json=data, headers=headers, timeout=15)
            if r.status_code == 201:
                if season and episode:
                    new_val = f"[B][COLOR orange]Trakt utoljára:[/COLOR][/B] S{int(season):02d}E{int(episode):02d}"
                else:
                    new_val = "[B][COLOR orange]Trakt:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"

                cache = {}
                if os.path.exists(trakt_status_cache):
                    try:
                        with open(trakt_status_cache, 'r', encoding='utf-8') as f: cache = json.load(f)
                    except: pass
                cache[imdb_id] = new_val
                with open(trakt_status_cache, 'w', encoding='utf-8') as f: json.dump(cache, f, indent=2, ensure_ascii=False)
                return True
        except: pass
        return False

    @staticmethod
    def get_trakt_info(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"] or not imdb_id: return None

        if os.path.exists(trakt_status_cache):
            try:
                with open(trakt_status_cache, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                    if imdb_id in cache: return cache[imdb_id]
            except: pass

        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}

        try:
            r_s = requests.get("https://api.trakt.tv/sync/watched/shows?extended=full", headers=headers, timeout=15)
            if r_s.status_code == 200:
                for item in r_s.json():
                    if item.get('show', {}).get('ids', {}).get('imdb') == imdb_id:
                        ls, le = 0, 0
                        for s in item.get('seasons', []):
                            sn = s.get('number', 0)
                            for e in s.get('episodes', []):
                                en = e.get('number', 0)
                                if sn > ls or (sn == ls and en > le): ls, le = sn, en
                        res = f"[B][COLOR orange]Trakt utoljára:[/COLOR][/B] S{ls:02d}E{le:02d}"
                        TraktInterface._save_cache_internal(imdb_id, res)
                        return res

            r_m = requests.get("https://api.trakt.tv/sync/watched/movies", headers=headers, timeout=15)
            if r_m.status_code == 200:
                for item in r_m.json():
                    if item.get('movie', {}).get('ids', {}).get('imdb') == imdb_id:
                        res = "[B][COLOR orange]Trakt:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                        TraktInterface._save_cache_internal(imdb_id, res)
                        return res
        except: pass
        return None

    @staticmethod
    def get_watched_movies():
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token: return None
        url = "https://api.trakt.tv/sync/watched/movies?extended=full"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                return r.json()
        except: pass
        return None

    @staticmethod
    def get_watched_shows():
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token: return None

        url = "https://api.trakt.tv/sync/watched/shows?extended=full,progress"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                return r.json()
        except: pass
        return None

    @staticmethod
    def get_trakt_watchlist(type='movies'):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"]: return None

        url = f"https://api.trakt.tv/sync/watchlist/{type}?extended=full,images"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }
    
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                return r.json()
        except:
            pass
        return None

    @staticmethod
    def get_trakt_show_progress(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or not imdb_id: return None

        url = f"https://api.trakt.tv/shows/{imdb_id}/progress/watched?extended=full"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()
                next_ep = data.get('next_episode')
                if next_ep:
                    screenshot = ""
                    images = next_ep.get('images', {})
                    screenshots = images.get('screenshot', [])
                    if screenshots:
                        screenshot = "https://" + screenshots[0] if not screenshots[0].startswith('http') else screenshots[0]

                    return {
                        'season': next_ep.get('season'),
                        'number': next_ep.get('number'),
                        'title': next_ep.get('title'),
                        'plot': next_ep.get('overview', ''),
                        'thumb': screenshot,
                        'completed': data.get('completed', 0),
                        'aired': data.get('aired', 0)
                    }
        except: pass
        return None

    @staticmethod
    def get_trakt_history(page=1, limit=40):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token: return None

        url = f"https://api.trakt.tv/sync/history?extended=full&page={page}&limit={limit}"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                return r.json()
        except: pass
        return None
        
    @staticmethod
    def trakt_add_watchlist(imdb_id, is_series=False):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or not imdb_id or str(imdb_id).lower() == "none": return False
        
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
        key = "shows" if is_series else "movies"
        data = {key: [{"ids": {"imdb": str(imdb_id)}}]}
        
        try:
            r = requests.post("https://api.trakt.tv/sync/watchlist", json=data, headers=headers, timeout=15)
            if r.status_code == 201:
                res_data = r.json()
                added_count = res_data.get('added', {}).get(key, 0)
                existing_count = res_data.get('existing', {}).get(key, 0)
                
                if added_count > 0 or existing_count > 0:
                    return True
                else:
                    xbmcgui.Dialog().notification("Trakt", "Nem található az adatbázisban", xbmcgui.NOTIFICATION_WARNING, 3000)
                    return False
        except: pass
        return False

    @staticmethod
    def sync_full_trakt_history(retry=True, return_data=False):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"]: return False

        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
        new_watched_data = {}
        new_id_map = {}

        try:
            for w_type in ['movies', 'shows']:
                r_w = requests.get(f"https://api.trakt.tv/sync/watchlist/{w_type}", headers=headers, timeout=15)
                if r_w.status_code == 401 and retry:
                    if TraktInterface.refresh_trakt_token():
                        return TraktInterface.sync_full_trakt_history(retry=False, return_data=return_data)
                    return False

                if r_w.status_code == 200:
                    for item in r_w.json():
                        inner = item.get('movie') or item.get('show')
                        imdb = inner.get('ids', {}).get('imdb') if inner else None
                        t_id = inner.get('ids', {}).get('trakt') if inner else None
                        if imdb:
                            new_watched_data[imdb] = "[B][COLOR orange]Trakt:[/COLOR] [COLOR yellow]Listán[/COLOR][/B]"
                            if t_id: new_id_map[imdb] = t_id

            r_m = requests.get("https://api.trakt.tv/sync/watched/movies", headers=headers, timeout=15)
            if r_m.status_code == 200:
                for item in r_m.json():
                    imdb = item.get('movie', {}).get('ids', {}).get('imdb')
                    t_id = item.get('movie', {}).get('ids', {}).get('trakt')
                    if imdb:
                        new_watched_data[imdb] = "[B][COLOR orange]Trakt:[/COLOR] [COLOR lime]Láttam[/COLOR][/B]"
                        if t_id: new_id_map[imdb] = t_id

            r_s = requests.get("https://api.trakt.tv/sync/watched/shows?extended=full,progress", headers=headers, timeout=15)
            if r_s.status_code == 200:
                for item in r_s.json():
                    imdb = item.get('show', {}).get('ids', {}).get('imdb')
                    t_id = item.get('show', {}).get('ids', {}).get('trakt')
                    if imdb:
                        if t_id: new_id_map[imdb] = t_id
                        ls, le = 0, 0
                        for s in item.get('seasons', []):
                            sn = s.get('number', 0)
                            for e in s.get('episodes', []):
                                en = e.get('number', 0)
                                if sn > ls or (sn == ls and en > le): ls, le = sn, en
                        new_watched_data[imdb] = f"[B][COLOR orange]Trakt utoljára:[/COLOR][/B] S{ls:02d}E{le:02d}"

            if return_data:
                return new_watched_data, new_id_map
            
            return True
        except: return False

    @staticmethod
    def get_simkl_poster_for_imdb(imdb_id):
        if not imdb_id: return 'DefaultMovies.png'
        
        try:
            from resources.lib.indexers.database import DatabaseManager
            db_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile')), 'ncore_tv.db')
            db = DatabaseManager(db_path)
            
            db_data = db.get_indicators_for_list([imdb_id]).get(imdb_id)
            if db_data:
                pid = dict(db_data).get('simkl_poster')
                if pid:
                    return f"https://simkl.in/posters/{pid}_m.jpg"
        except: pass
        
        return 'DefaultMovies.png'

    @staticmethod
    def get_trakt_calendar():
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"]: return None

        import datetime
        start_date = (datetime.datetime.now() - datetime.timedelta(days=7)).strftime('%Y-%m-%d')

        url = f"https://api.trakt.tv/calendars/my/shows/{start_date}/14?extended=full,images"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                return r.json()
        except: pass
        return None

    _last_action_sent = "none"

    @staticmethod
    def trakt_scrobble_manager(imdb_id, action, progress, season=None, episode=None):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        
        if not token or token in ["", "None"] or not imdb_id:
            return False

        if action in ['pause', 'stop'] and TraktInterface._last_action_sent == 'pause':
            TraktInterface.trakt_scrobble_manager(imdb_id, 'start', progress, season, episode)
            xbmc.sleep(800)

        TraktInterface._last_action_sent = action

        try:
            from resources.lib.indexers.database import DatabaseManager
            db_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile')), 'ncore_tv.db')
            db = DatabaseManager(db_path)
            trakt_id = db.get_sync_id(imdb_id, 'trakt')
        except:
            trakt_id = None
    
        url = f"https://api.trakt.tv/scrobble/{action}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }
    
        ids = {"trakt": int(trakt_id)} if trakt_id else {"imdb": str(imdb_id)}
    
        if season and episode:
            data = {"show": {"ids": ids}, "episode": {"season": int(season), "number": int(episode)}, "progress": float(progress)}
        else:
            data = {"movie": {"ids": ids}, "progress": float(progress)}
    
        try:
            r = requests.post(url, json=data, headers=headers, timeout=15)
            if r.status_code in [200, 201]:
                return True
            elif r.status_code == 401:
                if TraktInterface.refresh_trakt_token():
                    return TraktInterface.trakt_scrobble_manager(imdb_id, action, progress, season, episode)
            return False
        except Exception as e:
            xbmc.log(f"[Trakt-MANAGER] Hiba: {str(e)}", xbmc.LOGERROR)
            return False

    @staticmethod
    def get_trakt_playback(retry=True, page=1, limit=20): 
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token: return None, 0

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }

        try:
            url = f"https://api.trakt.tv/sync/playback?extended=full&page={page}&limit={limit}"
            
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()

                total_count = int(r.headers.get('X-Pagination-Item-Count', 0))

                data.sort(key=lambda x: x.get('paused_at', ''), reverse=True)
                
                return data, total_count
            
            elif r.status_code == 401 and retry:
                if TraktInterface.refresh_trakt_token():
                    return TraktInterface.get_trakt_playback(retry=False, page=page, limit=limit)
                else:
                    return "AUTH_ERROR", 0
        except Exception as e:
            xbmc.log(f"[TRAKT-DEBUG] Kritikus hálózati hiba: {str(e)}", xbmc.LOGERROR)
        
        return None, 0

    @staticmethod
    def clear_trakt_playback(imdb_id):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or not imdb_id: return

        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
        try:
            r = requests.get("https://api.trakt.tv/sync/playback", headers=headers, timeout=15)
            if r.status_code == 200:
                for item in r.json():
                    media = item.get('movie') or item.get('show')
                    if media and media.get('ids', {}).get('imdb') == imdb_id:
                        p_id = item.get('id')

                        requests.delete(f"https://api.trakt.tv/sync/playback/{p_id}", headers=headers, timeout=15)
                        break
        except: pass

    @staticmethod
    def get_tmdb_poster_path_profi(tmdb_id, itype='movie'):
        if not tmdb_id: return None

        tmdb_endpoint = 'movie' if itype == 'movie' else 'tv'
        url = f"https://api.themoviedb.org/3/{tmdb_endpoint}/{tmdb_id}?api_key={bd_cnd}{cd_bdc}{ak_tdk}{tn_knk}{kt_ufg}{tk_rlt}"
        
        try:
            r = requests.get(url, timeout=15)
            if r.status_code == 200:
                data = r.json()
                path = data.get('poster_path')
                if path:
                    return f"https://image.tmdb.org/t/p/w500{path}"
        except: pass
        return None

    @staticmethod
    def get_trakt_resume_progress(imdb_id, season=None, episode=None):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or not imdb_id: return None

        url = "https://api.trakt.tv/sync/playback?extended=full"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }

        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()
                for item in data:
                    itype = item.get('type')
                    if itype == 'movie':
                        if item.get('movie', {}).get('ids', {}).get('imdb') == imdb_id:
                            return float(item.get('progress', 0))
                    elif itype == 'episode':
                        show_imdb = item.get('show', {}).get('ids', {}).get('imdb')
                        if show_imdb == imdb_id:
                            ep = item.get('episode', {})
                            if ep.get('season') == season and ep.get('number') == episode:
                                return float(item.get('progress', 0))
        except: pass
        return None

    @staticmethod
    def get_trakt_genres(media_type):
        headers = {
            "Content-Type": "application/json", 
            "trakt-api-version": "2", 
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }
        url = f"https://api.trakt.tv/genres/{media_type}"
        try:
            r = requests.get(url, headers=headers, timeout=15)
            return r.json() if r.status_code == 200 else []
        except: return []

    @staticmethod
    def get_trakt_filtered_content(media_type, genre_slug, year, page=1, limit=20):
        headers = {
            "Content-Type": "application/json", 
            "trakt-api-version": "2", 
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }
        
        url = f"https://api.trakt.tv/{media_type}/popular?genres={genre_slug}&years={year}&page={page}&limit={limit}&extended=full,images"
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                total_items = int(r.headers.get('X-Pagination-Item-Count', 0))
                return r.json(), total_items
        except: pass
        return [], 0

    @staticmethod
    def get_trakt_trending_lists(page=1, limit=20):
        headers = {
            "Content-Type": "application/json",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }
        url = f"https://api.trakt.tv/lists/trending?page={page}&limit={limit}"
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()
                return data
            return []
        except:
            return []

    @staticmethod
    def get_trakt_list_items(list_id, user_slug=None):
        headers = {
            "Content-Type": "application/json",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }

        if user_slug and user_slug != 'None':
            url = f"https://api.trakt.tv/users/{user_slug}/lists/{list_id}/items?extended=full,images"
        else:
            url = f"https://api.trakt.tv/lists/{list_id}/items?extended=full,images"
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                return r.json()
            return []
        except:
            return []

    @staticmethod
    def fetch_all_trakt_ratings():
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"]: return None

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "trakt-api-version": "2",
            "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"
        }

        all_results = []
        types = [
            ('movies', 'movie'), 
            ('shows', 'show'), 
            ('seasons', 'season'), 
            ('episodes', 'episode')
        ]

        for endpoint, r_type in types:
            try:
                url = f"https://api.trakt.tv/sync/ratings/{endpoint}"
                r = requests.get(url, headers=headers, timeout=15)
                if r.status_code == 200:
                    data = r.json()
                    count_before = len(all_results)
                    for item in data:
                        show_obj = item.get('show')
                        imdb = show_obj.get('ids', {}).get('imdb') if show_obj else None
                        
                        if not imdb:
                            media_obj = item.get(r_type)
                            if media_obj:
                                imdb = media_obj.get('ids', {}).get('imdb')
                        
                        if not imdb: continue

                        entry = {'imdb_id': imdb, 'type': r_type, 'rating': item.get('rating'), 's': 0, 'e': 0}

                        if r_type == 'season':
                            entry['s'] = item.get('season', {}).get('number', 0)
                        elif r_type == 'episode':
                            entry['s'] = item.get('episode', {}).get('season', 0)
                            entry['e'] = item.get('episode', {}).get('number', 0)
                        
                        all_results.append(entry)
                    
                    found_now = len(all_results) - count_before
            except Exception as e:
                xbmc.log(f"[nCore_Rating_Sync] HIBA a(z) {endpoint} lekérésekor: {e}", xbmc.LOGERROR)

        return all_results

    @staticmethod
    def send_trakt_rating(imdb_id, r_type, rating, season=0, episode=0):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"]: return False

        url = "https://api.trakt.tv/sync/ratings"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}
        ids = {"imdb": str(imdb_id)}

        if r_type == 'movie':
            data = {"movies": [{"rating": int(rating), "ids": ids}]}
        elif r_type == 'show':
            data = {"shows": [{"rating": int(rating), "ids": ids}]}
        elif r_type == 'season':
            data = {"shows": [{"ids": ids, "seasons": [{"number": int(season), "rating": int(rating)}]}]}
        elif r_type == 'episode':
            data = {"shows": [{"ids": ids, "seasons": [{"number": int(season), "episodes": [{"number": int(episode), "rating": int(rating)}]}]}]}

        try:
            r = requests.post(url, json=data, headers=headers, timeout=15)
            return r.status_code in [200, 201]
        except Exception as e:
            xbmc.log(f"[nCore_Rating_Error] API hiba: {e}", xbmc.LOGERROR)
            return False

    @staticmethod
    def send_trakt_batch_ratings(batch_data):
        myself = xbmcaddon.Addon(addon_id)
        token = myself.getSetting('trakt_access_token')
        if not token or token in ["", "None"] or not batch_data: return False

        url = "https://api.trakt.tv/sync/ratings"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}", "trakt-api-version": "2", "trakt-api-key": f"{ajb_9n}{kjf_9n}{fjt_9n}{qje_9n}"}

        try:
            r = requests.post(url, json=batch_data, headers=headers, timeout=20)
            return r.status_code in [200, 201]
        except Exception as e:
            xbmc.log(f"[nCore_Rating_Error] Batch hálózati hiba: {e}", xbmc.LOGERROR)
            return False
