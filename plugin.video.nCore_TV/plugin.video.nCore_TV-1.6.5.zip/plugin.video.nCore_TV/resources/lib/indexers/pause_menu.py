# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import time
import urllib.parse
import base64
import json
import pyxbmct
import re
from pyxbmct import AddonDialogWindow, Button
from urllib.parse import unquote_plus, parse_qs, quote

from .static_data import *

class PlaybackInterceptor(xbmcgui.WindowDialog):
    def __init__(self, torrent_id, current_file_name, elementum_url, original_args, fps="", hz="", res="", f_pos=0, f_count=0):
        super(PlaybackInterceptor, self).__init__()
        self.torrent_id = torrent_id
        self.elementum_url = elementum_url
        self.current_file_name = current_file_name
        self.original_args = original_args
        self.f_pos = f_pos
        self.f_count = f_count
        self.click_count = 0
        self.last_click_time = 0
        self.active = True
        self.init_time = time.time()
        
        self.screen_width = self.getWidth()
        self.screen_height = self.getHeight()

        self.background_catcher = xbmcgui.ControlButton(0, 0, self.screen_width, self.screen_height, "", 
                                                       focusTexture=' ', noFocusTexture=' ')
        self.addControl(self.background_catcher)
        self.setFocus(self.background_catcher)
        
        self.label = xbmcgui.ControlLabel(0, 80, self.screen_width, 80, 
                                        f'[COLOR yellow][B]Extra menü: 3x OK/Enter (más gombbal eltűnik)\n{self.current_file_name}[/COLOR][/B]',
                                        font='font14', alignment=2)
        self.addControl(self.label)

        res_raw = res if (res and 'VideoPlayer' not in res) else ""
        if res_raw.lower() == "4k":
            v_res = "4K"
        elif res_raw.isdigit():
            v_res = f"{res_raw}p"
        else:
            v_res = res_raw if res_raw else "???"

        v_fps_str = fps if (fps and 'Player.' not in fps) else "---"
        s_hz_str = hz if (hz and 'System.' not in hz) else "---"

        sync_color = 'white'
        try:
            import re
            v_fps = float(re.findall(r"\d+\.\d+|\d+", str(v_fps_str))[0])
            s_hz = float(re.findall(r"\d+\.\d+|\d+", str(s_hz_str))[0])
            
            if v_fps > 0 and s_hz > 0:
                ratio = s_hz / v_fps

                diff_from_int = abs(ratio - round(ratio))

                if abs(ratio - 1.0) < 0.05:
                    sync_color = 'lime'

                elif diff_from_int < 0.1:
                    sync_color = 'lightblue'

                else:
                    sync_color = 'FFfc1303'
        except: pass

        info_text = f'\n[COLOR grey]Videó:[/COLOR] [B]{v_res} @ {v_fps_str} fps[/B]  |  '
        info_text += f'[COLOR grey]Kijelző:[/COLOR] [B][COLOR {sync_color}]{s_hz_str} Hz[/COLOR][/B]'

        self.info_label = xbmcgui.ControlLabel(0, 135, self.screen_width, 60, 
                                              info_text, 
                                              font='font13', alignment=2)
        self.addControl(self.info_label)

    def onAction(self, action):
        action_id = action.getId()

        if action_id in [107, 100, 101, 92, 10, 1, 2, 3, 4]:
            if action_id == 107 and (time.time() - self.init_time) < 0.5:
                return
            self.active = False
            self.close()
            return

        if action_id == 7:
            if xbmc.getCondVisibility('Window.IsActive(pointer)'):
                self.active = False
                self.close()
                return

            current_time = time.time()
            if (current_time - self.last_click_time) < 0.6:
                self.click_count += 1
            else:
                self.click_count = 1
            
            self.last_click_time = current_time

            if self.click_count >= 3:
                self.click_count = 0
                self.active = False
                self.close()

                quoted_args = quote(str(self.original_args))
                plugin_url = (f'plugin://plugin.video.nCore_TV/?action=playback_settings_menu'
                             f'&torrent_id={self.torrent_id}'
                             f'&elementum_url={self.elementum_url}'
                             f'&original_args={quoted_args}'
                             f'&f_pos={self.f_pos}'
                             f'&f_count={self.f_count}')
                
                xbmc.executebuiltin(f'RunPlugin({plugin_url})')
            return

class PlaybackSettingsMenu(AddonDialogWindow):
    def __init__(self, torrent_id, elementum_url, original_args, title='[B]Extra menü:[/B]', f_pos=0, f_count=0):
        super(PlaybackSettingsMenu, self).__init__(title)
        self.torrent_id = torrent_id
        self.elementum_url = elementum_url
        self.original_args = original_args
        self.f_pos = int(f_pos)
        self.f_count = int(f_count)

        self.setGeometry(600, 500, 11, 4)

        is_series = False
        is_music = False
        is_xxx = False

        try:
            decoded_params = base64.b64decode(self.original_args).decode('utf-8')
            parsed_params = parse_qs(decoded_params.lstrip('?'))
            
            is_music = parsed_params.get('is_music', [''])[0] == 'true'
            is_xxx = parsed_params.get('is_xxx', [''])[0] == 'true'

            playing_file = xbmc.Player().getPlayingFile()
            series_pattern = r'[sS]\d+[eExX]\d+|(?<!\d)\d{3,4}(?!\d)'
            if re.search(series_pattern, playing_file):
                is_series = True

            if not is_series:
                full_url = parsed_params.get('full_url', [''])[0]
                if not full_url: full_url = parsed_params.get('title_1', [''])[0]
                season_pack_pattern = r'[sS]\d+(?![eExX\d])|(?:\d+\.\s*évad)|Season\s*\d+'
                if full_url and re.search(season_pack_pattern, unquote_plus(full_url), re.IGNORECASE):
                    is_series = True
        except:
            pass

        self.button_config = [
            ('Jelenlegi pozíció mentése', self.save_position_action),
            ('Mentett pozíció(k) betöltése', self.load_position_action),
            ('Mentett (helyi) pozíció(k) törlése', self.manage_positions_action)
        ]

        if extra_play_nav_menu_enabled and self.f_count > 1:
            if is_series or is_music or is_xxx:
                if self.f_pos < self.f_count:
                    next_idx = self.f_pos + 1
                    next_tag = f" ({next_idx}/{self.f_count})"
                    if is_music: next_label = f'[COLOR orange][B]Következő szám lejátszása{next_tag}[/B][/COLOR]'
                    elif is_xxx: next_label = f'[COLOR orange][B]Következő klip lejátszása{next_tag}[/B][/COLOR]'
                    else: next_label = f'[COLOR orange][B]Következő epizód lejátszása{next_tag}[/B][/COLOR]'
                    self.button_config.append((next_label, self.next_episode_action))

                if self.f_pos > 1:
                    prev_idx = self.f_pos - 1
                    prev_tag = f" ({prev_idx}/{self.f_count})"
                    if is_music: prev_label = f'[COLOR grey][B]Előző szám lejátszása{prev_tag}[/B][/COLOR]'
                    elif is_xxx: prev_label = f'[COLOR grey][B]Előző klip lejátszása{prev_tag}[/B][/COLOR]'
                    else: prev_label = f'[COLOR grey][B]Előző epizód lejátszása{prev_tag}[/B][/COLOR]'
                    self.button_config.append((prev_label, self.prev_episode_action))

                all_tag = f" ({self.f_count} db)"
                if is_music: browse_label = f'Váltás másik számra (Tallózás{all_tag})'
                elif is_xxx: browse_label = f'Váltás másik klipre (Tallózás{all_tag})'
                else: browse_label = f'Váltás másik epizódra (Tallózás{all_tag})'
                self.button_config.append((browse_label, self.select_episode_action))

        self.button_config.append(('Bezárás', self.close))

        self.buttons = []
        for index, (label, function) in enumerate(self.button_config):
            btn = Button(label)
            row = index if label != 'Bezárás' else 10
            self.placeControl(btn, row, 0, 1, 4)
            self.connect(btn, function)
            self.buttons.append(btn)

        for i in range(len(self.buttons)):
            up_target = self.buttons[(i - 1) % len(self.buttons)]
            down_target = self.buttons[(i + 1) % len(self.buttons)]
            self.buttons[i].controlUp(up_target)
            self.buttons[i].controlDown(down_target)

        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.setFocus(self.buttons[0])

    def save_position_action(self):
        xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.nCore_TV/?action=save_video_position&torrent_id={self.torrent_id})')

    def load_position_action(self):
        xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.nCore_TV/?action=load_video_position&torrent_id={self.torrent_id})')
        self.close()

    def manage_positions_action(self):
        xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.nCore_TV/?action=manage_saved_positions&torrent_id={self.torrent_id})')

    def next_episode_action(self):
        self.close()
        quoted_args = quote(str(self.original_args))
        url = (f'plugin://plugin.video.nCore_TV/?action=play_next_episode_action'
               f'&torrent_id={self.torrent_id}'
               f'&original_args={quoted_args}')
        xbmc.executebuiltin(f'RunPlugin({url})')

    def prev_episode_action(self):
        self.close()
        quoted_args = quote(str(self.original_args))
        url = (f'plugin://plugin.video.nCore_TV/?action=play_prev_episode_action'
               f'&torrent_id={self.torrent_id}'
               f'&original_args={quoted_args}')
        xbmc.executebuiltin(f'RunPlugin({url})')

    def select_episode_action(self):
        self.close()
        xbmc.executebuiltin('Notification(nCore TV, Tallózó megnyitása..., 2000)')
        xbmc.executebuiltin('PlayerControl(Stop)')
        xbmc.sleep(2000)

        try:
            args_raw = base64.b64decode(self.original_args).decode('utf-8')
            if args_raw.startswith('?'): args_raw = args_raw[1:]
            
            from urllib.parse import parse_qsl, urlencode
            params_dict = dict(parse_qsl(args_raw))
            
            keys_to_clear = ['resume_percent', 'resume_seconds', 'resume_time', 'target_episode', 'f_name', 'file_match', 'position']
            for key in keys_to_clear:
                params_dict.pop(key, None)
            
            params_dict['select'] = '1'
            
            clean_query = urlencode(params_dict)
            new_addon_url = f'plugin://plugin.video.nCore_TV/?{clean_query}'
            
            xbmc.executebuiltin(f'AlarmClock(nCoreRestart, PlayMedia("{new_addon_url}"), 00:03, silent)')
        except Exception as e:
            xbmc.log(f"[nCore_DEBUG] SelectAction -> HIBA: {str(e)}", xbmc.LOGERROR)
