# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, xbmcaddon, re
import pyxbmct
from pyxbmct import AddonDialogWindow, Label, List, Button
from urllib.parse import unquote_plus

addon_id = 'plugin.video.nCore_TV'
addon = xbmcaddon.Addon(addon_id)

class RatingManagerWindow(AddonDialogWindow):
    def __init__(self, title, torrent_id, imdb_id, db_manager):
        super(RatingManagerWindow, self).__init__(title)
        self.torrent_id = torrent_id
        self.imdb_id = imdb_id
        self.db = db_manager
        self.modified_data = {}
        
        self.setGeometry(900, 650, 14, 12)
        self.setup_controls()
        self.load_files()
        self.set_navigation()

        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def setup_controls(self):
        self.placeControl(Label("[COLOR gold]Navigáció: Fel/Le - váltás | Jobbra/Balra - pontszám (+/-)[/COLOR]"), 0, 0, 1, 12)

        self.file_list = List(font='font13')
        self.placeControl(self.file_list, 1, 0, 11, 12)

        self.save_btn = Button("[B][COLOR lime]Értékelések Mentése (Trakt + SQL)[/COLOR][/B]")
        self.placeControl(self.save_btn, 12, 0, 1, 6)
        
        self.close_btn = Button("Mégsem / Bezárás")
        self.placeControl(self.close_btn, 12, 6, 1, 6)

        self.connect(self.save_btn, self.on_save)
        self.connect(self.close_btn, self.close)

    def onAction(self, action):
        action_id = action.getId()

        if self.getFocus() == self.file_list:
            if action_id == 2:
                self.increment_rating()
                return
            elif action_id == 1:
                self.decrement_rating()
                return
                
        super(RatingManagerWindow, self).onAction(action)

    def load_files(self):
        with self.db._get_connection() as conn:
            rows = conn.execute("SELECT file_name FROM torrent_files WHERE torrent_id = ? ORDER BY file_name ASC", (str(self.torrent_id),)).fetchall()
        
        self.files_data = []

        show_rating = self.db.get_trakt_rating(self.imdb_id, 'show', 0, 0)
        self.files_data.append({
            'name': '>>> [ TELJES SOROZAT ÉRTÉKELÉSE ] <<<',
            's': 0, 'e': 0, 'type': 'show', 'rating': show_rating or 0
        })

        found_seasons = sorted(list(set([self.extract_se(r['file_name'])[0] for r in rows if self.extract_se(r['file_name'])[0] is not None])))
        
        for s_num in found_seasons:
            season_rating = self.db.get_trakt_rating(self.imdb_id, 'season', s_num, 0)
            self.files_data.append({
                'name': f'>> [ {s_num}. ÉVAD ÉRTÉKELÉSE ] <<',
                's': s_num, 'e': 0, 'type': 'season', 'rating': season_rating or 0
            })

        for r in rows:
            f_name = r['file_name']
            s, e = self.extract_se(f_name)
            if s is not None and e is not None:
                current_rating = self.db.get_trakt_rating(self.imdb_id, 'episode', s, e)
                self.files_data.append({
                    'name': f_name, 's': s, 'e': e, 'type': 'episode', 'rating': current_rating or 0
                })

        self.update_ui_list()

    def update_ui_list(self):
        pos = self.file_list.getSelectedPosition()
        self.file_list.reset()
        for item in self.files_data:
            score = item['rating']
            score_label = f"[ {score:>2} ★ ]" if score > 0 else "[  --  ]"
            
            if item['type'] == 'show':
                display_name = f"[COLOR gold]{score_label} {item['name']}[/COLOR]"
            elif item['type'] == 'season':
                display_name = f"[COLOR orange]{score_label} {item['name']}[/COLOR]"
            else:
                prefix = f"S{item['s']:02d}E{item['e']:02d}"
                display_name = f"{score_label} {prefix} | {item['name']}"
            
            if item['name'] in self.modified_data:
                display_name = f"[COLOR lime]* {display_name}[/COLOR]"
            
            self.file_list.addItem(display_name)
        if pos >= 0: self.file_list.selectItem(pos)

    def extract_se(self, text):
        patterns = [
            r'[sS](?P<season>\d{1,2})[.\s-]*[eE](?P<episode>\d{1,2})',
            r'(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})',
        ]
        for p in patterns:
            m = re.search(p, str(text))
            if m: return int(m.group(1)), int(m.group(2))
        return None, None

    def increment_rating(self):
        idx = self.file_list.getSelectedPosition()
        if idx >= 0:
            val = self.files_data[idx]['rating']
            if val < 10:
                self.files_data[idx]['rating'] = val + 1
                self.modified_data[self.files_data[idx]['name']] = True
                self.update_ui_list()

    def decrement_rating(self):
        idx = self.file_list.getSelectedPosition()
        if idx >= 0:
            val = self.files_data[idx]['rating']
            if val > 0:
                self.files_data[idx]['rating'] = val - 1
                self.modified_data[self.files_data[idx]['name']] = True
                self.update_ui_list()

    def set_navigation(self):
        self.file_list.controlDown(self.save_btn)
        self.save_btn.controlUp(self.file_list)
        self.save_btn.controlRight(self.close_btn)
        self.close_btn.controlLeft(self.save_btn)
        self.close_btn.controlUp(self.file_list)
        self.setFocus(self.file_list)

    def on_save(self):
        if not self.modified_data:
            self.close()
            return

        batch = {"movies": [], "shows": []}
        ids = {"imdb": self.imdb_id}
        to_save_local = []

        seasons_to_rate = {}
        episodes_to_rate = {}

        for item in self.files_data:
            if item['name'] in self.modified_data:
                rating = item['rating']
                to_save_local.append(item)
                
                if item['type'] == 'movie':
                    batch['movies'].append({"rating": rating, "ids": ids})
                
                elif item['type'] == 'show':
                    batch['shows'].append({"rating": rating, "ids": ids})
                
                elif item['type'] == 'season':
                    seasons_to_rate[item['s']] = rating
                
                elif item['type'] == 'episode':
                    s_num = item['s']
                    if s_num not in episodes_to_rate:
                        episodes_to_rate[s_num] = []
                    episodes_to_rate[s_num].append({"number": item['e'], "rating": rating})

        if seasons_to_rate:
            season_list = [{"number": s, "rating": r} for s, r in seasons_to_rate.items()]
            batch['shows'].append({"ids": ids, "seasons": season_list})

        if episodes_to_rate:
            ep_season_list = []
            for s_num, eps in episodes_to_rate.items():
                ep_season_list.append({"number": s_num, "episodes": eps})
            batch['shows'].append({"ids": ids, "seasons": ep_season_list})

        if not batch["movies"] and not batch["shows"]:
            self.close()
            return

        xbmcgui.Dialog().notification("nCore TV", "Szinkronizálás...", "", 1500)
        from resources.lib.indexers.trakt_parts import TraktInterface

        #xbmc.log(f"[nCore_Rating_Debug] Batch JSON: {batch}", xbmc.LOGINFO)
        
        if TraktInterface.send_trakt_batch_ratings(batch):
            for item in to_save_local:
                self.db.save_trakt_rating(self.imdb_id, item['type'], item['rating'], item['s'], item['e'])
            xbmcgui.Dialog().notification("Sikeres", f"{len(to_save_local)} tétel mentve!", "", 3000)
            self.close()
        else:
            xbmcgui.Dialog().ok("Trakt Hiba", "Hiba történt a beküldésnél.")