# -*- coding: utf-8 -*-
import pyxbmct
import xbmc

class AuthErrorWindow(pyxbmct.AddonDialogWindow):
    def __init__(self, title, message):
        super(AuthErrorWindow, self).__init__(title)

        self.setGeometry(700, 450, 10, 4)

        self.textbox = pyxbmct.TextBox()
        self.placeControl(self.textbox, 0, 0, 8, 4)
        self.textbox.setText(message)

        self.dummy_btn = pyxbmct.Button('[ - Kövesd a tájékoztatót - ]')
        self.placeControl(self.dummy_btn, 9, 0, 1, 2)

        self.check_btn = pyxbmct.Button('[B][COLOR lime]Újraellenőrzés[/COLOR][/B]')
        self.placeControl(self.check_btn, 9, 2, 1, 1)
        self.connect(self.check_btn, self.run_cloud_check)

        self.close_btn = pyxbmct.Button('Bezárás')
        self.placeControl(self.close_btn, 9, 3, 1, 1)
        self.connect(self.close_btn, self.close)

        self.dummy_btn.controlRight(self.check_btn)
        self.check_btn.controlLeft(self.dummy_btn)
        self.check_btn.controlRight(self.close_btn)
        self.close_btn.controlLeft(self.check_btn)

        self.setFocus(self.dummy_btn)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def run_cloud_check(self):
        from resources.lib.indexers.navigator import navigator
        nav = navigator()
        nav.CloudAuthDiagnostic()
        self.close()