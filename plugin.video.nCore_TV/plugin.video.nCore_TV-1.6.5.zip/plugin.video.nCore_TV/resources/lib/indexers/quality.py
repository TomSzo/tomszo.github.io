# -*- coding: utf-8 -*-
# nCore TV (fork) - új fájl. Copyright (C) 2026 TomSzo, GPL-3.0-or-later (lásd LICENSE.txt).
"""
Release-név alapú minőség-felismerés (REMUX, felbontás, HDR/DV) és pontozás.

Tiszta Python, semmilyen Kodi-függősége nincs, így a logika Kodin kívül is tesztelhető.
A régi, két helyen duplikált szűrőblokk (getItems) helyett ez fut.
"""
import re

_RE_REMUX = re.compile(r'(?<![a-z0-9])remux(?![a-z0-9])')
_RE_DV = re.compile(r'(?<![a-z0-9])(?:dv|dovi)(?![a-z0-9])|dolby[ ._-]?vision')
_RE_HDR = re.compile(r'(?<![a-z0-9])(?:hdr(?:10)?(?:\+|plus)?|hlg)(?![a-z0-9])')
_RE_2160 = re.compile(r'2160|(?<![a-z0-9])4k(?![a-z0-9])|(?<![a-z0-9])uhd(?![a-z0-9])')
_RE_1080 = re.compile(r'1080')
_RE_720 = re.compile(r'720')
_RE_BD_DISC = re.compile(r'(?<![a-z0-9])bd(25|50|66|100)(?![a-z0-9])')
_RE_BAD_SRC = re.compile(r'(?<![a-z0-9])(hdtc|hdts|hdcam|tc|ts|cam|scr)(?![a-z0-9])|(telesync)|(telecine)|(screener)')
_RE_AUDIO_TOP = re.compile(r'atmos|truehd|dts[ ._-]?hd|dts[ ._-]?x')

# A szűrő-menü indexei (custom_filter_list értékei)
FILTER_NAMES = ["SD", "720", "1080", "DV/HDR (1080)", "4K DV/HDR", "REMUX (bármely felbontás)"]
FILTER_MENU_LABELS = [
    "SD tartalmak",
    "720 tartalmak",
    "1080 tartalmak",
    "DV/HDR (1080)",
    "4K DV/HDR tartalmak",
    "REMUX (bármely felbontás)",
]

# Gyors elnevezések a widget / TMDb Helper URL-ekhez: quality=remux stb.
_QUALITY_ALIASES = {
    'sd': '0', '720': '1', '720p': '1', '1080': '2', '1080p': '2',
    'hdr': '3', 'dv': '3', '2160': '4', '2160p': '4', '4k': '4', 'uhd': '4',
    'remux': '5',
}


class Quality(object):
    __slots__ = ('res', 'remux', 'hdr', 'dv', 'audio_top', 'sd', 'hun', 'is4k', 'is1080', 'is720', 'disc', 'bad')

    def __init__(self, title, cat=''):
        t = (title or '').lower()
        c = (cat or '').lower()
        self.remux = bool(_RE_REMUX.search(t))
        self.dv = bool(_RE_DV.search(t))
        self.hdr = bool(_RE_HDR.search(t)) or self.dv
        self.audio_top = bool(_RE_AUDIO_TOP.search(t))
        self.sd = 'xvid' in c
        self.hun = ('hun' in c) or ('hunsub' in t) or bool(re.search(r'(?<![a-z0-9])hun(?![a-z0-9])', t))
        # Ugyanaz a szabály, mint a régi szűrőben: 1080 jelenlétében nem 4K
        self.is1080 = bool(_RE_1080.search(t))
        self.is4k = bool(_RE_2160.search(t)) and not self.is1080
        self.is720 = bool(_RE_720.search(t)) and not self.is1080
        # Teljes lemez (BD50 = 1080p, BD66/BD100 = UHD): a névben nincs felbontás
        md = _RE_BD_DISC.search(t)
        self.disc = md.group(1) if md else ''
        if self.disc in ('25', '50') and not (self.is1080 or self.is4k or self.is720):
            self.is1080 = True
        elif self.disc in ('66', '100') and not (self.is1080 or self.is4k):
            self.is4k = True
        mb = _RE_BAD_SRC.search(t)
        self.bad = (mb.group(0).upper().replace('HD', '') if mb else '')
        if self.bad in ('TELESYNC',): self.bad = 'TS'
        if self.bad in ('TELECINE',): self.bad = 'TC'
        if self.bad in ('SCREENER',): self.bad = 'SCR'
        if self.is4k:
            self.res = 2160
        elif self.is1080:
            self.res = 1080
        elif self.is720:
            self.res = 720
        elif self.sd:
            self.res = 480
        else:
            self.res = 0


def parse(title, cat=''):
    return Quality(title, cat)


def chosen_from(value):
    """'remux' / '2160,remux' / '5' / ['0','2'] -> ['5'] alakú indexlista."""
    if not value:
        return []
    if isinstance(value, str):
        parts = [p.strip().lower() for p in value.split(',') if p.strip()]
    else:
        parts = [str(p).strip().lower() for p in value]
    out = []
    for p in parts:
        idx = _QUALITY_ALIASES.get(p, p if p.isdigit() else None)
        if idx is not None and idx not in out:
            out.append(idx)
    return out


def allowed(title, cat, chosen):
    """
    True, ha a release megfelel a kiválasztott szűrőknek.
    chosen: indexek listája (lásd FILTER_NAMES). A logika a régi szűrőt követi,
    kiegészítve a "5" (REMUX) opcióval, ami felbontástól függetlenül átenged.
    """
    q = Quality(title, cat)
    if '5' in chosen and q.remux:
        return True

    cat_l = (cat or '').lower()
    allow = False
    if q.sd and '0' in chosen:
        allow = True
    elif q.is720 and '1' in chosen:
        allow = True
    elif q.is1080 and not q.is4k:
        if q.hdr and '3' in chosen:
            allow = True
        elif not q.hdr and '2' in chosen:
            allow = True
    elif q.is4k and '4' in chosen:
        allow = True

    if not (q.sd or q.is720 or q.is1080 or q.is4k):
        if 'hd' in cat_l and ('2' in chosen or '1' in chosen):
            allow = True
        if 'xvid' in cat_l and '0' in chosen:
            allow = True
    return allow


def score(title, cat='', seeders=0, pref='auto'):
    """
    Nagyobb = jobb. pref: 'auto' | 'remux' | '2160' | '1080'.
    A seeder nélküli torrent erősen hátra kerül (nem indul el).
    """
    q = Quality(title, cat)
    try:
        seeders = int(str(seeders).strip() or 0)
    except ValueError:
        seeders = 0

    res_pts = {2160: 400, 1080: 300, 720: 200, 480: 100, 0: 150}[q.res]
    pts = res_pts
    pref = (pref or 'auto').lower()

    if pref in ('auto', 'remux'):
        pts += 150 if q.remux else 0
    if pref == 'remux' and q.remux:
        pts += 1000
    if pref in ('2160', '4k') and q.res == 2160:
        pts += 1000
    if pref == '1080' and q.res == 1080:
        pts += 1000

    if q.disc and pref in ('auto', 'remux'):
        pts += 100
    if q.bad:
        pts -= 900  # TC/TS/CAM/SCR: nézhetetlen minőség
    if q.dv and re.search(r'(?<![a-z0-9])p5(?![a-z0-9])', (title or '').lower()):
        pts -= 30   # DV Profile 5: nincs HDR10 alaprétege, nem-DV láncon hibás színek
    if q.dv:
        pts += 40
    if q.hdr:
        pts += 25
    if q.audio_top:
        pts += 15
    if q.hun:
        pts += 20
    pts += min(max(seeders, 0), 30) * 3
    if seeders <= 0:
        pts -= 600
    return pts


def pref_from_setting(label):
    """A settings.xml labelenum értékéből (Auto/REMUX/2160p/1080p) pref kulcs."""
    l = (label or 'auto').strip().lower()
    if l.startswith('remux'):
        return 'remux'
    if l.startswith('2160') or l.startswith('4k'):
        return '2160'
    if l.startswith('1080'):
        return '1080'
    return 'auto'


def badge(title, cat=''):
    """Rövid címke a kiválasztó dialógushoz, pl. '4K REMUX DV HDR'."""
    q = Quality(title, cat)
    parts = []
    parts.append({2160: '4K', 1080: '1080p', 720: '720p', 480: 'SD', 0: '?'}[q.res])
    if q.remux:
        parts.append('REMUX')
    if q.dv:
        parts.append('DV')
    if q.hdr and not q.dv:
        parts.append('HDR')
    elif q.hdr and q.dv:
        parts.append('HDR')
    if q.hun:
        parts.append('HU')
    return ' '.join(parts)


# ----------------------------------------------------------------------
# Kompakt, színes címke a Source Select dialógushoz
# ----------------------------------------------------------------------
_RE_SRC_UHDBD = re.compile(r'uhd[ ._-]?blu[ ._-]?ray|uhd[ ._-]?bd')
_RE_SRC_BD = re.compile(r'blu[ ._-]?ray|bdrip|brrip|(?<![a-z0-9])bd(?![a-z0-9])')
_RE_SRC_WEBDL = re.compile(r'web[ ._-]?dl')
_RE_SRC_WEBRIP = re.compile(r'web[ ._-]?rip')
_RE_SRC_HDTV = re.compile(r'hdtv')
_RE_SVC = re.compile(r'(?<![a-z0-9])(amzn|nf|dsnp|atvp|hmax|max|hulu|pcok|pmtp|skst|sho|crav)(?![a-z0-9])')
_RE_AV1 = re.compile(r'(?<![a-z0-9])av1(?![a-z0-9])')
_RE_HEVC = re.compile(r'hevc|x265|h[ ._]?265')
_RE_AVC = re.compile(r'(?<![a-z0-9])avc(?![a-z0-9])|x264|h[ ._]?264')
_RE_VC1 = re.compile(r'vc[ ._-]?1')
_RE_HDR10P = re.compile(r'hdr10(?:\+|plus)')
_RE_HDR10 = re.compile(r'hdr10(?![a-z0-9+])')
_RE_ATMOS = re.compile(r'atmos')
_RE_TRUEHD = re.compile(r'truehd')
_RE_DTSHDMA = re.compile(r'dts[ ._-]?hd[ ._-]?ma|(?<![a-z0-9])hd[ ._-]?ma(?![a-z0-9])')
_RE_DTSHD = re.compile(r'dts[ ._-]?hd')
_RE_DTSX = re.compile(r'dts[ ._-]?x')
_RE_DTS = re.compile(r'(?<![a-z0-9])dts(?![a-z0-9-])')
_RE_DDP = re.compile(r'ddp|dd\+|e[ ._-]?ac[ ._-]?3')
_RE_DD = re.compile(r'(?<![a-z0-9])dd(?=[0-9. ])|ac[ ._-]?3')
_RE_CH = re.compile(r'(?<![0-9])([1-9]\.[01])(?![0-9])')
_RE_GROUP = re.compile(r'-([A-Za-z0-9]{2,15})(?:\.[a-z0-9]{2,4})?$')
_RE_PACK = re.compile(r'(?<![a-z0-9])s\d{1,2}(?![0-9e])|complete|season', re.I)

_EDITIONS = [
    (re.compile(r"director'?s?[ ._-]?cut"), 'DIR CUT'),
    (re.compile(r'extended[ ._-]?(?:cut|version|edition)?|(?<![a-z0-9])ext[ ._-]?cut'), 'EXTENDED'),
    (re.compile(r'theatrical[ ._-]?(?:cut|version|edition)?'), 'THEATRICAL'),
    (re.compile(r'(?<![a-z0-9])unrated(?![a-z0-9])'), 'UNRATED'),
    (re.compile(r'(?<![a-z0-9])uncut(?![a-z0-9])'), 'UNCUT'),
    (re.compile(r'(?<![a-z0-9])imax(?![a-z0-9])'), 'IMAX'),
    (re.compile(r'remaster(?:ed)?'), 'REMASTER'),
    (re.compile(r'final[ ._-]?cut'), 'FINAL CUT'),
    (re.compile(r'special[ ._-]?edition'), 'SPECIAL ED'),
    (re.compile(r'(?<![a-z0-9])redux(?![a-z0-9])'), 'REDUX'),
    (re.compile(r'open[ ._-]?matte'), 'OPEN MATTE'),
    (re.compile(r'(?<![a-z0-9])3d(?![a-z0-9])'), '3D'),
]

# Fekete-fehér / színes változat (pl. Spider-Noir): csak a cím UTÁNI részben keressük (évszám vagy
# S01 / S01E02 után), hogy a címben szereplő szó (pl. "The Color Purple") ne adjon hamis jelzést.
_RE_AFTER_TITLE = re.compile(r'(?<![a-z0-9])(?:(?:19|20)\d{2}|s\d{1,2}(?:e\d{1,3})?)(?![a-z0-9])')
_RE_BW = re.compile(r'(?<![a-z0-9])(?:b[ ._-]?&[ ._-]?w|b[ ._-]?and[ ._-]?w|bw|black[ ._-]?(?:and|&|n)?[ ._-]?white'
                    r'|monochrome|fekete[ ._-]?feher|fekete[ ._-]?fehér)(?![a-z0-9])')
_RE_COLOR = re.compile(r'(?<![a-z0-9])(?:(?:full|true)[ ._-]?)?(?:colou?r(?:ed|i[sz]ed)?|true[ ._-]?hue|sz[ií]nes)(?![a-z0-9])')

# Színkódok (Kodi [COLOR AARRGGBB])
C_REMUX = 'FFFFD700'   # arany
C_4K = 'FF00BFFF'      # égkék
C_1080 = 'FF7CFC00'    # zöld
C_720 = 'FFFFFF00'     # sárga
C_SD = 'FFFF4500'      # piros
C_DV = 'FFFF69B4'      # rózsaszín
C_HDR = 'FFFFA500'     # narancs
C_AUDIO = 'FF87CEFA'   # világoskék
C_ED = 'FFDA70D6'      # kiadás (orchidea)
C_DIM = 'FF9E9E9E'     # szürke
C_HU = 'FF32CD32'      # HU
C_GOOD = 'FF32CD32'
C_WARN = 'FFFFA500'
C_BAD = 'FFFF4500'


def _c(color, text):
    return '[COLOR %s]%s[/COLOR]' % (color, text)


def details(title, cat=''):
    """Release-név részletes felbontása (forrás, kodek, hang, csatornák, HDR-típus, csoport)."""
    t = (title or '').lower()
    q = Quality(title, cat)
    d = {'q': q}
    if _RE_SRC_UHDBD.search(t):
        d['source'] = 'UHD BD'
    elif _RE_SRC_BD.search(t):
        d['source'] = 'BluRay'
    elif _RE_SRC_WEBDL.search(t):
        d['source'] = 'WEB-DL'
    elif _RE_SRC_WEBRIP.search(t):
        d['source'] = 'WEBRip'
    elif _RE_SRC_HDTV.search(t):
        d['source'] = 'HDTV'
    else:
        d['source'] = ''
    if q.disc and not q.remux:
        d['source'] = ('BD' + q.disc) + (' UHD' if q.disc in ('66', '100') else '')
    m = _RE_SVC.search(t)
    d['svc'] = m.group(1).upper() if m else ''
    if not d['svc']:
        # kis/nagybetű-érzékeny szolgáltatás-jelek: iT (iTunes), MA (Movies Anywhere)
        if re.search(r'(?<![A-Za-z0-9])iT(?![A-Za-z0-9])', title or ''): d['svc'] = 'iT'
        elif re.search(r'(?<![A-Za-z0-9])MA(?=[ ._-]WEB)', title or ''): d['svc'] = 'MA'
    if _RE_AV1.search(t): d['codec'] = 'AV1'
    elif _RE_HEVC.search(t): d['codec'] = 'HEVC'
    elif _RE_AVC.search(t): d['codec'] = 'AVC'
    elif _RE_VC1.search(t): d['codec'] = 'VC-1'
    else: d['codec'] = ''
    # csak akkor HDR-címke, ha a névben tényleg szerepel (a sima DV/DoVi nem HDR10)
    if _RE_HDR10P.search(t): d['hdr'] = 'HDR10+'
    elif _RE_HDR10.search(t): d['hdr'] = 'HDR10'
    elif re.search(r'(?<![a-z0-9])(hdr|hlg)(?![a-z0-9])', t): d['hdr'] = 'HLG' if 'hlg' in t and 'hdr' not in t else 'HDR'
    else: d['hdr'] = ''
    mp = re.search(r'(?<![a-z0-9])p(5|7|8)(?![a-z0-9])', t) if q.dv else None
    d['dvp'] = ('P' + mp.group(1)) if mp else ''
    atmos = bool(_RE_ATMOS.search(t))
    if _RE_TRUEHD.search(t): a = 'TrueHD Atmos' if atmos else 'TrueHD'
    elif _RE_DTSX.search(t): a = 'DTS:X'
    elif _RE_DTSHDMA.search(t): a = 'DTS-HD MA'
    elif _RE_DTSHD.search(t): a = 'DTS-HD'
    elif _RE_DDP.search(t): a = 'DD+ Atmos' if atmos else 'DD+'
    elif _RE_DTS.search(t): a = 'DTS'
    elif _RE_DD.search(t): a = 'DD'
    elif atmos: a = 'Atmos'
    else: a = ''
    d['audio'] = a
    m = _RE_CH.search(t)
    d['ch'] = m.group(1) if m else ''
    m = _RE_GROUP.search((title or '').strip())
    d['group'] = m.group(1) if m else ''
    d['pack'] = bool(_RE_PACK.search(title or '')) and not re.search(r's\d{1,2}e\d{1,3}', t)
    d['hunsub'] = 'hunsub' in t
    d['editions'] = []
    for rx, label in _EDITIONS:
        if rx.search(t) and label not in d['editions']:
            d['editions'].append(label)
    m = _RE_AFTER_TITLE.search(t)
    tail = t[m.end():] if m else ''
    d['bw'] = bool(tail and _RE_BW.search(tail))
    d['color'] = bool(tail and not d['bw'] and _RE_COLOR.search(tail))
    return d


def _seed_int(seeders):
    try:
        return int(re.sub(r'\D', '', str(seeders)) or 0)
    except ValueError:
        return 0


def has_bw(titles):
    """Van-e a verziók között fekete-fehér kiadás? (Ilyenkor a jelöletlen verziók a színesek.)"""
    return any(details(t or '').get('bw') for t in titles)


def dialog_item(title, cat='', size='', seeders=0, mark_color=False):
    """
    (label1, label2) a Source Select dialógushoz. Rövid, szín-kódolt, hogy ne kelljen görgetni:
      label1: 4K REMUX DV HDR10+  ·  HEVC  ·  TrueHD Atmos 7.1
      label2: UHD BD  ·  58.4 GB  ·  S:12  ·  GRP  ·  HU
    """
    d = details(title, cat)
    q = d['q']
    res_txt, res_col = {2160: ('4K', C_4K), 1080: ('1080p', C_1080), 720: ('720p', C_720), 480: ('SD', C_SD), 0: ('?', C_DIM)}[q.res]
    tags = []
    if q.bad:
        tags.append(_c(C_BAD, '[B]%s![/B]' % q.bad))
    tags.append(_c(res_col, '[B]%s[/B]' % res_txt))
    if q.remux:
        tags.append(_c(C_REMUX, '[B]REMUX[/B]'))
    if q.dv:
        tags.append(_c(C_DV, '[B]DV%s[/B]' % ((' ' + d['dvp']) if d['dvp'] else '')))
    if d['hdr']:
        tags.append(_c(C_HDR, d['hdr']))
    for ed in d['editions']:
        tags.append(_c(C_ED, '[B]%s[/B]' % ed))
    if mark_color and not d.get('bw'):
        d['color'] = True          # a csoportban van fekete-fehér -> a jelöletlen verzió a színes
    if d.get('bw'):
        tags.append('[COLOR FFFFFFFF][B]FEKETE[/B][/COLOR][COLOR FF9E9E9E][B]-FEHÉR[/B][/COLOR]')
    elif d.get('color'):
        tags.append(''.join('[COLOR %s][B]%s[/B][/COLOR]' % (c, ch) for c, ch in
                            zip(('FFFF0000', 'FFFF8C00', 'FFFFFF00', 'FF00FF00', 'FF00BFFF', 'FFB44CFF'), 'SZÍNES')))
    if d['pack']:
        tags.append(_c(C_WARN, 'PACK'))
    parts = ['  '.join(tags)]
    tech = []
    if d['codec']:
        tech.append(d['codec'])
    if d['audio']:
        tech.append(_c(C_AUDIO, d['audio'] + ((' ' + d['ch']) if d['ch'] else '')))
    elif d['ch']:
        tech.append(d['ch'])
    if tech:
        parts.append('  \u00b7  '.join(tech))
    label1 = '  \u00b7  '.join(parts)

    n = _seed_int(seeders)
    s_col = C_BAD if n == 0 else (C_WARN if n < 5 else C_GOOD)
    l2 = []
    src = ' '.join(x for x in (d['source'], d['svc']) if x)
    if src:
        l2.append(src)
    if size:
        l2.append(str(size))
    l2.append(_c(s_col, 'S:%s' % n))
    if d['group']:
        l2.append(_c(C_DIM, d['group']))
    if q.hun:
        l2.append(_c(C_HU, 'HU' + (' sub' if d['hunsub'] else '')))
    label2 = '  \u00b7  '.join(l2)
    return label1, label2

