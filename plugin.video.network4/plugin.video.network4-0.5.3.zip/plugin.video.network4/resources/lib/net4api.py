# -*- coding: utf-8 -*-
"""
Network4 / Arena4+ - a hivatalos mobilalkalmazás API-ja (net4plus.network4.hu/api).

A plugin.video.arena4plus (szerzők: heg, vargalex; GPL-3.0) alapján feltérképezve
(új kód, nem fork):
    GET /api/login?email=..&password=..      -> {"access_token": "..."}   (Bearer)
    GET /api/collections                       -> [{title, slug, photo_thumbnail}, ...]
    GET /api/collectionitems/<slug>/<n>        -> [{vodsavail: [{title, short_desc,
                                                   poster_remote, vodviewer}, ...]}]
    GET /api/collectionitemslive/live/0        -> [{liveeventsavail: [{title, slug, status
                                                   (live/pre), expected_start, ...}]}]
    GET /api/watch/<slug>/live                 -> {src, replaysrc}
    GET /api/search/<szó>                      -> [{title, short_desc, vodviewer, ...}]
    VOD: a "vodviewer" oldalban: playbackUrl ... "https://...uplynk..."; 2026-09 óta nincs
         vodviewer - helyette https://content.uplynk.com/<verizon_id>.m3u8 (token: 0 esetén)

Nem a weboldalt (www.network4.hu) használjuk. Az API is Cloudflare mögött van, ezért
- a tulajdonos kérésére, az arena4plus-szal azonosan - a cloudscraper (MIT) kezeli a
Cloudflare-ellenőrzést (resources/lib/modules; kikapcsolható a beállításokban).
Kímélet: 1 mp szünet a kérések között, gyorsítótár (gyűjtemények / listák 6 óra),
a token lemezen, 401-nél egyszeri újrabelépés, sikertelen belépés után 10 perc szünet.
"""
import json
import os
import re
import sys
import time

try:
    from urllib.parse import quote
except ImportError:  # py2
    from urllib import quote

import xbmc
import xbmcaddon
import xbmcvfs

try:
    import requests
except ImportError:  # noqa
    requests = None

ADDON = xbmcaddon.Addon('plugin.video.network4')
ADDON_ID = 'plugin.video.network4'
API = 'https://net4plus.network4.hu/api'
STORAGE = 'https://net4plus.network4.hu/storage/'
FIREFOX_UA = 'Mozilla/5.0 (Android 16; Mobile; rv:156.0) Gecko/156.0 Firefox/156.0'
APP_UA = 'Dart/3.6 (dart:io)'
MIN_GAP = 1.0
LOGIN_COOLDOWN = 600
TOKEN_FILE = 'token.json'     # (a 0.1.x session.json-ja süti-lista volt)
LIST_TTL = 6 * 3600

CF_RETRIES = 2            # Cloudflare-hiba esetén ennyi újrapróba (5 mp szünettel)

_SESSION = None
_LAST = [0.0]


def _use_cloudscraper():
    return ADDON.getSetting('cloudscraper') != 'false'


def session():
    """Egy munkamenet a futás idejére. Alapból cloudscraper (mint a plugin.video.arena4plus:
    a net4plus API Cloudflare mögött van); kikapcsolva / hiányzó modulnál sima requests."""
    global _SESSION
    if _SESSION is not None:
        return _SESSION
    if requests is None:
        raise ApiError('Hiányzik a script.module.requests')
    if _use_cloudscraper():
        mod = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'modules')
        if mod not in sys.path:
            sys.path.insert(0, mod)
        try:
            import cloudscraper
            _SESSION = cloudscraper.create_scraper()
            return _SESSION
        except Exception as exc:  # noqa
            log('cloudscraper nem tölthető be (%s) - sima requests' % exc, xbmc.LOGWARNING)
    _SESSION = requests.Session()
    return _SESSION


class ApiError(Exception):
    pass


class ChallengeError(ApiError):
    """Cloudflare-kihívás, amit a cloudscraper sem tudott teljesíteni."""


class LoginError(ApiError):
    pass


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def api_user_agent():
    # alapból a mobilalkalmazás UA-ja (mint az arena4plus); választható a Firefox is
    return FIREFOX_UA if ADDON.getSetting('api_ua2') == '1' else APP_UA


def profile(name=''):
    prof = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(prof):
        try:
            os.makedirs(prof)
        except OSError:
            pass
    return os.path.join(prof, name)


def _read_json(name, default=None):
    """JSON a profil-mappából. Csak objektumot (dict) fogad el - a régi (0.1.x)
    verzió más szerkezetű fájljai (pl. süti-lista) így nem okoznak hibát."""
    try:
        with open(profile(name), 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (IOError, OSError, ValueError):
        return default
    return data if isinstance(data, dict) else default


def _write_json(name, data):
    try:
        with open(profile(name), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except (IOError, OSError) as exc:
        log('%s mentési hiba: %s' % (name, exc), xbmc.LOGWARNING)


# ---------------------------------------------------------------------------
# Számláló + HTTP
# ---------------------------------------------------------------------------
def _bump():
    today = time.strftime('%Y-%m-%d')
    data = _read_json('requests.json', {}) or {}
    if data.get('date') != today:
        data = {'date': today, 'count': 0}
    data['count'] = int(data.get('count', 0)) + 1
    _write_json('requests.json', data)


def today_requests():
    data = _read_json('requests.json', {}) or {}
    return int(data.get('count', 0)) if data.get('date') == time.strftime('%Y-%m-%d') else 0


def is_challenge(resp):
    if resp is None:
        return False
    if resp.headers.get('cf-mitigated', '').lower() == 'challenge':
        return True
    if resp.status_code in (403, 503) and 'text/html' in resp.headers.get('content-type', ''):
        body = resp.text[:4000]
        return '_cf_chl_opt' in body or 'Just a moment' in body or 'challenge-platform' in body
    return False


def _http(url, headers, params=None, timeout=25):
    sess = session()
    for attempt in range(CF_RETRIES + 1):
        gap = time.time() - _LAST[0]
        if gap < MIN_GAP:
            time.sleep(MIN_GAP - gap)
        _LAST[0] = time.time()
        _bump()
        log('GET %s%s' % (url.split('?')[0], ' (újra %d.)' % attempt if attempt else ''))
        try:
            resp = sess.get(url, params=params, headers=headers, timeout=timeout)
        except requests.exceptions.RequestException as exc:
            raise ApiError('Hálózati hiba: %s' % exc)
        except Exception as exc:  # noqa - a cloudscraper saját kivételei (pl. CloudflareChallengeError)
            log('Cloudflare / cloudscraper hiba: %s' % exc, xbmc.LOGWARNING)
            resp = None
        if resp is not None and not is_challenge(resp):
            return resp
        if resp is not None:
            _save_debug('challenge.html', resp.text)
        if attempt < CF_RETRIES:
            xbmc.sleep(5000)
    raise ChallengeError('Cloudflare-kihívás (%d próbálkozás után)' % (CF_RETRIES + 1))


def _save_debug(name, text):
    try:
        with open(profile(name), 'w', encoding='utf-8') as f:
            f.write(text or '')
    except (IOError, OSError):
        pass


def _api_headers(token=None):
    h = {'User-Agent': api_user_agent(), 'Accept': 'application/json, text/plain, */*'}
    if token:
        h['Authorization'] = 'Bearer %s' % token
    return h


# ---------------------------------------------------------------------------
# Belépés / token
# ---------------------------------------------------------------------------
def credentials():
    return ADDON.getSetting('email').strip(), ADDON.getSetting('password')


def have_credentials():
    e, p = credentials()
    return bool(e and p)


def saved_token():
    return (_read_json(TOKEN_FILE, {}) or {}).get('token')


def clear_token():
    try:
        os.remove(profile(TOKEN_FILE))
    except OSError:
        pass


def login():
    email, password = credentials()
    if not (email and password):
        raise LoginError('Add meg az email címet és a jelszót a beállításokban')
    last_fail = (_read_json(TOKEN_FILE, {}) or {}).get('failed', 0)
    if time.time() - last_fail < LOGIN_COOLDOWN:
        raise LoginError('Az előző belépés nem sikerült - 10 perc múlva próbálkozom újra '
                         '(vagy: Munkamenet törlése)')
    resp = _http(API + '/login', _api_headers(), params={'email': email, 'password': password})
    token = None
    try:
        token = resp.json().get('access_token')
    except ValueError:
        pass
    if resp.status_code == 200 and token:
        _write_json(TOKEN_FILE, {'token': token, 'ts': int(time.time())})
        log('Bejelentkezés sikeres.')
        return token
    _write_json(TOKEN_FILE, {'failed': int(time.time())})
    log('Bejelentkezés SIKERTELEN (HTTP %s): %s' % (resp.status_code, resp.text[:200]),
        xbmc.LOGWARNING)
    raise LoginError('Sikertelen belépés (HTTP %s) - ellenőrizd az email címet / jelszót'
                     % resp.status_code)


def token():
    return saved_token() or login()


def api_get(path, auth=True):
    """JSON a /api alól; 401/403-nál egyszer újra belép."""
    url = API + path
    tok = token() if auth else None
    resp = _http(url, _api_headers(tok))
    if auth and resp.status_code in (401, 403):
        log('Lejárt token (HTTP %s) - újrabelépés' % resp.status_code)
        clear_token()
        resp = _http(url, _api_headers(login()))
    if resp.status_code != 200:
        raise ApiError('HTTP %s: %s' % (resp.status_code, path))
    try:
        return resp.json()
    except ValueError:
        _save_debug('last_response.txt', resp.text)
        raise ApiError('Nem JSON válasz: %s' % path)


def cached(key, ttl, fetch):
    name = 'cache_%s.json' % re.sub(r'[^\w.-]', '_', key)[:80]
    data = _read_json(name)
    if data and time.time() - data.get('ts', 0) < ttl:
        return data['data']
    try:
        fresh = fetch()
    except ApiError:
        if data:
            log('hálózati hiba - a korábbi (%s) adat marad' % key, xbmc.LOGWARNING)
            return data['data']
        raise
    if fresh:
        _write_json(name, {'ts': time.time(), 'data': fresh})
    return fresh


def clear_cache():
    n = 0
    for name in os.listdir(profile()):
        if name.startswith('cache_'):
            try:
                os.remove(profile(name))
                n += 1
            except OSError:
                pass
    return n


# ---------------------------------------------------------------------------
# Tartalom
# ---------------------------------------------------------------------------
EXCLUDED = ('Élő közvetítések', 'Előzmények', 'Kedvenceim', 'Leading Articles',
            'Opinion Articles', 'Podcasts')


def _s(value):
    """Szöveg a JSON-mezőből. A szerver néha null-t, "null"-t, számot vagy listát ad
    (pl. cast_crew, meta, duration) - ezekből üres vagy egyszerű szöveg lesz."""
    if value is None or isinstance(value, (dict, list)):
        return ''
    value = value if isinstance(value, str) else str(value)
    value = value.strip()
    return '' if value.lower() == 'null' else value


def _first(data):
    """A lista-gyökerű válasz első objektuma ([{...}] -> {...}); egyébként {}."""
    if isinstance(data, list):
        data = data[0] if data else {}
    return data if isinstance(data, dict) else {}


def _dicts(value):
    """Csak a dict elemek egy listából (egyébként üres lista)."""
    return [i for i in value if isinstance(i, dict)] if isinstance(value, list) else []


def image(item):
    if _s(item.get('poster_remote')):
        return _s(item['poster_remote'])
    if _s(item.get('thumbnail_remote')):
        return _s(item['thumbnail_remote'])
    if _s(item.get('photo_thumbnail')):
        return STORAGE + _s(item['photo_thumbnail'])
    return ''


def collections():
    data = cached('collections', LIST_TTL, lambda: api_get('/collections'))
    out = []
    for c in _dicts(data):
        title, slug = _s(c.get('title')), _s(c.get('slug'))
        if title and slug and title not in EXCLUDED:
            out.append({'title': title, 'slug': slug, 'thumb': image(c)})
    return out


UPLYNK_HLS = 'https://content.uplynk.com/%s.m3u8'
_ASSET_RE = re.compile(r'^[0-9a-f]{32}$')


def _vod(item):
    """A lejátszási cím: a régi "vodviewer" oldal, ha van; 2026-09 óta az API nem adja,
    ekkor a "verizon_id" (Uplynk asset) HLS-címe. A "token": 1 elemekhez aláírt
    lejátszás kellene (a kulcs 403-at ad), ezeket "locked"-nak jelöljük."""
    viewer = _s(item.get('vodviewer'))
    asset = _s(item.get('verizon_id')).lower()
    url = viewer or (UPLYNK_HLS % asset if _ASSET_RE.match(asset) else '')
    return {'title': _s(item.get('title')), 'desc': _s(item.get('short_desc')),
            'thumb': image(item), 'url': url,
            'locked': not viewer and _s(item.get('token')) not in ('', '0'),
            'plot': (_s(item.get('long_desc')) or _s(item.get('description')) or
                     _s(item.get('short_desc')))}


def _vods(items):
    """Lejátszható videók (a "subvods" összefoglalók a meccs után); a nem dict /
    lejátszási cím nélküli elemek kimaradnak."""
    out = []
    for i in _dicts(items):
        out.append(_vod(i))
        out.extend(_vod(sub) for sub in _dicts(i.get('subvods')))
    return [v for v in out if v['url']]


def is_direct(url):
    """Közvetlenül lejátszható (Uplynk HLS) cím - nem kell a vodviewer oldal."""
    return url.startswith('https://content.uplynk.com/') and url.endswith('.m3u8')


def _series_vods(series):
    """A "series" objektum évadlistáiból (pl. {"1": [...], "22": [...]}). Csak a
    listaértékűeket vesszük: a szerver időnként egy üres kulcsú, dict értékű
    szemetet is küld ("": {"series": {...}}), az kimarad."""
    out, seen = [], set()
    if not isinstance(series, dict):
        return out
    for season, eps in series.items():
        if not season or not isinstance(eps, list):
            continue
        for v in _vods(eps):
            if v['url'] not in seen:
                seen.add(v['url'])
                out.append(v)
    return out


def collection_items(slug):
    # az alkalmazás a 11-es "oldal" paraméterrel kéri le a teljes listát
    data = _first(cached('items_' + slug, LIST_TTL,
                         lambda: api_get('/collectionitems/%s/11' % quote(slug, ''),
                                         auth=False)))
    vods = _vods(data.get('vodsavail')) or _series_vods(data.get('series'))
    if not vods:
        _explain_empty(slug, data)
    return vods


def _explain_empty(slug, data):
    """Üres lista esetén a kodi.log-ba írja, mi jött valójában, és elmenti a nyers
    választ (last_collection.json) - ebből látszik, ha a szerver átnevezett egy mezőt."""
    items = data.get('vodsavail')
    first = _dicts(items)[:1]
    series = data.get('series')
    log('"%s": nincs lejátszható videó. Kulcsok: %s | vodsavail: %s db (%s) | '
        'első elem mezői: %s | series: %s'
        % (slug, sorted(data.keys()), len(items) if isinstance(items, list) else '-',
           type(items).__name__, sorted(first[0].keys()) if first else '-',
           ', '.join('%r:%s' % (k, type(v).__name__) for k, v in series.items())
           if isinstance(series, dict) else type(series).__name__), xbmc.LOGWARNING)
    if first:
        log('első elem: %s' % json.dumps(first[0], ensure_ascii=False)[:1500], xbmc.LOGWARNING)
    _write_json('last_collection.json', {'slug': slug, 'data': data})


def search(term):
    data = api_get('/search/%s' % quote(term, ''), auth=False)
    return _vods(data)


def live_events():
    data = _first(api_get('/collectionitemslive/live/0'))
    out = []
    for e in _dicts(data.get('liveeventsavail')):
        if _s(e.get('slug')):
            out.append({'title': _s(e.get('title')), 'desc': _s(e.get('short_desc')),
                        'slug': _s(e['slug']), 'status': _s(e.get('status')),
                        'start': _s(e.get('expected_start')), 'stop': _s(e.get('expected_stop')),
                        'thumb': image(e)})
    return out


def live_sources(slug):
    data = _first(api_get('/watch/%s/live' % quote(slug, '')))
    return {'live': _s(data.get('src')), 'replay': _s(data.get('replaysrc'))}


_PLAYBACK_RE = re.compile(r'playbackUrl.{0,40}?(https:[^"\'\s<>]*uplynk[^"\'\s<>]*)', re.S)


def vod_stream(viewer_url):
    """A vodviewer oldalból az Uplynk lejátszási URL."""
    resp = _http(viewer_url, {'User-Agent': FIREFOX_UA,
                              'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8'})
    m = _PLAYBACK_RE.search(resp.text)
    if not m:
        _save_debug('last_vodviewer.html', resp.text)
        raise ApiError('Nem található lejátszási URL (mentve: last_vodviewer.html)')
    return m.group(1).replace('\\/', '/')
